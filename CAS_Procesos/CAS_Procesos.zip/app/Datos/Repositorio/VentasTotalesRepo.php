<?php

	namespace Datos\Repositorio;
	
	class VentasTotalesRepo{
		
		// MM 06/06/2017	- 	carga premios completa
		
		/************************************************/
		/*		carga ctaspcia_totales			*/
		/************************************************/
		
		public static function cargarVtDat($archivo,$juego, $sorteo,$usuario){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$formatoHora = '%H:%i:%s';
				$cod_juego = $juego;
				$id_usuario = $usuario;
				$nrosorteo = $sorteo;
				//-- 
				// nuevo formato
				// DELETE FROM sor_rec_ctaspcia_totales WHERE codigo_juego = $juego;
				// 
				$query =sprintf("
				
					TRUNCATE TABLE sor_rec_ctaspcia_totales ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_ctaspcia_totales`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
						`ctap_codigo_provincia`=SUBSTR(@registro,1,2),
						`ctap_aporte_premios_pp`=CAST(SUBSTR(@registro,3,15)/100 AS DECIMAL(18,2)),
						`ctap_gastos_adm_pp`=CAST(SUBSTR(@registro,18,15)/100 AS DECIMAL(18,2)),
						`ctap_aporte_premios_re`=CAST(SUBSTR(@registro,33,15)/100 AS DECIMAL(18,2)),
						`ctap_gastos_adm_re`=CAST(SUBSTR(@registro,48,15)/100 AS DECIMAL(18,2)),
						`ctap_fondo_comun_re`=CAST(SUBSTR(@registro,63,15)/100 AS DECIMAL(18,2)),
						`ctap_aporte_premios_sos`=CAST(SUBSTR(@registro,78,15)/100 AS DECIMAL(18,2)),
						`ctap_gastos_adm_sos`=CAST(SUBSTR(@registro,93,15)/100 AS DECIMAL(18,2)),
						`ctap_fondo_comun_sos`=CAST(SUBSTR(@registro,108,15)/100 AS DECIMAL(18,2)),
						`ctap_prem_6aciertos_pp`=CAST(SUBSTR(@registro,123,15)/100 AS DECIMAL(18,2)),
						`ctap_prem_5aciertos_pp`=CAST(SUBSTR(@registro,138,15)/100 AS DECIMAL(18,2)),
						`ctap_prem_4aciertos_pp`=CAST(SUBSTR(@registro,153,15)/100 AS DECIMAL(18,2)),
						`ctap_prem_estimulo_pp`=CAST(SUBSTR(@registro,168,15)/100 AS DECIMAL(18,2)),
						`ctap_prem_6aciertos_re`=CAST(SUBSTR(@registro,183,15)/100 AS DECIMAL(18,2)),
						`ctap_prem_estimulo_re`=CAST(SUBSTR(@registro,198,15)/100 AS DECIMAL(18,2)),
						`ctap_prem_6aciertos_sos`=CAST(SUBSTR(@registro,213,15)/100 AS DECIMAL(18,2)),
						`ctap_prem_estimulo_sos`=CAST(SUBSTR(@registro,228,15)/100 AS DECIMAL(18,2)),
						`ctap_prem_especial`=CAST(SUBSTR(@registro,243,15)/100 AS DECIMAL(18,2)),
						`ctap_retenciones`=CAST(SUBSTR(@registro,258,15)/100 AS DECIMAL(18,2)),
						`ctap_tot_deuda`=CAST(SUBSTR(@registro,273,15)/100 AS DECIMAL(18,2)),
						`ctap_fecha`=str_to_date(curdate(),'%s'),
						`ctap_hora`=str_to_date(now(),'%s'),
						`codigo_juego`=CONVERT('%s',UNSIGNED INTEGER),
						`id_usuario`='%s',
						`nrosorteo`=CONVERT('%s',UNSIGNED INTEGER);",
						addslashes($archivo),
						addslashes($formatoFecha),
						addslashes($formatoHora),
						addslashes($cod_juego),
						addslashes($id_usuario),
						addslashes($nrosorteo));

		/*
					SET 
					`ctap_codigo_provincia`=SUBSTR(@registro,1,2),
					`ctap_aporte_premios_pp`=CAST(SUBSTR(@registro,3,15)/100 AS DECIMAL(18,2)),
					`ctap_gastos_adm_pp`=CAST(SUBSTR(@registro,14,11)/100 AS DECIMAL(18,2)),
					`ctap_gastos_prc_pp`=CAST(SUBSTR(@registro,25,11)/100 AS DECIMAL(18,2)),
					`ctap_aporte_premios_re`=CAST(SUBSTR(@registro,36,11)/100 AS DECIMAL(18,2)),
					`ctap_gastos_adm_re`=CAST(SUBSTR(@registro,47,11)/100 AS DECIMAL(18,2)),
					`ctap_gastos_prc_re`=CAST(SUBSTR(@registro,58,11)/100 AS DECIMAL(18,2)),
					`ctap_fondo_comun_re`=CAST(SUBSTR(@registro,69,11)/100 AS DECIMAL(18,2)),
					`ctap_aporte_premios_sos`=CAST(SUBSTR(@registro,80,11)/100 AS DECIMAL(18,2)),
					`ctap_gastos_adm_sos`=CAST(SUBSTR(@registro,91,11)/100 AS DECIMAL(18,2)),
					`ctap_gastos_prc_sos`=CAST(SUBSTR(@registro,102,11)/100 AS DECIMAL(18,2)),
					`ctap_fondo_comun_sos`=CAST(SUBSTR(@registro,113,11)/100 AS DECIMAL(18,2)),
					`ctap_prem_6aciertos_pp`=CAST(SUBSTR(@registro,124,11)/100 AS DECIMAL(18,2)),
					`ctap_prem_5aciertos_pp`=CAST(SUBSTR(@registro,135,11)/100 AS DECIMAL(18,2)),
					`ctap_prem_4aciertos_pp`=CAST(SUBSTR(@registro,146,11)/100 AS DECIMAL(18,2)),
					`ctap_prem_estimulo_pp`=CAST(SUBSTR(@registro,157,11)/100 AS DECIMAL(18,2)),
					`ctap_prem_6aciertos_re`=CAST(SUBSTR(@registro,168,11)/100 AS DECIMAL(18,2)),
					`ctap_prem_estimulo_re`=CAST(SUBSTR(@registro,179,11)/100 AS DECIMAL(18,2)),
					`ctap_prem_6aciertos_sos`=CAST(SUBSTR(@registro,190,11)/100 AS DECIMAL(18,2)),
					`ctap_prem_estimulo_sos`=CAST(SUBSTR(@registro,201,11)/100 AS DECIMAL(18,2)),
					`ctap_prem_especial`=CAST(SUBSTR(@registro,212,11)/100 AS DECIMAL(18,2)),
					`ctap_retenciones`=CAST(SUBSTR(@registro,223,11)/100 AS DECIMAL(18,2)),
					`ctap_tot_deuda`=CAST(0 AS DECIMAL(18,2)),
					`ctap_fecha`=str_to_date(curdate(),'%s'),
					`ctap_hora`=str_to_date(now(),'%s'),
					`codigo_juego`=CONVERT('%s',UNSIGNED INTEGER),
					`id_usuario`='%s',
					`nrosorteo`=CONVERT('%s',UNSIGNED INTEGER);",
			    	addslashes($archivo),addslashes($formatoFecha),addslashes($formatoHora),addslashes($cod_juego),addslashes($id_usuario),addslashes($nrosorteo));

		*/
		/*
				switch ($juego) {
					case 4:              // Quini 6
					$query =sprintf("
							DELETE FROM sor_rec_ctaspcia_totales WHERE codigo_juego = $juego;
							LOAD DATA 
									INFILE '%s' INTO TABLE `sor_rec_ctaspcia_totales`
									LINES TERMINATED BY '\n'
									(@registro)
									SET 
										`ctap_codigo_provincia`=SUBSTR(@registro,1,2),
										`ctap_aporte_premios_pp`=CAST(SUBSTR(@registro,3,15)/100 AS DECIMAL(18,2)),
										`ctap_gastos_adm_pp`=CAST(SUBSTR(@registro,18,15)/100 AS DECIMAL(18,2)),
										`ctap_aporte_premios_re`=CAST(SUBSTR(@registro,33,15)/100 AS DECIMAL(18,2)),
										`ctap_gastos_adm_re`=CAST(SUBSTR(@registro,48,15)/100 AS DECIMAL(18,2)),
										`ctap_fondo_comun_re`=CAST(SUBSTR(@registro,63,15)/100 AS DECIMAL(18,2)),
										`ctap_aporte_premios_sos`=CAST(SUBSTR(@registro,78,15)/100 AS DECIMAL(18,2)),
										`ctap_gastos_adm_sos`=CAST(SUBSTR(@registro,93,15)/100 AS DECIMAL(18,2)),
										`ctap_fondo_comun_sos`=CAST(SUBSTR(@registro,108,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_6aciertos_pp`=CAST(SUBSTR(@registro,123,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_5aciertos_pp`=CAST(SUBSTR(@registro,138,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_4aciertos_pp`=CAST(SUBSTR(@registro,153,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_estimulo_pp`=CAST(SUBSTR(@registro,168,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_6aciertos_re`=CAST(SUBSTR(@registro,183,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_estimulo_re`=CAST(SUBSTR(@registro,198,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_6aciertos_sos`=CAST(SUBSTR(@registro,213,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_estimulo_sos`=CAST(SUBSTR(@registro,228,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_especial`=CAST(SUBSTR(@registro,243,15)/100 AS DECIMAL(18,2)),
										`ctap_retenciones`=CAST(SUBSTR(@registro,258,15)/100 AS DECIMAL(18,2)),
										`ctap_tot_deuda`=CAST(SUBSTR(@registro,273,15)/100 AS DECIMAL(18,2)),
										`ctap_fecha`=str_to_date(curdate(),'%s'),
										`ctap_hora`=str_to_date(now(),'%s'),
										`codigo_juego`=CONVERT('%s',UNSIGNED INTEGER),
										`id_usuario`='%s',
										`nrosorteo`=CONVERT('%s',UNSIGNED INTEGER);",
							addslashes($archivo),
							addslashes($formatoFecha),
							addslashes($formatoHora),
							addslashes($cod_juego),
							addslashes($id_usuario),
							addslashes($nrosorteo));

						break;
					case 13:             // Brinco
					$query =sprintf("
							DELETE FROM sor_rec_ctaspcia_totales WHERE codigo_juego = $juego;
							LOAD DATA 
									INFILE '%s' INTO TABLE `sor_rec_ctaspcia_totales`
									LINES TERMINATED BY '\n'
									(@registro)
									SET 
										`ctap_codigo_provincia`=SUBSTR(@registro,1,2),
										`ctap_aporte_premios_pp`=CAST(SUBSTR(@registro,3,15)/100 AS DECIMAL(18,2)),
										`ctap_gastos_adm_pp`=CAST(SUBSTR(@registro,18,15)/100 AS DECIMAL(18,2)),
										`ctap_fondo_comun_pp`=CAST(SUBSTR(@registro,63,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_6aciertos_pp`=CAST(SUBSTR(@registro,123,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_5aciertos_pp`=CAST(SUBSTR(@registro,138,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_4aciertos_pp`=CAST(SUBSTR(@registro,153,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_estimulo_pp`=CAST(SUBSTR(@registro,168,15)/100 AS DECIMAL(18,2)),
										`ctap_retenciones`=CAST(SUBSTR(@registro,258,15)/100 AS DECIMAL(18,2)),
										`ctap_fecha`=str_to_date(curdate(),'%s'),
										`ctap_hora`=str_to_date(now(),'%s'),
										`codigo_juego`=CONVERT('%s',UNSIGNED INTEGER),
										`id_usuario`='%s',
										`nrosorteo`=CONVERT('%s',UNSIGNED INTEGER);",
							addslashes($archivo),
							addslashes($formatoFecha),
							addslashes($formatoHora),
							addslashes($cod_juego),
							addslashes($id_usuario),
							addslashes($nrosorteo));
						
						break;
					case 30:             // Poceada Federal
					$query =sprintf("
							DELETE FROM sor_rec_ctaspcia_totales WHERE codigo_juego = $juego;
							LOAD DATA 
									INFILE '%s' INTO TABLE `sor_rec_ctaspcia_totales`
									LINES TERMINATED BY '\n'
									(@registro)
									SET 
										`ctap_codigo_provincia`=SUBSTR(@registro,1,2),
										`ctap_aporte_premios_pp`=CAST(SUBSTR(@registro,3,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_6aciertos_pp`=CAST(SUBSTR(@registro,123,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_5aciertos_pp`=CAST(SUBSTR(@registro,138,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_4aciertos_pp`=CAST(SUBSTR(@registro,153,15)/100 AS DECIMAL(18,2)),
										`ctap_prem_estimulo_pp`=CAST(SUBSTR(@registro,168,15)/100 AS DECIMAL(18,2)),
										`ctap_fecha`=str_to_date(curdate(),'%s'),
										`ctap_hora`=str_to_date(now(),'%s'),
										`codigo_juego`=CONVERT('%s',UNSIGNED INTEGER),
										`id_usuario`='%s',
										`nrosorteo`=CONVERT('%s',UNSIGNED INTEGER);",
							addslashes($archivo),
							addslashes($formatoFecha),
							addslashes($formatoHora),
							addslashes($cod_juego),
							addslashes($id_usuario),
							addslashes($nrosorteo));
						break;
				}	
*/				
				$db= \DB::connection('suitecrm');
				\Log::info("comenzó carga sor_rec_ctaspcia_totales");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminó carga sor_rec_ctaspcia_totales");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de totales sor_rec_ctaspcia_totales");
				\Log::info($e);
				return false;
			}
		}
	
		
		/****************************************/
		/* 		ctaspcia_modalidades		*/
		/****************************************/
		
		public static function cargarVtModalidades($archivo,$juego, $sorteo,$usuario,$tipoTrf){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$tipoTrf_V = $tipoTrf;
				$cod_juego = $juego;
				$id_usuario = $usuario;
				$nrosorteo = $sorteo;
				$query =sprintf("
					DELETE FROM sor_rec_ctaspcia_modalidades WHERE codigo_juego = $juego AND ctapm_modalidad_sorteo = $tipoTrf;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_ctaspcia_modalidades`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`ctapm_codigo_provincia`=SUBSTR(@registro,1,2),
					`ctapm_cant_cupones`=SUBSTR(@registro,3,9),
					`ctapm_recaudacion`=CAST(SUBSTR(@registro,12,15)/100 AS DECIMAL(18,2)),
					`ctapm_comision`=CAST(SUBSTR(@registro,27,15)/100 AS DECIMAL(18,2)),
					`ctapm_pozo_premios`=CAST(SUBSTR(@registro,42,15)/100 AS DECIMAL(18,2)),
					`ctapm_arancel`=CAST(SUBSTR(@registro,57,15)/100 AS DECIMAL(18,2)),
					`ctapm_gastos_adm`=CAST(SUBSTR(@registro,72,15)/100 AS DECIMAL(18,2)),
					`ctapm_modalidad_sorteo`=('%s'),
					`ctapm_fecha`=str_to_date(curdate(),'%s'),
					`codigo_juego`=CONVERT('%s',UNSIGNED INTEGER),
					`id_usuario`='%s',
					`nrosorteo`=CONVERT('%s',UNSIGNED INTEGER);",
			    	addslashes($archivo),addslashes($tipoTrf_V),addslashes($formatoFecha),addslashes($cod_juego),addslashes($id_usuario),addslashes($nrosorteo));
				$db=  \DB::connection('suitecrm');
				\Log::info("comenzó carga sor_rec_ctaspcia_modalidades");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminó carga sor_rec_ctaspcia_modalidades");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de totales transferencia en la tabla sor_rec_ctaspcia_modalidades");
				\Log::info($e);
				return false;
			}
		}		
		
		/****************************************/
		/* 		ctas prov reserva				*/
		/****************************************/
		
		public static function cargarVtRes($archivo,$usuario,$juego){
			try{
				$archivo=str_replace("\\", "/", $archivo);

				\Log::info('lista archivos reserva aden -> ',array($archivo));
				
				$formatoFecha = '%Y%m%d';
				// $tipoTrf_V = $tipoTrf;
				$cod_juego = $juego;
				$id_usuario = $usuario;
				//$nrosorteo = $sorteo;
				/*
					`sor_producto_id_c`=SUBSTR(@registro,34,11),
					`sor_pgmsorteo_id_c`=SUBSTR(@registro,34,11),
				*/
				// TRUNCATE TABLE `sor_rec_ctaspcia_reservas` ; 
				$query =sprintf("
					DELETE  FROM sor_rec_ctaspcia_reservas WHERE juego = $juego;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_ctaspcia_reservas`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`juego`=CONVERT('%s',UNSIGNED INTEGER),
					`sorteo`=SUBSTR(@registro,3,5),
					`concepto`=SUBSTR(@registro,8,3),
					`importe`=CAST(SUBSTR(@registro,11,15)/100 AS DECIMAL(18,2)),
					`fecha`=str_to_date(curdate(),'%s'),
					`id_usuario`='%s';",
			    	addslashes($archivo),addslashes($cod_juego),addslashes($formatoFecha),addslashes($id_usuario));
				$db=  \DB::connection('suitecrm');
				\Log::info("comenzó carga sor_rec_ctaspcia_reserva");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminó carga sor_rec_ctaspcia_reserva");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de totales transferencia en la tabla sor_rec_ctaspcia_reserva");
				\Log::info($e);
				return false;
			}
		}		
			

		/********************************************/
		/*		premios retencion completo			*/
		/********************************************/
		
			public static function cargarPremiosCompletoRetDet($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				//if(strpos(strtolower($archivo), 'detall')!==false){
					$query =sprintf("
						TRUNCATE TABLE `sor_rec_premios_detalle` ;
						LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_detalle`
						LINES TERMINATED BY '\n'
						(@registro)
						SET 
						`codigo_provincia`=SUBSTR(@registro,1,2),
						`id_juego`=SUBSTR(@registro,3,3),
						`nro_emision`=SUBSTR(@registro,6,8),
						`nro_ticket`=SUBSTR(@registro,14,10),
						`digito_verificador`=SUBSTR(@registro,24,1),
						`nro_parte_panel`=SUBSTR(@registro,25,3),
						`clase_premio`=SUBSTR(@registro,28,1),
						`tipo_de_premio`=SUBSTR(@registro,29,1),
						`codigo_concepto`=SUBSTR(@registro,30,3),
						`importe`=CAST(SUBSTR(@registro,33,17)/100 AS DECIMAL(18,2));",
				    	addslashes($archivo));
				/*
				}else{
					$query =sprintf("
						TRUNCATE TABLE `sor_rec_premios_ret` ;
						LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_ret`
						LINES TERMINATED BY '\n'
						(@registro)
						SET 
						`id_juego`=SUBSTR(@registro,1,2),
						`nro_emision`=SUBSTR(@registro,3,8),
						`id_juego_asociado`=SUBSTR(@registro,11,2),
						`nro_emision_asociada`=SUBSTR(@registro,13,8),
						`codigo_provincia`=SUBSTR(@registro,21,2),
						`nro_ticket`=SUBSTR(@registro,23,10),
						`clase_premio`=SUBSTR(@registro,33,1),
						`codigo_concepto`=SUBSTR(@registro,34,3),
						`importe`=SUBSTR(@registro,37,13);",
				    	addslashes($archivo));
				}
				*/
				
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga pre_det_ret");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga pre_det_ret");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de premios ret/det en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		/************************************		MM 06/06/2017	********************/		
		public static function cargarPremiosControl($archivo, $archivoPremios){
			try{	
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoPremios);			
			
				//obtenemos el contenido del archivo
				$xml = file_get_contents($archivo);
				//instanciamos la clase
				$DOM = new \DOMDocument('1.0', 'utf-8');
				//leemos el contenido de la variable 
				$DOM->loadXML($xml);
				//obtenemos los registros del archivo --> se crea un arreglo con los registros
				$registros = $DOM->getElementsByTagName('Registro');
				//recorremos el arreglo y accedemos a cada nodo y obtenemos el valor
				foreach($registros as $registro){
					$tipo_archivo=$registro->getElementsByTagName('tipo_archivo')->item(0)->nodeValue;			
					$version=$registro->getElementsByTagName('version')->item(0)->nodeValue;
					$nombre_archivo=$registro->getElementsByTagName('nombre_archivo')->item(0)->nodeValue;
					$provincia=$registro->getElementsByTagName('provincia')->item(0)->nodeValue;
					$juego=$registro->getElementsByTagName('juego')->item(0)->nodeValue;
					$sorteo=$registro->getElementsByTagName('sorteo')->item(0)->nodeValue;
					$sistema=$registro->getElementsByTagName('sistema')->item(0)->nodeValue;
					$cantidad_premios=$registro->getElementsByTagName('cantidad_premios')->item(0)->nodeValue;
					$importe_premios=$registro->getElementsByTagName('importe_premios')->item(0)->nodeValue;
					$importe_impuesto=$registro->getElementsByTagName('importe_impuesto')->item(0)->nodeValue;
					$md5_archivo=$registro->getElementsByTagName('md5')->item(0)->nodeValue;
				}
			
				//insertamos en la tabla
				$query = 'TRUNCATE TABLE sor_rec_pre_ctr ; ';
				$query =$query.'insert into sor_rec_pre_ctr(tipo_archivo, version, nombre_archivo, provincia, juego, sorteo, sistema, cantidad_premios, importe_premios, importe_impuesto, md5_archivo, md5_calculado)'
				.'values("'.$tipo_archivo.'",'.$version.',"'.$nombre_archivo.'",'.$provincia.','.$juego.','.$sorteo.','.$sistema.','.$cantidad_premios.','.$importe_premios.','.$importe_impuesto.',"'.$md5_archivo.'","'.$md5_calculado.'")';
				
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga pre_ctrl");
				$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga pre_ctrl");
				if($db->getPdo()->errorCode()== '00000'){
					return 1;
				}else{
					return 0;
				}
				
				}catch(\Exception $e){
					\Log::info("Error cargando el archivo de premios control en la tabla");
					\Log::info($e);
					return false;
				}
		}

		


		/******************************************************************
		* Funciones para carga de archivos de premios detalle y retención *
		*******************************************************************/
		public static function cargarPremiosRetencionControl($archivo, $archivoDR, $sobreEscribir){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoDR);
				\Log::info("empecé carga pre_ret");
				//tabla en la que se cargará
				$tabla='';
				if($sobreEscribir==1){
					//guardo el contenido del archivo
					$f=file($archivo);
					//reemplazo lo que sea necesario				
					$final = count($f);
					$nuevoContenido=[];				
					for($x=0; $x<=$final;$x++){
						if($x==0){
							array_push($nuevoContenido, '<?xml version="1.0" encoding="Windows-1252" standalone="yes"?>');
						}else if($x==1){
							array_push($nuevoContenido, '<Raiz>');					
							array_push($nuevoContenido, $f[$x]);
						}else if($x==$final){
							//array_push($nuevoContenido, '</Datos>');//agregado para prueba
							array_push($nuevoContenido, '</Raiz>');
						}else if($x<$final-1){
							array_push($nuevoContenido, $f[$x]);						
						}
					}
					
					$contenido=implode("", $nuevoContenido);
					$fp = fopen($archivo, 'w');
					fwrite($fp, $contenido);
					fclose($fp);
				}
				
				//obtenemos el contenido del archivo
				$xml = file_get_contents($archivo);
				//instanciamos la clase
				$DOM = new \DOMDocument('1.0', 'utf-8');
				//leemos el contenido de la variable 
				$DOM->loadXML($xml);

				//obtenemos los registros del archivo --> se crea un arreglo con los registros
				$registros = $DOM->getElementsByTagName('Registro');
				//recorremos el arreglo y accedemos a cada nodo y obtenemos el valor
				$db=  \DB::connection('suitecrm');		
				foreach($registros as $registro){
					$tipo_archivo=$registro->getElementsByTagName('tipo_archivo')->item(0)->nodeValue;			

					$version=$registro->getElementsByTagName('version')->item(0)->nodeValue;
					$nombre_archivo=$registro->getElementsByTagName('nombre_archivo')->item(0)->nodeValue;
					$juego=$registro->getElementsByTagName('juego')->item(0)->nodeValue;
					$sorteo=$registro->getElementsByTagName('sorteo')->item(0)->nodeValue;
					$cantidad_registros=$registro->getElementsByTagName('cantidad_registros')->item(0)->nodeValue;
					$md5_archivo=$registro->getElementsByTagName('md5')->item(0)->nodeValue;				
			
					if(strcasecmp(strtoupper($tipo_archivo),'DETALLE')==0 && strpos(strtoupper($archivoDR),'DETALL')!==false){
						$tabla='sor_rec_premios_det_ctr';
						//insertamos en la tabla
						$query = sprintf('TRUNCATE TABLE %s; ',$tabla);
						$query =sprintf($query.'insert into %s(tipo_archivo, version, nombre_archivo, juego, sorteo, cantidad_registros,  md5_archivo, md5_calculado)'
						.'values("'.$tipo_archivo.'",'.$version.',"'.$nombre_archivo.'",'.$juego.','.$sorteo.','.$cantidad_registros.',"'.$md5_archivo.'","'.$md5_calculado.'")',$tabla);
						$resultado=$db->getpdo()->exec($query);
					}else if(strcasecmp(strtoupper($tipo_archivo),'RETENCION')==0 && strpos(strtoupper($archivoDR),'RETEN')!==false){
						$tabla='sor_rec_premios_ret_ctr';
						//insertamos en la tabla
						$query = sprintf('TRUNCATE TABLE %s; ',$tabla);
						$query =sprintf($query.'insert into %s(tipo_archivo, version, nombre_archivo, juego, sorteo, cantidad_registros,  md5_archivo, md5_calculado)'
						.'values("'.$tipo_archivo.'",'.$version.',"'.$nombre_archivo.'",'.$juego.','.$sorteo.','.$cantidad_registros.',"'.$md5_archivo.'","'.$md5_calculado.'")',$tabla);
						$resultado=$db->getpdo()->exec($query);
					}
				}
				\Log::info("terminé carga pre_ret");
				if($db->getPdo()->errorCode()== '00000'){
					return 1;
				}else{
					return 0;
				}
				
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de premios control detalle/retención en las tablas");
				\Log::info($e);
				return false;
			}
		}

		public static function cargarPremiosRetDet($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				if(strpos(strtolower($archivo), 'detall')!==false){
					$query =sprintf("
						TRUNCATE TABLE `sor_rec_premios_det` ;
						LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_det`
						LINES TERMINATED BY '\n'
						(@registro)
						SET 
						`id_juego`=SUBSTR(@registro,1,2),
						`nro_emision`=SUBSTR(@registro,3,8),
						`id_juego_asociado`=SUBSTR(@registro,11,2),
						`nro_emision_asociada`=SUBSTR(@registro,13,8),
						`fecha_sorteo`=SUBSTR(@registro,21,8),
						`fecha_proceso`=SUBSTR(@registro,29,8),
						`codigo_provincia`=SUBSTR(@registro,37,2),
						`nro_ticket`=SUBSTR(@registro,39,10),
						`clase_premio`=SUBSTR(@registro,49,1),
						`importe_premio`=SUBSTR(@registro,50,13),
						`tipo_de_premio`=SUBSTR(@registro,63,2),
						`agente`=SUBSTR(@registro,65,5),
						`subagente`=SUBSTR(@registro,70,3),
						`ambulante`=SUBSTR(@registro,73,3),
						`tipo_doc`=SUBSTR(@registro,76,1),
						`nro_doc`=SUBSTR(@registro,77,9),
						`pago_en_agencia`=SUBSTR(@registro,86,1),
						`codigo_verificacion`=SUBSTR(@registro,87,6);",
				    	addslashes($archivo));

				}else{
					$query =sprintf("
						TRUNCATE TABLE `sor_rec_premios_ret` ;
						LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_ret`
						LINES TERMINATED BY '\n'
						(@registro)
						SET 
						`id_juego`=SUBSTR(@registro,1,2),
						`nro_emision`=SUBSTR(@registro,3,8),
						`id_juego_asociado`=SUBSTR(@registro,11,2),
						`nro_emision_asociada`=SUBSTR(@registro,13,8),
						`codigo_provincia`=SUBSTR(@registro,21,2),
						`nro_ticket`=SUBSTR(@registro,23,10),
						`clase_premio`=SUBSTR(@registro,33,1),
						`codigo_concepto`=SUBSTR(@registro,34,3),
						`importe`=SUBSTR(@registro,37,13);",
				    	addslashes($archivo));
				}

				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga pre_det_ret");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga pre_det_ret");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de premios ret/det en la tabla");
				\Log::info($e);
				return false;
			}
		}
		

		/******** PARA ZIPEADOS ***********/
		public static function cargarPremiosRetencionControlContenedor($archivo, $archivoDR){
			return 1;
		}
		
		
		/***************************************/
		/*	valida SP sor_valida_ctascte_pcia	*/
		/****************************************/
		
		public static function valida_ctasctes($juego, $sorteo, $idProceso, $usuario){
			$datos = $juego.','.$sorteo.','.$idProceso.',"'.$usuario.'",@msgret';
			\Log::info("Llama sor_valida_ctascte_pcia", array($datos));
			\Log::info("JERE 1", array($datos));
			//$ok = \DB::connection('suitecrm')->select(\DB::raw('CALL `sor_valida_ctascte_pcia`('.$datos.')'));
			try{
			\Log::info("JERE 2");
				$jere=\DB::connection('suitecrm')->unprepared(\DB::raw('CALL sor_valida_ctascte_pcia('.$datos.')'));
			\Log::info("JERE 3" , array($jere));
				$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			\Log::info("JERE 4", array($ok));
				 \DB::disconnect('suitecrm');
			\Log::info("JERE 5", array($ok[0]));
				return $ok[0]->msgret;							
			}catch(\Exception $e){
				\Log::info("JERE 6");
				\Log::info("Problema al llamar al stored de validación de ventas totales.");
				\Log::info($e);
			}
		}
}
?>