<?php

	namespace Datos\Repositorio;
	
	class LimitesRepo{
				
		public static function cargarLimitesControl($archivo, $archivoComisiones){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoComisiones);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE tmp_limites_venta_ctrl;
					LOAD DATA INFILE '%s' INTO TABLE `tmp_limites_venta_ctrl`
					CHARACTER SET binary
					FIELDS TERMINATED BY '%s'
					LINES STARTING BY '<Registro>' TERMINATED BY '</Registro>'
					(@registro)
					SET
						`tipo_archivo`= ExtractValue(@registro, 'tipo_archivo'),
			            `version`= ExtractValue(@registro, 'version'),
			            `nombre_archivo`= ExtractValue(@registro, 'nombre_archivo'),
			            `md5_archivo`= ExtractValue(@registro, 'md5'),
			            `md5_calculado`='%s';",
			    	addslashes($archivo),addslashes("\\t"), addslashes($formatoFecha),addslashes($md5_calculado));
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga com_ctrl");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga com_ctrl");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de limites control en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		/*public static function cargarLimites($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
	    		$db=  \DB::connection('suitecrm');
				$query =sprintf("
					TRUNCATE TABLE `tmp_limites_varchar` ;
					LOAD DATA INFILE '%s' INTO TABLE `tmp_limites_varchar`
					LINES TERMINATED BY '\r\n'",
					addslashes($archivo));
				\Log::info("empecé carga lv");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga lv");
				$query="call sor_carga_tmp_limites();";
				$resultado=$db->getpdo()->exec($query);
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de comisiones en la tabla");
				\Log::info($e);
				return false;
			}
		}*/
	
		public static function cargarLimites($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$query =sprintf("
					TRUNCATE TABLE `tmp_limites_venta` ;
					LOAD DATA INFILE '%s' INTO TABLE `tmp_limites_venta`
					LINES TERMINATED BY '\r\n'
					(@registro)
					SET 
					`agente`=SUBSTR(@registro,3,4),
					`subagente`=SUBSTR(@registro,7,3),
					`monto`=CAST(SUBSTR(@registro,15,12)/100 AS DECIMAL(15,2));
					",
			    	addslashes($archivo));

	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga lv");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga lv");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de comisiones en la tabla");
				\Log::info($e);
				return false;
			}
		}
		/*
		carga de límites antes del 30/08/2016
		
		public static function cargarLimites($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha1 = '%d/%m/%Y';
				$formatoFecha2 = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `tmp_limites_venta` ;
					LOAD DATA INFILE '%s' INTO TABLE `tmp_limites_venta`
					FIELDS TERMINATED BY ','
					LINES TERMINATED BY '\r\n'
					(@col1, @col2, @col3, @col4, @col5)
					SET 
					`agente`=SUBSTR(@col1,1,6),
					`subagente`=SUBSTR(SUBSTR(@col1,7,9),1,3),
					`monto`=@col4,
					`fechaHoraArchivo`=DATE_FORMAT(STR_TO_DATE(@col5, '%s'),'%s');
					",
			    	addslashes($archivo),addslashes($formatoFecha1),addslashes($formatoFecha2));

	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga lv");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga lv");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de comisiones en la tabla");
				\Log::info($e);
				return false;
			}
		}*/
		
		/*Carga recorriendo el archivo
		public static function cargarLimites($archivo, $fechaHora){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				
				$db=  \DB::connection('suitecrm');
				$query ="TRUNCATE TABLE `tmp_limites_venta`;";
				$resultado=$db->getpdo()->exec($query);
				\Log::info("empecé carga lv");
				$file = fopen($archivo, "r");
				//obtengo la fila
				$row=fgets($file);
				//recorremos el archivo
				while(!feof($file))
				{
					$query="";
					$valoresFila = explode(",", $row);
					$agente = substr($valoresFila[0],1,5);
					$subagente=substr(substr($valoresFila[0],6,9),0,3);
					$monto = $valoresFila[3];
					/*\Log::info("subagente: ", array($valoresFila[0]));
					\Log::info("subagente2: ", array(substr($valoresFila[0],6,9)));
					\Log::info("subagente3: ", array(substr(substr($valoresFila[0],6,9),0,3)));
					\Log::info("fila: ", array($valoresFila[0]));
					\Log::info("agente: ", array($agente));
					\Log::info("subagente: ", array($subagente));*
					
					$query="INSERT INTO tmp_limites_venta(agente,subagente,monto, fechaHoraArchivo)";
					$query.="VALUES(".$agente.",".$subagente.",".$monto.",".$fechaHora.")";
					$resultado=$db->getpdo()->exec($query);
					
					//obtengo la fila
					$row=fgets($file);
					//se coloca porque no grababa la última fila
                    if(feof($file)){
						$valoresFila = explode(",", $row);
						$agente = substr($valoresFila[0],1,5);
						$subagente=substr(substr($valoresFila[0],6,9),0,3);
						$monto = $valoresFila[3];
											
						$query="INSERT INTO tmp_limites_venta(agente,subagente,monto, fechaHoraArchivo)";
						$query.="VALUES(".$agente.",".$subagente.",".$monto.",".$fechaHora.")";
						$resultado=$db->getpdo()->exec($query);					
					}
				}

				fclose($file);
				\Log::info("terminé carga lv");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				$query ="TRUNCATE TABLE `tmp_limites_venta`;";
				$resultado=$db->getpdo()->exec($query);
				\Log::info("Error cargando el archivo de limites de venta en la tabla");
				\Log::info($e);
				return false;
			}
		}*/
		/*******************************************************
		* Llamada al stored para procesar los límites de venta *
		********************************************************/
		public static function sor_procesa_limites($idProceso, $usuario, $nro_sorteo){
			$datos=$idProceso.",'".$usuario."',".$nro_sorteo.",@msgret";
			try{
				\DB::connection('suitecrm')->unprepared(\DB::raw('CALL gar_procesa_lvd('.$datos.')'));
				$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
				return $ok[0]->msgret; 
			}catch(\Exception $e){
				\Log::info("Problema al llamar al stored de procesamiento de limites de venta.");
				\Log::info($e);
			}
		}
		
		
	}
?>
