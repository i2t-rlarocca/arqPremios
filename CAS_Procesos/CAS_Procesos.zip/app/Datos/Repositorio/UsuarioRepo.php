<?php

	namespace Datos\Repositorio;
	use models\UsuarioSesionModelo;
	class UsuarioRepo{
				
		/**
		 * Devuelve un usuario a partir del nombre de usuario
		 * que le llega como parámetro
		 * @param type $nombreUsuario
		 */
		public static function buscar($userName){
            $datosUsuario = \DB::connection('suitecrm')->select(\DB::raw('CALL sor_usuario_funciones("'.$userName.'")'));
			//\Log::info("UsuarioRepo.buscar(".$userName.") - ACAAA - llama al stored: CALL sor_usuario_funciones('$userName') - datos devueltos: ", array($datosUsuario));
			
			if (is_null($datosUsuario) or empty($datosUsuario)) {
				//\Log::info("UsuarioRepo - método buscar(username) - resultado NO OK del stored: NO DEVOLVIO DATOS: ", array($datosUsuario));
				\Log::info("UsuarioRepo - método buscar(username) - resultado NO OK del stored: NO DEVOLVIO DATOS.");
				return null;
			}else{
				$usuario['idUsuario']=$datosUsuario[0]->id;
				$usuario['nombreUsuario']=$userName;
				$usuario['funciones']=explode(",",$datosUsuario[0]->funciones);
				\Log::info("UsuarioRepo - método buscar(username) - resultado OK del stored.");
				return $usuario;
			} 
		}


		/**
		 * Función que se encarga de verificar si el usuario 
		 * aún está logueado en el portal
		 */
		/*public static function controlSesion($nombreUsuario){
			try{
				$intentos=0;
				$sesionPortal=[];
				while($intentos<3){
					$query = UsuarioSesionModelo::query();
					$sesionActiva=$query->where('username','=',$nombreUsuario)->get();
					$sesionPortal['portal'] = 'general'; 
					if (count($sesionActiva)==0 || is_null($sesionActiva)) {
						if($intentos<3){
							sleep(3);
							\Log::info(array($sesionActiva));
							\Log::info("Intento control sesión: ", array($intentos));
							$intentos++;
						}
					}else{
						$intentos=3;
					}
				}
				if (count($sesionActiva)==0 || is_null($sesionActiva)) {
					if($intentos==3){
						\Log::info("Ha finalizado la sesión", array($nombreUsuario));
						$sesionPortal['sesionActiva']=false;
						return $sesionPortal;
					}
				}else{
					$sesionPortal['sesionActiva']=true;
					return $sesionPortal;
				}
			}catch(\Exception $e){
				\Log::info("Ocurrió un error al controlar la sesión: ", array($e->getMessage()));
				return false;
			}
		}*/
		
		public static function controlSesion($id_portal, $letra_portal){
			$sesionPortal=[];
			$query = 'select * from session_usuario_v where userid="'.$id_portal.'" and portal='.$letra_portal;
			// \Log::info("UsuarioRepo - método controlSesion(id_portal, letra_portal) - Ejecuta Select: $query", array($sesionPortal));
			
			$sesionActiva=\DB::connection('suitecrm')->select(\DB::raw($query));
			/*$sesionActiva=UsuarioSesionModelo::where('userid','=',$id_portal)
						  ->where('portal','=',$letra_portal)->get();
			
						  $query= 'select * from session_usuario_v where userid='.$id_portal.' and portal='.$letra_portal;
						  \Log::info($query);*/
			if (count($sesionActiva)==0 || is_null($sesionActiva)) {
				$sesionPortal['sesionActiva']=false;
				// \Log::info("UsuarioRepo - método controlSesion(id_portal, letra_portal) - Sesion Activa NO EXISTE (es null o count ==0): sesionPortal ->", array($sesionPortal));
				return $sesionPortal; 
			}else{
				$sesionPortal['sesionActiva']=true;
				// \Log::info("UsuarioRepo - método controlSesion(id_portal, letra_portal) - Sesion Activa EXISTE: sesionPortal ->", array($sesionPortal));
				return $sesionPortal;
			}
		}
		
		/******************************************************************
		* 				obtiene para el usuario los Accesos				  *
		*******************************************************************/
		public static function ControlAcceso($sistema,$usuario){
			
			$datos="'".$sistema."','".$usuario."'";
			$query = 'CALL CC_Acceso_Procesos ('.$datos.')';
			//\Log::info("UsuarioRepo - método ControlAcceso(sistema,usuario) - Llama al Stored: $query", array($datos));
			$db = \DB::connection('suitecrm');
			$db->getpdo()->setAttribute(\PDO::ATTR_EMULATE_PREPARES, true);
			$resultados=$db->select(\DB::raw($query));
			//\Log::info("UsuarioRepo - método ControlAcceso(sistema,usuario) - Resultado del Stored:", array($resultados));
			return $resultados;
		}
		
		/*******************************************************************************************
		* Recupera datos extendidos del usuario segun su tipo de usuario (provincia, loteria, etc) *
		*******************************************************************************************/
		public static function GetDatosTipoUsuario($usuario){
			$datos="'".$usuario."'";
			$query = "CALL USU_getDatosTipoUsuario($datos)";
			\Log::info("UsuarioRepo.GetDatosTipoUsuario - Llama al Stored: $query");
			$db = \DB::connection('suitecrm');
			$db->getpdo()->setAttribute(\PDO::ATTR_EMULATE_PREPARES, true);
			$resultados=$db->select(\DB::raw($query));
			\Log::info("UsuarioRepo.GetDatosTipoUsuario - Resultado del Stored: ", array($resultados));
			return $resultados;
		}
		
	}
?>