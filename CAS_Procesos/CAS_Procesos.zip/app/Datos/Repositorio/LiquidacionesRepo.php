<?php

	namespace Datos\Repositorio;
	
	class LiquidacionesRepo{


// BCF0014 codigos juegos
		public static function cargarCodigoJuegos($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_bcf0014` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_bcf0014`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`bc_cod_juego`=SUBSTR(@registro,1,2),
					`bc_nombre_juego`= TRIM(REPLACE(TRIM(BOTH '' FROM SUBSTR(@registro,3,23)),'\r',''))
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga BCF0014");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga BCF0014");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo BCF0014 en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
// CCF0001 comprobantes
		public static function cargarComprobantes($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0001` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0001`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_cod_comprobante`=SUBSTR(@registro,1,3),
					`cc_desc_comprobante`=SUBSTR(@registro,4,20),
					`cc_debito_credito`=SUBSTR(@registro,24,1),
					`cc_iniciales`=SUBSTR(@registro,25,2),
					`cc_aplica`=SUBSTR(@registro,27,1),
					`cc_origen`=SUBSTR(@registro,28,1),
					`cc_imprime`=SUBSTR(@registro,29,1),
					`cc_filler1`=SUBSTR(@registro,30,1),
					`cc_filler2`=SUBSTR(@registro,31,6),
					`cc_filler3`= TRIM(BOTH '' FROM SUBSTR(@registro,37,4))
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga ccf0001");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga ccf0001");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo ccf0001 en la tabla");
				\Log::info($e);
				return false;
			}
		}

// CCF0002 conceptos

	public static function cargarConceptos($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0002` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0002`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_cod_concepto`=SUBSTR(@registro,1,3),
					`cc_desc_concepto`=SUBSTR(@registro,4,20),
					`cc_debito_credito`=SUBSTR(@registro,24,1),
					`cc_origen`=SUBSTR(@registro,25,1),
					`cc_baja`=SUBSTR(@registro,26,1),
					`cc_fecha_baja`=SUBSTR(@registro,27,6),
					`cc_filler1`= TRIM(BOTH '' FROM SUBSTR(@registro,33,8))
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga ccf0002");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga ccf0002");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo ccf0002 en la tabla");
				\Log::info($e);
				return false;
			}
		}

		
		
		// CCF0003 saldos por juegos

	
		public static function cargarSaldosJuegos($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$formatoFecha2 = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0003` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0003`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_cod_juego`=CAST( SUBSTR(@registro,1,2) AS UNSIGNED),
					`cc_ult_nro_compr`= SUBSTR(@registro,3,8),					
					`cc_ult_nro_interno`=SUBSTR(@registro,11,8),
					`cc_ult_nro_multijuego`=SUBSTR(@registro,19,8),
					`cc_saldo_actual`=convierte_imp(SUBSTR(@registro,27,15)), 
					`cc_fecha_anterior`=str_to_date(SUBSTR(@registro,42,8),'%s'),					
					`cc_filler1`=SUBSTR(@registro,50,15),
					`cc_filler2`=SUBSTR(@registro,65,15),
					`cc_filler3`=SUBSTR(@registro,80,8),
					`cc_saldo_vencido`=convierte_imp(SUBSTR(@registro,88,15)),
					`cc_saldo_a_vencer`=convierte_imp(SUBSTR(@registro,103,15)),
					`cc_fecha_actual`=str_to_date(SUBSTR(@registro,118,8),'%s'),					
					`cc_creditos_aplicados`= TRIM(BOTH '' FROM SUBSTR(@registro,126,11))					
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo),addslashes($formatoFecha),addslashes($formatoFecha2));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0003");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0003");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0003 en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
	// -- CCF0004 afectaciones
	
	public static function cargarAfectaciones($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0004` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0004`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_cod_afectacion`=SUBSTR(@registro,1,2),
					`cc_desc_afec`=SUBSTR(@registro,3,30),
					`cc_deb_cred_amb`=SUBSTR(@registro,33,1),
					`cc_cod_comprobante_debito`=SUBSTR(@registro,34,3),
					`cc_cod_comprobante_credito`=SUBSTR(@registro,37,3),
					`cc_filler1`=SUBSTR(@registro,40,12),
					`cc_filler2`=SUBSTR(@registro,52,9)
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0004");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0004");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0004 en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
	
	// -- CCF0015 parametros
	
	public static function cargarParametros($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$formatoFecha2 = '%Y%m%d';
				$formatoFecha3 = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0015` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0015`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_fijo_cc`=SUBSTR(@registro,1,2),
					`cc_fecha_proceso`=str_to_date(SUBSTR(@registro,3,8),'%s'),
					`cc_fecha_acreditacion`=str_to_date(SUBSTR(@registro,11,8),'%s'),
					`cc_coeficiente`=SUBSTR(@registro,19,6),
					`cc_valor`=SUBSTR(@registro,25,11),
					`cc_agencia_desde`=SUBSTR(@registro,36,5),
					`cc_agencia_hasta`=SUBSTR(@registro,41,5),
					`cc_fecha_vencimiento`=str_to_date(SUBSTR(@registro,46,8),'%s'),
					`cc_abc`=SUBSTR(@registro,54,343),
					`cc_filler1`= TRIM(BOTH '' FROM SUBSTR(@registro,397,4))					
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha),addslashes($formatoFecha2),addslashes($formatoFecha3));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0015");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0015");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0015 en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
/*
		public static function cargarParametros($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$db=  \DB::connection('suitecrm');
				$query ="TRUNCATE TABLE `rec_ccf0015` ;";
				$resultado=$db->getpdo()->exec($query);
				
				$file = fopen($archivo, "r");
				//obtengo la fila
				$row=fgets($file);
				
				//recorremos el archivo
			
			//while(!feof($file))
			//	{
					//cargo datos de la fila
					$cc_fijo_cc= substr($row,0,2);	
					//\Log::info($cc_fijo_cc);
					$cc_fecha_proceso= substr($row,2,8);
					//\Log::info($cc_fecha_proceso);
					$cc_fecha_acreditacion=substr($row,10,8);
					//\Log::info($cc_fecha_acreditacion);
					$cc_coeficiente=substr($row,18,6);
					//\Log::info($cc_coeficiente);
					$cc_valor=substr($row,24,11);
					//\Log::info($cc_valor);
					$cc_agencia_desde=substr($row,35,5);
					//\Log::info($cc_agencia_desde);
					$cc_agencia_hasta=substr($row,40,5);
					//\Log::info($cc_agencia_hasta);
					$cc_fecha_vencimiento=substr($row,45,8);
					//\Log::info($cc_fecha_vencimiento);
					$cc_abc=substr($row,53,342);
					//\Log::info($cc_abc);
					$cc_filler1=TRIM(substr($row,396,4), "");
					//\Log::info($cc_filler1);
					
					\Log::info("inicio carga CCF0015");
					//insertamos la fila
					$query="INSERT INTO rec_ccf0015(cc_fijo_cc,cc_fecha_proceso,cc_fecha_acreditacion,cc_coeficiente,cc_valor,cc_agencia_desde,cc_agencia_hasta,cc_fecha_vencimiento,cc_abc,cc_filler1)";
					$query.="VALUES('".$cc_fijo_cc."',".$cc_fecha_proceso.",".$cc_fecha_acreditacion.",".$cc_coeficiente.",".$cc_valor.",".$cc_agencia_desde.",".$cc_agencia_hasta.",".$cc_fecha_vencimiento.",'".$cc_abc."','".$cc_filler1."');";
					
					//\Log::info($query);
					$resultado=$db->getpdo()->exec($query);
					//\Log::info($resultado);
					//obtengo la fila
					$row=fgets($file);
					
			//	}
				fclose($file);
	    		
	    		if($db->getPdo()->errorCode()== '00000'){
	    			\Log::info("fin carga CCF0015");
					return 1;
	    		}else{
	    			return 0;
	    		}
			}catch (Illuminate\Filesystem\FileNotFoundException $exception){
				\Log::info("Error cargando el archivo CCF0015 en la tabla");
				\Log::info($e);
				return false;
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0015 en la tabla");
				\Log::info($e);
				return false;
			}
		}		
*/
	
	// -- CCF0016 Multijuego
	
		public static function cargarMultijuegos($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0016` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0016`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_fijo_cc`=SUBSTR(@registro,1,2),
					`cc_cod_afectacion`=SUBSTR(@registro,3,2),
					`cc_cod_juego`=SUBSTR(@registro,5,2),
					`cc_filler1`=SUBSTR(@registro,7,14)
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0016");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0016");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0016 en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
	// -- CCF0017 Saldos por agentes
	
	public static function cargarSaldosAgente($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$formatoFecha2 = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0017` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0017`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_provincia`=SUBSTR(@registro,1,2),
					`cc_agencia`=SUBSTR(@registro,3,5),
					`cc_filler1`=SUBSTR(@registro,8,1),
					`cc_filler2`=SUBSTR(@registro,9,3),
					`cc_cod_juego`=SUBSTR(@registro,12,2),
					`cc_saldo`=convierte_imp(LPAD(SUBSTR(@registro,14,13), 15,'0')),
					`cc_fecha_actual`=str_to_date(SUBSTR(@registro,27,8),'%s'),
					`cc_filler3`=SUBSTR(@registro,35,13),
					`cc_filler4`=SUBSTR(@registro,48,13),
					`cc_filler5`=SUBSTR(@registro,61,8),
					`cc_saldo_vencido`=convierte_imp(LPAD(SUBSTR(@registro,69,13), 15,'0')),
					`cc_saldo_a_vencer`=convierte_imp(LPAD(SUBSTR(@registro,82,13), 15,'0')),
					`cc_fecha_saldo_vencer`=str_to_date(SUBSTR(@registro,95,8),'%s'),
					`cc_filler6`=SUBSTR(@registro,103,1),
					`cc_creditos_aplicados`=convierte_imp(SUBSTR(@registro,104,13))
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha), addslashes($formatoFecha2));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0017");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0017");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0017 en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
	// -- CCF0079 Tipos de Garantias
	
		public static function cargarTiposGarantias($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0079` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0079`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_tipo_garantia`=SUBSTR(@registro,1,1),
					`cc_desc_garantia`=SUBSTR(@registro,2,29)
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0079");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0079");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0079 en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
	// -- CCF0301 Movimientos de comprobantes

	
	public static function cargarMovimientosComprobantes($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$formatoFecha2 = '%Y%m%d';
				$formatoFecha3 = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0301` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0301`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_provincia`=SUBSTR(@registro,1,2),
					`cc_agencia`=SUBSTR(@registro,3,5),
					`cc_filler1`=SUBSTR(@registro,8,4),
					`cc_cod_juego`=SUBSTR(@registro,12,2),
					`cc_cod_comprobante`=SUBSTR(@registro,14,3),
					`cc_nro_comprobante`=SUBSTR(@registro,17,8),
					`cc_debito_credito`=SUBSTR(@registro,25,1),
					`cc_nro_multijue_o_indiv`=SUBSTR(@registro,26,8),
					`cc_fecha_proceso_ini`= case when str_to_date(SUBSTR(@registro,34,8),'%s') = '0000-00-00' then NULL else str_to_date(SUBSTR(@registro,34,8),'%s') end,
					`cc_fecha_vencimiento`= case when str_to_date(SUBSTR(@registro,42,8),'%s') = '0000-00-00' then NULL else str_to_date(SUBSTR(@registro,42,8),'%s') end,
					`cc_cod_afectacion`=SUBSTR(@registro,50,2),
					`cc_tipo_movimiento`=SUBSTR(@registro,52,1),
					`cc_juego_transf`=SUBSTR(@registro,53,2),
					`cc_sor_desde`=SUBSTR(@registro,55,5),
					`cc_sor_hasta`=SUBSTR(@registro,60,5),
					`cc_fecha_proceso_fin`= case when str_to_date(SUBSTR(@registro,65,8),'%s') = '0000-00-00' then NULL else str_to_date(SUBSTR(@registro,65,8),'%s') end ,
					`cc_importe`=convierte_imp(SUBSTR(@registro,73,11)),
					`cc_saldo`=convierte_imp(SUBSTR(@registro,84,11)),
					`cc_filler2`=SUBSTR(@registro,95,2),
					`cc_filler3`=SUBSTR(@registro,97,2),
					`cc_mes_anio`=SUBSTR(@registro,99,6),
					`cc_procedencia`=SUBSTR(@registro,105,1),
					`cc_aplicacion`=SUBSTR(@registro,106,1),
					`cc_filler4`=SUBSTR(@registro,107,3)
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha),addslashes($formatoFecha), addslashes($formatoFecha2),addslashes($formatoFecha2), addslashes($formatoFecha3),addslashes($formatoFecha3));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0301");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0301");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0301 en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
	// -- CCF0302 Concepto de comprobantes
	
	public static function cargarConceptosComprobantes($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0302` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0302`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_cod_comprobante`=SUBSTR(@registro,1,3),
					`cc_nro_comprobante`=SUBSTR(@registro,4,8),
					`cc_cod_concepto`=SUBSTR(@registro,12,2),
					`cc_provincia`=SUBSTR(@registro,14,2),
					`cc_agencia`=SUBSTR(@registro,16,5),
					`cc_filler1`=SUBSTR(@registro,21,4),
					`cc_cod_juego`=SUBSTR(@registro,25,2),
					`cc_cod_afectacion`=SUBSTR(@registro,27,2),
					`cc_sor_desde`=SUBSTR(@registro,29,5),
					`cc_sor_hasta`=SUBSTR(@registro,34,5),
					`cc_importe`=convierte_imp(SUBSTR(@registro,39,11)),
					`cc_debito_credito`=SUBSTR(@registro,50,1),
					`cc_manual_sistema`=SUBSTR(@registro,51,1),
					`cc_filler2`=SUBSTR(@registro,52,20)
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0302");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0302");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0302 en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
	//	-- CCF0304 Aplicaciones
	
		
		public static function cargarAplicaciones($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0304` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0304`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_provincia`=SUBSTR(@registro,1,2),
					`cc_agencia`=SUBSTR(@registro,3,5),
					`cc_filler1`=SUBSTR(@registro,8,4),
					`cc_cod_juego_aplic`=SUBSTR(@registro,12,2),
					`cc_cod_comp_aplicacion`=SUBSTR(@registro,14,3),
					`cc_nro_aplicacion`=SUBSTR(@registro,17,8),
					`cc_secuencia_aplicacion`=SUBSTR(@registro,25,2),
					`cc_cod_juego_comp`=SUBSTR(@registro,27,2),
					`cc_cod_comprobante`=SUBSTR(@registro,29,3),
					`cc_nro_comprobante`=SUBSTR(@registro,32,8),
					`cc_importe`=convierte_imp(SUBSTR(@registro,40,11)),
					`cc_fecha`=str_to_date(SUBSTR(@registro,51,8),'%s'),
					`cc_filler2`=SUBSTR(@registro,59,7)
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0304");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0304");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0304 en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
	//	-- CCF0305 Premios
	
		
				public static function cargarPremios($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$formatoFecha2 = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0305` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0305`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_cod_juego`=SUBSTR(@registro,1,2),
					`cc_cod_sorteo`=SUBSTR(@registro,3,5),
					`cc_fecha_sorteo`=str_to_date(SUBSTR(@registro,8,8),'%s'),
					`cc_total_importe`= CAST((SUBSTR(@registro,16,13)/100) AS DECIMAL(15,2)),
					`cc_fecha_proceso`=str_to_date(SUBSTR(@registro,29,8),'%s')
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha), addslashes($formatoFecha2));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0305");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0305");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0305 en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		// -- CCF0306 Numero de Secuencia
				 
				public static function cargarNumeroSecuencia($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);						
				\Log::info(date("Y-m-d H:i:s")." RR - inicio carga CCF0306 ".$archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0306` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0306`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_nro_secuencia`=SUBSTR(@registro,1,8)
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0306");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0306");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0306 en la tabla");
				\Log::info($e);
				return false;
			}
		}
		 
		 
		// -- CCF0307 Creditos efectivizados
		
		
			public static function cargarCreditosEfectivizados($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0307` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0307`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_agencia`=SUBSTR(@registro,1,5),
					`cc_filler1`=SUBSTR(@registro,6,6),
					`cc_nro_comprobante`=SUBSTR(@registro,12,8),
					`cc_fecha_proceso`=str_to_date(SUBSTR(@registro,20,8),'%s'),
					`cc_importe`=CONVERT(SUBSTR(@registro,28,13)/100, DEC(15,2))
					-- `cc_importe`=convierte_imp(TRIM(REPLACE(TRIM(BOTH '' FROM SUBSTR(@registro,28,13)),'\r','')))
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0307");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0307");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0307 en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		
		// -- CCF0308 Premios pagados para la UIF
		
			public static function cargarPremiosPagadosUIF($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$formatoFecha2 = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `rec_ccf0308` ;
					LOAD DATA INFILE '%s' INTO TABLE `rec_ccf0308`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`cc_cod_juego`=SUBSTR(@registro,1,2),
					`cc_cod_sorteo`=SUBSTR(@registro,3,8),
					`cc_fecha_pago`=str_to_date(SUBSTR(@registro,11,8),'%s'),
					`cc_hora_pago`=SUBSTR(@registro,19,6),
					`cc_fecha_captura`=str_to_date(SUBSTR(@registro,25,8),'%s'),
					`cc_hora_captura`=SUBSTR(@registro,33,6),
					`cc_provincia`=SUBSTR(@registro,39,2),
					`cc_ocr`=SUBSTR(@registro,41,10),
					`cc_importe`=convierte_imp(SUBSTR(@registro,51,13)),
					`cc_agencia`=SUBSTR(@registro,64,5),
					`cc_subagencia`=SUBSTR(@registro,69,3),
					`cc_filler1`=SUBSTR(@registro,72,13)
					-- id_detalle=UUID()
					;",
			    	addslashes($archivo), addslashes($formatoFecha), addslashes($formatoFecha2));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga CCF0308");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga CCF0308");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo CCF0308 en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
		/*********************************************
		* 			obtiene secuencia esperada		 *
		**********************************************/

		public static function secuenciaEsperada(){
			$db=\DB::connection('suitecrm');
			// cambiar la consulta una vez conocida la tabla que guardará la ultima secuencia
			$resultado = $db->select(\DB::raw('SELECT obtiene_sgte_secuencia_recep() as sec_esp'));
			//$resultado = $db->select(\DB::raw('SELECT null AS sec_esp FROM rec_ccf0306'));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				$datos['sec_esp']=$resultado[0]->sec_esp;
				return $datos['sec_esp'];
			}else{
				return null;
			}
		}

		
		/*********************************************
		* 			validar Secuencia				 *
		**********************************************/
		
		public static function validarSecuencia($idProceso,$nroSecuencia,$usuario){
			//$datos=$periodo.",".$idProceso.",'".$usuario."',@msgret";
			//$idProceso=28;
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','SEC',@msgret";
			\Log::info('validarSecuencia->',array('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			return $ok[0]->msgret;
		}
		
		
		/*********************************************
		* 	validar vuelco en cada tabla			 *
		**********************************************/
		
		public static function validarVuelcos($idProceso,$nroSecuencia,$usuario){
			//$datos=$periodo.",".$idProceso.",'".$usuario."',@msgret";
			//$idProceso=28;
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','CDT',@msgret";
			\Log::info('validarVuelcos->',array('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			return $ok[0]->msgret;
		}
		
		
		
		/*********************************************
		* 	validar comprobantes					 *
		**********************************************/
		
		public static function validarComprobantes($idProceso,$nroSecuencia,$usuario){
			//$datos=$periodo.",".$idProceso.",'".$usuario."',@msgret";
			//$idProceso=28;
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','COM',@msgret";
			\Log::info('validarComprobantes->',array('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			return $ok[0]->msgret;
		}
		
		
		/*********************************************
		* 	validar conceptos						 *
		**********************************************/
		
		public static function validarConceptos($idProceso,$nroSecuencia,$usuario){
			//$datos=$periodo.",".$idProceso.",'".$usuario."',@msgret";
			//$idProceso=28;
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','CON',@msgret";
			\Log::info('validarConceptos->',array('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			return $ok[0]->msgret;
		}
		
		/*********************************************
		* 	validar juegos							 *
		**********************************************/
		
		public static function validarJuegos($idProceso,$nroSecuencia,$usuario){
			//$datos=$periodo.",".$idProceso.",'".$usuario."',@msgret";
			//$idProceso=28;
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','JUE',@msgret";
			\Log::info('validarJuegos->',array('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			return $ok[0]->msgret;
		}
		
		/*********************************************
		* 	validar agencia							 *
		**********************************************/
		
		public static function validarAgencias($idProceso,$nroSecuencia,$usuario){
			//$datos=$periodo.",".$idProceso.",'".$usuario."',@msgret";
			//$idProceso=28;
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','AGE',@msgret";
			\Log::info('validarAgencias->',array('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			return $ok[0]->msgret;
		}
		
		
		/*********************************************
		* 	validar afectaciones					 *
		**********************************************/
		
		public static function validarAfectaciones($idProceso,$nroSecuencia,$usuario){
			//$datos=$periodo.",".$idProceso.",'".$usuario."',@msgret";
			//$idProceso=28;
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','AFE',@msgret";
			\Log::info('validarAfectaciones->',array('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			return $ok[0]->msgret;
		}
		
		/********************************************************************
		* 	validar vuelco definitivo		-- MM en desuso 05-10-2018		 *
		*********************************************************************/
		
		public static function validarVuelcoDatosFinal($idProceso,$nroSecuencia,$usuario){
			//$datos=$periodo.",".$idProceso.",'".$usuario."',@msgret";
			//$idProceso=28;
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','VDF',@msgret";
			\Log::info('validarVuelcoDatosFinal->',array('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Valida_CtaCte_Agencia`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			return $ok[0]->msgret;
		}
		
		
		/*********************************************
		* 	vuelco 									 *
		**********************************************/
		// volcar datos liquidaciones
		public static function Vuelco_CtaCte($idProceso,$nroSecuencia,$usuario){
			try{
				// $ok = '';
				// $datos = '';
				// $query = '';
				// $pdo=\DB::connection('suitecrm')->getPdo();
		
				// $datos = $idProceso.",".$nroSecuencia.",'".$usuario."','VDF',@msgretVuelco"; 
				// $query = 'CALL CC_Vuelco_CtaCte_Agencia('.$datos.')';
				// \Log::info('Vuelco_CtaCte->',array('CALL `CC_Vuelco_CtaCte_Agencia`('.$datos.')'));
				// \DB::connection('suitecrm')->statement($query);
				// $okk = \DB::connection('suitecrm')->select(\DB::raw($query));
				// //$result = $okk->fetchall();
				// $mensaje=$okk;
				// \DB::disconnect('suitecrm');
				// return $mensaje;
				$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','VDF',@msgret";
				\Log::info('Vuelco_CtaCte->',array('CALL `CC_Vuelco_CtaCte_Agencia`('.$datos.')'));
				\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Vuelco_CtaCte_Agencia`('.$datos.')'));
				$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
				return $ok[0]->msgret;

			}catch(\PDOException $e){
				\Log::info($e);
				return false;
			}
		}
	}
?>