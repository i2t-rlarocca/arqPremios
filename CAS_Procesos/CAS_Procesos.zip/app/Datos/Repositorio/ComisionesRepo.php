<?php

	namespace Datos\Repositorio;
	
	class ComisionesRepo{
				
		public static function cargarComisionesControl($archivo, $archivoComisiones){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoComisiones);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE sor_rec_comisiones_adic_ctr ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_comisiones_adic_ctr`
					CHARACTER SET binary
					FIELDS TERMINATED BY '%s'
					LINES STARTING BY '<Registro>' TERMINATED BY '</Registro>'
					(@registro)
					SET
						`tipo_archivo`= ExtractValue(@registro, 'tipo_archivo'),
			            `version`= ExtractValue(@registro, 'version'),
			            `nombre_archivo`= ExtractValue(@registro, 'nombre_archivo'),
			            `provincia`= ExtractValue(@registro, 'provincia'),
			            `tipo_liquidacion`= ExtractValue(@registro, 'Tipoliquidacion'),
			            `secuencia_liquidacion`= ExtractValue(@registro, 'Secuencialiquidacion'),
			            `nro_liquidacion`= ExtractValue(@registro, 'Nroliquidacion'),
			            `fecha_liquidacion`= str_to_date(ExtractValue(@registro, 'Fechaliquidacion'),'%s'),
			            `hora_liquidacion`= ExtractValue(@registro, 'Horaliquidacion'),
			            `cantidad_registros`= ExtractValue(@registro, 'cantidad_registros'),
			            `suma_importe`= ExtractValue(@registro, 'suma_importe'),
			            `md5_archivo`= ExtractValue(@registro, 'md5'),
			            `md5_calculado`='%s';",
			    	addslashes($archivo),addslashes("\\t"), addslashes($formatoFecha),addslashes($md5_calculado));
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga com_ctrl");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga com_ctrl");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de comisiones control en la tabla");
				\Log::info($e);
				return false;
			}
		}

		public static function cargarComision($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `sor_rec_comisiones_adic` ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_comisiones_adic`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`nro_juego`=SUBSTR(@registro,1,3),
					`nro_sorteo`=SUBSTR(@registro,4,6),
					`fecha_sorteo`=str_to_date(SUBSTR(@registro,10,8),'%s'),
					`agente`=SUBSTR(@registro,18,6),
					`subagente`=SUBSTR(@registro,24,3),
					`vendedor`=SUBSTR(@registro,27,3),
					`cuit`=SUBSTR(@registro,30,11),
					`codigo_concepto`=SUBSTR(@registro,41,4),
					`alicuota`=SUBSTR(@registro,45,17),
					`moneda`=SUBSTR(@registro,62,1),
					`importe`=SUBSTR(@registro,63,17),
					`debito_credito`=SUBSTR(@registro,80,2),
					`agente_originante`=SUBSTR(@registro,82,6),
					`subagente_originante`=SUBSTR(@registro,88,3),
					`vendedor_originante`=SUBSTR(@registro,91,3),
					`tipo_terminal`=SUBSTR(@registro,94,1),
					`nro_terminal`=SUBSTR(@registro,95,8),
					`nro_constancia`=SUBSTR(@registro,103,8),
					`crc`=SUBSTR(@registro,111,114),
					-- id_padre=UUID(),
					id_detalle=UUID();",
			    	addslashes($archivo), addslashes($formatoFecha));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga com");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga com");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de comisiones en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		public static function cargarManSelladoControl($archivo, $archivoManSellado){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoManSellado);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE sor_rec_comisiones_adic_debitos_ctr ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_comisiones_adic_debitos_ctr`
					CHARACTER SET binary
					FIELDS TERMINATED BY '%s'
					LINES STARTING BY '<Registro>' TERMINATED BY '</Registro>'
					(@registro)
					SET
						`tipo_archivo`= ExtractValue(@registro, 'tipo_archivo'),
			            `version`= ExtractValue(@registro, 'version'),
			            `nombre_archivo`= ExtractValue(@registro, 'nombre_archivo'),
			            `provincia`= ExtractValue(@registro, 'provincia'),
			            `tipo_liquidacion`= ExtractValue(@registro, 'Tipoliquidacion'),
			            `secuencia_liquidacion`= ExtractValue(@registro, 'Secuencialiquidacion'),
			            `nro_liquidacion`= ExtractValue(@registro, 'Nroliquidacion'),
			            `fecha_liquidacion`= str_to_date(ExtractValue(@registro, 'Fechaliquidacion'),'%s'),
			            `hora_liquidacion`= ExtractValue(@registro, 'Horaliquidacion'),
			            `cantidad_registros`= ExtractValue(@registro, 'cantidad_registros'),
			            `suma_importe`= ExtractValue(@registro, 'suma_importe'),
			            `md5_archivo`= ExtractValue(@registro, 'md5'),
			            `md5_calculado`='%s';",
			    	addslashes($archivo),addslashes("\\t"), addslashes($formatoFecha),addslashes($md5_calculado));
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga com_sell_ctrl");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga com_sell_ctrl");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de mant. y sellado control en la tabla");
				\Log::info($e);
				return false;
			}
		}

		public static function cargarManSellado($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `sor_rec_comisiones_adic_debitos` ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_comisiones_adic_debitos`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`nro_juego`=SUBSTR(@registro,1,3),
					`nro_sorteo`=SUBSTR(@registro,4,6),
					`fecha_sorteo`=str_to_date(SUBSTR(@registro,10,8),'%s'),
					`agente`=SUBSTR(@registro,18,6),
					`subagente`=SUBSTR(@registro,24,3),
					`vendedor`=SUBSTR(@registro,27,3),
					`cuit`=SUBSTR(@registro,30,11),
					`codigo_concepto`=SUBSTR(@registro,41,4),
					`alicuota`=SUBSTR(@registro,45,17),
					`moneda`=SUBSTR(@registro,62,1),
					`importe`=SUBSTR(@registro,63,17),
					`debito_credito`=SUBSTR(@registro,80,2),
					`agente_originante`=SUBSTR(@registro,82,6),
					`subagente_originante`=SUBSTR(@registro,88,3),
					`vendedor_originante`=SUBSTR(@registro,91,3),
					`tipo_terminal`=SUBSTR(@registro,94,1),
					`nro_terminal`=SUBSTR(@registro,95,8),
					`nro_constancia`=SUBSTR(@registro,103,8),
					`crc`=SUBSTR(@registro,111,114),
					-- id_padre=UUID(),
					id_detalle=UUID();",
			    	addslashes($archivo), addslashes($formatoFecha));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga com_sell");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga com_sell");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de mant. y sellado en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		/*********************************************
		* Llamada al stored para retornar el periodo. *
		**********************************************/
		public static function valida_periodo(){
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `sor_valida_periodo_comisiones`(@msgret)'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			return $ok[0]->msgret;
		}
		
		/**********************************************
		* Llamada al stored para validar el período.  *        
		***********************************************/
		/*public static function periodoValido($periodo_completo){
			$datos=$periodo_completo.",@msgret";
			try{
				/*\DB::connection('suitecrm')->unprepared(\DB::raw('CALL sor_valida_comisiones_adicionales('.$datos.')'));
				$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
				return 'ok'; //$ok[0]->msgret;
			}catch(\Exception $e){
				\Log::info("Problema al llamar al stored de validación del período a procesar de comisiones adicionales.");
				\Log::info($e);
			}
		}*/
		/**************************************************************
		* Llamada al stored para procesar las comisiones del período. *
		***************************************************************/
		public static function sor_procesa_comisiones_adic($periodo, $idProceso, $usuario){
			$datos=$periodo.",".$idProceso.",'".$usuario."',@msgret";
			try{
				\DB::connection('suitecrm')->unprepared(\DB::raw('CALL sor_procesa_comisiones('.$datos.')'));
				\Log::info("CALL sor_procesa_comisiones(".$datos.")");
				$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
				return $ok[0]->msgret;
			}catch(\Exception $e){
				\Log::info("Problema al llamar al stored de procesamiento de comisiones adicionales.");
				\Log::info($e);
				return "Problema al llamar al stored de procesamiento de comisiones adicionales.";
			}
		}
	
	/*
	// ejecucion alternativa
		public static function sor_procesa_comisiones_adic($periodo, $idProceso, $usuario){
			$datos=$periodo.",".$idProceso.",'".$usuario."',@msgret";
			try{
				$db = \DB::connection('suitecrm');
				
				\Log::info("CALL sor_procesa_comisiones(".$datos.")");
				$stmt= $db->getpdo()->prepare('CALL `sor_procesa_comisiones`('.$datos.')');
				$stmt->execute();
				\Log::info(" resultado de stmt ".$stmt.")");
				if($stmt->columnCount()>0){
					$resultado=$stmt->fetch(\PDO::FETCH_BOTH);//fetchAll(\PDO::FETCH_CLASS, 'stdClass');	
					\Log::info(" resultado de llamado a sor_procesa_comisiones ".$resultado.")");
					$resultado=$resultado['msgret'];//$resultado[0]->msjret;
					//insertar auditoria
					\DB::disconnect('suitecrm');
					return $resultado;
				}else{
					return 'Problema ejecución stored comisiones.';
				}
				

			}catch(\Exception $e){
				\Log::info("Problema al llamar al stored de procesamiento de comisiones adicionales.");
				\Log::info($e->getMessage());
				return "Problema al llamar al stored de procesamiento de comisiones adicionales.";
			}
		}	
		*/
		
	}
?>