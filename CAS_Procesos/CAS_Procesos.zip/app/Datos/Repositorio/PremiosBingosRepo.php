<?php

	namespace Datos\Repositorio;
	
	class PremiosBingosRepo{
		
		public static function cargarPremioTT($archivo,$idjuego, $idProceso,$usuario,$fechaSorteo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$juego = $idjuego;
				$formatoFecha = '%Y-%m-%d';
				//$formatoFechaHora = '%Y-%m-%d %h:%m:%s';
				$query =sprintf("
					TRUNCATE TABLE `sor_rec_premios_bingos_det` ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_bingos_det`
					FIELDS TERMINATED BY ';'
					LINES TERMINATED BY '\n'
					(@sorteo,@serie,@billete,@idpremio,@premio,@importe,@codigobarras) 
					SET 
					`codigo_provincia`= 22,
					`id_juego`= %s,
					`nro_emision`=@sorteo,
					`serie`=@serie,
					`nro_ticket`=@billete,
					`id_premio`=@idpremio,
					`premio`=@premio,
					`importe`=CAST(@importe AS DECIMAL(18,2)),
					`cod_barras`=@codigobarras,
					`idproceso`= '%s',
					`usuario`= '%s',
					`fecha`= str_to_date('%s', '%s')
					;",
			    	addslashes($archivo),addslashes($juego),addslashes($idProceso),addslashes($usuario),addslashes($fechaSorteo),addslashes($formatoFecha));
			    	// addslashes($archivo),addslashes($juego),addslashes($idProceso),addslashes($usuario),addslashes($fechaSorteo),addslashes($formatoFecha),addslashes($formatoFechaHora));
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga sor_rec_premios_bingos_det TT");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga sor_rec_premios_bingos_det TT");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de premios en la tabla sor_rec_premios_bingos_det");
				\Log::info($e);
				return false;
			}
		}

		/* calamari	*/ 
		
		public static function cargarPremioTK($archivo,$idjuego, $idProceso,$usuario,$fechaSorteo){
			try{
				
				//*********************************************
				//  Limpio la tabla sor_rec_premios_bingos_cab
				//**********************************************
				$query = "TRUNCATE TABLE `sor_rec_premios_bingos_cab`;";
				$db=  \DB::connection('suitecrm');
				$resultado = $db->getpdo()->exec($query);
				
				// //***********************************
				// // Cargo cabecera
				// //***********************************
				$data = file($archivo);
				\Log::info('data',array($data));
				
				$header = $data[0];
				$nrosorteo = substr($header,0,4);
				$cod_provincia = 22;
				$juego = $idjuego;
				unset($data[0]); // elimina fila con numero de sorteo
				unset($data[1]); // "elimina fila con la palabra "categorias"
				
				/* Ejemplo de archivo
CATEGORIAS
1,7479895.00,1,2.00                 
2,5564.00,34,2.00                      
3,245.00,1419,0.00
4,40.00,16895,0.00
5,20.00,87620,0.00
				
categoria, importe, cantidad de ganadores, % para el agenciero
				
				*/
				
				for ($x = 2; $x <= 6; $x++) {
					
					$filacategorias = $data[$x];
					$datos=explode(",",$filacategorias);
					$categoria= $datos[0];
					$importe_premio= $datos[1];
					$cant_ganadores= $datos[2];
					$porc_agenciero= $datos[3];
				
					//insertamos la fila
					$query_h="INSERT INTO sor_rec_premios_bingos_cab(codigo_provincia,id_juego,nro_emision,categoria,importe_premio,cant_ganadores,descrip_premio, porc_agenciero)";
					$query_h.="VALUES('".$cod_provincia."','".$juego."','".$nrosorteo."','".$categoria."',CAST('".$importe_premio."' AS DECIMAL(18,2)),'".$cant_ganadores."','NULL',".$porc_agenciero.");";
					$resultado = $db->getpdo()->exec($query_h);
					unset($data[$x]);
				} 
				
				
				unset($data[7]); 
						
				//***********************************
				// Cargo el trailer en la tabla 
				//***********************************
			
				file_put_contents($archivo, $data);
				
				//********************************************
				// Cargo los datos en la tabla  con el load
				//********************************************
				//$formatoFecha = '%d%m%Y';
				//$formatoFecha2 = '%d%m%Y';
				$id_Proceso = $idProceso;
				$usuario_in = $usuario;
				
				
	    		$query_d =sprintf("
					TRUNCATE TABLE `sor_rec_premios_bingos_det`;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_bingos_det`
					FIELDS TERMINATED BY ','
					LINES TERMINATED BY '\r\n'
					(@ticket,@categoria) 
					SET 
					`codigo_provincia` ='%s',
					`id_juego` ='%s',
					`serie` ='0',
					`nro_emision` ='%s',
					`nro_ticket` =	@ticket,
					`categoria` =	@categoria,
					`idproceso` =	'%s',
					`usuario` =	'%s';",
					addslashes($archivo),addslashes($cod_provincia),addslashes($juego),addslashes($nrosorteo),addslashes($id_Proceso),addslashes($usuario_in));
			    $db = \DB::connection('suitecrm');
				\Log::info("empecé carga sor_rec_premios_bingos_det TK");
	    		$resultado=$db->getpdo()->exec($query_d);
				\Log::info("terminé carga sor_rec_premios_bingos_det TK");
			}catch(\Exception $e){
				$filename = explode('.',$archivo); 
				$filename = $filename[0];
				\Log::info("Recepción premios telekino: Error al cargar el archivo sor_rec_premios_bingos_det");
				\Log::info($e);
				return false;
			}

			return 1;
		}

		
		// MM 20/03/2018 - carga maradona
		
		public static function cargarPremioTM($archivo,$idjuego, $idProceso,$usuario,$fechaSorteo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$juego = $idjuego;
				$formatoFecha = '%Y-%m-%d';
				if(strpos(strtolower($archivo), 'dat')!==false){
					$query =sprintf("
						TRUNCATE TABLE `sor_rec_premios_bingos_det` ;
						LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_bingos_det`
						LINES TERMINATED BY '\n'
						(@registro)
						SET 
						`id_juego`=SUBSTR(@registro,1,3),
						`nro_emision`=SUBSTR(@registro,4,6),
						`nro_ticket`=SUBSTR(@registro,10,10),
						`codigo_provincia`=SUBSTR(@registro,20,2),
						`agente`=SUBSTR(@registro,22,6),
						`categoria`=case when SUBSTR(@registro,28,1) = 'A' then 1 when SUBSTR(@registro,28,1) = 'E' then 9 else null end,
						`id_premio`=SUBSTR(@registro,29,2),
						`importe`=CAST(SUBSTR(@registro,39,11)/100 AS DECIMAL(18,2)),
						`importe_impimponible`=CAST(SUBSTR(@registro,50,11)/100 AS DECIMAL(18,2)),
						`importe_ley20630`=CAST(SUBSTR(@registro,61,11)/100 AS DECIMAL(18,2)),
						`importe_ley23351`=CAST(SUBSTR(@registro,72,11)/100 AS DECIMAL(18,2)),
						`importe_ley11264`=CAST(SUBSTR(@registro,83,11)/100 AS DECIMAL(18,2)),
						`importe_impotros`=CAST(SUBSTR(@registro,94,11)/100 AS DECIMAL(18,2)),
						`cod_barras`=SUBSTR(@registro,105,22),
						`idproceso`= '%s',
						`usuario`= '%s',
						`fecha`= str_to_date('%s', '%s');",
			    	addslashes($archivo),addslashes($idProceso),addslashes($usuario),addslashes($fechaSorteo),addslashes($formatoFecha));

				}else{
					\Log::info("nombre archivo: ",array($archivo));
					$archivodat= md5_file(str_replace(".CTL",".DAT",str_replace("\\", "/", $archivo)));
					//$dato=str_replace(".CTL",".DAT",str_replace("\\", "/", $archivo));
					\Log::info("nombre archivo dato: ",array($archivodat));
					$query =sprintf("
						TRUNCATE TABLE `sor_rec_premios_bingos_ctl` ;
						LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_bingos_ctl`
						LINES TERMINATED BY '\n'
						(@registro)
						SET 
						`id_juego`=SUBSTR(@registro,1,3),
						`nro_emision`=SUBSTR(@registro,4,6),
						`cant_registros`=SUBSTR(@registro,10,10),
						`importe_bruto`=CAST(SUBSTR(@registro,20,13)/100 AS DECIMAL(16,2)),
						`huella_md5`=SUBSTR(@registro,33,32),
						`huella_md5_calculada`='%s';",
				    	addslashes($archivo),addslashes($archivodat));
				}

				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga premios maradona");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga premios maradona");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de premios ret/det en la tabla");
				\Log::info($e);
				return false;
			}
		}
				
		// MM 06/06/2017	- 	carga premios completa
		
		/************************************************/
		/*		carga control premios completo			*/
		/************************************************/
		
		public static function cargarPremiosCompletoControl($archivo, $archivoPremios, $archivoPremiosRet){
			try{	
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculadopre = md5_file($archivoPremios);			
				$md5_calculadoret = md5_file($archivoPremiosRet);			
			
				//obtenemos el contenido del archivo
				$xml = file_get_contents($archivo);
				//instanciamos la clase
				$DOM = new \DOMDocument('1.0', 'utf-8');
				//leemos el contenido de la variable 
				$DOM->loadXML($xml);
				//obtenemos los registros del archivo --> se crea un arreglo con los registros
				$registros = $DOM->getElementsByTagName('Registro');
				//recorremos el arreglo y accedemos a cada nodo y obtenemos el valor
				foreach($registros as $registro){
					$tipo_archivo=$registro->getElementsByTagName('tipo_archivo')->item(0)->nodeValue;			
					$version=$registro->getElementsByTagName('version')->item(0)->nodeValue;
					$nombre_archivoPre=$registro->getElementsByTagName('nombre_archivoPre')->item(0)->nodeValue;
					$nombre_archivoRet=$registro->getElementsByTagName('nombre_archivoRet')->item(0)->nodeValue;
					$provincia=$registro->getElementsByTagName('provincia')->item(0)->nodeValue;
					$secuencia_envio=$registro->getElementsByTagName('secuenciaEnvio')->item(0)->nodeValue;
					$fechaHoraEnvio=$registro->getElementsByTagName('fechaHoraEnvio')->item(0)->nodeValue;
					$cantidadRegistrosPre=$registro->getElementsByTagName('cantidadRegistrosPre')->item(0)->nodeValue;
					$cantidadRegistrosRet=$registro->getElementsByTagName('cantidadRegistrosRet')->item(0)->nodeValue;
					$sumaImportePre=$registro->getElementsByTagName('sumaImportePre')->item(0)->nodeValue;
					$sumaImporteRet=$registro->getElementsByTagName('sumaImporteRet')->item(0)->nodeValue;
					$md5Pre=$registro->getElementsByTagName('md5Pre')->item(0)->nodeValue;
					$md5Ret=$registro->getElementsByTagName('md5Ret')->item(0)->nodeValue;
					//$sistema=$registro->getElementsByTagName('sistema')->item(0)->nodeValue;
					//$cantidad_premios=$registro->getElementsByTagName('cantidad_premios')->item(0)->nodeValue;
				}
			
				//insertamos en la tabla
				$query = 'TRUNCATE TABLE sor_rec_premios_ctrl ; ';
				$query = $query.'insert into sor_rec_premios_ctrl(tipo_archivo, version, nombre_archivoPre, nombre_archivoRet, provincia, secuencia_envio, fechaHoraEnvio, cantidadRegistrosPre, cantidadRegistrosRet, sumaImportePre, sumaImporteRet, md5Pre,md5Ret, md5Pre_calculado, md5Ret_calculado)'
				.'values("'.$tipo_archivo.'",'.$version.',"'.$nombre_archivoPre.'","'.$nombre_archivoRet.'",'.$provincia.','.$secuencia_envio.',"'.$fechaHoraEnvio.'",'.$cantidadRegistrosPre.','.$cantidadRegistrosRet.','.$sumaImportePre.','.$sumaImporteRet.',"'.$md5Pre.'","'.$md5Ret.'","'.$md5_calculadopre.'","'.$md5_calculadoret.'")';
				
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga sor_rec_premios_ctrl");
				$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga sor_rec_premios_ctrl");
				if($db->getPdo()->errorCode()== '00000'){
					return 1;
				}else{
					return 0;
				}
				
				}catch(\Exception $e){
					\Log::info("Error cargando el archivo de premios control en la tabla");
					\Log::info($e);
					return false;
				}
		}
		
		/****************************************/
		/* 		premios liquidados completo		*/
		/****************************************/
		
		public static function cargarPremioCompleto($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					TRUNCATE TABLE `sor_rec_premios` ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`prov_venta`=SUBSTR(@registro,1,2),
					`id_juego`=SUBSTR(@registro,3,3),
					`nro_emision`=SUBSTR(@registro,6,8),
					`nro_ticket`=SUBSTR(@registro,14,10),
					`digito_verificador`=SUBSTR(@registro,24,1),
					`nro_parte_panel`=SUBSTR(@registro,25,3),
					`clase_premio`=SUBSTR(@registro,28,1),
					`tipo_de_premio`=SUBSTR(@registro,29,1),
					`pago_en_agencia`=SUBSTR(@registro,30,1),
					`agente`=SUBSTR(@registro,31,6),
					`subagente`=SUBSTR(@registro,37,3),
					`codigo_provincia`=SUBSTR(@registro,40,2),
					`nro_ticket_OP`=SUBSTR(@registro,42,30),
					`importe_premio`=CAST(SUBSTR(@registro,72,17)/100 AS DECIMAL(18,2)),
					`importe_retenciones`=CAST(SUBSTR(@registro,89,17)/100 AS DECIMAL(18,2)),
					`importe_impneto`=CAST(SUBSTR(@registro,106,17)/100 AS DECIMAL(18,2)),
					`importe_impimponible`=CAST(SUBSTR(@registro,123,17)/100 AS DECIMAL(18,2)),
					`importe_impotros`=CAST(SUBSTR(@registro,140,17)/100 AS DECIMAL(18,2)),
					`tipo_doc`=SUBSTR(@registro,157,4),
					`nro_doc`=SUBSTR(@registro,161,11),
					`codigo_verificacion`=SUBSTR(@registro,172,10);",
			    	addslashes($archivo),addslashes($formatoFecha));
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga sor_rec_premios");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga sor_rec_premios");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de premios en la tabla");
				\Log::info($e);
				return false;
			}
		}		
			

		/********************************************/
		/*		premios retencion completo			*/
		/********************************************/
		
			public static function cargarPremiosCompletoRetDet($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				//if(strpos(strtolower($archivo), 'detall')!==false){
					$query =sprintf("
						TRUNCATE TABLE `sor_rec_premios_detalle` ;
						LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_detalle`
						LINES TERMINATED BY '\n'
						(@registro)
						SET 
						`codigo_provincia`=SUBSTR(@registro,1,2),
						`id_juego`=SUBSTR(@registro,3,3),
						`nro_emision`=SUBSTR(@registro,6,8),
						`nro_ticket`=SUBSTR(@registro,14,10),
						`digito_verificador`=SUBSTR(@registro,24,1),
						`nro_parte_panel`=SUBSTR(@registro,25,3),
						`clase_premio`=SUBSTR(@registro,28,1),
						`tipo_de_premio`=SUBSTR(@registro,29,1),
						`codigo_concepto`=SUBSTR(@registro,30,3),
						`importe`=CAST(SUBSTR(@registro,33,17)/100 AS DECIMAL(18,2));",
				    	addslashes($archivo));
				/*
				}else{
					$query =sprintf("
						TRUNCATE TABLE `sor_rec_premios_ret` ;
						LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_ret`
						LINES TERMINATED BY '\n'
						(@registro)
						SET 
						`id_juego`=SUBSTR(@registro,1,2),
						`nro_emision`=SUBSTR(@registro,3,8),
						`id_juego_asociado`=SUBSTR(@registro,11,2),
						`nro_emision_asociada`=SUBSTR(@registro,13,8),
						`codigo_provincia`=SUBSTR(@registro,21,2),
						`nro_ticket`=SUBSTR(@registro,23,10),
						`clase_premio`=SUBSTR(@registro,33,1),
						`codigo_concepto`=SUBSTR(@registro,34,3),
						`importe`=SUBSTR(@registro,37,13);",
				    	addslashes($archivo));
				}
				*/
				
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga pre_det_ret");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga pre_det_ret");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de premios ret/det en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		/************************************		MM 06/06/2017	********************/				
		public static function cargarPremiosControl($archivo, $archivoPremios){
			try{	
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoPremios);			
			
				//obtenemos el contenido del archivo
				$xml = file_get_contents($archivo);
				//instanciamos la clase
				$DOM = new \DOMDocument('1.0', 'utf-8');
				//leemos el contenido de la variable 
				$DOM->loadXML($xml);
				//obtenemos los registros del archivo --> se crea un arreglo con los registros
				$registros = $DOM->getElementsByTagName('Registro');
				//recorremos el arreglo y accedemos a cada nodo y obtenemos el valor
				foreach($registros as $registro){
					$tipo_archivo=$registro->getElementsByTagName('tipo_archivo')->item(0)->nodeValue;			
					$version=$registro->getElementsByTagName('version')->item(0)->nodeValue;
					$nombre_archivo=$registro->getElementsByTagName('nombre_archivo')->item(0)->nodeValue;
					$provincia=$registro->getElementsByTagName('provincia')->item(0)->nodeValue;
					$juego=$registro->getElementsByTagName('juego')->item(0)->nodeValue;
					$sorteo=$registro->getElementsByTagName('sorteo')->item(0)->nodeValue;
					$sistema=$registro->getElementsByTagName('sistema')->item(0)->nodeValue;
					$cantidad_premios=$registro->getElementsByTagName('cantidad_premios')->item(0)->nodeValue;
					$importe_premios=$registro->getElementsByTagName('importe_premios')->item(0)->nodeValue;
					$importe_impuesto=$registro->getElementsByTagName('importe_impuesto')->item(0)->nodeValue;
					$md5_archivo=$registro->getElementsByTagName('md5')->item(0)->nodeValue;
				}
			
				//insertamos en la tabla
				$query = 'TRUNCATE TABLE sor_rec_pre_ctr ; ';
				$query =$query.'insert into sor_rec_pre_ctr(tipo_archivo, version, nombre_archivo, provincia, juego, sorteo, sistema, cantidad_premios, importe_premios, importe_impuesto, md5_archivo, md5_calculado)'
				.'values("'.$tipo_archivo.'",'.$version.',"'.$nombre_archivo.'",'.$provincia.','.$juego.','.$sorteo.','.$sistema.','.$cantidad_premios.','.$importe_premios.','.$importe_impuesto.',"'.$md5_archivo.'","'.$md5_calculado.'")';
				
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga pre_ctrl");
				$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga pre_ctrl");
				if($db->getPdo()->errorCode()== '00000'){
					return 1;
				}else{
					return 0;
				}
				
				}catch(\Exception $e){
					\Log::info("Error cargando el archivo de premios control en la tabla");
					\Log::info($e);
					return false;
				}
		}

		

		/******************************************************************
		* Funciones para carga de archivos de premios detalle y retención *
		*******************************************************************/
		public static function cargarPremiosRetencionControl($archivo, $archivoDR, $sobreEscribir){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoDR);
				\Log::info("empecé carga pre_ret");
				//tabla en la que se cargará
				$tabla='';
				if($sobreEscribir==1){
					//guardo el contenido del archivo
					$f=file($archivo);
					//reemplazo lo que sea necesario				
					$final = count($f);
					$nuevoContenido=[];				
					for($x=0; $x<=$final;$x++){
						if($x==0){
							array_push($nuevoContenido, '<?xml version="1.0" encoding="Windows-1252" standalone="yes"?>');
						}else if($x==1){
							array_push($nuevoContenido, '<Raiz>');					
							array_push($nuevoContenido, $f[$x]);
						}else if($x==$final){
							array_push($nuevoContenido, '</Datos>');//agregado para prueba
							array_push($nuevoContenido, '</Raiz>');
						}else if($x<$final-1){
							array_push($nuevoContenido, $f[$x]);						
						}
					}
					
					$contenido=implode("", $nuevoContenido);
					$fp = fopen($archivo, 'w');
					fwrite($fp, $contenido);
					fclose($fp);
				}
				
				//obtenemos el contenido del archivo
				$xml = file_get_contents($archivo);
				//instanciamos la clase
				$DOM = new \DOMDocument('1.0', 'utf-8');
				//leemos el contenido de la variable 
				$DOM->loadXML($xml);

				//obtenemos los registros del archivo --> se crea un arreglo con los registros
				$registros = $DOM->getElementsByTagName('Registro');
				//recorremos el arreglo y accedemos a cada nodo y obtenemos el valor
				$db=  \DB::connection('suitecrm');		
				foreach($registros as $registro){
					$tipo_archivo=$registro->getElementsByTagName('tipo_archivo')->item(0)->nodeValue;			

					$version=$registro->getElementsByTagName('version')->item(0)->nodeValue;
					$nombre_archivo=$registro->getElementsByTagName('nombre_archivo')->item(0)->nodeValue;
					$juego=$registro->getElementsByTagName('juego')->item(0)->nodeValue;
					$sorteo=$registro->getElementsByTagName('sorteo')->item(0)->nodeValue;
					$cantidad_registros=$registro->getElementsByTagName('cantidad_registros')->item(0)->nodeValue;
					$md5_archivo=$registro->getElementsByTagName('md5')->item(0)->nodeValue;				
			
					if(strcasecmp(strtoupper($tipo_archivo),'DETALLE')==0 && strpos(strtoupper($archivoDR),'DETALL')!==false){
						$tabla='sor_rec_premios_det_ctr';
						//insertamos en la tabla
						$query = sprintf('TRUNCATE TABLE %s; ',$tabla);
						$query =sprintf($query.'insert into %s(tipo_archivo, version, nombre_archivo, juego, sorteo, cantidad_registros,  md5_archivo, md5_calculado)'
						.'values("'.$tipo_archivo.'",'.$version.',"'.$nombre_archivo.'",'.$juego.','.$sorteo.','.$cantidad_registros.',"'.$md5_archivo.'","'.$md5_calculado.'")',$tabla);
						$resultado=$db->getpdo()->exec($query);
					}else if(strcasecmp(strtoupper($tipo_archivo),'RETENCION')==0 && strpos(strtoupper($archivoDR),'RETEN')!==false){
						$tabla='sor_rec_premios_ret_ctr';
						//insertamos en la tabla
						$query = sprintf('TRUNCATE TABLE %s; ',$tabla);
						$query =sprintf($query.'insert into %s(tipo_archivo, version, nombre_archivo, juego, sorteo, cantidad_registros,  md5_archivo, md5_calculado)'
						.'values("'.$tipo_archivo.'",'.$version.',"'.$nombre_archivo.'",'.$juego.','.$sorteo.','.$cantidad_registros.',"'.$md5_archivo.'","'.$md5_calculado.'")',$tabla);
						$resultado=$db->getpdo()->exec($query);
					}
				}
				\Log::info("terminé carga pre_ret");
				if($db->getPdo()->errorCode()== '00000'){
					return 1;
				}else{
					return 0;
				}
				
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de premios control detalle/retención en las tablas");
				\Log::info($e);
				return false;
			}
		}

		public static function cargarPremiosRetDet($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				if(strpos(strtolower($archivo), 'detall')!==false){
					$query =sprintf("
						TRUNCATE TABLE `sor_rec_premios_det` ;
						LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_det`
						LINES TERMINATED BY '\n'
						(@registro)
						SET 
						`id_juego`=SUBSTR(@registro,1,2),
						`nro_emision`=SUBSTR(@registro,3,8),
						`id_juego_asociado`=SUBSTR(@registro,11,2),
						`nro_emision_asociada`=SUBSTR(@registro,13,8),
						`fecha_sorteo`=SUBSTR(@registro,21,8),
						`fecha_proceso`=SUBSTR(@registro,29,8),
						`codigo_provincia`=SUBSTR(@registro,37,2),
						`nro_ticket`=SUBSTR(@registro,39,10),
						`clase_premio`=SUBSTR(@registro,49,1),
						`importe_premio`=SUBSTR(@registro,50,13),
						`tipo_de_premio`=SUBSTR(@registro,63,2),
						`agente`=SUBSTR(@registro,65,5),
						`subagente`=SUBSTR(@registro,70,3),
						`ambulante`=SUBSTR(@registro,73,3),
						`tipo_doc`=SUBSTR(@registro,76,1),
						`nro_doc`=SUBSTR(@registro,77,9),
						`pago_en_agencia`=SUBSTR(@registro,86,1),
						`codigo_verificacion`=SUBSTR(@registro,87,6);",
				    	addslashes($archivo));

				}else{
					$query =sprintf("
						TRUNCATE TABLE `sor_rec_premios_ret` ;
						LOAD DATA INFILE '%s' INTO TABLE `sor_rec_premios_ret`
						LINES TERMINATED BY '\n'
						(@registro)
						SET 
						`id_juego`=SUBSTR(@registro,1,2),
						`nro_emision`=SUBSTR(@registro,3,8),
						`id_juego_asociado`=SUBSTR(@registro,11,2),
						`nro_emision_asociada`=SUBSTR(@registro,13,8),
						`codigo_provincia`=SUBSTR(@registro,21,2),
						`nro_ticket`=SUBSTR(@registro,23,10),
						`clase_premio`=SUBSTR(@registro,33,1),
						`codigo_concepto`=SUBSTR(@registro,34,3),
						`importe`=SUBSTR(@registro,37,13);",
				    	addslashes($archivo));
				}

				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga pre_det_ret");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga pre_det_ret");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de premios ret/det en la tabla");
				\Log::info($e);
				return false;
			}
		}
		

		/******** PARA ZIPEADOS ***********/
		public static function cargarPremiosRetencionControlContenedor($archivo, $archivoDR){
			return 1;
		}
}
?>