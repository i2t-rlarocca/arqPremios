<?php

	namespace Datos\Repositorio;
	
	class ResultadosRepo{
		//resultado control	
		public static function cargarResultadosControl($archivo, $archivoResultados){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoResultados);
				$query =sprintf("
					TRUNCATE TABLE sor_rec_resultados_ctr ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_resultados_ctr`
					CHARACTER SET binary
					FIELDS TERMINATED BY '%s'
					LINES STARTING BY '<Registro>' TERMINATED BY '</Registro>'
					(@registro)
					SET
						`tipo_archivo`= ExtractValue(@registro, 'tipo_archivo'),
			            `version`= ExtractValue(@registro, 'version'),
			            `nombre_archivo`= ExtractValue(@registro, 'nombre_archivo'),
			            `provincia`= ExtractValue(@registro, 'provincia'),
			            `juego`= ExtractValue(@registro, 'juego'),
			            `sorteo`= ExtractValue(@registro, 'sorteo'),
			            `cantidad_registros`= ExtractValue(@registro, 'cantidad_registros'),
			            `md5_archivo`= ExtractValue(@registro, 'md5'),
			            `md5_calculado`='%s';",
			    		addslashes($archivo),addslashes("\\t"), addslashes($md5_calculado));

	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga res_ctrl");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga res_ctrl");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de resultados control en la tabla");
				\Log::info($e);
				return false;
			}
		}

		//resultado 	
		public static function cargarResultados($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$query =sprintf("
					TRUNCATE TABLE `sor_rec_resultados` ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_resultados`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`codigo_juego`=SUBSTR(@registro,1,2),
					`sorteo`=SUBSTR(@registro,3,6),
					`modalidad`=SUBSTR(@registro,9,2),
					`codigo_premio`=SUBSTR(@registro,11,7),
					`importe_pozo`=SUBSTR(@registro,18,17),
					`cantidad_ganadores`=SUBSTR(@registro,35,6),
					`importe_premio`=SUBSTR(@registro,41,17),
					`vacante`=SUBSTR(@registro,58,1),
					`cantidad_apuestas`=SUBSTR(@registro,59,9),
					`importe_pozo_real`=SUBSTR(@registro,68,17);",
			    	addslashes($archivo));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga res");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga res");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de resultados en la tabla");
				\Log::info($e);
				return false;
			}
		}

		//sueldos control
		public static function cargarSueldosControl($archivo, $archivoSueldos){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoSueldos);
			
				$query =sprintf("
					TRUNCATE TABLE sor_rec_resultados_sue_ctr ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_resultados_sue_ctr`
					CHARACTER SET binary
					FIELDS TERMINATED BY '%s'
					LINES STARTING BY '<Registro>' TERMINATED BY '</Registro>'
					(@registro)
					SET
						`tipo_archivo`= ExtractValue(@registro, 'tipo_archivo'),
			            `version`= ExtractValue(@registro, 'version'),
			            `nombre_archivo`= ExtractValue(@registro, 'nombre_archivo'),
			            `provincia`= ExtractValue(@registro, 'provincia'),
			            `juego`= ExtractValue(@registro, 'juego'),
			            `sorteo`= ExtractValue(@registro, 'sorteo'),
			            `cantidad_registros`= ExtractValue(@registro, 'cantidad_registros'),
			            `md5_archivo`= ExtractValue(@registro, 'md5'),
			            `md5_calculado`='%s';",
			    		addslashes($archivo),addslashes("\\t"), addslashes($md5_calculado));
	    		$db=\DB::connection('suitecrm');
				\Log::info("empecé carga sue_ctrl");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga sue_ctrl");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de sueldos control en la tabla");
				\Log::info($e);
				return false;
			}
		}

		//sueldos 	
		public static function cargarSueldos($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$query =sprintf("
					TRUNCATE TABLE `sor_rec_resultados_sue` ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_resultados_sue`
					CHARACTER SET latin1
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`tipo_registro`=SUBSTR(@registro,1,2),
					`orden`=SUBSTR(@registro,3,2),
					`agente`=SUBSTR(@registro,5,7),
					`subagente`=SUBSTR(@registro,12,3),
					`vendedor`=SUBSTR(@registro,15,3),
					`razon_social`=  REPLACE(CONVERT(CAST(SUBSTR(@registro,18,50) AS BINARY) USING latin1),'¡','Í'),
					`ticket`=SUBSTR(@registro,68,30),
					`localidad`=SUBSTR(@registro,98,50),
					`provincia`=SUBSTR(@registro,148,50);",
			    	addslashes($archivo));
				\Log::info("queryyyyy", array($query));
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga sue");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga sue");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de resultados en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		//extractos control
		public static function cargarExtractosControl($archivo, $archivoExtractos){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoExtractos);
			
				$query =sprintf("
					TRUNCATE TABLE sor_extractos_control ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_extractos_control`
					CHARACTER SET binary
					FIELDS TERMINATED BY '%s'
					LINES STARTING BY '<Registro>' TERMINATED BY '</Registro>'
					(@registro)
					SET
						`tipo_archivo`= ExtractValue(@registro, 'tipo_archivo'),
			            `version`= ExtractValue(@registro, 'version'),
			            `nombre_archivo`= ExtractValue(@registro, 'nombre_archivo'),
			            `provincia`= ExtractValue(@registro, 'provincia'),
			            `juego`= ExtractValue(@registro, 'juego'),
			            `sorteo`= ExtractValue(@registro, 'sorteo'),
			            `cantidad_registros`= ExtractValue(@registro, 'cantidad_registros'),
			            `md5_archivo`= ExtractValue(@registro, 'md5'),
			            `md5_calculado`='%s';",
			    		addslashes($archivo),addslashes("\\t"), addslashes($md5_calculado));
	    		$db=\DB::connection('suitecrm');
				\Log::info("empecé carga ext_ctrl");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga ext_ctrl");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de extractos control en la tabla");
				\Log::info($e);
				return false;
			}
		}

		//extractos 	
		public static function cargarExtractos($archivo,$idpgmsorteo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$query =sprintf("
					TRUNCATE TABLE `sor_extractos_datos` ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_extractos_datos`
					LINES TERMINATED BY '\r\n'
					(@registro)
					SET 
					`idpgmsorteo`=%d,
					`datos`=@registro;",
			    	addslashes($archivo), addslashes($idpgmsorteo));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga ext");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga ext");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de resultados en la tabla");
				\Log::info($e);
				return false;
			}
		}

		/**********************************************************
		* Llamada al stored para validar los resultados(premios). *
		***********************************************************/
		public static function validaResultados($idProceso,$juego, $sorteo, &$mensaje, $idEstado, $usuario){
			$datos = $idProceso.','.$juego.','.$sorteo.',"'.$usuario.'",'.$idEstado.",@mensaje";
			//$ok = \DB::connection('suitecrm')->select(\DB::raw('CALL `sor_valida_resultados`('.$datos.');'));
			//$mensaje=$ok[0]->mensaje;	
			/*if(strcasecmp($mensaje, 'OK')==0){
				return 1;
			}else{
				return 0;			
			}*/
			$db=\DB::connection('suitecrm');
			\Log::info("Llama SOR_VALIDA_RESULTADOS", array($datos));

			$stmt= $db->getpdo()->prepare('CALL `sor_valida_resultados`('.$datos.')');
			$stmt->execute();
			//\Log::info("ResultadosRepo.php - validaResultados - stmt ->$stmt<-");
			\Log::info("ResultadosRepo.php - resultado-mensaje -> ",array($stmt));
			if($stmt->columnCount()>0){
				$resultado=$stmt->fetch(\PDO::FETCH_BOTH);
				$mensaje=$resultado['mensaje'];
				//\Log::info("ResultadosRepo.php - resultado-mensaje ->$resultado['mensaje']<-");
				\Log::info("ResultadosRepo.php - resultado-mensaje -> ",array($resultado['mensaje']));
				\DB::disconnect('suitecrm');
				return 1;
			}else{
				return 0;
			}
		}

		/**********************************************************
		* Llamada al stored para validar los resultados(sueldos). *
		***********************************************************/
		public static function validaSueldos($nro,$juego, $sorteo, &$mensaje, $usuario, $idEstado){
			$datos = $nro.','.$juego.','.$sorteo.',"'.$usuario.'",'.$idEstado;
			$query='CALL `sor_valida_sueldos`('.$datos.');';
			$conexion=\DB::connection('suitecrm');
			//$ok = $conexion->getpdo()->prepare($query);
			//$ok->execute();
			$ok=$conexion->select(\DB::raw($query));
			if(count($ok)>0){
				\log::info($ok->fetch(\PDO::FETCH_ASSOC));
				$mensaje=$ok[0]->mensaje;
			}else{
				$mensaje='OK';
			}
			if(strcasecmp($mensaje, 'OK')==0){
				return 1;
			}else{
				return 0;			
			}
		}

	}
?>