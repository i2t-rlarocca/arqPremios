<?php

	namespace Datos\Repositorio;
	
	class ExportacionesRepo{


// BCF0014 codigos juegos
		
		/*********************************************
		* 			consultaTipoExportacion		 *
		**********************************************/

		public static function consultaTipoExportacion($tipo_proceso){
			$db=\DB::connection('suitecrm');
			// cambiar la consulta una vez conocida la tabla que guardará la ultima secuencia
			$resultado = $db->select(\DB::raw('SELECT   
												  NAME,
												  date_entered,
												  date_modified,
												  modified_user_id,
												  created_by,
												  description,
												  assigned_user_id,
												  cmps_sql,
												  cmps_label,
												  cmps_tipo_sql,
												  paq_tipo,
												  paq_cant_archivos,
												  paq_fmt_nombre,
												  paq_ult_envio,
												  paq_path,
												  paq_mail_remite,
												  paq_mail_destino,
												  paq_mail_asunto,
												  paq_mail_cuerpo,
												  mail_remite,
												  mail_destino,
												  aud_etapa,
												  paq_cant_lst,
												  titulo
											FROM exp_exportacion_tipo
											WHERE NAME = "'.$tipo_proceso.'" and deleted = 0;'));
			//$resultado = $db->select(\DB::raw('SELECT null AS sec_esp FROM rec_ccf0306'));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				return $resultado;
			}else{
				return null;
			}
		}
	
	
		/*********************************************
		* 			EjecutaSP		 *
		**********************************************/

		public static function EjecutaSP($sql){
			$db=\DB::connection('suitecrm');
			// cambiar la consulta una vez conocida la tabla que guardará la ultima secuencia
			$resultado = $db->select(\DB::raw($sql));
			//$resultado = $db->select(\DB::raw('SELECT null AS sec_esp FROM rec_ccf0306'));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				return $resultado;
			}else{
				return null;
			}
		}

		
		/*********************************************
		* 			EjecutaSQL				 *
		**********************************************/
		
		public static function EjecutaSQL($sql){
			$db=\DB::connection('suitecrm');
			// cambiar la consulta una vez conocida la tabla que guardará la ultima secuencia
			$resultado = $db->select(\DB::raw($sql));
			//$resultado = $db->select(\DB::raw('SELECT null AS sec_esp FROM rec_ccf0306'));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				return $resultado;
			}else{
				return null;
			}
		}
		
		
		

		/*********************************************
		* 	ConsultaPaquetesExportacion			 *
		**********************************************/

		public static function ConsultaPaquetesExportacion($nombre_exportacion){
			$db=\DB::connection('suitecrm');
			// cambiar la consulta una vez conocida la tabla que guardará la ultima secuencia
			$resultado = $db->select(\DB::raw('SELECT distinct envio AS paquete, fec_fin AS fecha, paq_nombre, paq_path AS descargar, paq_mail_destino 
												FROM exp_exportacion_ejecucion 
												WHERE fec_fin is not null and  paq_nombre like "'.$nombre_exportacion.'%" and deleted = 0 order by date_entered desc,fec_fin desc , envio desc'));
			//$resultado = $db->select(\DB::raw('SELECT null AS sec_esp FROM rec_ccf0306'));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				return $resultado;
			}else{
				return null;
			}
		}
		
		/*********************************************
		* 	validar PrcExp_CrearSP	va al procedimiento almacenado EXP_MANUALES_BOLDT_GET_PAQUETE				 *
		**********************************************/
		
		public static function PrcExp_CrearSP($nombre_exportacion){
					
			$datos='"'.$nombre_exportacion.'",@envio,@paq_nombre,@paq_path,@msgRet';
			\Log::info('datos - PrcExp_CrearSP',array($datos));
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL EXP_'.$nombre_exportacion.'_GET_PAQUETE('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @envio as envio,@paq_nombre as paq_nombre,@paq_path as paq_path,@msgRet as msgret'));
			\Log::info('ok - PrcExp_CrearSP',array($ok));
			return $ok;
		}

		/*********************************************
		* 	inserta estado nuevo							 *
		**********************************************/
		
				
		public static function InsertPrcExpNuevo($nombre_proceso,$id_ejec_proc,$id_auditoria,$id_exp_tipo,$paq_path,$mail_destino_paq,$envio){
			
			try{
				$db=\DB::connection('suitecrm');
				$query="INSERT INTO exp_exportacion_ejecucion(id, NAME, date_entered, date_modified,deleted, exp_exportacion_tipo_id_c,sor_aud_consolidacion_id_c, envio, estado, fec_ini,hor_ini,paq_nombre,paq_path,paq_mail_destino)";
				$query.='VALUES ("'.$id_ejec_proc.'","'.$nombre_proceso.' - '.$envio.'", NOW(),NOW(), 0, "'.$id_exp_tipo.'","'.$id_auditoria.'","'.$envio.'","Nuevo", CURDATE(), DATE_FORMAT(NOW(), "%T"),"'.$nombre_proceso.'","'.$paq_path.'", "'.$mail_destino_paq.'");';
				
				$resultadoINSERT=$db->getpdo()->exec($query);	
				
				if(count($resultadoINSERT)>0){
					//$db=\DB::connection('suitecrm');
					$query="INSERT INTO exp_exportacion_tipo_exp_exportacion_ejecucion_c(id, date_modified, deleted, exp_export9328on_tipo_ida, exp_exportb2d0ecucion_idb)";
					$query.='VALUES (uuid(), NOW(), 0, "'.$id_exp_tipo.'","'.$id_ejec_proc.'");';
					
					$resultadoINSERT=$db->getpdo()->exec($query);	
					\DB::disconnect('suitecrm');				
					return true;
				}else{
					\DB::disconnect('suitecrm');
					return null;
				}
			}catch(\Exception $e){
				\Log::info("Error realizando insert estado Nuevo en tabla exp_exportacion_ejecucion");
				\Log::info($e);
				return false;
			}
		}
		
		
		/*************************************************
		* 	Elimina proceso sin registros para exportar	 *
		*************************************************/
		public static function DeletePrcExpNuevo($id_ejecucion){
			try{
				$db = \DB::connection('suitecrm');
				$query = "DELETE FROM exp_exportacion_ejecucion WHERE id = '".$id_ejecucion."'";
				//$query.='VALUES ("'.$id_ejec_proc.'","'.$nombre_proceso.'", NOW(),NOW(), 0, "'.$id_exp_tipo.'","'.$id_auditoria.'","'.$envio.'","Nuevo", CURDATE(), DATE_FORMAT(NOW(), "%T"),"'.$nombre_proceso.'","'.$paq_path.'", "'.$mail_destino_paq.'");';
				
				$resultadoDELETE = $db->getpdo()->exec($query);	
				
				if(count($resultadoDELETE)>0){
					$query = "DELETE FROM exp_exportacion_tipo_exp_exportacion_ejecucion_c WHERE exp_exportb2d0ecucion_idb NOT IN (SELECT id FROM exp_exportacion_ejecucion);";
					$resultadoDELETE = $db->getpdo()->exec($query);	
					\DB::disconnect('suitecrm');
					return true;
				}else{
					\DB::disconnect('suitecrm');
					return null;
				}
			}catch(\Exception $e){
				\Log::info("Error realizando delete estado Nuevo en tabla exp_exportacion_ejecucion");
				\Log::info($e);
				return false;
			}
		}
		
		/*********************************************
		* 	PrcExp_ObtenerLstArchivos			 *
		**********************************************/

		public static function PrcExp_ObtenerLstArchivos($nombre_exportacion){
			\Log::info('RR-ExportacionesRepo - PrcExp_ObtenerLstArchivos - nombre_exportacion',array($nombre_exportacion));
			$db=\DB::connection('suitecrm');
			// cambiar la consulta una vez conocida la tabla que guardará la ultima secuencia
			$resultado = $db->select(\DB::raw('SELECT 	ea.id, 
														ea.name as nombre_archivo, 
														ea.fmt_nombre as formato_nombre_archivo, 
														ea.fmt_nombre_ctrl as formato_nombre_arch_ctrl,
														ea.tipo_huella as huella,
														ea.tipo_sql as tipo_comando , 
														ea.sql_arch_datos as sentencia,
														COALESCE(ee.id,et.paq_ult_envio) AS id_exp_eje
												FROM  exp_exportacion_tipo et
												inner join exp_exportacion_archivo ea on ea.exp_exportacion_tipo_id_c = et.id AND ea.deleted = 0
												LEFT JOIN (SELECT eje.envio AS id, eje.NAME,eje.exp_exportacion_tipo_id_c AS exp_exportacion_tipo_id_c, MAX(eje.date_entered) 
															FROM exp_exportacion_ejecucion eje 
															WHERE  eje.deleted = 0 and eje.name = "'.$nombre_exportacion.'" AND eje.envio != ""
															
															)ee ON ee.exp_exportacion_tipo_id_c = et.id 
												WHERE et.name = "'.$nombre_exportacion.'" and et.deleted = 0'));
			//$resultado = $db->select(\DB::raw('SELECT null AS sec_esp FROM rec_ccf0306'));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				return $resultado;
			}else{
				return null;
			}
		}
		
		/*********************************************
		* 	PrcExp_ObtenerLstArchivos2 va al procedimiento almacenado 	EXP_MANUALES_BOLDT_GET_ARCHIVO				 *
		**********************************************/
		
		public static function PrcExp_ObtenerLstArchivos2($nombre_exportacion,$id_ejecucion, $id_archivo){
			// funciona
	
			$db=\DB::connection('suitecrm');
			$datos="'".$id_ejecucion."','".$id_archivo."',@nom_archivo,@nom_archivo_ctrl,@path_archivo,@msgRet";
			
			\DB::connection('suitecrm')->statement('CALL EXP_'.$nombre_exportacion.'_GET_ARCHIVO('.$datos.')');
			$ok= \DB::connection('suitecrm')->select('SELECT @nom_archivo as nom_archivo,@nom_archivo_ctrl as nom_archivo_ctrl,@path_archivo as path_archivo,@msgRet as msgret');
			\DB::disconnect('suitecrm');
			// \Log::info('ok - PrcExp_ObtenerLstArchivos2',array($ok));
			return $ok;
		}
		
		
		/*********************************************
		* 	PrcExp_ObtenerRegistros 	EXP_MANUALES_BOLDT_GET_REGISTROS				 *
		**********************************************/
		
		public static function PrcExp_ObtenerRegistros($nombre_exportacion,$id_ejecucion, $id_archivo, $opc, $huella){
	
		\Log::info('PrcExp_ObtenerRegistros - nombre_exportacion: ',array($nombre_exportacion));
			$ok = '';
			$datos = '';
			$query = '';
			$pdo=\DB::connection('suitecrm')->getPdo();
			$datos="'".$id_ejecucion."','".$id_archivo."', '".$opc."','".$huella."',@registro,@msgRet";
			$query = 'CALL EXP_'.$nombre_exportacion.'_GET_REGISTROS('.$datos.')';
	
	\Log::info('PrcExp_ObtenerRegistros - query: ',array($query));
			\DB::connection('suitecrm')->statement($query);
			$okk = \DB::connection('suitecrm')->select(\DB::raw($query));

	\Log::info('okk - PrcExp_ObtenerRegistros',array($query));
			$mensaje=$okk;
			$ok= \DB::connection('suitecrm')->select('SELECT @registro as registro,@msgRet as msgret');
			\DB::disconnect('suitecrm');

			return $mensaje;
		}	
	
		/*********************************************
		* 	PrcExp_ObtenerRegistrosCtrl 	EXP_MANUALES_BOLDT_GET_REGISTROS				 *
		**********************************************/
		
		public static function PrcExp_ObtenerRegistrosCtrl($nombre_exportacion,$id_ejecucion, $id_archivo, $opc, $huella){
			$ok = '';
			$datos = '';
			$query = '';
			$pdo=\DB::connection('suitecrm')->getPdo();
			$datos="'".$id_ejecucion."','".$id_archivo."', '".$opc."','".$huella."',@registro,@msgRet";
			$query = 'CALL EXP_'.$nombre_exportacion.'_GET_REGISTROS('.$datos.')';
	\Log::info('query PrcExp_ObtenerRegistrosCtrl',array($query));
			\DB::connection('suitecrm')->statement($query);
			$okk = \DB::connection('suitecrm')->select(\DB::raw($query));
			//$okk = $okk->fetchall();
	\Log::info('okk - PrcExp_ObtenerRegistrosCtrl',array($okk));
			$mensaje=$okk;
			$ok= \DB::connection('suitecrm')->select('SELECT @registro as registro,@msgRet as msgret');
			//\Log::info('ok',array($ok));
			\DB::disconnect('suitecrm');
			// \Log::info('***ACA fin ok PrcExp_ObtenerRegistros ',array($mensaje));
			return $mensaje;
		}
			
			

		/*********************************************
		* 	PrcExp_ObtenerRegistros 	EXP_ENVIA_UIF_GET_REGISTROS				 *
		**********************************************/
		
		public static function PrcExp_ObtenerRegistrosUIF($nombre_exportacion,$id_ejecucion, $id_archivo, $opc, $huella){
			/*
			$datos="'".$id_ejecucion."','".$id_archivo."', '".$opc."','".$huella."',@msgRet";
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL EXP_'.$nombre_exportacion.'_GET_REGISTROS('.$datos.')'));
			$ok= \DB::connection('suitecrm')->getPdo();
			$ok= \DB::connection('suitecrm')->select(\DB::raw('SELECT @nom_archivo as nom_archivo,@nom_archivo_ctrl as nom_archivo_ctrl,@path_archivo as path_archivo,@msgRet as msgret'));
			//$ok=PDOStatement::fetchAll();
			\DB::disconnect('suitecrm');
			//$ok = $ok->fetchAll(PDO::FETCH_OBJ);
			return $ok;
			*/
			/*
			$db=\DB::connection('suitecrm');
			$datos="'".$id_ejecucion."','".$id_archivo."', '".$opc."','".$huella."',@registro,@msgRet";
			$query = 'CALL EXP_'.$nombre_exportacion.'_GET_REGISTROS('.$datos.')';
			\DB::connection('suitecrm')->statement($query);
			$ok= \DB::connection('suitecrm')->select('SELECT @registro as registro,@msgRet as msgret');
			\DB::disconnect('suitecrm');
			*/
			//\Log::info('***ACA entro a PrcExp_ObtenerRegistros de la uif');
			$ok = '';
			$stmt = '';
			$datos = '';
			$query = '';
			//$pdo = DB::connection()->getPdo();
			$pdo=\DB::connection('suitecrm')->getPdo();
			$datos="'".$id_ejecucion."','".$id_archivo."', '".$opc."','".$huella."',@registro,@msgRet";
			$query = 'CALL EXP_'.$nombre_exportacion.'_GET_REGISTROS('.$datos.')';
			$stmt = $pdo->prepare($query);
			
			\DB::connection('suitecrm')->statement($query);
			$ok= \DB::connection('suitecrm')->select('SELECT @registro as registro,@msgRet as msgret');
			\Log::info('ok',array($ok));
			$stmt->bindParam(1, $ok);
			//$stmt->bindParam(2, $ok);
			$stmt->execute();
			// $stmt->bindColumn(3, $ok);
			// esto trae el select con los resultados y no produce error, falta trabajarlo un poco ya que obtiene más resultados de los que se esperan.
			//para enviar esto, habría que crear un arreglo con campo de error->ok y campo datos->resultados
			$result = $stmt->fetchall();
			\Log::info('result',array($result));
			
			/*
			// RL: ejemplo de inspeccion del conj de resultados devuelto
			//saco el numero de elementos
			$longitud = count($result);
			//Recorro todos los elementos
			$i = 0;
			$j = 0;
			foreach($result as $r) {
				$i++;
				$h = $r;
				$xx = is_array($h) ? 'Es un array' : 'No es un array';
				\Log::info(" xx ",array($xx));
				if ($xx == 'Es un array') {
					\Log::info("elemento $i",$h);
					 $long = count($xx);
					 \Log::info(" longitud del array ",array($long));
					 $j = 0;
					 foreach($h as $hh) {
						 $j++;
					 //for($j=0; $j<=$long; $j++) {
						 \Log::info("campo$j de result[$i]",array($hh));
					}		
				}
				else {
					\Log::info("elemento $i",array($h));
					}
			}
			*/
			/*
			for($i=0; $i<$longitud; $i++)
			{
				$h = $result[$i];
				
				
				$xx = is_array($h) ? 'Es un array' : 'No es un array';
				\Log::info(" xx ",array($xx));
				if ($xx == 'Es un array') {
					\Log::info("elemento $i",$h);
					 $long = count($xx);
					 \Log::info(" longitud del array ",array($long));
					 for($j=0; $j<=$long; $j++) {
						 $k = $j+1;
						 \Log::info("campo$k de result[$i]",array($h[$j]));
					}		
					 
				}
				else {
					\Log::info("elemento $i",array($h));
					}
				
				//\Log::info("elemento $i",array((count($result[$i]))));
				
			}
			*/
			// FIN RL: ejemplo de inspeccion del conj de resultados devuelto
			//return $out; //that's output
			
			\DB::disconnect('suitecrm');
			
			return $ok;

		}
		
		
		
		
		
		/*********************************************
		* 	GeneraIdProc						 *
		**********************************************/
		
		public static function GeneraIdProc(){
			$db=\DB::connection('suitecrm');
			// cambiar la consulta una vez conocida la tabla que guardará la ultima secuencia
			$resultado = $db->select(\DB::raw('SELECT 	uuid() as id_proceso;'));
			//$resultado = $db->select(\DB::raw('SELECT null AS sec_esp FROM rec_ccf0306'));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				return $resultado;
			}else{
				return null;
			}
		}
		
		/*********************************************
		* 	validar agencia							 *
		**********************************************/
		
		public static function TraeIdAuditoria(){
			$db=\DB::connection('suitecrm');
			// cambiar la consulta una vez conocida la tabla que guardará la ultima secuencia
			$resultado = $db->select(\DB::raw('SELECT MAX(id_pro_consolidacion)+1 AS id_auditoria FROM sor_aud_consolidacion;'));
			//$resultado = $db->select(\DB::raw('SELECT null AS sec_esp FROM rec_ccf0306'));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				return $resultado;
			}else{
				return null;
			}
		}
		
		
		
		
		/*********************************************
		* 	Actualiza estado iniciado						 *
		**********************************************/
		
				
		public static function UpdatePrcExpEstado($nombre_proceso,$id_exp_tipo,$envio,$estado){
			try{
			$db=\DB::connection('suitecrm');
			$query='UPDATE exp_exportacion_ejecucion SET date_modified=NOW(),estado = "'.$estado.'",fec_ini= CURDATE(),  hor_ini=  DATE_FORMAT(NOW(), "%T")  WHERE NAME="'.$nombre_proceso.'" and exp_exportacion_tipo_id_c= "'.$id_exp_tipo.'" and envio ="'.$envio.'"';
			//UPDATE INTO exp_exportacion_ejecucion(id, NAME, date_entered, date_modified,deleted, exp_exportacion_tipo_id_c,sor_aud_consolidacion_id_c, envio, estado, fec_ini,hor_ini,paq_nombre,paq_path,paq_mail_destino)";
			//$query.='VALUES (UUID(),"'.$nombre_proceso.'", NOW(),NOW(), 0, "'.$id_exp_tipo.'","'.$id_auditoria.'","'.$envio.'","Iniciado", CURDATE(), DATE_FORMAT(NOW(), "%T"),"'.$nombre_proceso.'","'.$paq_path.'", "'.$mail_destino_paq.'");';
			$resultadoUPDATE=$db->getpdo()->exec($query);	
			\DB::disconnect('suitecrm');
			if(count($resultadoUPDATE)>0){
				return true;
			}else{
				return null;
			}
		}catch(\Exception $e){
				\Log::info("Error realizando update estado Iniciado en tabla exp_exportacion_ejecucion");
				\Log::info($e);
				return false;
			}
		}
		
		/*********************************************
		* 	Actualiza estado finalizado er						 *
		**********************************************/
		
				
		public static function UpdatePrcExpEstadoFin($nombre_proceso,$id_exp_tipo,$envio,$nombre_archivo,$estado){
			try{
		
			$db=\DB::connection('suitecrm');
			//$query='UPDATE exp_exportacion_ejecucion SET date_modified=NOW(),estado = "'.$estado.'",fec_fin= CURDATE(),  hor_fin=  DATE_FORMAT(NOW(), "%T"), paq_path="'.$nombre_archivo.'"  WHERE NAME="'.$nombre_proceso.'" and exp_exportacion_tipo_id_c= "'.$id_exp_tipo.'"';
			$query='UPDATE exp_exportacion_ejecucion SET date_modified=NOW(),estado = "'.$estado.'",fec_fin= CURDATE(),  hor_fin=  DATE_FORMAT(NOW(), "%T"), paq_path="'.$nombre_archivo.'"  WHERE NAME="'.$nombre_proceso." - ".$envio.'" and envio= "'.$envio.'"';
			$resultadoUPDATE=$db->getpdo()->exec($query);	
			\DB::disconnect('suitecrm');
			if(count($resultadoUPDATE)>0){
				return true;
			}else{
				return null;
			}
		}catch(\Exception $e){
				\Log::info("Error realizando update estado Finalizado er en tabla exp_exportacion_ejecucion");
				\Log::info($e);
				return false;
			}
		}
		
		/*********************************************
		* 	Actualiza estado dis_conceptos_liquidados			 *
		**********************************************/
		
				
		public static function UpdateEstadoDisConLiq($nombre_exportacion,$id_exp_tipo,$envio,$id_ejecucion){
			try{
			$db=\DB::connection('suitecrm');
			$query='UPDATE dis_conceptos_liquidados SET estado_envio_boldt ="P", date_modified = NOW() WHERE exp_exportacion_ejecucion_id_c ="'.$id_ejecucion.'"';
			$resultadoUPDATE=$db->getpdo()->exec($query);	
			\DB::disconnect('suitecrm');
			if(count($resultadoUPDATE)>0){
				return true;
			}else{
				return null;
			}
		}catch(\Exception $e){
				\Log::info("Error update estado P dis_conceptos_liquidados por error y no finalizacion de proceso. ");
				\Log::info($e);
				return false;
			}
		}
		
		/*********************************************
		* 	Actualiza estado pre_envios_uif				 *
		**********************************************/
		
				
		public static function UpdateExpExportacionTipoOk($nombre_proceso,$envio){
			try{
			$db=\DB::connection('suitecrm');
			// si el campo a mostrar en formulario es el envio a enviar (vale decir el siguiente al ultimo enviado) actualizar con un mes mas de intervalo
			//$query='UPDATE exp_exportacion_tipo SET paq_ult_envio=DATE_FORMAT(DATE_ADD(CONCAT("'.$envio.'","01"), INTERVAL 1 MONTH),"%Y%m")  where name = "'.$nombre_proceso.'"';
			$query='UPDATE exp_exportacion_tipo SET paq_ult_envio="'.$envio.'" where name = "'.$nombre_proceso.'"';
			$resultadoUPDATE=$db->getpdo()->exec($query);	
			\DB::disconnect('suitecrm');
			if(count($resultadoUPDATE)>0){
				return true;
			}else{
				return null;
			}
		}catch(\Exception $e){
				\Log::info("Error realizando update estado Finalizado ok en tabla exp_exportacion_ejecucion");
				\Log::info($e);
				return false;
			}
		}
		
		/*********************************************
		* 	Actualiza estado pre_envios_uif				 *
		**********************************************/
		
				
		public static function UpdatePreEnviosUIFOk($nombre_proceso,$envio){
			try{
			$db=\DB::connection('suitecrm');
			$query='UPDATE pre_envios_uif SET date_modified = now(),peu_fecha=curdate(), peu_estado = "E" where id = "'.$envio.'"';
			$resultadoUPDATE=$db->getpdo()->exec($query);	
			\DB::disconnect('suitecrm');
			if(count($resultadoUPDATE)>0){
				return true;
			}else{
				return null;
			}
		}catch(\Exception $e){
				\Log::info("Error realizando update en tabla pre_envios_uif");
				\Log::info($e);
				return false;
			}
		}
		
		/*********************************************
		* 	Actualiza estado afip				 *
		**********************************************/
		
				
		public static function UpdatePreEnviosAFIPOk($nombre_proceso,$envio){
			try{
				
			$db=\DB::connection('suitecrm');
			$query='UPDATE imp_ganancias_envio_afip SET date_modified = now(),ieg_fecha=curdate(), ieg_estado = "E" where id = "'.$envio.'"';
			$resultadoUPDATE=$db->getpdo()->exec($query);	
			\DB::disconnect('suitecrm');
			if(count($resultadoUPDATE)>0){
				return true;
			}else{
				return null;
			}
		}catch(\Exception $e){
				\Log::info("Error realizando update en tabla pre_envios_uif");
				\Log::info($e);
				return false;
			}
		}

		public static function UpdateReservaBilletesLoteria($nombre_proceso,$envio){
			try{
			$db=\DB::connection('suitecrm');
			//$query = 'UPDATE sorl_pgmsorteo pgm SET pgm.`estado_vuelco_reservas` = "E" WHERE pgm.`nrosorteo` = "'.$envio.'" and pgm.deleted = 0';
			$query = 'UPDATE sorl_pgmsorteo pgm 
					SET pgm.estado_vuelco_reservas = "E",
						pgm.fecha_ult_vuelco = CURDATE(),
						pgm.hora_ult_vuelco = CURTIME()
					WHERE pgm.nrosorteo = "'.$envio.'" 
					  AND pgm.deleted = 0';
					  
			$resultadoUPDATE=$db->getpdo()->exec($query);	
			\DB::disconnect('suitecrm');
			if(count($resultadoUPDATE)>0){
				return true;
			}else{
				return null;
			}
		}catch(\Exception $e){
				\Log::info("Error realizando update en tabla sorl_pgmsorteo");
				\Log::info($e);
				return false;
			}
		}
		
		
		/*****************************************************************************************
		* 	update manuales finalizan ok paso de estado de manuales en proceso (-2)				 *
		******************************************************************************************/
		
				
		public static function UpdateManualesOk($nombre_proceso,$envio){
			try{
				
			$db=\DB::connection('suitecrm');
			$query='UPDATE cas02_cc_manuales SET date_modified = now(),estado = "2"  where grupo = "A" and estado = "-2"';
			$resultadoUPDATE=$db->getpdo()->exec($query);	
			\DB::disconnect('suitecrm');
			if(count($resultadoUPDATE)>0){
				return true;
			}else{
				return null;
			}
		}catch(\Exception $e){
				\Log::info("Error realizando update en tabla cas02_cc_manuales");
				\Log::info($e);
				return false;
			}
		}
		
		
	}
?>