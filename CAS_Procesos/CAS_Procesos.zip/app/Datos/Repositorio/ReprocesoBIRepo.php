<?php

	namespace Datos\Repositorio;
	// esto sacar..
	use models\ServidorFTPModelo;
	use models\ProductoFTPModelo;
	// fin esto sacar...
	use \Carbon\Carbon;

	class ReprocesoBIRepo{

		/************************************************
		* Devuelve una lista de los meses que se pueden *
		* reprocesar. Regla: últimos 6 meses cerrados   *
		************************************************/
		public static function getMesesReprocesoBI(){
			try{
				$db = \DB::connection('bi_cas');
				//$resultados=$db->select(\DB::raw("SELECT CONCAT(d.id_messor,'-', CASE d.estado_bi WHEN 3 THEN 'ER' WHEN 4 THEN 'OK' ELSE 'XX' END ) AS periodo FROM d_messor d WHERE d.id_messor < YEAR(NOW())*100 + MONTH(NOW()) AND d.estado_bi > 0 ORDER BY d.id_messor DESC LIMIT 6;"));
				$resultados=$db->select(\DB::raw("SELECT concat(d.id_messor,'-',d.estado_bi) as id_messor, d.estado_bi AS estado_bi FROM d_messor d WHERE d.id_messor < YEAR(NOW())*100 + MONTH(NOW()) AND d.estado_bi > 0 ORDER BY d.id_messor DESC LIMIT 6;"));
				//convertimos el resultado (stdClass) a un arreglo
//				\Log::info($resultados);
			
				$resultados=json_decode(json_encode((array) $resultados), true);
				$listaMeses=[];
				$mes_defecto=999999;
				$ultimo="";
				$x=1;
				foreach ($resultados as $resultado) {
					$mes['idMessor']=$resultado['id_messor'];
					$mes['estado']=$resultado['estado_bi'];
					/*
					if ($resultado['estado_bi']<4 and $mes['idMessor']<$mes_defecto){
						$mes['defecto']=" default='true' ";
						$mes_defecto = $resultado['id_messor'];
					}else {
						$mes['defecto']="";
					}
					*/
					if(array_key_exists($resultado['id_messor'], $listaMeses)){
						array_push($listaMeses ,$mes);
						//array_push($listaMeses [$x],$mes);
					}else{
						//$listaMeses [$x]=[];
						//array_push($listaMeses [$resultado['id_messor']],$mes);				
						//array_push($listaMeses [$x],$mes);
						array_push($listaMeses ,$mes);
					}
					$ultimo=$resultado['id_messor'];
					$x++;
				}
				//\log::info($listaMeses);
				return $listaMeses;
			}catch(\Exception $e){
				\Log::info("Error consultando los meses a visualizar.");
				\Log::info($e);
				return false;
			}
		}

		
		/*********************************************
		* Llamada al stored para retornar el periodo. *
		**********************************************/
		public static function valida_periodo(){
			\DB::connection('bi_cas')->unprepared(\DB::raw('CALL `p_get_periodos_vuelco_bi`(@msgret);'));
			$ok=\DB::connection('bi_cas')->select(\DB::raw('SELECT @msgret as msgret'));
			//\Log::info($ok);
			$ok=json_decode(json_encode((array) $ok), true);
			//\Log::info($ok);
			//dd($ok);
			return $ok;
		}
		
		
			
		/*********************************************
		* Llamada al stored para procesa Periodo 	 *
		**********************************************/
		//public static function insertaPGM($juego,$fechaSorteo){
		public static function procesaPeriodo($periodo,$estado,$a_partir_fallo,$completo,$incl_cuad_afec,$dif_ejec){
			try{
				$datos = $periodo.',"'.$estado.'",'.$a_partir_fallo.','.$completo.','.$incl_cuad_afec.','.$dif_ejec.',@msgret';
				\DB::connection('bi_cas')->unprepared(\DB::raw('CALL `p_reproceso_vuelco_bi`('.$datos.');'));
				//\Log::info($algo);
				$ok=\DB::connection('bi_cas')->select(\DB::raw('SELECT @msgret as msgret;'));
			
			//	\Log::info('algo ');
			return $ok[0]->msgret;
			
			}catch(\PDOException $e){
				\Log::info($e->getMessage());
				return 0;
			}
		}
		
		

	}//fin clase
?>