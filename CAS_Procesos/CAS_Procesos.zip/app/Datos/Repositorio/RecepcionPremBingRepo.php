<?php

	namespace Datos\Repositorio;
	
	use models\ServidorFTPModelo;
	use models\ProductoFTPModelo;
	use \Carbon\Carbon;

	class RecepcionPremBingRepo{
		
		/***************************************************************
		* Devuelve 1 si puede seguir procesando en la transacción      *
		* 0 en caso de que no pueda seguir por falta de procesamiento  *
		* de el sorteo previo.                                         *
		****************************************************************/
		public static function puedeProcesar($nro_sorteo, $idJuego){
				$db=\DB::connection('suitecrm');
				$puedeProcesar =$db->table('sor_pgmsorteo')								
								->where('nroSorteo','=',$nro_sorteo-1)
								->where('idJuego','=',$idJuego)
								->where('idEstado','=',50)->count();
				
				return $puedeProcesar;
		}
		
		
		/**********************************************
		* Devuelve una lista de los tipos de archivos *
		* esperados por cada juego.                   *
		***********************************************/
		public static function especif_arch_x_juego(){
			try{
				$db = \DB::connection('suitecrm');
				$resultados=$db->select(\DB::raw("SELECT COALESCE(p.`id_juego`,999) as id_juego, a.`transaccion`, a.`tipo_requerimiento`, e.tipo_archivo, e.`nombre`, e.`cant_arch_esperados`, e.`extension`, e.`descomprime`, e.`id_padre`, e.control,a.`tipo_requerimiento`  
				FROM sor_producto p
				RIGHT JOIN sor_producto_archivo a ON a.`id_producto`=p.`id`
				INNER JOIN sor_especificacion_archivo e ON (e.id=a.`id_especificacion_archivo` OR e.`id_padre`=a.`id_especificacion_archivo`) AND e.`habilitado`=1
				-- GROUP BY e.nombre
				WHERE e.tipo_archivo IN ('TT','TK','TM')
				ORDER BY p.`id_juego`,e.tipo_archivo, e.control DESC"));
				
				//convertimos el resultado (stdClass) a un arreglo
				$resultados=json_decode(json_encode((array) $resultados), true);
				$listaArchivosJuego=[];
				foreach ($resultados as $resultado) {
					$archivo['transaccion']=$resultado['transaccion'];
					$archivo['nombre']=$resultado['nombre'];
					$archivo['tipo_archivo']=$resultado['tipo_archivo'];
					$archivo['extension']=$resultado['extension'];
					$archivo['cant_arch_esperados']=$resultado['cant_arch_esperados'];
					$archivo['descomprime']=$resultado['descomprime'];
					$archivo['id_padre']=$resultado['id_padre'];
					$archivo['control']=$resultado['control'];
					$archivo['requerido']=$resultado['tipo_requerimiento'];
					if(array_key_exists($resultado['id_juego'], $listaArchivosJuego)){
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);
					}else{
						$listaArchivosJuego [$resultado['id_juego']]=[];
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);				
					}
				}

				return $listaArchivosJuego;
			}catch(\Exception $e){
				\Log::info("Error consultando los tipos de archivos a esperar");
				\Log::info($e);
				return false;
			}
		}

		/*************************************************************
		* Devuelve la lista de sorteos pendientes de días anteriores *
		* y la lista de sorteos del día actual en cualquier estado.  *
		**************************************************************/
		public static function sorteos_panel_alertas(){
			$db = \DB::connection('suitecrm');
/* ::tomorrow */
                        $fecha = \Carbon\Carbon::now('America/Argentina/Buenos_Aires');
                        $fechaHoy = $fecha;
                        $fechaHoy = \Carbon\Carbon::parse($fechaHoy)->format('Y-m-d');//->format('d/m/Y');

                        // Traigo 1 dia mas
                        $fecha = \Carbon\Carbon::tomorrow('America/Argentina/Buenos_Aires');
	\Log::info('fecha',array($fecha));
			$db->getpdo()->setAttribute(\PDO::ATTR_EMULATE_PREPARES, true);
			$resultados=$db->select(\DB::raw("CALL `sor_obtener_pgmsorteos_bingos`('".$fecha."',1)"));
			$diasAnteriores=[];
			$diaActual=[];
			//$diaFuturo=[];
			foreach ($resultados as $sorteo) {
				$fechaSorteo = \Carbon\Carbon::parse($sorteo->fecha)->format('Y-m-d');//->format('d/m/Y');
				
				if($fechaSorteo<$fechaHoy){
					array_push($diasAnteriores, $sorteo);
				}else if($fechaSorteo==$fechaHoy){
					array_push($diaActual, $sorteo);
				}/*
				else if($fechaSorteo>$fechaHoy){
					array_push($diaFuturo, $sorteo);
				}
				*/
			}
						
			$listaSorteos=[];
			self::listaPanel($diasAnteriores,$listaSorteos, 'diasAnteriores');
			self::listaPanel($diaActual,$listaSorteos, 'diaActual');
			//self::listaPanel($diaFuturo,$listaSorteos, 'diaFuturo');
            \DB::disconnect('suitecrm');
	        return $listaSorteos;
		}


		/***********************************************
		* Arma un arreglo con los datos de los sorteos *
		************************************************/
		private static function listaPanel($resultados, &$listaSorteos,$dia){
			$listaSorteos[$dia]=[];
			foreach ($resultados as $resultado) {
				$sorteo['idPgmSorteo']=$resultado->idPgmSorteo;
				$sorteo['idJuego']=$resultado->idJuego;
				$sorteo['nombre_juego']=$resultado->juegodesc;
				$sorteo['nroSorteo']=$resultado->nroSorteo;
				$sorteo['idJuego_extracto_de']=$resultado->idJuego_extracto_de;
				$sorteo['de_estado']=$resultado->estado;
				$sorteo['idEstado']=$resultado->idEstado;
				$sorteo['fecha']=$resultado->fecha;
				$sorteo['fechaHoraPrescripcion']=$resultado->fechaHoraPrescripcion;
				$sorteo['fechaHoraProximo']=$resultado->fechaHoraProximo;
				$sorteo['PozoEstimadoProximo']=$resultado->PozoEstimadoProximo;
				$sorteo['localidad']=$resultado->localidad;
				$sorteo['tiene_adic']=$resultado->tiene_adic;
				$sorteo['fechaHora_car']=$resultado->fechaHora_car;
				$sorteo['fechaHora_res']=$resultado->fechaHora_res;
				$sorteo['apuestas']=$resultado->apuestas;
				$sorteo['formato_procesamiento']=$resultado->formato;
				array_push($listaSorteos[$dia],$sorteo);
			}
		}
		
		/*********************************************
		* Llamada al stored para insertar pgmsorteo. *
		**********************************************/
		public static function insertaPGM($juego,$fechaSorteo){
			try{
				$datos = $juego.',"'.$fechaSorteo.'",1,@msjret';
				$db=\DB::connection('suitecrm');
				/*//$db->getpdo()->setAttribute(\PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);			
				//$ok= $db->select(\DB::raw('CALL `sor_inserta_pgmsorteo`('.$datos.')'));
				$sql='CALL `sor_inserta_pgmsorteo`('.$datos.')';
				$ok=$db->statement($sql);
				
				$ok = $db->select(\DB::raw('SELECT @salida as p_out'))[0]->p_out;*/
				
				/*$stmt = $db->getpdo()->prepare('CALL `sor_inserta_pgmsorteo`('.$datos.')');
				$stmt=$stmt->fetchAll(\PDO::FETCH_ASSOC);
				$ok = $db->getpdo()->query('SELECT @msjret as p_out')->fetchAll(\PDO::FETCH_ASSOC);*/
				/*$stmt = $db->getpdo()->prepare('CALL `sor_inserta_pgmsorteo`('.$datos.');');
				$stmt->execute();
				$ok = $db->getpdo()->query('SELECT @msjret as p_out')->fetchAll(\PDO::FETCH_ASSOC);*/

				$stmt= $db->getpdo()->prepare('CALL `sor_inserta_pgmsorteo`('.$datos.')');
				$stmt->execute();
				/*$stmt= $db->getpdo()->prepare('CALL `sor_inserta_pgmsorteo`(?,?,?,?)');
				$value='mensaje';
				$modalidad=1;
				$stmt->bindParam(1, $juego,\PDO::PARAM_INT); 
				$stmt->bindParam(2, $fechaSorteo); 
				$stmt->bindParam(3, $modalidad, \PDO::PARAM_INT); 
				$stmt->bindParam(4, $value, \PDO::PARAM_STR|\PDO::PARAM_INPUT_OUTPUT, 2046); 
				$stmt->execute();

				\Log::info("antes del valor:");
				\Log::info($value);*/
				if($stmt->columnCount()>0){
					$resultado=$stmt->fetch(\PDO::FETCH_BOTH);//fetchAll(\PDO::FETCH_CLASS, 'stdClass');	
					$resultado=$resultado['msjret'];//$resultado[0]->msjret;
					//insertar auditoria
					\DB::disconnect('suitecrm');
					return 1;
				}else{
					return 0;
				}
			}catch(\PDOException $e){
				\Log::info($e->getMessage());
				return 0;
			}
		}
		
		
		/****************************************
		* Llamada al stored para validar.      *
		*****************************************/
		public static function validar($juego,$sorteo,$idProceso,$usuario,$fechaSorteo){
			//$datos = $juego.','.$sorteo.',@msgret';
			$datos = $juego.",".$sorteo.",".$idProceso.",'".$usuario."','".$fechaSorteo."',@msgret";
			\Log::info('validar bingos CALL sor_valida_premios_bingo(', array($datos));
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `sor_valida_premios_bingo`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			\DB::disconnect('suitecrm');
			return $ok[0]->msgret;
		
		}
		
		
		/****************************************
		* Llamada al stored para procesar.      *
		*****************************************/
		public static function procesa($juego,$sorteo,$idProceso,$usuario,$fechaSorteo){
			//$datos = $juego.','.$sorteo.',@msgret';
			$datos = $juego.",".$sorteo.",".$idProceso.",'".$usuario."','".$fechaSorteo."',@msgret";
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `sor_procesa_premios_bingo`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			\DB::disconnect('suitecrm');
			return $ok[0]->msgret;
		
		}
		
		
		/****************************************
		* Llamada al stored para publicar.      *
		*****************************************/
		public static function publicar($juego,$sorteo,$idProceso,$usuario,$fechaSorteo){
			//$datos = $juego.','.$sorteo.',@msgret';
			$datos = $juego.",".$sorteo.",".$idProceso.",'".$usuario."','".$fechaSorteo."',@msgret";
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `sor_publica_bingos`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			\DB::disconnect('suitecrm');
			return $ok[0]->msgret;
		
		}
		

		/******************************************************************
		* Obtener los datos de pgmsorteo para un sorteo/juego determinado *
		*******************************************************************/
		public static function datosProcesados($sorteo, $idjuego){
			$db=\DB::connection('suitecrm');
			/*$resultado = $db->table('sor_pgmsorteo')->select('idPgmSorteo', 'e.idEstado', 'de_estado', 'tck_afe','apu_afe','rec_afe','pre_afe') //CONCAT(REPLACE(FORMAT(pre_afe,0),",","."),",",SUBSTRING_INDEX(FORMAT(pre_afe,2),".",-1)) as  //CONCAT(REPLACE(FORMAT(rec_afe,0),",",".") ",",SUBSTRING_INDEX(FORMAT(rec_afe,2),".",-1)) as 
					->join('sor_estado_pgmsorteo as e', 'sor_pgmsorteo.idEstado', '=', 'e.idEstado')
					->where('idJuego','=',$idjuego)
					->where('nroSorteo','=',$sorteo)
                    ->first();*/
			$resultado = $db->select(\DB::raw('SELECT s.id as idPgmSorteo , e.idEstado, e.de_estado,
												COUNT(a.nro_ticket) AS cant_tck, -- cant tck premiados
												CONCAT(REPLACE(FORMAT(SUBSTRING(SUM(a.importe_premio),1,LENGTH(SUM(a.importe_premio))-3),0),",","."),",",SUBSTRING_INDEX(FORMAT(SUM(a.importe_premio),2),".",-1)) AS imp_total_bruto,
												CONCAT(REPLACE(FORMAT(SUBSTRING(SUM(a.importe_retenciones),1,LENGTH(SUM(a.importe_retenciones))-3),0),",","."),",",SUBSTRING_INDEX(FORMAT(SUM(a.importe_retenciones),2),".",-1)) AS imp_total_ret,
												CONCAT(REPLACE(FORMAT(SUBSTRING(SUM(a.importe_impneto),1,LENGTH(SUM(a.importe_impneto))-3),0),",","."),",",SUBSTRING_INDEX(FORMAT(SUM(a.importe_impneto),2),".",-1)) AS imp_total_neto
												
												FROM sor_aux_premios_bingos a
												INNER JOIN sor_pgmsorteo s ON s.idjuego = a.id_juego AND s.nrosorteo = a.nro_emision
												INNER JOIN sor_estado_pgmsorteo e ON s.idEstado=e.idEstado
												WHERE a.id_juego='.$idjuego.' AND nro_emision='.$sorteo));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
			
				$datos['idPgmSorteo']=$resultado[0]->idPgmSorteo;
				$datos['idEstado']=$resultado[0]->idEstado;
				$datos['de_estado']=$resultado[0]->de_estado;
				$datos['cant_tck']=$resultado[0]->cant_tck;
				$datos['imp_total_bruto']=$resultado[0]->imp_total_bruto;
				$datos['imp_total_ret']=$resultado[0]->imp_total_ret;
				$datos['imp_total_neto']=$resultado[0]->imp_total_neto;
				
				return $datos;
			}else{
				return null;
			}
			
		}
		
		
		
		/****************************************
		* Llamada al stored para consolidación. *
		*****************************************/
		public static function consolidar($juego, $sorteo, $fechaSorteo, $idProceso, $usuario){
			$datos = $juego.','.$sorteo.',"'.$fechaSorteo.'",'.$idProceso.',"'.$usuario.'"';			
			$ok = \DB::connection('suitecrm')->select(\DB::raw('CALL `SOR_Consolidacion`('.$datos.')'));

			return $ok[0]->msgret;
		}
		
		/****************************************
		* Llamada al stored para publicar.      *
		*****************************************/
		/*
		public static function publicar($juego, $sorteo){
			$datos = $juego.','.$sorteo.',@msgret';
			$msgret=\DB::connection('suitecrm')->select(\DB::raw('CALL `sor_publicacion`('.$datos.')'));			
			return $msgret[0]->msgret;
		}
		*/
		/******************************************************************
		* Llamada al stored para control del nombre con el nº de sorteo.  *
		*******************************************************************/
		public static function controlSorteo($sorteo, $idJuego, $tipoArchivo){
			$datos =$idJuego.','.$sorteo.','.$tipoArchivo;
			$resultado=\DB::connection('suitecrm')->select(\DB::raw('CALL `sor_control_sorteo`('.$datos.')'))[0]->exito;
			return  $resultado;
		}
		
		/******************************************************************
		* Obtener los datos de pgmsorteo para un sorteo/juego determinado *
		*******************************************************************/
		public static function datosPGMSorteo($sorteo, $idjuego){
			$db=\DB::connection('suitecrm');
			/*$resultado = $db->table('sor_pgmsorteo')->select('idPgmSorteo', 'e.idEstado', 'de_estado', 'tck_afe','apu_afe','rec_afe','pre_afe') //CONCAT(REPLACE(FORMAT(pre_afe,0),",","."),",",SUBSTRING_INDEX(FORMAT(pre_afe,2),".",-1)) as  //CONCAT(REPLACE(FORMAT(rec_afe,0),",",".") ",",SUBSTRING_INDEX(FORMAT(rec_afe,2),".",-1)) as 
					->join('sor_estado_pgmsorteo as e', 'sor_pgmsorteo.idEstado', '=', 'e.idEstado')
					->where('idJuego','=',$idjuego)
					->where('nroSorteo','=',$sorteo)
                    ->first();*/
			$resultado = $db->select(\DB::raw('SELECT idPgmSorteo, e.idEstado, de_estado, tck_afe,apu_afe,
												CONCAT(REPLACE(FORMAT(SUBSTRING(rec_afe,1,LENGTH(rec_afe)-3),0),",","."),",",SUBSTRING_INDEX(FORMAT(rec_afe,2),".",-1)) AS rec_afe,
												CONCAT(REPLACE(FORMAT(SUBSTRING(pre_afe,1,LENGTH(pre_afe)-3),0),",","."),",",SUBSTRING_INDEX(FORMAT(pre_afe,2),".",-1)) AS pre_afe
												FROM sor_pgmsorteo
												INNER JOIN sor_estado_pgmsorteo AS e ON sor_pgmsorteo.idEstado=e.idEstado
												WHERE idJuego='.$idjuego.' AND nroSorteo='.$sorteo));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
			
				$datos['idPgmSorteo']=$resultado[0]->idPgmSorteo;
				$datos['idEstado']=$resultado[0]->idEstado;
				$datos['de_estado']=$resultado[0]->de_estado;
				$datos['tck_afe']=$resultado[0]->tck_afe;
				$datos['apu_afe']=$resultado[0]->apu_afe;
				$datos['rec_afe']=$resultado[0]->rec_afe;
				$datos['pre_afe']=$resultado[0]->pre_afe;
				
				return $datos;
			}else{
				return null;
			}
			
		}
		
		/*********************************************************************
		* actualizar el estado de pgmsorteo para un sorteo/juego determinado *
		**********************************************************************/
		public static function actualizaEstado($sorteo,$idJuego,$idEstado){
			$db=\DB::connection('suitecrm');
			$resultado = $db->table('sor_pgmsorteo')->select('id')					
					->where('idJuego','=',$idJuego)
					->where('nroSorteo','=',$sorteo)
                    ->get();
			\DB::disconnect('suitecrm');

			if(count($resultado)>0){
				$idPgm=$resultado[0]->id;
				//$query='UPDATE sor_pgmsorteo SET idEstado='.$idEstado.'	WHERE idPgmSorteo='.$idPgm;
				$query='CALL sor_actualiza_estado_pgmsorteo_bingo("'.$idPgm.'",'.$idEstado.')';
				$stmt = $db->getpdo()->prepare($query);
				$stmt->execute();
				
				$ok=$stmt->errorCode();
				
				if($ok== '00000'){
					return 1;
				}else{
					return 0;
				}
			}else{
				return 0;
			}
		}

		/**********************************************************************
		* Función para ver si el juego requiere car/res/sue
		***********************************************************************/
		public static function requiereCarResSue($idJuego){
			$db=\DB::connection('suitecrm');
			$resultado = $db->table('sor_producto')->select('requiere_car','requiere_res','requiere_sue','requiere_cons','requiere_apu')					
					->where('id_juego','=',$idJuego)
                    ->get();
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				$datos['requiere_car']=$resultado[0]->requiere_car;
				$datos['requiere_res']=$resultado[0]->requiere_res;
				$datos['requiere_sue']=$resultado[0]->requiere_sue;
				$datos['requiere_cons']=$resultado[0]->requiere_cons;
				$datos['requiere_apu']=$resultado[0]->requiere_apu;
				return $datos;			
			}else{
				return 0;
			}

		}

		
		/***************************************************************
		* Función que genera u obtiene un id de proceso para auditoria *
		****************************************************************/
		public static function getNumeroProcesoAuditoriaCtaCte($juego, $sorteo){
			try{
				$db=\DB::connection('suitecrm');
				//llamada a una función definida en la bd 
				$query="select getProcesoAuditoriaCtaCte(".$juego.",".$sorteo.") AS id_proceso;";
				$stmt = $db->getpdo()->prepare($query);
				$stmt->execute();
				$idProceso=$stmt->fetch(\PDO::FETCH_ASSOC)['id_proceso'];
				return $idProceso;		
			}catch(\Exception $e){
				\Log::info("Error en getNumeroProcesoAuditoriaCtaCte");
			}
		}

		/***********************************************************
		* Función que inserta un registro en la tabla de auditoría *
		************************************************************/
		public static function insertaAuditoria($idProceso,$idJuego, $sorteo, $evento, $operador, $idEstadoPrev, $idEstadoPost, $detalle){
			$db=\DB::connection('suitecrm');
			$query='CALL `sor_inserta_auditoria`('.$idProceso.','.$idJuego.','.$sorteo.','.$evento.',"'.$operador.'",'.$idEstadoPrev.','.$idEstadoPost.',"'.$detalle.'")';
			$stmt = $db->getpdo()->prepare($query);
			$stmt->execute();
		}
		
		/*********************************************************************
		* Función para actualizar la fecha de carga del archivo de apuestas  *        
		**********************************************************************/
		public static function actualizaFHC($idJuego, $sorteo,$date){
			try{
				$db=\DB::connection('suitecrm');
				$query='UPDATE sor_pgmsorteo set fechahora_car = "'.$date.'" where idjuego='.$idJuego.' and nrosorteo='.$sorteo.';';
				$db->statement($query);
			}catch(\Exception $e){
				\Log::info("Error al actualizar la fecha de carga del archivo de apuestas");
			}
		}
		
		
		/* Para carga de prueba*/
		public static function cargarPGM($archivo){
			try{
				$ffhactual='%d/%m/%Y %r';
				$ffactual='%d/%m/%Y';
				$formatoFecha = '%Y%m%d';
				$formatoFechaHora = '%Y-%m-%d %h:%m:%s';
				$query =sprintf("
					TRUNCATE TABLE pgm_sorteo ;
					LOAD DATA INFILE '%s' INTO TABLE `pgm_sorteo`
					FIELDS TERMINATED BY ','
					LINES TERMINATED BY '\n'
					IGNORE 1 LINES (`juego`,`sorteo`,@fecha_sorteo,`hora_sorteo`,@fecha_proximo,`hora_proximo`,@fecha_hora_presc,`concurso`)
					set
					fecha_sorteo= date_format(str_to_date(@fecha_sorteo, '%s'), '%s'),
					fecha_proximo=date_format(str_to_date(@fecha_proximo, '%s'), '%s'),
					fecha_hora_presc=date_format(str_to_date(replace(@fecha_hora_presc,'.',''), '%s'), '%s');",
			    	addslashes($archivo),addslashes($ffactual), addslashes($formatoFecha),addslashes($ffactual),addslashes($formatoFecha), addslashes($ffhactual),addslashes($formatoFechaHora));
	    		return \DB::connection('suitecrm')->getpdo()->exec($query);
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de sorteo afectaciones control en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		/*Para cargar todos los servidores FTP*/
		public static function servidoresFTP(){
			$servidores = ServidorFTPModelo::all();
			$servidores = $servidores->toArray();			
			return $servidores;
		}
		//para obtener las rutas de los productos al ftp
		public static function productoFTP($id_juego){
			$producto=ProductoFTPModelo::find($id_juego);
			$producto = $producto->toArray();			
			return $producto;
		}

		/**********************************************
		* Devuelve tipo de archivo esperado cas.zip  	*

		***********************************************/
		public static function especif_arch_liq(){
			try{
				$db = \DB::connection('suitecrm');
				$resultados=$db->select(\DB::raw("SELECT 	
						999 AS id_juego, 
						a.`transaccion`, 
						a.`tipo_requerimiento`, 
						e.tipo_archivo, 
						e.`nombre`, 
						e.`cant_arch_esperados`, 
						e.`extension`, 
						e.`descomprime`, 
						e.`id_padre`, 
						e.control,
						a.tipo_requerimiento
					FROM sor_producto_archivo a 
					INNER JOIN sor_especificacion_archivo e ON (e.id=a.id_especificacion_archivo OR e.id_padre=a.id_especificacion_archivo) AND e.habilitado=1 AND e.tipo_archivo = 'RL'
					WHERE e.tipo_archivo IN ('TT','TK')
					ORDER BY e.tipo_archivo, e.control DESC"));
				//convertimos el resultado (stdClass) a un arreglo
				$resultados=json_decode(json_encode((array) $resultados), true);
				$listaArchivosJuego=[];
				foreach ($resultados as $resultado) {
					$archivo['transaccion']=$resultado['transaccion'];
					$archivo['nombre']=$resultado['nombre'];
					$archivo['tipo_archivo']=$resultado['tipo_archivo'];
					$archivo['extension']=$resultado['extension'];
					$archivo['cant_arch_esperados']=$resultado['cant_arch_esperados'];
					$archivo['descomprime']=$resultado['descomprime'];
					$archivo['id_padre']=$resultado['id_padre'];
					$archivo['control']=$resultado['control'];
					$archivo['requerido']=$resultado['tipo_requerimiento'];
					if(array_key_exists($resultado['id_juego'], $listaArchivosJuego)){
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);
					}else{
						$listaArchivosJuego [$resultado['id_juego']]=[];
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);				
					}
				}

				return $listaArchivosJuego;
			}catch(\Exception $e){
				\Log::info("Error consultando el tipo de archivos a esperar para cas.zip");
				\Log::info($e);
				return false;
			}
		}
				
				
		/************************************************
		* Devuelve tipos de archivo esperados 			*
		*		dentro de cas.zip 					 	*
		************************************************/
		public static function especif_arch_liq_in(){
			try{
				$db = \DB::connection('suitecrm');
				$resultados=$db->select(\DB::raw("SELECT 	
						999 AS id_juego, 
						a.`transaccion`, 
						a.`tipo_requerimiento`, 
						e.tipo_archivo, 
						e.`nombre`, 
						e.`cant_arch_esperados`, 
						e.`extension`, 
						e.`descomprime`, 
						e.`id_padre`, 
						e.control,
						a.tipo_requerimiento
					FROM sor_producto_archivo a -- ON a.`id_producto`=p.`id`
					INNER JOIN sor_especificacion_archivo e ON (e.id=a.`id_especificacion_archivo` ) AND e.`habilitado`=1 
					WHERE e.nombre LIKE '%CCF%' OR e.nombre LIKE '%BC%'
					ORDER BY e.tipo_archivo, e.control DESC"));
				//convertimos el resultado (stdClass) a un arreglo
				$resultados=json_decode(json_encode((array) $resultados), true);
				$listaArchivosJuego=[];
				foreach ($resultados as $resultado) {
					$archivo['transaccion']=$resultado['transaccion'];
					$archivo['nombre']=$resultado['nombre'];
					$archivo['tipo_archivo']=$resultado['tipo_archivo'];
					$archivo['extension']=$resultado['extension'];
					$archivo['cant_arch_esperados']=$resultado['cant_arch_esperados'];
					$archivo['descomprime']=$resultado['descomprime'];
					$archivo['id_padre']=$resultado['id_padre'];
					$archivo['control']=$resultado['control'];
					$archivo['requerido']=$resultado['tipo_requerimiento'];
					if(array_key_exists($resultado['id_juego'], $listaArchivosJuego)){
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);
					}else{
						$listaArchivosJuego [$resultado['id_juego']]=[];
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);				
					}
				}

				return $listaArchivosJuego;
			}catch(\Exception $e){
				\Log::info("Error consultando los tipos de archivos a esperar dentro de cas.zip");
				\Log::info($e);
				return false;
			}
		}
	}//fin clase
?>