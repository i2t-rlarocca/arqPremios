<?php

	namespace Datos\Repositorio;
	
	class CaratulaRepo{
				
		public static function cargarCaratulaControl($archivo, $archivoCaratula){
			try{		
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoCaratula);
				$query =sprintf("
					TRUNCATE TABLE sor_rec_caratula_ctr ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_caratula_ctr`
					CHARACTER SET binary
					FIELDS TERMINATED BY '%s'
					LINES STARTING BY '<Registro>' TERMINATED BY '</Registro>'
					(@registro)
					SET
						`tipo_archivo`= ExtractValue(@registro, 'tipo_archivo'),
			            `version`= ExtractValue(@registro, 'version'),
			            `nombre_archivo`= ExtractValue(@registro, 'nombre_archivo'),
			            `provincia`= ExtractValue(@registro, 'provincia'),
			            `juego`= ExtractValue(@registro, 'juego'),
			            `sorteo`= ExtractValue(@registro, 'sorteo'),
			            `cantidad_registros`= ExtractValue(@registro, 'cantidad_registros'),
			            `md5_archivo`= ExtractValue(@registro, 'md5'),
			            `md5_calculado`='%s';",
			    	addslashes($archivo),addslashes("\\t"), addslashes($md5_calculado));
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga car_ctrl");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga car_ctrl");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}

			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de carátula control en la tabla");
				\Log::info($e);
				return false;
			}
		}

		public static function cargarCaratula($archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$query =sprintf("
					TRUNCATE TABLE `sor_rec_caratula` ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_caratula`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`codigo_juego`=SUBSTR(@registro,1,2),
					`sorteo`=SUBSTR(@registro,3,6),
					`modalidad`=SUBSTR(@registro,9,2),
					`codigo_premio`=SUBSTR(@registro,11,7),
					`importe_pozo`=SUBSTR(@registro,18,17),
					`cantidad_ganadores`=SUBSTR(@registro,35,6),
					`importe_premio`=SUBSTR(@registro,41,17),
					`vacante`=SUBSTR(@registro,58,1),
					`cantidad_apuestas`=SUBSTR(@registro,59,9),
					`importe_pozo_real`=SUBSTR(@registro,68,17);",
			    	addslashes($archivo));
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga car");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga car");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de carátula en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		/**********************************************
		* Llamada al stored para validar la carátula. *
		***********************************************/
		public static function validaCaratula($idProceso,$juego, $sorteo, &$mensaje, $usuario, $idEstado){
			$datos = $idProceso.','.$juego.','.$sorteo.',"'.$usuario.'",'.$idEstado;
			$ok = \DB::connection('suitecrm')->select(\DB::raw('CALL `sor_valida_caratula`('.$datos.')'));
			\Log::info("Llama SOR_VALIDA_CARATULA", array($datos));

			$mensaje=$ok[0]->mensaje;
			
			if(strcasecmp($mensaje, 'OK')==0){
				return 1;
			}else{
				return 0;			
			}
		}
		
		
		
}
?>