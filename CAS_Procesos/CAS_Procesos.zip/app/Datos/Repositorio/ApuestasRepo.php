<?php

	namespace Datos\Repositorio;
	
	class ApuestasRepo{
				
		public static function cargarApuestasControl($archivo, $archivoApuestas,$idjuego){
			try{
				
				\Log::info('cargarApuestasControl-idjuego',array($idjuego));
				$in = "";
					switch ($idjuego) {
						case "49":
							$in = "49,24";
							break;
						case "4":
							$in = "4,14";
							break;
						case "50":
							$in = "50,10";
							break;
						case "51":
							$in = "51,20";
							break;
						case "5":
							$in = "5,33";
							break;
						case "13":
							$in = "13,34";
							break;
						case "29":
							$in = "29,43";
							break;
						case "30":
							$in = "30,67";
							break;
						default:
							$in = $idjuego;
					}
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculado = md5_file($archivoApuestas);
				$query =sprintf("
					
					DELETE FROM sor_rec_apu_ctr WHERE juego in (".$in.");
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_apu_ctr`
					CHARACTER SET binary
					FIELDS TERMINATED BY '%s'
					LINES STARTING BY '<Registro>' TERMINATED BY '</Registro>'
					(@registro)
					SET
						`tipo_archivo`= ExtractValue(@registro, 'tipo_archivo'),
			            `version`= ExtractValue(@registro, 'version'),
			            `nombre_archivo`= ExtractValue(@registro, 'nombre_archivo'),
			            `provincia`= ExtractValue(@registro, 'provincia'),
			            `juego`= ExtractValue(@registro, 'juego'),
			            `sorteo`= ExtractValue(@registro, 'sorteo'),
			            `sistema`= ExtractValue(@registro, 'sistema'),
			            `cantidad_registros`= ExtractValue(@registro, 'cantidad_registros'),
			            `md5_archivo`= ExtractValue(@registro, 'md5'),
			            `md5_calculado`='%s';",
			    	addslashes($archivo),addslashes("\\t"), addslashes($md5_calculado));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empece carga apu_ctrl");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga apu_ctrl");
	    		if($db->getPdo()->errorCode()== '00000'){
					\Log::info("error carga apu_ctrl", array($db->getPdo()->errorCode()));
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de sorteo apuestas control en la tabla");
				\Log::info($e);
				return false;
			}
		}
/*

// FORMATO LIBRA 201804

		public static function cargarApuestasQuinielas($archivo,$idjuego){
			try{
				//$in = "";
				$q = "DELETE FROM sor_rec_apu WHERE codigo_juego = ".$idjuego.";";
					switch ($idjuego) {
						case "49":
							$in = "49,24";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 24;";
							break;
						case "4":
							$in = "4,14";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 14;";
							break;
						case "50":
							$in = "50,10";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 10;";
							break;
						case "51":
							$in = "51,20";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 20;";
							break;
						case "5":
							$in = "5,33";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 33;";
							break;
						case "13":
							$in = "13,34";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 34;";
							break;
						case "29":
							$in = "29,43";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 43;";
							break;
						case "30":
							$in = "30,67";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 67;";
							break;
						default:
							$in = $idjuego;
						
					}
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
				
					".$q."
					
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_apu`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`codigo_juego`=SUBSTR(@registro,1,2),
					`codigo_provincia`=SUBSTR(@registro,3,2),
					`sorteo_participa`=SUBSTR(@registro,5,5),
					`agente`=SUBSTR(@registro,10,6),
					`subagente`=SUBSTR(@registro,16,3),
					`corredor`=SUBSTR(@registro,19,3),
					`OCR`=SUBSTR(@registro,22,9),
					`digito_verificador`=SUBSTR(@registro,31,1),
					`tipo_sistema`=SUBSTR(@registro,32,1),
					`tipo_documento`=SUBSTR(@registro,48,1),
					`nro_documento`=SUBSTR(@registro,49,11),
					`moneda`=SUBSTR(@registro,37,2),
					`tipo_terminal`=SUBSTR(@registro,39,1),
					`fecha_jugada`=SUBSTR(@registro,60,8),
					`hora_jugada`=SUBSTR(@registro,68,6),
					`estado_jugada`=SUBSTR(@registro,74,1),
					`reimpresiones`=SUBSTR(@registro,68,2),
					`fecha_cancelacion`=SUBSTR(@registro,75,8),
					`hora_cancelacion`=SUBSTR(@registro,83,6),
					`nro_terminal`=SUBSTR(@registro,40,8),
					`loterias`=SUBSTR(@registro,89,8),
					`pozo`=SUBSTR(@registro,123,1), 
					`prim_apu_pozo`=SUBSTR(@registro,124,3), 
					`seg_apu_pozo`=SUBSTR(@registro,127,3), 
					`moneda_prem_instan`=SUBSTR(@registro,97,2),
					`importe_prem_instan`=SUBSTR(@registro,99,12),
					`importe_ret_premio`=SUBSTR(@registro,111,12),
					`cant_paneles_partes`=SUBSTR(@registro,130,2),
					`datos_extras`=SUBSTR(@registro,132,LENGTH(@registro)-135),
					`crc`=SUBSTR(@registro,LENGTH(@registro)-4,4)
					;",
			    	addslashes($archivo));
				\Log::info('cargarApuestasQuinielas-query',array($query));
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empece carga apu", array($query));
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("termine carga apu->", array($resultado));
	    		if($db->getPdo()->errorCode()== '00000'){
					\Log::info("error carga apu QNL", array($db->getPdo()->errorCode()));
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de apuestas quiniela en la tabla");
				\Log::info($e);
				return false;
			}
		}
		*/
		
		/*
			inicio Ajustes 18/03/2021 - MM
			LIBRA 202010
		*/
		public static function cargarApuestasQuinielas($archivo,$idjuego){
			try{
				//$in = "";
				$q = "DELETE FROM sor_rec_apu WHERE codigo_juego = ".$idjuego.";";
					switch ($idjuego) {
						case "49":
							$in = "49,24";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 24;";
							break;
						case "4":
							$in = "4,14";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 14;";
							break;
						case "50":
							$in = "50,10";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 10;";
							break;
						case "51":
							$in = "51,20";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 20;";
							break;
						case "5":
							$in = "5,33";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 33;";
							break;
						case "13":
							$in = "13,34";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 34;";
							break;
						case "29":
							$in = "29,43";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 43;";
							break;
						case "30":
							$in = "30,67";
							$q = $q . "DELETE FROM sor_rec_apu WHERE codigo_juego = 67;";
							break;
						default:
							$in = $idjuego;
						
					}
				$archivo=str_replace("\\", "/", $archivo);
				\Log::info('cargarApuestasQuinielas-ADEN-archivo',array($archivo));
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
				
					".$q."
					
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_apu`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`codigo_juego`=SUBSTR(@registro,1,2),
					`codigo_provincia`=SUBSTR(@registro,3,2),
					`sorteo_participa`=SUBSTR(@registro,5,5),
					`agente`=SUBSTR(@registro,10,6),
					`subagente`=SUBSTR(@registro,16,3),
					`corredor`=SUBSTR(@registro,19,3),
					`OCR`=SUBSTR(@registro,22,9),
					`digito_verificador`=SUBSTR(@registro,31,1),
					`tipo_sistema`=SUBSTR(@registro,32,1),
					`tipo_documento`=SUBSTR(@registro,48,1),
					`nro_documento`=SUBSTR(@registro,49,11),
					`moneda`=SUBSTR(@registro,37,2),
					`tipo_terminal`=SUBSTR(@registro,39,1),
					`fecha_jugada`=SUBSTR(@registro,60,8),
					`hora_jugada`=SUBSTR(@registro,68,6),
					`estado_jugada`=SUBSTR(@registro,74,1),
					`reimpresiones`=SUBSTR(@registro,68,2),
					`fecha_cancelacion`=SUBSTR(@registro,75,8),
					`hora_cancelacion`=SUBSTR(@registro,83,6),
					`nro_terminal`=SUBSTR(@registro,40,8),
					`loterias`=SUBSTR(@registro,89,8),
					`pozo`=SUBSTR(@registro,123,1), 
					`prim_apu_pozo`=SUBSTR(@registro,124,3), 
					`seg_apu_pozo`=SUBSTR(@registro,127,3), 
					`moneda_prem_instan`=SUBSTR(@registro,97,2),
					`importe_prem_instan`=SUBSTR(@registro,99,12),
					`importe_ret_premio`=SUBSTR(@registro,111,12),
					`triplona`=SUBSTR(@registro,123,1),
					`1ra_apu_triplona`=SUBSTR(@registro,124,3),
					`2da_apu_triplona`=SUBSTR(@registro,127,3),
					`modo_ing_apu`=SUBSTR(@registro,130,1),
					`medio_envio_apu`=SUBSTR(@registro,131,1),
					`canal_venta_cancel`=SUBSTR(@registro,132,2),
					`modo_ing_cancel`=SUBSTR(@registro,134,1),
					`medio_envio_cancel`=SUBSTR(@registro,135,1),
					`id_cliente`=SUBSTR(@registro,136,10),
					`sesion_cliente`=SUBSTR(@registro,146,17),
					`cant_paneles_partes`=SUBSTR(@registro,163,2),
					`datos_extras`=SUBSTR(@registro,165,((LENGTH(@registro)-4))-165),
					`crc`=SUBSTR(@registro,(LENGTH(@registro)-4),4)
					;",
			    	addslashes($archivo));
				\Log::info('cargarApuestasQuinielas-query',array($query));
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empece carga apu", array($query));
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("termine carga apu->", array($resultado));
	    		if($db->getPdo()->errorCode()== '00000'){
					\Log::info("error carga apu QNL", array($db->getPdo()->errorCode()));
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de apuestas quiniela en la tabla");
				\Log::info($e);
				return false;
			}
		}
		/*
			fin Ajustes 18/03/2021 - MM
		*/
		
		
		/*
			
			LIBRA 201804
		*/
		/*
		
		public static function cargarApuestasQExpress($archivo,$idjuego){
			try{
				$in = "";
					switch ($idjuego) {
						case "49":
							$in = "49,24";
							break;
						case "4":
							$in = "4,14";
							break;
						case "50":
							$in = "50,10";
							break;
						case "51":
							$in = "51,20";
							break;
						case "5":
							$in = "5,33";
							break;
						case "13":
							$in = "13,34";
							break;
						case "29":
							$in = "29,43";
							break;
						case "30":
							$in = "30,67";
							break;
						default:
							$in = $idjuego;
					}
				
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					DELETE FROM sor_rec_apu WHERE codigo_juego in (".$in.");
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_apu`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`codigo_juego`=SUBSTR(@registro,1,2),
					`codigo_provincia`=SUBSTR(@registro,3,2),
					`sorteo_participa`=SUBSTR(@registro,5,5),
					`agente`=SUBSTR(@registro,10,6),
					`subagente`=SUBSTR(@registro,16,3),
					`corredor`=SUBSTR(@registro,19,3),
					`OCR`=SUBSTR(@registro,22,9),
					`digito_verificador`=SUBSTR(@registro,31,1),
					`tipo_sistema`=SUBSTR(@registro,32,1),
					`tipo_documento`=SUBSTR(@registro,48,1),
					`nro_documento`=SUBSTR(@registro,49,11),
					`moneda`=SUBSTR(@registro,37,2),
					`tipo_terminal`=SUBSTR(@registro,39,1),
					`fecha_jugada`=SUBSTR(@registro,60,8),
					`hora_jugada`=SUBSTR(@registro,68,6),
					`estado_jugada`=SUBSTR(@registro,74,1),
					`fecha_cancelacion`=SUBSTR(@registro,75,8),
					`hora_cancelacion`=SUBSTR(@registro,83,6),
					`nro_terminal`=SUBSTR(@registro,40,8),
					`loterias`=SUBSTR(@registro,89,8),
					`moneda_prem_instan`=SUBSTR(@registro,97,2),
					`importe_prem_instan`=SUBSTR(@registro,99,12),
					`importe_ret_premio`=SUBSTR(@registro,111,12),
					`extracto`=SUBSTR(@registro,123,100),
					`cant_paneles_partes`=SUBSTR(@registro,223,2),
					`datos_extras`=SUBSTR(@registro,225,LENGTH(@registro)-228),
					`crc`=SUBSTR(@registro,LENGTH(@registro)-4,4)
					;",
			    	addslashes($archivo));
				\Log::info('cargarApuestasQExpress-query',array($query));
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empece carga apuQE", array($query));
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("termine carga apuQE");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de apuestas quiniela en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		*/
		
		
		
		/*
				LIBRA 202010
				Ajustes 19/03/2021 - MM
		*/
		
		public static function cargarApuestasQExpress($archivo,$idjuego){
			try{
				$in = "";
					switch ($idjuego) {
						case "49":
							$in = "49,24";
							break;
						case "4":
							$in = "4,14";
							break;
						case "50":
							$in = "50,10";
							break;
						case "51":
							$in = "51,20";
							break;
						case "5":
							$in = "5,33";
							break;
						case "13":
							$in = "13,34";
							break;
						case "29":
							$in = "29,43";
							break;
						case "30":
							$in = "30,67";
							break;
						default:
							$in = $idjuego;
					}
				
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';
				$query =sprintf("
					DELETE FROM sor_rec_apu WHERE codigo_juego in (".$in.");
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_apu`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`codigo_juego`=SUBSTR(@registro,1,2),
					`codigo_provincia`=SUBSTR(@registro,3,2),
					`sorteo_participa`=SUBSTR(@registro,5,5),
					`agente`=SUBSTR(@registro,10,6),
					`subagente`=SUBSTR(@registro,16,3),
					`corredor`=SUBSTR(@registro,19,3),
					`OCR`=SUBSTR(@registro,22,9),
					`digito_verificador`=SUBSTR(@registro,31,1),
					`tipo_sistema`=SUBSTR(@registro,32,1),
					`tipo_documento`=SUBSTR(@registro,48,1),
					`nro_documento`=SUBSTR(@registro,49,11),
					`moneda`=SUBSTR(@registro,37,2),
					`tipo_terminal`=SUBSTR(@registro,39,1),
					`fecha_jugada`=SUBSTR(@registro,60,8),
					`hora_jugada`=SUBSTR(@registro,68,6),
					`estado_jugada`=SUBSTR(@registro,74,1),
					`fecha_cancelacion`=SUBSTR(@registro,75,8),
					`hora_cancelacion`=SUBSTR(@registro,83,6),
					`nro_terminal`=SUBSTR(@registro,40,8),
					`loterias`=SUBSTR(@registro,89,8),
					`moneda_prem_instan`=SUBSTR(@registro,97,2),
					`importe_prem_instan`=SUBSTR(@registro,99,12),
					`importe_ret_premio`=SUBSTR(@registro,111,12),
					`extracto`=SUBSTR(@registro,123,100),
					
					`modo_ing_apu`=SUBSTR(@registro,223,1),
					`medio_envio_apu`=SUBSTR(@registro,224,1),
					`canal_venta_cancel`=SUBSTR(@registro,225,2),
					`modo_ing_cancel`=SUBSTR(@registro,227,1),
					`medio_envio_cancel`=SUBSTR(@registro,228,1),
					`id_cliente`=SUBSTR(@registro,229,10),
					`sesion_cliente`=SUBSTR(@registro,239,17),
					
					`cant_paneles_partes`=SUBSTR(@registro,256,2),
					`datos_extras`=SUBSTR(@registro,258,LENGTH(@registro)-262),
					`crc`=SUBSTR(@registro,LENGTH(@registro)-4,4)
					;",
			    	addslashes($archivo));
				\Log::info('cargarApuestasQExpress-query',array($query));
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empece carga apuQE", array($query));
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("termine carga apuQE");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de apuestas quiniela en la tabla");
				\Log::info($e);
				return false;
			}
		}
		
		/*
				fin	Ajustes 19/03/2021 - MM
		*/
		
		/*
				LIBRA 201804
		*/
		
	public static function cargarApuestasPoceados($archivo,$idjuego){
			try{
				$in = "";
					switch ($idjuego) {
						case "49":
							$in = "49,24";
							break;
						case "4":
							$in = "4,14";
							break;
						case "50":
							$in = "50,10";
							break;
						case "51":
							$in = "51,20";
							break;
						case "5":
							$in = "5,33";
							break;
						case "13":
							$in = "13,34";
							break;
						case "29":
							$in = "29,43";
							break;
						case "30":
							$in = "30,67";
							break;
						default:
							$in = $idjuego;
					}
				$archivo=str_replace("\\", "/", $archivo);
				$formatoFecha = '%Y%m%d';

/* FORMATO VIEJO - LIBRA 2012 
				
				$query =sprintf("
					TRUNCATE TABLE `sor_rec_apu` ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_apu`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`codigo_juego`=SUBSTR(@registro,1,2),
					`codigo_provincia`=SUBSTR(@registro,3,2),
					`sorteo_participa`=SUBSTR(@registro,5,5),
					`sorteo_venta`=SUBSTR(@registro,10,5),
					`agente`=SUBSTR(@registro,15,6),
					`subagente`=SUBSTR(@registro,21,3),
					`corredor`=SUBSTR(@registro,24,3),
					`OCR`=SUBSTR(@registro,27,9),
					`digito_verificador`=SUBSTR(@registro,36,1),
					`tipo_sistema`=SUBSTR(@registro,37,1),
					`tipo_documento`=SUBSTR(@registro,38,1),
					`nro_documento`=SUBSTR(@registro,39,11),
					`moneda`=SUBSTR(@registro,50,2),
					`tipo_terminal`=SUBSTR(@registro,52,1),
					`fecha_jugada`=SUBSTR(@registro,53,8),
					`hora_jugada`=SUBSTR(@registro,61,6),
					`estado_jugada`=SUBSTR(@registro,67,1),
					`reimpresiones`=SUBSTR(@registro,68,2),
					`fecha_cancelacion`=SUBSTR(@registro,70,8),
					`hora_cancelacion`=SUBSTR(@registro,78,6),
					`nro_terminal`=SUBSTR(@registro,84,8),
					`tipo_sorteo_modal`=SUBSTR(@registro,92,1),
					`cant_paneles_partes`=SUBSTR(@registro,93,2),
					`nro_combinadas`=SUBSTR(@registro,95,2),
					`apuesta`=SUBSTR(@registro,97,40),
					`crc`=SUBSTR(@registro,137,4)
					;",
			    	addslashes($archivo));
*/				
/* FORMATO NUEVO - LIBRA 201701 
				$query =sprintf("
					DELETE FROM sor_rec_apu WHERE codigo_juego in (".$in.");
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_apu`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`codigo_juego`=SUBSTR(@registro,1,2),
					`codigo_provincia`=SUBSTR(@registro,3,2),
					`sorteo_participa`=SUBSTR(@registro,5,5),
					`agente`=SUBSTR(@registro,10,6),
					`subagente`=SUBSTR(@registro,16,3),
					`corredor`=SUBSTR(@registro,19,3),
					`OCR`=SUBSTR(@registro,22,9),
					`digito_verificador`=SUBSTR(@registro,31,1),
					`tipo_sistema`=SUBSTR(@registro,32,1),
					`tipo_documento`=SUBSTR(@registro,48,1),
					`nro_documento`=SUBSTR(@registro,49,11),
					`moneda`=SUBSTR(@registro,37,2),
					`tipo_terminal`=SUBSTR(@registro,39,1),
					`fecha_jugada`=SUBSTR(@registro,60,8),
					`hora_jugada`=SUBSTR(@registro,68,6),
					`estado_jugada`=SUBSTR(@registro,74,1),
					`fecha_cancelacion`=SUBSTR(@registro,75,8),
					`hora_cancelacion`=SUBSTR(@registro,83,6),
					`nro_terminal`=SUBSTR(@registro,40,8),
					`datos_extras`=SUBSTR(@registro,89,12),
					`tipo_sorteo_modal`=SUBSTR(@registro,89,1),
					`cant_paneles_partes`=SUBSTR(@registro,90,2),
					`nro_combinadas`=SUBSTR(@registro,92,2),
					`apuesta`=SUBSTR(@registro,94,40),
					`crc`=SUBSTR(@registro,134,4)
					;",
			    	addslashes($archivo));
*/					

/* FORMATO NUEVO - LIBRA 201804 */
/*
				$query =sprintf("
					DELETE FROM sor_rec_apu WHERE codigo_juego in (".$in.");
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_apu`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`codigo_juego`=SUBSTR(@registro,1,2),
					`codigo_provincia`=SUBSTR(@registro,3,2),
					`sorteo_participa`=SUBSTR(@registro,5,5),
					`agente`=SUBSTR(@registro,10,6),
					`subagente`=SUBSTR(@registro,16,3),
					`corredor`=SUBSTR(@registro,19,3),
					`OCR`=SUBSTR(@registro,22,9),
					`digito_verificador`=SUBSTR(@registro,31,1),
					`tipo_sistema`=SUBSTR(@registro,32,1),
					`tipo_documento`=SUBSTR(@registro,48,1),
					`nro_documento`=SUBSTR(@registro,49,11),
					`moneda`=SUBSTR(@registro,37,2),
					`tipo_terminal`=SUBSTR(@registro,39,1),
					`fecha_jugada`=SUBSTR(@registro,60,8),
					`hora_jugada`=SUBSTR(@registro,68,6),
					`estado_jugada`=SUBSTR(@registro,74,1),
					`fecha_cancelacion`=SUBSTR(@registro,75,8),
					`hora_cancelacion`=SUBSTR(@registro,83,6),
					`nro_terminal`=SUBSTR(@registro,40,8),
					`datos_extras`=SUBSTR(@registro,89,12),
					`tipo_sorteo_modal`=SUBSTR(@registro,101,1),
					`cant_paneles_partes`=SUBSTR(@registro,102,2),
					`nro_combinadas`=SUBSTR(@registro,104,2),
					`apuesta`=SUBSTR(@registro,106,40),
					`crc`=SUBSTR(@registro,146,4)
					;",
			    	addslashes($archivo));
*/					

/* FORMATO NUEVO - LIBRA 202010 */

				$query =sprintf("
					DELETE FROM sor_rec_apu WHERE codigo_juego in (".$in.");
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_apu`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`codigo_juego`=SUBSTR(@registro,1,2),
					`codigo_provincia`=SUBSTR(@registro,3,2),
					`sorteo_participa`=SUBSTR(@registro,5,5),
					`agente`=SUBSTR(@registro,10,6),
					`subagente`=SUBSTR(@registro,16,3),
					`corredor`=SUBSTR(@registro,19,3),
					`OCR`=SUBSTR(@registro,22,9),
					`digito_verificador`=SUBSTR(@registro,31,1),
					`tipo_sistema`=SUBSTR(@registro,32,1),
					`canal_ventas`=SUBSTR(@registro,33,2),
					`medio_pago`=SUBSTR(@registro,35,2),
					`moneda`=SUBSTR(@registro,37,2),
					`tipo_terminal`=SUBSTR(@registro,39,1),
					`nro_terminal`=SUBSTR(@registro,40,8),
					`tipo_documento`=SUBSTR(@registro,48,1),
					`nro_documento`=SUBSTR(@registro,49,11),
					`fecha_jugada`=SUBSTR(@registro,60,8),
					`hora_jugada`=SUBSTR(@registro,68,6),
					`estado_jugada`=SUBSTR(@registro,74,1),
					`fecha_cancelacion`=SUBSTR(@registro,75,8),
					`hora_cancelacion`=SUBSTR(@registro,83,6),
					`datos_extras`=SUBSTR(@registro,89,12),
					`tipo_sorteo_modal`=SUBSTR(@registro,101,1),
					`cant_paneles_partes`=SUBSTR(@registro,102,2),
					`nro_combinadas`=SUBSTR(@registro,104,2),
					`apuesta`=SUBSTR(@registro,106,40),
					`modo_ing_apu`=SUBSTR(@registro,146,1),
					`medio_envio_apu`=SUBSTR(@registro,147,1),
					`canal_venta_cancel`=SUBSTR(@registro,148,2),
					`modo_ing_cancel`=SUBSTR(@registro,150,1),
					`medio_envio_cancel`=SUBSTR(@registro,151,1),
					`id_cliente`=SUBSTR(@registro,152,10),
					`sesion_cliente`=SUBSTR(@registro,162,17),
					`crc`=SUBSTR(@registro,179,4)
					;",
			    	addslashes($archivo));


				\Log::info('cargarApuestasPoceados-query',array($query));
	    		$db=  \DB::connection('suitecrm');
				\Log::info("empece carga apuPOZ", array($query));
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("termine carga apuPOZ");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de apuestas quiniela en la tabla");
				\Log::info($e);
				return false;
			}
		}

	/**
	* Elimina las apuestas canceladas de la tabla de apuestas
	**/
	public static function quitarCancelados(){
		try{
			$query='DELETE FROM sor_rec_apu WHERE fecha_cancelacion <> "0000-00-00";';
			return \DB::connection('suitecrm')->getpdo()->query($query);
			//return \DB::connection('suitecrm')->select(\DB::raw($query));
			//return \DB::connection()->getpdo()->exec($query);
		}catch(\Exception $e){
			\Log::info("Error al intentar eliminar las apuestas canceladas.");
			\Log::info($e);
			return false;
		}
	}

}
?>