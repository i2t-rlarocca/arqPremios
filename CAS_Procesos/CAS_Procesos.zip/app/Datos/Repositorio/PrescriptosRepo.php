<?php

	namespace Datos\Repositorio;
	
	class PrescriptosRepo{

		/*********************************************
		* 			obtiene secuencia esperada		 *  // se debe modificar el nombre de la tabla y campo al finalizar el flujo
		**********************************************/
		public static function secuenciaEsperada(){
			$db=\DB::connection('suitecrm');
			// cambiar la consulta una vez conocida la tabla que guardará la ultima secuencia
			$resultado = $db->select(\DB::raw('SELECT obtiene_sgte_secuencia_recep_presc() as sec_esp'));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				$datos['sec_esp']=$resultado[0]->sec_esp;
				return $datos['sec_esp'];
			}else{
				return null;
			}
		}

	/**********************************************
	* Devuelve tipo de archivo esperado cas.zip  	*ok
	***********************************************/
	public static function especif_arch_pre(){
		try{
			$db = \DB::connection('suitecrm');
			$resultados=$db->select(\DB::raw("SELECT 	
					999 AS id_juego, 
					a.`transaccion`, 
					a.`tipo_requerimiento`, 
					e.tipo_archivo, 
					e.`nombre`, 
					e.`cant_arch_esperados`, 
					e.`extension`, 
					e.`descomprime`, 
					e.`id_padre`, 
					e.control,
					a.tipo_requerimiento
				FROM sor_producto_archivo a 
				INNER JOIN sor_especificacion_archivo e ON (e.id=a.id_especificacion_archivo ) AND e.habilitado=1 AND e.tipo_archivo = 'PP'
				ORDER BY e.tipo_archivo, e.control DESC"));
			//convertimos el resultado (stdClass) a un arreglo
			$resultados=json_decode(json_encode((array) $resultados), true);
			$listaArchivosJuego=[];
			foreach ($resultados as $resultado) {
				$archivo['transaccion']=$resultado['transaccion'];
				$archivo['nombre']=$resultado['nombre'];
				$archivo['tipo_archivo']=$resultado['tipo_archivo'];
				$archivo['extension']=$resultado['extension'];
				$archivo['cant_arch_esperados']=$resultado['cant_arch_esperados'];
				$archivo['descomprime']=$resultado['descomprime'];
				$archivo['id_padre']=$resultado['id_padre'];
				$archivo['control']=$resultado['control'];
				$archivo['requerido']=$resultado['tipo_requerimiento'];
				if(array_key_exists($resultado['id_juego'], $listaArchivosJuego)){
					array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);
				}else{
					$listaArchivosJuego [$resultado['id_juego']]=[];
					array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);				
				}
			}
			return $listaArchivosJuego;
		}catch(\Exception $e){
			\Log::info("Error consultando el tipo de archivos a esperar para cas.zip");
			\Log::info($e);
			return false;
		}
	}

	/**********************************************
	* lectura archivo xml	CFE de control	*ok
	***********************************************/
	public static function cargarPrescriptosControl($archivo, $idProceso, $archivodatos){
		try{	
			$archivo=str_replace("\\", "/", $archivo);
			$md5_calculado = md5_file($archivodatos);			
		
			//obtenemos el contenido del archivo
			$xml = file_get_contents($archivo);
			//instanciamos la clase
			$DOM = new \DOMDocument('1.0', 'utf-8');
			//leemos el contenido de la variable 
			$DOM->loadXML($xml);
			//obtenemos los registros del archivo --> se crea un arreglo con los registros
			$registros = $DOM->getElementsByTagName('Registro');
			
			//recorremos el arreglo y accedemos a cada nodo y obtenemos el valor
			foreach($registros as $registro){
				$tipo_archivo=$registro->getElementsByTagName('tipo_archivo')->item(0)->nodeValue;			
				$version=$registro->getElementsByTagName('version')->item(0)->nodeValue;
				$nombre_archivo=$registro->getElementsByTagName('nombre_archivo')->item(0)->nodeValue;
				$provincia=$registro->getElementsByTagName('provincia')->item(0)->nodeValue;
				$tipoliquidacion=$registro->getElementsByTagName('Tipoliquidacion')->item(0)->nodeValue; //   P=Premios Prescriptos
				$secuencialiquidacion=$registro->getElementsByTagName('Secuencialiquidacion')->item(0)->nodeValue;
				$nroliquidacion=$registro->getElementsByTagName('Nroliquidacion')->item(0)->nodeValue;
				$fechaliquidacion=$registro->getElementsByTagName('Fechaliquidacion')->item(0)->nodeValue;
				$horaliquidacion=$registro->getElementsByTagName('Horaliquidacion')->item(0)->nodeValue;
				$cantidad_registros=$registro->getElementsByTagName('cantidad_registros')->item(0)->nodeValue;
				$suma_importe=$registro->getElementsByTagName('suma_importe')->item(0)->nodeValue;
				$md5_archivo=$registro->getElementsByTagName('md5')->item(0)->nodeValue;
			}
			if($tipoliquidacion == "P"){
					$tipo_archivo ='AFECTACIONES_PREMIOS_PRESCRIPTOS';
				}
			//insertamos en la tabla
			//$query = '';
			$query = 'TRUNCATE TABLE sor_rec_prescrip_ctrl;';
			$query .= 'insert into sor_rec_prescrip_ctrl(tipo_archivo,version,nombre_archivo,provincia,juego,sorteo,sistema,tipo_liquidacion,secuencia_liquidacion,nro_liquidacion,fecha_liquidacion,hora_liquidacion,cantidad_registros,suma_importe,importe_impuesto,md5_archivo,md5_calculado,id_proceso)'
			.'values("'.$tipo_archivo.'","'.$version.'","'.$nombre_archivo.'",'.$provincia.',999,0,"8","'.$tipoliquidacion.'",'.$secuencialiquidacion.',"'.$nroliquidacion.'",'.$fechaliquidacion.',time("'.$horaliquidacion.'"),'.$cantidad_registros.',convert('.$suma_importe.'/100,DECIMAL(18,2)),convert(0,decimal(18,2)),"'.$md5_archivo.'","'.$md5_calculado.'",'.$idProceso.')';
				
			$db=  \DB::connection('suitecrm');
			\Log::info("empecé carga sor_rec_prescrip_ctrl");
			$resultado=$db->getpdo()->exec($query);
			\Log::info("terminé carga sor_rec_prescrip_ctrl");
			if($db->getPdo()->errorCode()== '00000'){
				return 1;
			}else{
				return 0;
			}
			
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de prescriptos control en la tabla sor_rec_prescrip_ctrl");
				\Log::info($e);
				return false;
			}
	}
	
	/************************************************
	* lectura archivo prescripciones	AFE 		*
	***********************************************/
	public static function cargarPrescriptos($archivo,$idProceso){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$query =sprintf("
					TRUNCATE TABLE `sor_rec_prescrip` ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_prescrip`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`nro_juego`=SUBSTR(@registro,1,3),
					`nro_sorteo`=SUBSTR(@registro,4,6),
					`fecha_sorteo`=SUBSTR(@registro,10,8),
					`agente`=SUBSTR(@registro,18,6),
					`subagente`=SUBSTR(@registro,24,3),
					`vendedor`=SUBSTR(@registro,27,3),
					`cuit`=SUBSTR(@registro,30,11),
					`codigo_concepto`=SUBSTR(@registro,41,4),
					`alicuota`=SUBSTR(@registro,45,17),
					`moneda`=SUBSTR(@registro,62,1),
					`importe`=convert(SUBSTR(@registro,63,17)/100,decimal(18,2)),
					`debito_credito`=SUBSTR(@registro,80,2),
					`agente_originante`=SUBSTR(@registro,82,6),
					`subagente_originante`=SUBSTR(@registro,88,3),
					`vendedor_originante`=SUBSTR(@registro,91,3),
					`tipo_terminal`=SUBSTR(@registro,94,1),
					`nro_terminal`=SUBSTR(@registro,95,8),
					`nro_constancia`=SUBSTR(@registro,103,8),
					`crc`=SUBSTR(@registro,111,4),
					`id_proceso`='%s'
					;",
			    	addslashes($archivo),addslashes($idProceso));
				
	    		$db=  \DB::connection('suitecrm');
				\Log::info("inicio carga sor_rec_prescrip");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("fin carga sor_rec_prescrip");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo sor_rec_prescrip en la tabla");
				\Log::info($e);
				return false;
			}
		}
	
		/*********************************************
		* 	validar vuelco en cada tabla			 *
		**********************************************/
		public static function validarVuelcos($idProceso,$nroSecuencia,$usuario){
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','DAT',@msgret";
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Prescriptos_validacion`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			
			\DB::disconnect('suitecrm');
			return $ok[0]->msgret;
		}
	
		/*********************************************
		* 			validar Secuencia				 *
		**********************************************/
		public static function validarSecuencia($idProceso,$nroSecuencia,$usuario){
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','SEC',@msgret";
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Prescriptos_validacion`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			\Log::info("validasecuencia",array($ok[0]->msgret));
			\DB::disconnect('suitecrm');
			return $ok[0]->msgret;
		}
		
		/*********************************************
		* 	validar SORTEOS					 *
		**********************************************/
		public static function validarSorteos($idProceso,$nroSecuencia,$usuario){
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','SOR',@msgret";
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Prescriptos_validacion`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			\DB::disconnect('suitecrm');
			return $ok[0]->msgret;
		}
		
		/*****************************************************************************************
		* 	validar fecha liquidacion igual o superior a fecha de prescripcion del sorteo		 *
		*****************************************************************************************/
		public static function validarFechaLiquidacion($idProceso,$nroSecuencia,$usuario){
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','FLP',@msgret";
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Prescriptos_validacion`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			\DB::disconnect('suitecrm');
			return $ok[0]->msgret;
		}

		/*********************************************
		* 	validar agencia							 *
		**********************************************/
		public static function validarAgencias($idProceso,$nroSecuencia,$usuario){
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','AGE',@msgret";
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Prescriptos_validacion`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			\DB::disconnect('suitecrm');
			return $ok[0]->msgret;
		}

		/*********************************************
		* 	validar conceptos						 *
		**********************************************/
		public static function validarConceptos($idProceso,$nroSecuencia,$usuario){
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','CON',@msgret";
			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Prescriptos_validacion`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			\DB::disconnect('suitecrm');
			return $ok[0]->msgret;
		}

		/*********************************************
		* 	validar vuelco definitivo	prescriptos	 *
		**********************************************/
		public static function ProcesoPrescriptos($idProceso,$nroSecuencia,$usuario){
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','PPR',@msgret";

			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Prescriptos_Proceso`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			\Log::info("ok vuelta",array($ok[0]->msgret));

			\DB::disconnect('suitecrm');
			return $ok[0]->msgret;
		}

		/*********************************************
		* 	validar vuelco definitivo	prescriptos	 *
		**********************************************/
		public static function PrescriptosResumen($idProceso,$nroSecuencia,$usuario){
			$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','RES',@msgret";

			\DB::connection('suitecrm')->unprepared(\DB::raw('CALL `CC_Prescriptos_Proceso`('.$datos.')'));
			$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
			\Log::info('RES',array($ok));
			
			\DB::disconnect('suitecrm');
			return $ok[0]->msgret;
		}
		
		/**************************************************************
		* 	Genera Minutas Prescripción Premios Canal Tesorería (UIF) *
		**************************************************************/
		public static function PrescriptosMinutasTesoreria($idProceso,$nroSecuencia,$usuario){
			$juego = -1;
			$sorteo = -1;
			$identprc = 'pprt_' . str_pad($idProceso, 10, "0", STR_PAD_LEFT);
			$datos2 = $juego.','.$sorteo.',"'.$usuario.'","'.$identprc.'",@rcode, @rtxt, @id, @rsqlerrno, @rsqlerrtxt';

			\Log::info("Llama SOR_PUBLICA_MINUTAS - datos ", array($datos2)); 
			\DB::connection('suitecrm')->unprepared(\DB::raw("CALL sor_publica_minutas($datos2)"));
			$res = \DB::connection('suitecrm')->select(\DB::raw('SELECT @rcode as rcode, @rtxt as rtxt, @id as id, @rsqlerrno as rsqlerrno, @rsqlerrtxt as rsqlerrtxt'));
			\Log::info("Devuelve sor_publica_minutas - res  ", array($res));
			
			\DB::disconnect('suitecrm');
			return $res[0]->rtxt;
		}		
	}
?>