<?php

	namespace Datos\Repositorio;
	
	use models\ServidorFTPModelo;
	use models\ProductoFTPModelo;
	use \Carbon\Carbon;

	class RecepcionPrePagadosRepo{	
		// RR
		/*********************************************
		* 			obtiene secuencia esperada		 *
		**********************************************/		
		public static function secuenciaEsperada(){
			\Log::info('Estoy en el metodo secuenciaEsperada'); 
			$db=\DB::connection('suitecrm');
		
			$resultado = $db->select(\DB::raw('SELECT obtiene_sgte_secuencia_liq_presc() as sec_esp'));		
		
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				$datos['sec_esp']=$resultado[0]->sec_esp;
				return $datos['sec_esp'];
			}else{
				return null;
			}
		}
		
		/*********************************************
		* 			validar secuencia				 *
		**********************************************/
	
		public static function validarSecuencia($idProceso,$nroSecuencia,$usuario,$tipo_validacion){
			\Log::info("RR- Entra al metodo - validarSecuencia");			
			try{
				$datos=$idProceso.",".$nroSecuencia.",'".$usuario."','".$tipo_validacion."',@juego_s,@sorteo_s,@ticket_s,@provincia_s,@agencia_s,@importe_s,@error";
				
				\Log::info('validarSecuencia',array($datos));
				$msgret=\DB::connection('suitecrm')->select(\DB::raw('CALL CC_Premios_Pagados_OP_Validacion('.$datos.')'));
				return $msgret[0];

			}catch(\Exception $e){
				\Log::info("RR - validarSecuencia.");
				\Log::info("Error al validar secuencia en premios pagados otras provincias.");
				\Log::info($e);
			}
		}
		
		/*********************************************
		* 			actualizar secuencia				 *
		**********************************************/	

		public static function actualizaSecuencia($idProceso,$opcion){
			\Log::info("RR- Entra al metodo - actualizaSecuencia");		

			try{
				$datos =$idProceso.",'".$opcion."',@msgret,@msgaux";
				\Log::info("Llama CC_Premios_Pagados_OP_Proceso datos: ",array($datos));
				$msgret=\DB::connection('suitecrm')->select(\DB::raw('CALL CC_Premios_Pagados_OP_Proceso('.$datos.')'));
				\DB::disconnect('suitecrm');
				\Log::info("RR - retorno SP msgret: ", array($msgret));
				return $msgret[0];	

			}catch(\Exception $e){
				\Log::info("RR - actualizaSecuencia.");
				\Log::info("Error al actualizar secuencia en premios pagados otras provincias.");
				\Log::info($e);
			}
		}
		

		/**********************************************
		* Devuelve tipo de archivo esperado .000
		***********************************************/
		public static function especif_arch_pre(){
			try{
				$db = \DB::connection('suitecrm');
				$resultados=$db->select(\DB::raw("SELECT 
						a.`transaccion`, 
						a.`tipo_requerimiento`, 
						e.tipo_archivo, 
						e.`nombre`, 
						e.`cant_arch_esperados`, 
						e.`extension`, 
						e.`descomprime`, 
						e.`id_padre`, 
						e.control,
						a.tipo_requerimiento
					FROM sor_producto_archivo a 
					INNER JOIN sor_especificacion_archivo e ON (e.id=a.id_especificacion_archivo ) AND e.habilitado=1 AND e.tipo_archivo = 'IR'
					ORDER BY e.tipo_archivo, e.control DESC"));
				//convertimos el resultado (stdClass) a un arreglo
				$resultados=json_decode(json_encode((array) $resultados), true);
				/*$listaArchivosJuego=[];
				foreach ($resultados as $resultado) {
					$archivo['transaccion']=$resultado['transaccion'];
					$archivo['nombre']=$resultado['nombre'];
					$archivo['tipo_archivo']=$resultado['tipo_archivo'];
					$archivo['extension']=$resultado['extension'];
					$archivo['cant_arch_esperados']=$resultado['cant_arch_esperados'];
					$archivo['descomprime']=$resultado['descomprime'];
					$archivo['id_padre']=$resultado['id_padre'];
					$archivo['control']=$resultado['control'];
					$archivo['requerido']=$resultado['tipo_requerimiento'];
					if(array_key_exists($resultado['id_juego'], $listaArchivosJuego)){
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);
					}else{
						$listaArchivosJuego [$resultado['id_juego']]=[];
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);				
					}
				}
				*/
				return $resultados[0];
			}catch(\Exception $e){
				\Log::info("Error consultando el tipo de archivos a esperar para .nnn");
				\Log::info($e);
				return false;  
			}
		}
		
		public static function especif_arch_x_juego(){
			try{
				$db = \DB::connection('suitecrm');
				$resultados=$db->select(\DB::raw("SELECT COALESCE(p.`id_juego`,999) as id_juego, a.`transaccion`, a.`tipo_requerimiento`, e.tipo_archivo, e.`nombre`, e.`cant_arch_esperados`, e.`extension`, e.`descomprime`, e.`id_padre`, e.control,a.`tipo_requerimiento`  
				FROM sor_producto p
				RIGHT JOIN sor_producto_archivo a ON a.`id_producto`=p.`id`
				INNER JOIN sor_especificacion_archivo e ON (e.id=a.`id_especificacion_archivo` OR e.`id_padre`=a.`id_especificacion_archivo`) AND e.`habilitado`=1
				WHERE e.tipo_archivo = 'PA'
				ORDER BY p.`id_juego`,e.tipo_archivo, e.control DESC"));
				
				//convertimos el resultado (stdClass) a un arreglo
				$resultados=json_decode(json_encode((array) $resultados), true);
				$listaArchivosJuego=[];
				foreach ($resultados as $resultado) {
					$archivo['transaccion']=$resultado['transaccion'];
					$archivo['nombre']=$resultado['nombre'];
					$archivo['tipo_archivo']=$resultado['tipo_archivo'];
					$archivo['extension']=$resultado['extension'];
					$archivo['cant_arch_esperados']=$resultado['cant_arch_esperados'];
					$archivo['descomprime']=$resultado['descomprime'];
					$archivo['id_padre']=$resultado['id_padre'];
					$archivo['control']=$resultado['control'];
					$archivo['requerido']=$resultado['tipo_requerimiento'];
					if(array_key_exists($resultado['id_juego'], $listaArchivosJuego)){
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);
					}else{
						$listaArchivosJuego [$resultado['id_juego']]=[];
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);				
					}
				}

				return $listaArchivosJuego;
			}catch(\Exception $e){
				\Log::info("Error consultando los tipos de archivos a esperar");
				\Log::info($e);
				return false;
			}
		}
		
		/**********************************************
		* Devuelve tipo de archivo 
		***********************************************/
		
		public static function especif_arch_x_juego_otrprov(){
			try{
				$db = \DB::connection('suitecrm');
				$resultados=$db->select(\DB::raw("SELECT COALESCE(p.`id_juego`,999) as id_juego, a.`transaccion`, a.`tipo_requerimiento`, e.tipo_archivo, e.`nombre`, e.`cant_arch_esperados`, e.`extension`, e.`descomprime`, e.`id_padre`, e.control,a.`tipo_requerimiento`  
				FROM sor_producto p
				RIGHT JOIN sor_producto_archivo a ON a.`id_producto`=p.`id`
				INNER JOIN sor_especificacion_archivo e ON (e.id=a.`id_especificacion_archivo` OR e.`id_padre`=a.`id_especificacion_archivo`) AND e.`habilitado`=1
				WHERE e.tipo_archivo = 'OP'
				ORDER BY p.`id_juego`,e.tipo_archivo, e.control DESC"));
				
				//convertimos el resultado (stdClass) a un arreglo
				$resultados=json_decode(json_encode((array) $resultados), true);
				$listaArchivosJuego=[];
				foreach ($resultados as $resultado) {
					$archivo['transaccion']=$resultado['transaccion'];
					$archivo['nombre']=$resultado['nombre'];
					$archivo['tipo_archivo']=$resultado['tipo_archivo'];
					$archivo['extension']=$resultado['extension'];
					$archivo['cant_arch_esperados']=$resultado['cant_arch_esperados'];
					$archivo['descomprime']=$resultado['descomprime'];
					$archivo['id_padre']=$resultado['id_padre'];
					$archivo['control']=$resultado['control'];
					$archivo['requerido']=$resultado['tipo_requerimiento'];
					if(array_key_exists($resultado['id_juego'], $listaArchivosJuego)){
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);
					}else{
						$listaArchivosJuego [$resultado['id_juego']]=[];
						array_push($listaArchivosJuego [$resultado['id_juego']],$archivo);				
					}
				}

				return $listaArchivosJuego;
			}catch(\Exception $e){
				\Log::info("Error consultando los tipos de archivos a esperar");
				\Log::info($e);
				return false;
			}
		}
		
		/**********************************************
		* Devuelve tipo de archivo esperado .000
		***********************************************/
		public static function especif_arch_premiospagados(){
			try{
				$db = \DB::connection('suitecrm');
				$resultados=$db->select(\DB::raw("SELECT 
						a.`transaccion`, 
						a.`tipo_requerimiento`, 
						e.tipo_archivo, 
						e.`nombre`, 
						e.`cant_arch_esperados`, 
						e.`extension`, 
						e.`descomprime`, 
						e.`id_padre`, 
						e.control,
						a.tipo_requerimiento
					FROM sor_producto_archivo a 
					INNER JOIN sor_especificacion_archivo e ON (e.id=a.id_especificacion_archivo ) AND e.habilitado=1 AND e.tipo_archivo = 'PA'
					ORDER BY e.tipo_archivo, e.control DESC"));
				//convertimos el resultado (stdClass) a un arreglo
				$resultados=json_decode(json_encode((array) $resultados), true);
				
				return $resultados[0];
			}catch(\Exception $e){
				\Log::info("Error consultando el tipo de archivos a esperar");
				\Log::info($e);
				return false;  
			}
		}

		
		/*****************************************************************************
		* Devuelve tipo de archivo esperado para premios pagados otras provincias
		******************************************************************************/
		public static function especif_arch_premiospagados_otrprov(){
			try{
				$db = \DB::connection('suitecrm');
				$resultados=$db->select(\DB::raw("SELECT 
						a.`transaccion`, 
						a.`tipo_requerimiento`, 
						e.tipo_archivo, 
						e.`nombre`, 
						e.`cant_arch_esperados`, 
						e.`extension`, 
						e.`descomprime`, 
						e.`id_padre`, 
						e.control,
						a.tipo_requerimiento
					FROM sor_producto_archivo a 
					INNER JOIN sor_especificacion_archivo e ON (e.id=a.id_especificacion_archivo ) AND e.habilitado=1 AND e.tipo_archivo = 'OP'
					ORDER BY e.tipo_archivo, e.control DESC"));
				//convertimos el resultado (stdClass) a un arreglo
				$resultados=json_decode(json_encode((array) $resultados), true);
				
				return $resultados[0];
			}catch(\Exception $e){
				\Log::info("Error consultando el tipo de archivos a esperar");
				\Log::info($e);
				return false;  
			}
		}
		
		
		public static function cargarPrePagados($archivo){
			try{	
				//********************************************
				// Cargo los datos en la tabla  con el load
				//********************************************
				// SUBSTR(@registro,169,8) a partir de la 169, lee 8
	    		$query =sprintf("
					TRUNCATE TABLE `cas02_cc_rec_prePagados`;
					LOAD DATA INFILE '%s' INTO TABLE `cas02_cc_rec_prePagados`
					LINES TERMINATED BY '\r\n'
					(@registro)
					SET 
					wm_jueg = SUBSTR(@registro,1,2),
					wm_sort = SUBSTR(@registro,3,8),
					wm_fpago = SUBSTR(@registro,11,8),
					wm_hpago = SUBSTR(@registro,19,6),
					wm_fpro = SUBSTR(@registro,25,8),
					wm_hpro = SUBSTR(@registro,33,6),
					wm_provi = SUBSTR(@registro,39,2),
					wm_ncupo = SUBSTR(@registro,41,10),
					wm_iprm = SUBSTR(@registro,51,13),
					wm_agen = SUBSTR(@registro,64,5),
					wm_sbag = SUBSTR(@registro,69,3),
					wm_ambu = SUBSTR(@registro,72,3),
					wm_tdoc = SUBSTR(@registro,75,1),
					wm_ndoc = SUBSTR(@registro,76,9),
					id_permiso = null,
					account_id_c = null;",
					addslashes($archivo));
			    $db = \DB::connection('suitecrm');
				\Log::info("empecé carga com_ctrl");
	    		$resultado=$db->getpdo()->exec($query);
	    		\Log::info('Resultado del exec query', array('resultado' => $resultado));

			}catch(\Exception $e){
				$filename = explode('.',$archivo); 
				$filename = $filename[0];
				\Log::info("Recep. PrePagados: Error al cargar el archivo" . $filename);
				\Log::info($e);
				return false;
			}

			
		}

		public static function validarEnvios($idProceso,$id_archivo,$usuario,$tipo_validacion){
			
			\Log::info("Inicio validar envios de archivo premios pagados.");
			$datos =$idProceso.",".$id_archivo.",'".$usuario."','".$tipo_validacion."',@juego_s,@sorteo_s,@ticket_s,@provincia_s,@agencia_s,@importe_s,@error";
			try{
				\DB::connection('suitecrm')->unprepared(\DB::raw('CALL CC_Premios_Pagados_Validacion('.$datos.')'));
				$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @juego_s as juego, @sorteo_s as sorteo, @ticket_s as ticket, @provincia_s as provincia,@agencia_s as agencia,@importe_s as importe,@error as cod_error'));
				\Log::info("RecepcionPrePagadosRepo->validarEnvios->Ok",array($ok));
				return $ok; 

			}catch(\Exception $e){
				\Log::info("Error al validar envios de archivo premios pagados.");
				\Log::info($e);
                                return false;
			}
			
		}
		
		public static function validarEnviosOtrProv($idProceso,$id_archivo,$usuario,$tipo_validacion){
			\Log::info("RR- Entra al metodo - validarEnviosOtrProv");
			$datos =$idProceso.",".$id_archivo.",'".$usuario."','".$tipo_validacion."',@juego_s,@sorteo_s,@ticket_s,@provincia_s,@agencia_s,@importe_s,@error";
			
			try{
				//\DB::connection('suitecrm')->unprepared(\DB::raw('CALL CC_Premios_Pagados_OP_Validacion('.$datos.')'));
				//$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @juego_s as juego, @sorteo_s as sorteo, @ticket_s as ticket, @provincia_s as provincia,@agencia_s as agencia,@importe_s as importe,@error as cod_error'));
				//\Log::info("Ok",array($ok));


			//$datos = $juego.','.$sorteo.',"'.$usuario.'",@msgret';
			\Log::info("RR - tratamientoArchivoPremPagOtrProv - else:", array($datos));
			$msgret=\DB::connection('suitecrm')->select(\DB::raw('CALL CC_Premios_Pagados_OP_Validacion('.$datos.')'));
			//return $ok; 
			return $msgret[0];	
				
				
				
			}catch(\Exception $e){
				\Log::info("RR - validarEnviosOtrProv.");
				\Log::info("Error al validar envios de archivo premios pagados otras provincias.");
				\Log::info($e);
			}
			
		}
		

		public static function Procesar_pre_pagados($idProceso){
			try{
				\Log::info("RecepcionPrePagadosRepo->Procesar_pre_pagados->call sp: ",array( "CALL CC_Premios_Pagados_Proceso($idProceso,@msgret,@msgaux)" ));
				\DB::connection('suitecrm')->unprepared(\DB::raw("CALL CC_Premios_Pagados_Proceso($idProceso,@msgret,@msgaux)"));
				$ok=\DB::connection('suitecrm')->select(\DB::raw("SELECT @msgret as msgret, @msgaux as msgaux;"));
				//$msgaux=\DB::connection('suitecrm')->select(\DB::raw("SELECT @msgaux as msgaux"));
				\Log::info("RecepcionPrePagadosRepo->Procesar_pre_pagados->Ok",array( $ok ));
				//\Log::info("RecepcionPrePagadosRepo->Procesar_pre_pagados->Resultado del Procesamiento: ",array( $msgaux ));
				return $ok;			

			}catch(\Exception $e){
				\Log::info("Procesamiento premios pagados: Problema al invocar CC_Premios_Pagados_Proceso.");
				\Log::info($e);
			}
		}
		
		/*
		public static function Procesar_pre_pagados_otrporv(){
			try{
				\DB::connection('suitecrm')->unprepared(\DB::raw('CALL CC_Premios_Pagados_OP_Proceso(@msgret,@msgaux)'));
				$ok=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgret as msgret'));
				$msgaux=\DB::connection('suitecrm')->select(\DB::raw('SELECT @msgaux as msgaux'));
				\Log::info("Ok",array( $ok ));
				\Log::info("Resultado del Procesamiento",array( $msgaux ));
				return $ok;			

			}catch(\Exception $e){
				\Log::info("Procesamiento premios pagados: Problema al invocar CALL CC_Premios_Pagados_Proceso.");
				\Log::info($e);
			}
		}
		*/
		
		
		public static function getNumeroProcesoAuditoria(){
			try{
				$db=\DB::connection('suitecrm');
				//llamada a una función definida en la bd 
				$query="select getNuevoProcesoAuditoria() AS id_proceso;";
				$stmt = $db->getpdo()->prepare($query);
				$stmt->execute();
				$idProceso=$stmt->fetch(\PDO::FETCH_ASSOC)['id_proceso'];
				return $idProceso;		
			}catch(\Exception $e){
				\Log::info("Error en getNumeroProcesoAuditoria");
			}
		}
		
		
		// MM 05/07/2017	- 	carga premios pagados
		
		/************************************************/
		/*		carga control premios pagados			*/
		/************************************************/
		
		public static function cargarPremiosPagadosControl($idProceso, $archivo, $archivoG){
			try{
				// RR
				//$archivo = '/var/data/prepagados_otrprov/' . basename($archivo);				
				$archivo=str_replace("\\", "/", $archivo);
				$md5_calculadopag = md5_file($archivoG);			
			
			
				//obtenemos el contenido del archivo
				$xml = file_get_contents($archivo);
				//instanciamos la clase
				$DOM = new \DOMDocument('1.0', 'utf-8');
				//leemos el contenido de la variable 
				$DOM->loadXML($xml);
				//obtenemos los registros del archivo --> se crea un arreglo con los registros
				$registros = $DOM->getElementsByTagName('Registro');
				//recorremos el arreglo y accedemos a cada nodo y obtenemos el valor
				foreach($registros as $registro){
					$tipo_archivo=$registro->getElementsByTagName('tipo_archivo')->item(0)->nodeValue;			
					$version=$registro->getElementsByTagName('version')->item(0)->nodeValue;
					$nombre_archivo=$registro->getElementsByTagName('nombre_archivo')->item(0)->nodeValue;
					$cantidad_pagos=$registro->getElementsByTagName('cantidad_pagos')->item(0)->nodeValue;
					$importe_pagos=$registro->getElementsByTagName('importe_pagos')->item(0)->nodeValue;
					$md5=$registro->getElementsByTagName('md5')->item(0)->nodeValue;
					
				}
			
				//insertamos en la tabla
				$query = 'TRUNCATE TABLE cas02_cc_rec_premiosPagados_ctrl ; ';
				$query =$query.'insert into cas02_cc_rec_premiosPagados_ctrl(tipo_archivo, version, nombre_archivoPag, cantidadRegistrosPag, ImportePag, md5Pag, md5Pag_calculado,id_proceso)'
				.'values("'.$tipo_archivo.'",'.$version.',"'.$nombre_archivo.'",'.$cantidad_pagos.',CAST('.$importe_pagos.'/100 AS DECIMAL(18,2)),"'.$md5.'","'.$md5_calculadopag.'",'.$idProceso.')';
				
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga cas02_cc_rec_premiosPagados_ctrl");
				$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga cas02_cc_rec_premiosPagados_ctrl");
				if($db->getPdo()->errorCode()== '00000'){
					return 1;
				}else{
					return 0;
				}
				
				}catch(\Exception $e){
					\Log::info("Error cargando el archivo de premios control en la tabla");
					\Log::info($e);
					return false;
				}
		}
	
	
	
		/****************************************/
		/* 		premios liquidados completo		*/
		/****************************************/
		
		public static function cargarPremiosPagados($idProceso,$archivo){
			try{
				$archivo=str_replace("\\", "/", $archivo);
				$formato = '%H:%i:%s';
				$Proceso = $idProceso;
				// A partir de 3/5 corresponde este diseño
								$query =sprintf("
					TRUNCATE TABLE `cas02_cc_rec_premiosPagados` ;
					LOAD DATA INFILE '%s' INTO TABLE `cas02_cc_rec_premiosPagados`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`id_juego`=SUBSTR(@registro,1,2),
					`codigo_provincia`=SUBSTR(@registro,3,2),
					`sorteo`=SUBSTR(@registro,5,5),
					`agente`=SUBSTR(@registro,10,6),
					`subagente`=SUBSTR(@registro,16,3),
					`codigo_corredor`=SUBSTR(@registro,19,3),
					`nro_ocr`=SUBSTR(@registro,22,9),
					`digito_verificador`=SUBSTR(@registro,31,1),
					`tipo_de_sistema`=SUBSTR(@registro,32,1),
					`moneda`=SUBSTR(@registro,33,2),
					`nro_parte`=SUBSTR(@registro,35,3),
					`fecha_pago`=DATE(SUBSTR(@registro,38,8)),
					`hora_pago`=TIME_FORMAT(SUBSTR(@registro,46,6), '%s'),
					`importe_pago`=CAST(SUBSTR(@registro,52,12)/100 AS DECIMAL(18,2)),
					`modo_pago`=SUBSTR(@registro,76,1),
					`tipo_documento`=SUBSTR(@registro,77,1),
					`numero_documento`=SUBSTR(@registro,78,11),
					`crc`=SUBSTR(@registro,97,4),
					id_proceso = '%s';",
			    	addslashes($archivo),addslashes($formato),addslashes($Proceso));
				/*
				$query =sprintf("
					TRUNCATE TABLE `cas02_cc_rec_premiosPagados` ;
					LOAD DATA INFILE '%s' INTO TABLE `cas02_cc_rec_premiosPagados`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`id_juego`=SUBSTR(@registro,1,2),
					`codigo_provincia`=SUBSTR(@registro,3,2),
					`sorteo`=SUBSTR(@registro,5,5),
					`agente`=SUBSTR(@registro,10,6),
					`subagente`=SUBSTR(@registro,16,3),
					`codigo_corredor`=SUBSTR(@registro,19,3),
					`nro_ocr`=SUBSTR(@registro,22,9),
					`digito_verificador`=SUBSTR(@registro,31,1),
					`tipo_de_sistema`=SUBSTR(@registro,32,1),
					`moneda`=SUBSTR(@registro,33,2),
					`nro_parte`=SUBSTR(@registro,35,3),
					`fecha_pago`=DATE(SUBSTR(@registro,38,8)),
					`hora_pago`=TIME_FORMAT(SUBSTR(@registro,46,6), '%s'),
					`importe_pago`=CAST(SUBSTR(@registro,52,12)/100 AS DECIMAL(18,2)),
					`modo_pago`=SUBSTR(@registro,64,1),
					`tipo_documento`=SUBSTR(@registro,65,1),
					`numero_documento`=SUBSTR(@registro,66,11),
					`crc`=SUBSTR(@registro,77,4),
					id_proceso = '%s';",
			    	addslashes($archivo),addslashes($formato),addslashes($Proceso));
				*/
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga cas02_cc_rec_premiosPagados");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga cas02_cc_rec_premiosPagados");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de premios en la tabla");
				\Log::info($e);
				return false;
			}
		}		
		
	/****************************************************************/
	/* 				premios pagados otras provincias				*/
	/*		   		  carga control premios pagados					*/
	/****************************************************************/
	
		public static function cargarPremiosPagadosOtrasProvinciasControl($idProceso, $archivo, $archivoG){
			try{	
				\Log::info("RR - cargarPremiosPagadosOtrasProvinciasControl - idProceso" , array($idProceso));
				\Log::info("RR - cargarPremiosPagadosOtrasProvinciasControl - archivo 1" , array($archivo));
				\Log::info("RR - cargarPremiosPagadosOtrasProvinciasControl - archivoG 2" , array($archivoG));
								
				// RR
				//$archivo = '/var/data/prepagados_otrprov/' . basename($archivo);	
				\Log::info("RR - cargarPremiosPagadosOtrasProvinciasControl - archivo" , array($archivo));			
				$archivo=str_replace("\\", "/", $archivo);			
				$archivoG=str_replace("\\", "/", $archivoG);
				//$archivoG = '/var/data/prepagados_otrprov/' . basename($archivoG);			
				$md5_calculado = md5_file($archivoG);	
						
				//obtenemos el contenido del archivo
				$xml = file_get_contents($archivo);
				\Log::info("RR - cargarPremiosPagadosOtrasProvinciasControl - file_get_contents" , array($archivo));
				//instanciamos la clase
				$DOM = new \DOMDocument('1.0', 'utf-8');
				//leemos el contenido de la variable 
				$DOM->loadXML($xml);
				//obtenemos los registros del archivo --> se crea un arreglo con los registros
				$registros = $DOM->getElementsByTagName('Registro');
				//recorremos el arreglo y accedemos a cada nodo y obtenemos el valor
				foreach($registros as $registro){
					$tipo_archivo=$registro->getElementsByTagName('tipo_archivo')->item(0)->nodeValue;			
					$version=$registro->getElementsByTagName('version')->item(0)->nodeValue;
					$nombre_archivo=$registro->getElementsByTagName('nombre_archivo')->item(0)->nodeValue;
					$provincia=$registro->getElementsByTagName('provincia')->item(0)->nodeValue;
					$secuenciaEnvio=$registro->getElementsByTagName('secuenciaEnvio')->item(0)->nodeValue; //RR
					$fechaHoraEnvio=$registro->getElementsByTagName('fechaHoraEnvio')->item(0)->nodeValue;
					$cantidadRegistros=$registro->getElementsByTagName('cantidadRegistros')->item(0)->nodeValue;
					$sumaImporte=$registro->getElementsByTagName('sumaImporte')->item(0)->nodeValue;
					$md5=$registro->getElementsByTagName('md5')->item(0)->nodeValue;
					
				}
			
				//insertamos en la tabla
				$query = 'TRUNCATE TABLE sor_rec_preop_ctr ; ';
				$query =$query.'insert into sor_rec_preop_ctr(tipo_archivo, version, nombre_archivo, provincia, secuencia_envio, fecha_hora_envio,cantidad_registros, suma_importe, md5_archivo, md5_calculado,id_proceso)'
				.'values("'.$tipo_archivo.'",'.$version.',"'.$nombre_archivo.'", CAST('.$provincia.' AS UNSIGNED), CAST('.$secuenciaEnvio.' AS UNSIGNED),"'.$fechaHoraEnvio.'",'.$cantidadRegistros.',CAST('.$sumaImporte.'/100 AS DECIMAL(18,2)),"'.$md5.'","'.$md5_calculado.'",'.$idProceso.')'; //RR
				
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga sor_rec_preop_ctr");
				$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga sor_rec_preop_ctr");
				if($db->getPdo()->errorCode()== '00000'){
					return 1;
				}else{
					return 0;
				}
				
				}catch(\Exception $e){
					\Log::info("Error cargando el archivo de premios otras provincias control en la tabla");
					\Log::info($e);
					return false;
				}
		}
	
	
	
		/****************************************/
		/* 		premios liquidados completo		*/
		/****************************************/
		
		public static function cargarPremiosPagadosOtrasProvincias($idProceso,$archivo){
			try{
				// $archivo = '/var/data/prepagados_otrprov/' . basename($archivo); 
				$archivo = '/var/www/cas/CAS_Procesos/public/archivos/prepagados_otrprov/'. basename($archivo);
				\Log::info("RR - cargarPremiosPagadosOtrasProvincias - ARCHIVO", array($archivo));
					
				//$archivo=str_replace("\\", "/", $archivo);
				$formato = '%H:%i:%s';
				$Proceso = $idProceso;
				// A partir de 3/5 corresponde este diseño
				// A partir de 23/11 corresponde este diseño `pais_desc`=SUBSTR(@registro,332,50), eliminado RR
				$query =sprintf("
					TRUNCATE TABLE `sor_rec_preop` ;
					LOAD DATA INFILE '%s' INTO TABLE `sor_rec_preop`
					LINES TERMINATED BY '\n'
					(@registro)
					SET 
					`provincia`=SUBSTR(@registro,1,2),
					`numero_juego`=SUBSTR(@registro,3,3),
					`numero_sorteo`=SUBSTR(@registro,6,6),
					`ocr`=SUBSTR(@registro,12,10),
					`digito_verificador`=SUBSTR(@registro,22,1),
					`importe_premiado_neto`=CAST(SUBSTR(@registro,23,17)/100 AS DECIMAL(15,2)),
					`fecha_pago`=SUBSTR(@registro,40,8),
					`benef_tipo_cuit_afip`=SUBSTR(@registro,48,2),
					`benef_cuit_cuil`=SUBSTR(@registro,50,11),
					`benef_nombre`=SUBSTR(@registro,61,50),
					`benef_apellido`=SUBSTR(@registro,111,50),
					`benef_calle_nombre`=SUBSTR(@registro,161,50),
					`benef_calle_numero`=SUBSTR(@registro,211,6),
					`benef_cod_postal_correo`=SUBSTR(@registro,217,8),
					`benef_cod_postal`=SUBSTR(@registro,225,4),
					`benef_localidad`=SUBSTR(@registro,229,50),
					`benef_provincia`=SUBSTR(@registro,279,2),
					`benef_email`=SUBSTR(@registro,281,50),
					`benef_sexo`=SUBSTR(@registro,331,1),
					
					`codigo_pais`=SUBSTR(@registro,332,3),
					`num_doc_persona_human`=SUBSTR(@registro,335,11),
					`tipo_benef`=SUBSTR(@registro,346,1),
					`benef_segundo_nombre`=SUBSTR(@registro,347,50),
					`benef_tipo_documento`=SUBSTR(@registro,397,2),
					`benef_calle_piso`=SUBSTR(@registro,399,10),
					`benef_calle_depto`=SUBSTR(@registro,409,10),
					`benef_fecha_nac_ini_actividades`=SUBSTR(@registro,419,10),
					`benef_estado_civil`=SUBSTR(@registro,429,2),
					`benef_telef_carac`=SUBSTR(@registro,431,5),
					`benef_telef`=SUBSTR(@registro,436,9),
					`benef_pep`=SUBSTR(@registro,445,1),
					`benef_cargo`=SUBSTR(@registro,446,150),
					`benef_ocupacion`=SUBSTR(@registro,596,3),
					`benef_nacionalidad`=SUBSTR(@registro,599,3),
					`benef_tipo_sociedad`=SUBSTR(@registro,602,3),
					`forma_pago`=SUBSTR(@registro,605,1),
					`codigo_banco`=SUBSTR(@registro,606,3),
					`tipo_cuenta`=SUBSTR(@registro,609,1),
					`numero_cuenta`=SUBSTR(@registro,610,11),
					`cbu`=SUBSTR(@registro,621,22),
					`numero_cheque`=SUBSTR(@registro,643,11),
					id_proceso = '%s';",					
			    	addslashes($archivo),addslashes($Proceso));  // addslashes($formato),
				
				$db=  \DB::connection('suitecrm');
				\Log::info("empecé carga sor_rec_preop");
	    		$resultado=$db->getpdo()->exec($query);
				\Log::info("terminé carga sor_rec_preop");
	    		if($db->getPdo()->errorCode()== '00000'){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
			}catch(\Exception $e){
				\Log::info("Error cargando el archivo de premios otras provincias en la tabla");
				\Log::info($e);
				return false;
			}
		}

		/*********************************************
		* 	PrcExp_ObtenerRegistros 	EXP_MANUALES_BOLDT_GET_REGISTROS				 *
		**********************************************/
		public static function Procesar_pre_pagados_otrporv($idProceso,$opcion){
			\Log::info("RR - ENTRO AL METODO Procesar_pre_pagados_otrporv");	
			
			try{
				$datos =$idProceso.",'".$opcion."',@msgret,@msgaux";
				\Log::info("Llama CC_Premios_Pagados_OP_Proceso datos: ", array($datos));
				$msgret=\DB::connection('suitecrm')->select(\DB::raw('CALL CC_Premios_Pagados_OP_Proceso('.$datos.')'));
				\DB::disconnect('suitecrm');
				\Log::info("MM - retorno SP msgret: ", array($msgret));
				return $msgret[0];			
				
				
			}catch(\Exception $e){
				\Log::info("RR - Procesar_pre_pagados_otrporv.");
				\Log::info("Error al validar envios de archivo premios pagados otras provincias.");
				\Log::info($e);
			}


			
			
				/* FUNCIONA SIN VALOR DE RETORNO
				try{
					$datos =$idProceso.",'".$opcion."',@msgret,@msgaux";
				\DB::connection('suitecrm')->statement(\DB::raw('CALL CC_Premios_Pagados_OP_Proceso('.$datos.')'));
				\Log::info("llamo al sp CC_Premios_Pagados_OP_Proceso ");
				$ok=\DB::connection('suitecrm')->select(\DB::raw("SELECT @msgret as msgret"));
				//$msgaux=\DB::connection('suitecrm')->select(\DB::raw("SELECT @msgaux as msgaux"));
				//\Log::info("RecepcionPrePagadosRepo->CC_Premios_Pagados_OP_Proceso->Ok",array( $ok ));
				//\Log::info("RecepcionPrePagadosRepo->CC_Premios_Pagados_OP_Proceso->Resultado del Procesamiento",array( $msgaux ));
				\Log::info("RecepcionPrePagadosRepo->CC_Premios_Pagados_OP_Proceso->Resultado del Procesamiento",array( $ok ));
				return $ok;			

			}catch(\Exception $e){
				\Log::info("Procesamiento premios pagados: Problema al invocar CALL CC_Premios_Pagados_OP_Proceso.");
				\Log::info($e);
			}*/
			
		}
	
		
		public static function Procesar_pre_pagados_otrporv_out($idProceso,$opcion){
			\Log::info("RR - ENTRO AL METODO Procesar_pre_pagados_otrporv_out");
			try{
				
			$ok = '';
			$datos = '';
			$query = '';
			//$pdo=\DB::connection('suitecrm')->getPdo();
			// $datos="'".$id_ejecucion."','".$id_archivo."', '".$opc."','".$huella."',@registro,@msgRet";
			$datos =$idProceso.",'".$opcion."',@msgret,@msgaux";
			$query = 'CALL CC_Premios_Pagados_OP_Proceso('.$datos.')';
			//	\Log::info('query PrcExp_ObtenerRegistros',array($query));
			//	\DB::connection('suitecrm')->statement($query);
			//$okk = \DB::connection('suitecrm')->select(\DB::raw($query));
			$okk= \DB::connection('suitecrm')->select(\DB::raw($query));
			//$result = $okk->fetchall();
			\Log::info('RR - okk - Procesar_pre_pagados_otrporv_out',array($okk));
			$mensaje=$okk;
			//$ok= \DB::connection('suitecrm')->select('SELECT @msgaux as registro,@msgret as msgret');
			//\Log::info('MM ok Procesar_pre_pagados_otrporv_out',array($ok));
			\DB::disconnect('suitecrm');
			// \Log::info('***ACA fin ok PrcExp_ObtenerRegistros ',array($mensaje));
			return $mensaje;
			}catch(\Exception $e){
				\Log::info("RR - Procesar_pre_pagados_otrporv_out.");
				\Log::info("Error al validar envios de archivo premios pagados otras provincias.");
				\Log::info($e);
			}		
		}
		
		
		/*********************************************
		* 	ConsultaPaquetesPremOtrProv			 *
		**********************************************/

		public static function ConsultaPaquetesPremOtrProv($nombre_exportacion){
			$db=\DB::connection('suitecrm');
			\Log::info('RR - ConsultaPaquetesPremOtrProv - nombre_exportacion',array($nombre_exportacion));
			// cambiar la consulta una vez conocida la tabla que guardará la ultima secuencia
			$resultado = $db->select(\DB::raw('SELECT envio AS paquete, MAX(fec_fin) AS fecha, paq_nombre, paq_path AS descargar, paq_mail_destino 
												FROM premios_otras_provincias_ejecucion 
												WHERE  paq_nombre = "'.$nombre_exportacion.'" 
												AND estado = "Finalizado"
												AND deleted = 0 
												-- order by date_entered desc,fec_fin desc , envio desc
												GROUP BY envio
												ORDER BY fec_fin DESC 
												'));
												// fec_fin is not null and
			//$resultado = $db->select(\DB::raw('SELECT null AS sec_esp FROM rec_ccf0306'));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				return $resultado;
			}else{
				return null;
			}
		}
		
		/*
		public static function PrcExp_ObtenerRegistros($nombre_exportacion,$id_ejecucion, $id_archivo, $opc, $huella){
						
			$ok = '';
			$datos = '';
			$query = '';
			$pdo=\DB::connection('suitecrm')->getPdo();
			$datos="'".$id_ejecucion."','".$id_archivo."', '".$opc."','".$huella."',@registro,@msgRet";
			$query = 'CALL EXP_'.$nombre_exportacion.'_GET_REGISTROS('.$datos.')';
					\Log::info('query PrcExp_ObtenerRegistros',array($query));
			\DB::connection('suitecrm')->statement($query);
			$okk = \DB::connection('suitecrm')->select(\DB::raw($query));
			//$result = $okk->fetchall();
					\Log::info('okk - PrcExp_ObtenerRegistros',array($okk));
			$mensaje=$okk;
			$ok= \DB::connection('suitecrm')->select('SELECT @registro as registro,@msgRet as msgret');
			//\Log::info('ok',array($ok));

			\DB::disconnect('suitecrm');
			// \Log::info('***ACA fin ok PrcExp_ObtenerRegistros ',array($mensaje));
			return $mensaje;
		}	
		*/
		
		public static function InsertPrcExpNuevo($nombre_proceso,$id_ejec_proc,$id_auditoria,$id_exp_tipo,$paq_path,$mail_destino_paq,$envio){
			
			try{
			$db=\DB::connection('suitecrm');
				$query="INSERT INTO premios_otras_provincias_ejecucion(id, NAME, date_entered, date_modified,deleted, exp_exportacion_tipo_id_c,sor_aud_consolidacion_id_c, envio, estado,fec_ini,hor_ini,fec_fin,hor_fin,paq_nombre,paq_path,paq_mail_destino)";
				$query.='VALUES ("'.$id_ejec_proc.'","'.$nombre_proceso.'", NOW(),NOW(), 0, "'.$id_exp_tipo.'","'.$id_auditoria.'","'.$envio.'","Finalizado",CURDATE(), DATE_FORMAT(NOW(), "%T"), CURDATE(), DATE_FORMAT(NOW(), "%T"),"'.$nombre_proceso.'","'.$paq_path.'", "'.$mail_destino_paq.'");';
				
				$resultadoINSERT=$db->getpdo()->exec($query);	
			\DB::disconnect('suitecrm');
			if(count($resultadoINSERT)>0){
				return true;
			}else{
				return null;
			}
		}catch(\Exception $e){
				\Log::info("Error realizando insert Nuevo en tabla premios_otras_provincias_ejecucion");
				\Log::info($e);
				return false;
			}
		}
		
		/*********************************************
		* 	GeneraIdProc						 *
		**********************************************/
		
		public static function GeneraIdProc(){
			$db=\DB::connection('suitecrm');
			// cambiar la consulta una vez conocida la tabla que guardará la ultima secuencia
			$resultado = $db->select(\DB::raw('SELECT 	uuid() as id_proceso;'));
			//$resultado = $db->select(\DB::raw('SELECT null AS sec_esp FROM rec_ccf0306'));
			\DB::disconnect('suitecrm');
			if(count($resultado)>0){
				return $resultado;
			}else{
				return null;
			}
		}
		
	}//fin clase


?>