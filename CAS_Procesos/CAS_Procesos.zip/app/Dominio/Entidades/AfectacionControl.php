<?php
namespace Dominio\Entidades;
	class AfectacionControl{
		public $id;
		public $tipo_archivo;
		public $version;
		public $nombre_archivo;
		public $provincia;
		public $tipo_liquidacion;
		public $secuencia_liquidacion;
		public $nro_liquidacion;
		public $fecha_liquidacion;
		public $hora_liquidacion;
		public $cantidad_registros;
		public $suma_importe;
		public $md5;

	}

?>