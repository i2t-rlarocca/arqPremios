<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\LiquidacionesRepo;

	class Liquidaciones{
		
		/***************************************************************
		* 				secuencia esperada					  		    *
		****************************************************************/
		
		public function secuenciaEsperada(){
				return LiquidacionesRepo::secuenciaEsperada();
		}
		
		/***************************************************************
		* 				validar secuencia					  		    *
		****************************************************************/
		
		public function validarSecuencia($idProceso,$nroSecuencia,$usuario){
				return LiquidacionesRepo::validarSecuencia($idProceso,$nroSecuencia,$usuario);
		}
		
		/***************************************************************
		* 				validar vuelcos					  		    *
		****************************************************************/
		
		public function validarVuelcos($idProceso,$nroSecuencia,$usuario){
				return LiquidacionesRepo::validarVuelcos($idProceso,$nroSecuencia,$usuario);
		}
		
		
		/***************************************************************
		* 				validar comprobantes					  		    *
		****************************************************************/
		
		public function validarComprobantes($idProceso,$nroSecuencia,$usuario){
				return LiquidacionesRepo::validarComprobantes($idProceso,$nroSecuencia,$usuario);
		}
		
		
		/***************************************************************
		* 				validar conceptos					  		    *
		****************************************************************/
		
		public function validarConceptos($idProceso,$nroSecuencia,$usuario){
				return LiquidacionesRepo::validarConceptos($idProceso,$nroSecuencia,$usuario);
		}
		
		/***************************************************************
		* 				validar Juegos						  		    *
		****************************************************************/
		
		public function validarJuegos($idProceso,$nroSecuencia,$usuario){
				return LiquidacionesRepo::validarJuegos($idProceso,$nroSecuencia,$usuario);
		}
		
		/***************************************************************
		* 				validar agencia						  		    *
		****************************************************************/
		
		public function validarAgencias($idProceso,$nroSecuencia,$usuario){
				return LiquidacionesRepo::validarAgencias($idProceso,$nroSecuencia,$usuario);
		}
		
		/***************************************************************
		* 				validar afectaciones				  		    *
		****************************************************************/
		
		public function validarAfectaciones($idProceso,$nroSecuencia,$usuario){
				return LiquidacionesRepo::validarAfectaciones($idProceso,$nroSecuencia,$usuario);
		}
		
		/***************************************************************
		* 				validar vuelco definitivo			  		    *
		****************************************************************/
		
		public function validarVuelcoDatosFinal($idProceso,$nroSecuencia,$usuario){
				return LiquidacionesRepo::validarVuelcoDatosFinal($idProceso,$nroSecuencia,$usuario);
		}
		
		/***************************************************************
		* 				carga tabla codigo juegos REC_BCF0014	  		    *
		****************************************************************/
		
		public function cargarCodigoJuegos($archivo){
				return LiquidacionesRepo::cargarCodigoJuegos($archivo);
		}
		
		/***************************************************************
		* 				carga tabla REC_CCF0001 comprobantes	  		    *
		****************************************************************/
		
		public function cargarComprobantes($archivo){
				return LiquidacionesRepo::cargarComprobantes($archivo);
		}
		
		/***************************************************************
		* 				carga tabla CCF0002 conceptos	  			    *
		****************************************************************/
		
		public function cargarConceptos($archivo){
				return LiquidacionesRepo::cargarConceptos($archivo);
		}
		
		/***************************************************************
		* 				carga tabla CCF0003 saldos por juegos  		    *
		****************************************************************/
		
		public function cargarSaldosJuegos($archivo){
				return LiquidacionesRepo::cargarSaldosJuegos($archivo);
		}
		
		/***************************************************************
		* 				carga tabla CCF0004 afectaciones  			    *
		****************************************************************/
		
		public function cargarAfectaciones($archivo){
				return LiquidacionesRepo::cargarAfectaciones($archivo);
		}
		
		/***************************************************************
		* 				carga tabla CCF0015 parametros  			    *
		****************************************************************/
		
		public function cargarParametros($archivo){
				return LiquidacionesRepo::cargarParametros($archivo);
		}
		
		/***************************************************************
		* 				carga tabla CCF0016 Multijuego  			    *
		****************************************************************/
		
		public function cargarMultijuegos($archivo){
				return LiquidacionesRepo::cargarMultijuegos($archivo);
		}
		
		/***************************************************************
		* 				carga tabla CCF0017 Saldos por agentes  	    *
		****************************************************************/
		
		public function cargarSaldosAgente($archivo){
				return LiquidacionesRepo::cargarSaldosAgente($archivo);
		}
		
		/***************************************************************
		* 				carga tabla CCF0079 Tipos de Garantias 		    *
		****************************************************************/
		
		public function cargarTiposGarantias($archivo){
				return LiquidacionesRepo::cargarTiposGarantias($archivo);
		}
		
		/***************************************************************
		* 				carga tabla CCF0301 Movimientos de comprobantes *
		****************************************************************/
		
		public function cargarMovimientosComprobantes($archivo){
				return LiquidacionesRepo::cargarMovimientosComprobantes($archivo);
		}
		
		
		/***************************************************************
		* 				carga tabla CCF0302 Concepto de comprobantes *
		****************************************************************/
		
		public function cargarConceptosComprobantes($archivo){
				return LiquidacionesRepo::cargarConceptosComprobantes($archivo);
		}
		
		/***************************************************************
		* 				carga tabla CCF0304 Aplicaciones				 *
		****************************************************************/
		
		public function cargarAplicaciones($archivo){
				return LiquidacionesRepo::cargarAplicaciones($archivo);
		}
		
		
		/***************************************************************
		* 				carga tabla CCF0305 Premios					 *
		****************************************************************/
		
		public function cargarPremios($archivo){
				return LiquidacionesRepo::cargarPremios($archivo);
		}
		
		/***************************************************************
		* 				carga tabla CCF0306 Numero de Secuencia			 *
		****************************************************************/
		
		public function cargarNumeroSecuencia($archivo){
				return LiquidacionesRepo::cargarNumeroSecuencia($archivo);
		}
		
		/***************************************************************
		* 				carga tabla CCF0307 Creditos efectivizados		 *
		****************************************************************/
		
		public function cargarCreditosEfectivizados($archivo){
				return LiquidacionesRepo::cargarCreditosEfectivizados($archivo);
		}
		
		/***************************************************************
		* 			carga tabla CCF0308 Premios pagados para la UIF		 *
		****************************************************************/
		
		public function cargarPremiosPagadosUIF($archivo){
				return LiquidacionesRepo::cargarPremiosPagadosUIF($archivo);
		}
		
		
		/***************************************************************
		* Devuelve 1 si puede seguir procesando en la transacción      *
		* 0 en caso de que no pueda seguir por falta de procesamiento  *
		* de el sorteo previo.                                         *
		****************************************************************/
		/*
		public function puedeProcesar($nro_sorteo, $idJuego){
				return CuentaCorrienteRepo::puedeProcesar($nro_sorteo, $idJuego);
		}
		*/
		/**********************************************
		* Devuelve una lista de los tipos de archivos *
		* esperados por cada juego.                   *
		***********************************************/
		/*
		public function especif_arch_liq(){
			return CuentaCorrienteRepo::especif_arch_liq();
		}
		*/
		/**********************************************
		* Devuelve una lista de los tipos de archivos *
		* esperados por cada juego.                   *
		***********************************************/
		/*
		public function especif_arch_x_juego(){
			return CuentaCorrienteRepo::especif_arch_x_juego();
		}
		*/
		
		/*****************************************************
		* Devuelve la lista de los juegos de días anteriores *
		* y del día. De los anteriores sólo los que no se han*
		* procesado. Del día todos.                          *
		******************************************************/
		/*
		public function sorteos_panel_alertas(){
			return CuentaCorrienteRepo::sorteos_panel_alertas();
		}
		*/
		/********************************************************
		* Función que se encarga de controlar si el nombre del  *
		* archivo es del sorteo y juego pedidos                 *
		*********************************************************/
		/*
		public function controlSorteo($sorteo, $idJuego, $tipoArchivo){
			return CuentaCorrienteRepo::controlSorteo($sorteo, $idJuego, $tipoArchivo);
		}
		*/
		/****************************************************
		* Llamada al stored para insertar en la pgmsorteo.  *        
		*****************************************************/
		/*
		public function insertaPGM($juego, $fechaSorteo){
			return CuentaCorrienteRepo::insertaPGM($juego, $fechaSorteo);
		}
		*/	
		
		/**************************************
		* Llamada al stored para consolidar.  *        
		***************************************/
		/*
		public function consolidar($juego, $sorteo, $fechaSorteo, $idProceso, $usuario){
			return CuentaCorrienteRepo::consolidar($juego, $sorteo, $fechaSorteo,$idProceso, $usuario);
		}
		*/
		/***********************************
		* Llamada al stored para publicar. *
		************************************/
		/*
		public function publicar($juego, $sorteo){
			return CuentaCorrienteRepo::publicar($juego, $sorteo);
		}
		*/
		/******************************************************************
		* Obtener los datos de pgmsorteo para un sorteo/juego determinado *
		*******************************************************************/
		/*
		public function datosPGMSorteo($sorteo, $idjuego){
			return CuentaCorrienteRepo::datosPGMSorteo($sorteo, $idjuego);
		}
		*/
		/*********************************************************************
		* actualizar el estado de pgmsorteo para un sorteo/juego determinado *
		**********************************************************************/
		/*
		public function actualizaEstado($sorteo,$idJuego,$idEstado){
			return CuentaCorrienteRepo::actualizaEstado($sorteo,$idJuego,$idEstado);
		}
		*/
		/************************************************
		* Insertar un registro en la tabla de auditoría *
		*************************************************/
		/*
		public function insertaAuditoria($idProceso,$idJuego, $sorteo, $evento, $operador, $idEstadoPrev, $idEstadoPost, $detalle){
			CuentaCorrienteRepo::insertaAuditoria($idProceso,$idJuego, $sorteo, $evento, $operador, $idEstadoPrev, $idEstadoPost, $detalle);
		}
		*/
		/******************************************
		* Retorna el id de proceso para auditoria *
		*******************************************/
		/*
		public function getNumeroProcesoAuditoriaCtaCte($juego, $sorteo){
			return CuentaCorrienteRepo::getNumeroProcesoAuditoriaCtaCte($juego, $sorteo);
		}
		*/
		/****************************************************
		* Función para ver si el juego requiere car/res/sue *
		*****************************************************/
		/*
		public function requiereCarResSue($idJuego){
			return CuentaCorrienteRepo::requiereCarResSue($idJuego);
		}
		*/
		/************************************************************
		* Función para obtener todos los servidores ftp disponibles *
		* Los devuelve en un arreglo.                               *
		*************************************************************/
		/*
		public function servidoresFTP(){
			return CuentaCorrienteRepo::servidoresFTP();
		}
		*/
		/****************************************
		* Función para obtener el productos ftp *
		* Los devuelve en un arreglo.           *
		*****************************************/
		/*
		public function productoFTP($id_juego){
			return CuentaCorrienteRepo::productoFTP($id_juego);
		}
		*/
	}


?>