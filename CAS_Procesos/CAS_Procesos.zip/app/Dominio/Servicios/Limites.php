<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\LimitesRepo;

	class Limites{
	
		public function cargarLimitesControl($archivo, $archivoComisiones){
			return $ok = LimitesRepo::cargarLimitesControl($archivo, $archivoComisiones);
		}

		public function cargarLimites($archivo, $fechaHora){
			return $ok = LimitesRepo::cargarLimites($archivo, $fechaHora);
		}
		
				
		
		/*********************************************************
		* Llamada al stored para procesar los límites de venta.  *        
		**********************************************************/
		public function sor_procesa_limites($idProceso, $usuario, $nro_sorteo){
			return LimitesRepo::sor_procesa_limites($idProceso, $usuario, $nro_sorteo);
		}

	}


?>