<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\AfectacionesRepo;

	class Afectaciones{
	
		public function cargarAfectacionControl($archivo, $archivoAfectaciones){
			return $ok = AfectacionesRepo::cargarAfectacionControl($archivo, $archivoAfectaciones);
		}

		public function cargarAfectacion($archivo){
			return $ok = AfectacionesRepo::cargarAfectacion($archivo);
		}

	}


?>