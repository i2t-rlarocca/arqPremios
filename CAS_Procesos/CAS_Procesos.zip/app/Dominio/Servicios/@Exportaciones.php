<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\ExportacionesRepo;

	class Exportaciones{
		
		/***************************************************************
		* consultaTipoExportacion                                        *
		****************************************************************/
	
		public function consultaTipoExportacion($tipo_proceso){
				return ExportacionesRepo::consultaTipoExportacion($tipo_proceso);
		}
		
		/**********************************************
		* EjecutaSP                   *
		***********************************************/
		public function EjecutaSP($sql){
			return ExportacionesRepo::EjecutaSP($sql);
		}
		
		
		/**********************************************
		* EjecutaSQL                  *
		***********************************************/
		public function EjecutaSQL($sql){
			return ExportacionesRepo::EjecutaSQL($sql);
		}
		
		
		/**********************************************
		* PrcExp_Crear *
		***********************************************/
	
		public function PrcExp_CrearSP($nombre_exportacion){
			return ExportacionesRepo::PrcExp_CrearSP($nombre_exportacion);
		}
		
		public function ConsultaPaquetesExportacion($nombre_exportacion){
			return ExportacionesRepo::ConsultaPaquetesExportacion($nombre_exportacion);
		}
		
		/**********************************************
		* PrcExp_Crear *
		***********************************************/
	
		public function PrcExp_CrearSQL($nombre_exportacion){
			return ExportacionesRepo::PrcExp_CrearSQL($nombre_exportacion);
		}
		
		/**********************************************
		* PrcExp_ObtenerLstArchivos                  *
		***********************************************/
		
		public function PrcExp_ObtenerLstArchivos($nombre_exportacion){
			return ExportacionesRepo::PrcExp_ObtenerLstArchivos($nombre_exportacion);
		}

		public function PrcExp_ObtenerLstArchivosUIF($nombre_exportacion,$envio){
			return ExportacionesRepo::PrcExp_ObtenerLstArchivosUIF($nombre_exportacion,$envio);
		}

		/*****************************************************
		* Devuelve la lista de los juegos de días anteriores *
		* y del día. De los anteriores sólo los que no se han*
		* procesado. Del día todos.                          *
		******************************************************/
		public function GeneraIdProc(){
			return ExportacionesRepo::GeneraIdProc();
		}
		
		/*****************************************************
		* Devuelve la lista de los juegos de días anteriores *
		* y del día. De los anteriores sólo los que no se han*
		* procesado. Del día todos.                          *
		******************************************************/
		public function TraeIdAuditoria(){
			return ExportacionesRepo::TraeIdAuditoria();
		}

		/********************************************************
		* Función que se encarga de insertar nuevo registro de  *
		* exportacion ejecucion                 *
		*********************************************************/
		public function InsertPrcExpNuevo($nombre_proceso,$id_auditoria,$id_exp_tipo,$paq_path,$mail_destino_paq,$envio){
			return ExportacionesRepo::InsertPrcExpNuevo($nombre_proceso,$id_auditoria,$id_exp_tipo,$paq_path,$mail_destino_paq,$envio);
		}

		/********************************************************
		* Función que se encarga de controlar si el nombre del  *
		* archivo es del sorteo y juego pedidos                 *
		*********************************************************/
		public function DeletePrcExpNuevo($id_ejecucion){
			return ExportacionesRepo::DeletePrcExpNuevo($id_ejecucion);
		}
		
		/****************************************************
		* Llamada al stored para insertar en la pgmsorteo.  *        
		*****************************************************/
		public function PrcExp_ObtenerLstArchivos2($nombre_proceso,$id_ejecucion, $id_archivo){
			return ExportacionesRepo::PrcExp_ObtenerLstArchivos2($nombre_proceso,$id_ejecucion, $id_archivo);
		}
		
		/*********************************************************************
		* Llamada para actualizar  estado exp_exportacion_ejecucion  *        
		**********************************************************************/
		public function UpdatePrcExpEstado($nombre_proceso,$id_exp_tipo,$envio,$estado){
			return ExportacionesRepo::UpdatePrcExpEstado($nombre_proceso,$id_exp_tipo,$envio,$estado);
		}
		
		/*********************************************************************
		* Llamada para actualizar   estado fin exp_exportacion_ejecucion  *   
		**********************************************************************/
		public function UpdatePrcExpEstadoFin($nombre_proceso,$id_exp_tipo,$envio,$nombre_archivo,$estado){
			return ExportacionesRepo::UpdatePrcExpEstadoFin($nombre_proceso,$id_exp_tipo,$envio,$nombre_archivo,$estado);
		}
		
		/*********************************************************************
		* Llamada para actualizar pre_envios_uif  *        
		**********************************************************************/
		public function UpdatePreEnviosUIFOk($nombre_proceso,$envio){
			return ExportacionesRepo::UpdatePreEnviosUIFOk($nombre_proceso,$envio);
		}
		
		
		/*********************************************************************
		* Llamada para actualizar imp_ganancias_envio_afip  *        
		**********************************************************************/
		public function UpdatePreEnviosAFIPOk($nombre_proceso,$envio){
			return ExportacionesRepo::UpdatePreEnviosAFIPOk($nombre_proceso,$envio);
		}

		/*********************************************************************
		* Llamada para actualizar cas02_cc_manuales  *        
		**********************************************************************/
		public function UpdateManualesOk($nombre_proceso,$envio){
			return ExportacionesRepo::UpdateManualesOk($nombre_proceso,$envio);
		}

		/*********************************************************************
		* Llamada para actualizar sorl_pgmsorteo  *        
		**********************************************************************/
		public function UpdateReservaBilletesLoteria($nombre_proceso,$envio){
			return ExportacionesRepo::UpdateReservaBilletesLoteria($nombre_proceso,$envio);
		}
		
		/*********************************************************************
		* Llamada para actualizar exp_exportacion_tipo  *        
		**********************************************************************/
		public function UpdateExpExportacionTipoOk($nombre_proceso,$envio){
			return ExportacionesRepo::UpdateExpExportacionTipoOk($nombre_proceso,$envio);
		}
		
		/*********************************************************************
		* Llamada para actualizar exp_exportacion_tipo  *        
		**********************************************************************/
		public function	UpdateEstadoDisConLiq($nombre_exportacion,$id_exp_tipo,$envio,$id_ejecucion){
			return ExportacionesRepo::UpdateEstadoDisConLiq($nombre_exportacion,$id_exp_tipo,$envio,$id_ejecucion);
		}
		
		/**************************************
		* Llamada al stored para obtener registros.  *        
		***************************************/
		public function PrcExp_ObtenerRegistros($nombre_proceso,$id_ejecucion, $id_archivo, $opc, $huella){
			return ExportacionesRepo::PrcExp_ObtenerRegistros($nombre_proceso,$id_ejecucion, $id_archivo, $opc, $huella);
		}
		
		/**************************************
		* Llamada al stored para obtener registros de UIF (XML).  *        
		***************************************/
		public function PrcExp_ObtenerRegistrosUIF($nombre_proceso,$id_ejecucion, $id_archivo, $opc, $huella){
			return ExportacionesRepo::PrcExp_ObtenerRegistrosUIF($nombre_proceso,$id_ejecucion, $id_archivo, $opc, $huella);
		}
		
		/**************************************
		* Llamada al stored para consolidar.  *        
		***************************************/
		public function PrcExp_ObtenerRegistrosCtrl($nombre_proceso,$id_ejecucion, $id_archivo, $opc, $huella){
			return ExportacionesRepo::PrcExp_ObtenerRegistrosCtrl($nombre_proceso,$id_ejecucion, $id_archivo, $opc, $huella);
		}

		/***********************************
		* Llamada al stored para publicar. *
		************************************/
/*		public function publicar($juego, $sorteo){
			return CuentaCorrienteRepo::publicar($juego, $sorteo);
		}
*/		
		/******************************************************************
		* Obtener los datos de pgmsorteo para un sorteo/juego determinado *
		*******************************************************************/
/*		public function datosPGMSorteo($sorteo, $idjuego){
			return CuentaCorrienteRepo::datosPGMSorteo($sorteo, $idjuego);
		}
*/		
		/*********************************************************************
		* actualizar el estado de pgmsorteo para un sorteo/juego determinado *
		**********************************************************************/
/*		public function actualizaEstado($sorteo,$idJuego,$idEstado){
			return CuentaCorrienteRepo::actualizaEstado($sorteo,$idJuego,$idEstado);
		}
*/
		/************************************************
		* Insertar un registro en la tabla de auditoría *
		*************************************************/
/*		public function insertaAuditoria($idProceso,$idJuego, $sorteo, $evento, $operador, $idEstadoPrev, $idEstadoPost, $detalle){
			CuentaCorrienteRepo::insertaAuditoria($idProceso,$idJuego, $sorteo, $evento, $operador, $idEstadoPrev, $idEstadoPost, $detalle);
		}
*/
		/******************************************
		* Retorna el id de proceso para auditoria *
		*******************************************/
/*		public function getNumeroProcesoAuditoriaCtaCte($juego, $sorteo){
			return CuentaCorrienteRepo::getNumeroProcesoAuditoriaCtaCte($juego, $sorteo);
		}
*/
		/****************************************************
		* Función para ver si el juego requiere car/res/sue *
		*****************************************************/
/*		public function requiereCarResSue($idJuego){
			return CuentaCorrienteRepo::requiereCarResSue($idJuego);
		}
*/		
		/************************************************************
		* Función para obtener todos los servidores ftp disponibles *
		* Los devuelve en un arreglo.                               *
		*************************************************************/
/*		public function servidoresFTP(){
			return CuentaCorrienteRepo::servidoresFTP();
		}
*/		
		/****************************************
		* Función para obtener el productos ftp *
		* Los devuelve en un arreglo.           *
		*****************************************/
/*		public function productoFTP($id_juego){
			return CuentaCorrienteRepo::productoFTP($id_juego);
		}
*/		
	}


?>