<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\ComisionesRepo;

	class Comisiones{
	
		public function cargarComisionesControl($archivo, $archivoComisiones){
			return $ok = ComisionesRepo::cargarComisionesControl($archivo, $archivoComisiones);
		}

		public function cargarComision($archivo){
			return $ok = ComisionesRepo::cargarComision($archivo);
		}
		
		public function cargarManSelladoControl($archivo, $archivoManSellado){
			return $ok = ComisionesRepo::cargarManSelladoControl($archivo, $archivoManSellado);
		}

		public function cargarManSellado($archivo){
			return $ok = ComisionesRepo::cargarManSellado($archivo);
		}
		
		/***********************************************
		* Llamada al stored para retornar el período.  *        
		************************************************/
		public function valida_periodo(){
			return ComisionesRepo::valida_periodo();
		}
		
		/**********************************************
		* Llamada al stored para validar el período.  *        
		***********************************************/
	/*	public function periodoValido($periodo_completo){
			return ComisionesRepo::periodoValido($periodo_completo);
		}*/
		
		
		/***************************************************************
		* Llamada al stored para procesar las comisiones del período.  *        
		****************************************************************/
		public function sor_procesa_comisiones_adic($periodo, $idProceso, $usuario){
			return ComisionesRepo::sor_procesa_comisiones_adic($periodo, $idProceso, $usuario);
		}

	}


?>