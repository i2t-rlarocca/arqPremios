<?php

	/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	namespace Dominio\Servicios;
	use Datos\Repositorio\UsuarioRepo;

	class Usuarios{
				
		
		public static function controlSesion($nombreUsuario){
			return UsuarioRepo::controlSesion($nombreUsuario);
		}

		
		/**
		* Busca el usuario por el nombre de usuario
		*/
		public static function buscar($nombreUsuario){
			$usuario=UsuarioRepo::buscar($nombreUsuario);
			return $usuario;
		}
		
		
	}
?>