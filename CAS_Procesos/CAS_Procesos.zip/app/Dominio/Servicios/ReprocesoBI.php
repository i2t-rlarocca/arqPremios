<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\ReprocesoBIRepo;

	class ReprocesoBI{
		
		/************************************************
		* Devuelve una lista de los meses que se pueden *
		* reprocesar. Regla: últimos 6 meses cerrados   *
		************************************************/
		public function getMesesReprocesoBI(){
			return ReprocesoBIRepo::getMesesReprocesoBI();
		}
		
		// lo que sigue es basurilla. solo para ejemplo....
		
		/***************************************************************
		* Devuelve 1 si puede seguir procesando en la transacción      *
		* 0 en caso de que no pueda seguir por falta de procesamiento  *
		* de el sorteo previo.                                         *
		****************************************************************/
		public function procesaPeriodo($periodo,$estado,$a_partir_fallo,$completo,$incl_cuad_afec,$dif_ejec){
				return ReprocesoBIRepo::procesaPeriodo($periodo,$estado,$a_partir_fallo,$completo,$incl_cuad_afec,$dif_ejec);
		}
		
		/**********************************************
		* Devuelve una lista de los tipos de archivos *
		* esperados por cada juego.                   *
		***********************************************/
		public function valida_periodo(){
			return ReprocesoBIRepo::valida_periodo();
		}

	
	}


?>