<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\ResultadosRepo;

	class Resultados{
	
		public function cargarResultadosControl($archivo, $archivoResultados){
			return ResultadosRepo::cargarResultadosControl($archivo, $archivoResultados);
		}

		public function cargarResultados($archivo){
			return ResultadosRepo::cargarResultados($archivo);
		}

		public function cargarSueldosControl($archivo, $archivoSueldos){
			return ResultadosRepo::cargarSueldosControl($archivo, $archivoSueldos);
		}

		public function cargarSueldos($archivo){
			return ResultadosRepo::cargarSueldos($archivo);
		}
		
		public function cargarExtractosControl($archivo, $archivoSueldos){
			return ResultadosRepo::cargarExtractosControl($archivo, $archivoSueldos);
		}

		public function cargarExtractos($archivo,$idpgmsorteo){
			return ResultadosRepo::cargarExtractos($archivo,$idpgmsorteo);
		}

		/***********************************************************
		* Llamada al stored para validar los resultados(premios).  *        
		************************************************************/
		public function validaResultados($idProceso,$juego, $sorteo, &$mensaje, $idEstado, $usuario){
			return ResultadosRepo::validaResultados($idProceso,$juego, $sorteo, $mensaje, $idEstado, $usuario);
		}

		/***********************************************************
		* Llamada al stored para validar los resultados(sueldos).  *        
		************************************************************/
		public function validaSueldos($nro,$juego, $sorteo, &$mensaje, $usuario, $idEstado){
			return ResultadosRepo::validaSueldos($nro,$juego, $sorteo, $mensaje, $usuario, $idEstado);
		}

	}


?>