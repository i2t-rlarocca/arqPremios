<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\VentasTotalesRepo;

	class VentasTotales{
		
		
		public function cargarVtDat($archivo,$juego,$sorteo,$usuario){
			return VentasTotalesRepo::cargarVtDat($archivo,$juego, $sorteo,$usuario);	
		}
	
		public function cargarVtModalidades($archivo,$juego, $sorteo,$usuario,$tipoTrf){
			return VentasTotalesRepo::cargarVtModalidades($archivo,$juego, $sorteo,$usuario,$tipoTrf);
		}

		public function cargarVtRes($archivo,$usuario,$juego){
			return VentasTotalesRepo::cargarVtRes($archivo,$usuario,$juego);
		}

		public function cargarVtSos($archivo,$juego){
			return VentasTotalesRepo::cargarVtSos($archivo,$juego);	
		}
	        /*Para cuando vienen en un zip*/
		public function cargarPremiosRetencionControlContenedor($archivo, $archivosPremios){
			return VentasTotalesRepo::cargarPremiosRetencionControlContenedor($archivo, $archivosPremios);
		}
		public function cargarPremiosRetencion($archivos){
			return VentasTotalesRepo::cargarPremiosRetencion($archivos);	
		}

		public function valida_ctasctes($juego, $sorteo, $idProceso, $usuario){
			return VentasTotalesRepo::valida_ctasctes($juego, $sorteo, $idProceso, $usuario);
		}
		
	}

?>