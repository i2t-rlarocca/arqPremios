<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\PremiosBingosRepo;

	class PremiosBingos{
		
		public function cargarPremiosControl($archivo, $archivoPremios){
			return PremiosBingosRepo::cargarPremiosControl($archivo, $archivoPremios);
		}

		public function cargarPremioTT($archivo,$idjuego, $idProceso,$usuario,$fechaSorteo){
			return PremiosBingosRepo::cargarPremioTT($archivo,$idjuego, $idProceso,$usuario,$fechaSorteo);	
		}

		public function cargarPremioTK($archivo,$idjuego, $idProceso,$usuario,$fechaSorteo){
			return PremiosBingosRepo::cargarPremioTK($archivo,$idjuego, $idProceso,$usuario,$fechaSorteo);	
		}

		public function cargarPremioTM($archivo,$idjuego, $idProceso,$usuario,$fechaSorteo){
			return PremiosBingosRepo::cargarPremioTM($archivo,$idjuego, $idProceso,$usuario,$fechaSorteo);	
		}
		
		public function cargarPremiosRetencionControl($archivo, $archivosPremios, $sobreEscribir){
			return PremiosBingosRepo::cargarPremiosRetencionControl($archivo, $archivosPremios, $sobreEscribir);
		}

		public function cargarPremiosRetDet($archivo){
			return PremiosBingosRepo::cargarPremiosRetDet($archivo);	
		}
	        /*Para cuando vienen en un zip*/
		public function cargarPremiosRetencionControlContenedor($archivo, $archivosPremios){
			return PremiosBingosRepo::cargarPremiosRetencionControlContenedor($archivo, $archivosPremios);
		}		
		public function cargarPremiosRetencion($archivos){
			return PremiosBingosRepo::cargarPremiosRetencion($archivos);	
		}
		/*fin zip*/

                public function cargarPremiosCompletoControl($archivo, $archivoPremios, $archivoPremiosRet){
			return PremiosBingosRepo::cargarPremiosCompletoControl($archivo, $archivoPremios, $archivoPremiosRet);
		}
		
		public function cargarPremioCompleto($archivo){
			return PremiosBingosRepo::cargarPremioCompleto($archivo);	
		}
	
		public function cargarPremiosCompletoRetDet($archivo){
			return PremiosBingosRepo::cargarPremiosCompletoRetDet($archivo);	
		}

	}

?>