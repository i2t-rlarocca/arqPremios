<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\CuentaCorrienteRepo;

	class CuentasCorrientes{
		
		/***************************************************************
		* Devuelve 1 si puede seguir procesando en la transacción      *
		* 0 en caso de que no pueda seguir por falta de procesamiento  *
		* de el sorteo previo.                                         *
		****************************************************************/
		public function puedeProcesar($nro_sorteo, $idJuego){
				return CuentaCorrienteRepo::puedeProcesar($nro_sorteo, $idJuego);
		}
		
		/**********************************************
		* Devuelve una lista de los tipos de archivos *
		* esperados por cada juego.                   *
		***********************************************/
		public function especif_arch_x_juego(){
			return CuentaCorrienteRepo::especif_arch_x_juego();
		}

		/*****************************************************
		* Devuelve la lista de los juegos de días anteriores *
		* y del día. De los anteriores sólo los que no se han*
		* procesado. Del día todos.                          *
		******************************************************/
		public function sorteos_panel_alertas(){
			return CuentaCorrienteRepo::sorteos_panel_alertas();
		}
		
		/********************************************************
		* Función que se encarga de controlar si el nombre del  *
		* archivo es del sorteo y juego pedidos                 *
		*********************************************************/
		public function controlSorteo($sorteo, $idJuego, $tipoArchivo){
			return CuentaCorrienteRepo::controlSorteo($sorteo, $idJuego, $tipoArchivo);
		}
	
		/****************************************************
		* Llamada al stored para insertar en la pgmsorteo.  *        
		*****************************************************/
		public function insertaPGM($juego, $fechaSorteo){
			return CuentaCorrienteRepo::insertaPGM($juego, $fechaSorteo);
		}
			
		
		/**************************************
		* Llamada al stored para consolidar.  *        
		***************************************/
		public function consolidar($juego, $sorteo, $fechaSorteo, $idProceso, $usuario){
			return CuentaCorrienteRepo::consolidar($juego, $sorteo, $fechaSorteo,$idProceso, $usuario);
		}

		/***********************************
		* Llamada al stored para publicar. *
		************************************/
		public function publicar($juego, $sorteo){
			return CuentaCorrienteRepo::publicar($juego, $sorteo);
		}
		
		/******************************************************************
		* Obtener los datos de pgmsorteo para un sorteo/juego determinado *
		*******************************************************************/
		public function datosPGMSorteo($sorteo, $idjuego){
			return CuentaCorrienteRepo::datosPGMSorteo($sorteo, $idjuego);
		}
		
		/*********************************************************************
		* actualizar el estado de pgmsorteo para un sorteo/juego determinado *
		**********************************************************************/
		public function actualizaEstado($sorteo,$idJuego,$idEstado){
			return CuentaCorrienteRepo::actualizaEstado($sorteo,$idJuego,$idEstado);
		}

		/************************************************
		* Insertar un registro en la tabla de auditoría *
		*************************************************/
		public function insertaAuditoria($idProceso,$idJuego, $sorteo, $evento, $operador, $idEstadoPrev, $idEstadoPost, $detalle){
			CuentaCorrienteRepo::insertaAuditoria($idProceso,$idJuego, $sorteo, $evento, $operador, $idEstadoPrev, $idEstadoPost, $detalle);
		}

		/******************************************
		* Retorna el id de proceso para auditoria *
		*******************************************/
		public function getNumeroProcesoAuditoriaCtaCte($juego, $sorteo){
			return CuentaCorrienteRepo::getNumeroProcesoAuditoriaCtaCte($juego, $sorteo);
		}

		/****************************************************
		* Función para ver si el juego requiere car/res/sue *
		*****************************************************/
		public function requiereCarResSue($idJuego){
			return CuentaCorrienteRepo::requiereCarResSue($idJuego);
		}

		
	}


?>