<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\CaratulaRepo;

	class Caratulas{
	
		public function cargarCaratulaControl($archivo, $archivoCaratula){
			return CaratulaRepo::cargarCaratulaControl($archivo, $archivoCaratula);
		}

		public function cargarCaratula($archivo){
			$ok= CaratulaRepo::cargarCaratula($archivo);	
			return $ok;
		}
		
		/***********************************************
		* Llamada al stored para validar la carátula.  *        
		************************************************/
		public function validaCaratula($idProceso,$juego, $sorteo, &$mensaje, $usuario, $idEstado){
			return CaratulaRepo::validaCaratula($idProceso,$juego, $sorteo, $mensaje, $usuario, $idEstado);
		}
		
	}


?>