<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\PrescriptosRepo;

	class Prescriptos{

		/**********************************************
		* Devuelve una lista de los tipos de archivos *
		* esperados por cada juego.                   *
		***********************************************/
		public function especif_arch_pre(){
			return PrescriptosRepo::especif_arch_pre();
		}
		
		/***************************************************************
		* 				secuencia esperada					  		    *
		****************************************************************/
		public function secuenciaEsperada(){
				return PrescriptosRepo::secuenciaEsperada();
		}
		
		/***************************************************************
		* 				carga archivo de control			  		    *
		****************************************************************/
		public function cargarPrescriptosControl($archivo, $idProceso,$archivodatos){
			return PrescriptosRepo::cargarPrescriptosControl($archivo, $idProceso,$archivodatos);
		}
		
		/***************************************************************
		* 				carga archivo de prescripciones		  		    *
		****************************************************************/
		public function cargarPrescriptos($archivo,$idProceso){
			return PrescriptosRepo::cargarPrescriptos($archivo,$idProceso);
		}
		
		/*********************************************
		* 	validar vuelco en cada tabla			 *
		**********************************************/
		public function validarVuelcos($idProceso,$nroSecuencia,$usuario){
			return PrescriptosRepo::validarVuelcos($idProceso,$nroSecuencia,$usuario);
		}
		
		/***************************************************************
		* 				validar secuencia					  		    *
		****************************************************************/
		public function validarSecuencia($idProceso,$nroSecuencia,$usuario){
			return PrescriptosRepo::validarSecuencia($idProceso,$nroSecuencia,$usuario);
		}
		
		/*********************************************
		* 	validar SORTEOS					 *
		**********************************************/
		public function validarSorteos($idProceso,$nroSecuencia,$usuario){
			return PrescriptosRepo::validarSorteos($idProceso,$nroSecuencia,$usuario);
		}

		/*****************************************************************************************
		* 	validar fecha liquidacion igual o superior a fecha de prescripcion del sorteo		 *
		*****************************************************************************************/
		public function validarFechaLiquidacion($idProceso,$nroSecuencia,$usuario){
			return PrescriptosRepo::validarFechaLiquidacion($idProceso,$nroSecuencia,$usuario);
		}
		
		/*********************************************
		* 	validar agencia							 *
		**********************************************/
		public function validarAgencias($idProceso,$nroSecuencia,$usuario){
			return PrescriptosRepo::validarAgencias($idProceso,$nroSecuencia,$usuario);
		}
		
		/*********************************************
		* 	validar conceptos						 *
		**********************************************/
		public function validarConceptos($idProceso,$nroSecuencia,$usuario){
			return PrescriptosRepo::validarConceptos($idProceso,$nroSecuencia,$usuario);
		}
		
		
		/*********************************************
		* 	validar vuelco definitivo				 *
		**********************************************/
		public function ProcesoPrescriptos($idProceso,$nroSecuencia,$usuario){
			return PrescriptosRepo::ProcesoPrescriptos($idProceso,$nroSecuencia,$usuario);
		}
		
		/*********************************************
		* 	validar prescriptos resumen				 *
		**********************************************/
		public function PrescriptosResumen($idProceso,$nroSecuencia,$usuario){
			return PrescriptosRepo::PrescriptosResumen($idProceso,$nroSecuencia,$usuario);
		}
		/*************************************************
		* 	Generar Minutas Prescripción Canal Tesoreria *
		*************************************************/
		public function PrescriptosMinutasTesoreria($idProceso,$nroSecuencia,$usuario){
			return PrescriptosRepo::PrescriptosMinutasTesoreria($idProceso,$nroSecuencia,$usuario);
		}		
		
	}


?>