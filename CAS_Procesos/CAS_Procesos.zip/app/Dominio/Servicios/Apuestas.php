<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\ApuestasRepo;

	class Apuestas{
	
		public function cargarApuestasControl($archivo, $archivoApuestas,$idJuego){ 
			\Log::info('SERV-cargarApuestasControl',array($idJuego));
			return $ok = ApuestasRepo::cargarApuestasControl($archivo, $archivoApuestas,$idJuego);
		}

		public function cargarApuestas($archivo, $idjuego, $formatoProcesamiento){
			if(strcasecmp ( $formatoProcesamiento , "Q" )==0)//quinielas - la express
				$okApu= ApuestasRepo::cargarApuestasQuinielas($archivo,$idjuego);
			if(strcasecmp ( $formatoProcesamiento , "E" )==0){//quiniela express
				$okApu=ApuestasRepo::cargarApuestasQExpress($archivo,$idjuego);
			}
			if(strcasecmp ( $formatoProcesamiento , "P" )==0){//poceados
				$okApu=ApuestasRepo::cargarApuestasPoceados($archivo,$idjuego);
			}
			//$okCancelApu = ApuestasRepo::quitarCancelados();
			return $okApu;
		}

	}


?>