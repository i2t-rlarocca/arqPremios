<?php

	/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	namespace Dominio\Servicios;
	use Datos\Repositorio\UsuarioRepo;

	class Usuarios{
		
		/*public static function controlSesion($nombreUsuario){
			return UsuarioRepo::controlSesion($nombreUsuario);
		}*/
		public static function controlSesion($id_portal, $letra_portal){
			return UsuarioRepo::controlSesion($id_portal, $letra_portal);
		}

		/**
		* Busca el usuario por el nombre de usuario
		*/
		public static function buscar($nombreUsuario){
			$usuario=UsuarioRepo::buscar($nombreUsuario);
			return $usuario;
		}
		
		/**
		* obtiene los niveles de accesos
		*/
		public static function ControlAcceso($sistema,$usuario){
			$accesos=UsuarioRepo::ControlAcceso($sistema,$usuario);
			return $accesos;
		}

		/**
		* Recupera datos extendidos del usuario segun su tipo de usuario (provincia, loteria, etc)
		*/		
		public function GetDatosTipoUsuario($usuario){
			return UsuarioRepo::GetDatosTipoUsuario($usuario);
		}
	
	}
?>