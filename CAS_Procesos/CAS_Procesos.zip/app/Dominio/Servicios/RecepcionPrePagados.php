<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\RecepcionPrePagadosRepo;

	class RecepcionPrePagados{

		/**********************************************
		* Devuelve una lista de los tipos de archivos *
		* esperados por cada juego.                   *
		***********************************************/
		public function especif_arch_pre(){
			return RecepcionPrePagadosRepo::especif_arch_pre();
		}
		
		/***************************************************************
		* 				secuencia esperada					  		    *
		****************************************************************/
		
		public function secuenciaEsperada(){
				return RecepcionPrePagadosRepo::secuenciaEsperada();
		}

		public function validarSecuencia($idProceso,$nroSecuencia,$usuario,$loteria,$tipo_validacion){ // RR
			return $ok = RecepcionPrePagadosRepo::validarSecuencia($idProceso,$nroSecuencia,$usuario,$loteria,$tipo_validacion);
		}

		public function actualizaSecuencia($idProceso,$opcion){ // RR
			return $ok = RecepcionPrePagadosRepo::actualizaSecuencia($idProceso,$opcion);
		}

		public function cargarPrePagados($archivo){
			return $ok = RecepcionPrePagadosRepo::cargarPrePagados($archivo); 
		}

	
		public function validarEnvios($idProceso,$id_archivo,$usuario,$tipo_validacion){
			return $ok = RecepcionPrePagadosRepo::validarEnvios($idProceso,$id_archivo,$usuario,$tipo_validacion); 
		}
		
		public function validarEnviosOtrProv($idProceso,$id_archivo,$usuario,$loteria,$tipo_validacion){
			return $ok = RecepcionPrePagadosRepo::validarEnviosOtrProv($idProceso,$id_archivo,$usuario,$loteria,$tipo_validacion); 
		}

		public function Procesar_pre_pagados($idProceso){
			return $ok = RecepcionPrePagadosRepo::Procesar_pre_pagados($idProceso);
		}
		
		public function Procesar_pre_pagados_otrprov($idProceso,$opcion){
			return $ok = RecepcionPrePagadosRepo::Procesar_pre_pagados_otrprov($idProceso,$opcion); 
		}
		
		public function Procesar_pre_pagados_otrprov_out($idProceso,$opcion){
			return $ok = RecepcionPrePagadosRepo::Procesar_pre_pagados_otrprov_out($idProceso,$opcion); 
		}
		
		/**********************************************
		* Devuelve una lista de los tipos de archivos *
		* esperados por cada juego.                   *
		***********************************************/
		
		public function especif_arch_premiospagados(){
			return RecepcionPrePagadosRepo::especif_arch_premiospagados();
		}
		
		/**********************************************
		* Devuelve una lista de los tipos de archivos *
		* esperados por cada juego.                   *
		***********************************************/
		public function especif_arch_premiospagados_otrprov(){
			return RecepcionPrePagadosRepo::especif_arch_premiospagados_otrprov();
		}
		
		public function especif_arch_x_juego(){
			return RecepcionPrePagadosRepo::especif_arch_x_juego();			
		}
		
		public function especif_arch_x_juego_otrprov(){
			return RecepcionPrePagadosRepo::especif_arch_x_juego_otrprov();			
		}
		
		public function getNumeroProcesoAuditoria(){
			return RecepcionPrePagadosRepo::getNumeroProcesoAuditoria();
		}
	
		public function cargarPremiosPagadosControl($idProceso,$archivo,$archivo2){
			return RecepcionPrePagadosRepo::cargarPremiosPagadosControl($idProceso,$archivo,$archivo2);
		}
		
		public function cargarPremiosPagados($idProceso,$archivo){
			return RecepcionPrePagadosRepo::cargarPremiosPagados($idProceso,$archivo);
		}
		
		public function cargarPremiosPagadosOtrasProvinciasControl($idProceso,$archivo,$archivo2){
			return RecepcionPrePagadosRepo::cargarPremiosPagadosOtrasProvinciasControl($idProceso,$archivo,$archivo2);
		}
		
		public function cargarPremiosPagadosOtrasProvincias($idProceso,$archivo,$archivo2){
			return RecepcionPrePagadosRepo::cargarPremiosPagadosOtrasProvincias($idProceso,$archivo,$archivo2);
		}
		
		/**************************************
		* Llamada al stored para obtener registros.  *        
		***************************************/
		public function PrcExp_ObtenerRegistros($nombre_proceso,$id_ejecucion, $id_archivo, $opc, $huella){
			return RecepcionPrePagadosRepo::PrcExp_ObtenerRegistros($nombre_proceso,$id_ejecucion, $id_archivo, $opc, $huella);
		}
		
		public function ConsultaPaquetesPremOtrProv($nombre_exportacion){
			return RecepcionPrePagadosRepo::ConsultaPaquetesPremOtrProv($nombre_exportacion);
		}
		
		public function InsertPrcExpNuevo($nombre_proceso,$id_ejec_proc,$id_auditoria,$id_exp_tipo,$paq_path,$mail_destino_paq,$envio){
			return RecepcionPrePagadosRepo::InsertPrcExpNuevo($nombre_proceso,$id_ejec_proc,$id_auditoria,$id_exp_tipo,$paq_path,$mail_destino_paq,$envio);
		}
		
		public function GeneraIdProc(){
			return RecepcionPrePagadosRepo::GeneraIdProc();
		}
	}
?>