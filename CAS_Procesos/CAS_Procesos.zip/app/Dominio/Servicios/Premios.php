<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\PremiosRepo;

	class Premios{
	
		public function cargarPremiosControl($archivo, $archivoPremios){
			return PremiosRepo::cargarPremiosControl($archivo, $archivoPremios);
		}

		public function cargarPremio($archivo){
			return PremiosRepo::cargarPremio($archivo);	
		}

		public function cargarPremiosRetencionControl($archivo, $archivosPremios, $sobreEscribir){
			return PremiosRepo::cargarPremiosRetencionControl($archivo, $archivosPremios, $sobreEscribir);
		}

		public function cargarPremiosRetDet($archivo){
			return PremiosRepo::cargarPremiosRetDet($archivo);	
		}
	        /*Para cuando vienen en un zip*/
		public function cargarPremiosRetencionControlContenedor($archivo, $archivosPremios){
			return PremiosRepo::cargarPremiosRetencionControlContenedor($archivo, $archivosPremios);
		}
		public function cargarPremiosRetencion($archivos){
			return PremiosRepo::cargarPremiosRetencion($archivos);	
		}
		/*fin zip*/

                public function cargarPremiosCompletoControl($archivo, $archivoPremios, $archivoPremiosRet){
			return PremiosRepo::cargarPremiosCompletoControl($archivo, $archivoPremios, $archivoPremiosRet);
		}
		

		public function cargarPremioCompleto($archivo, $idJuego){
			return PremiosRepo::cargarPremioCompleto($archivo, $idJuego);	
		}
	
		public function cargarPremiosCompletoRetDet($archivo){
			return PremiosRepo::cargarPremiosCompletoRetDet($archivo);	
		}

	}

?>