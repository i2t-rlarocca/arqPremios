<?php
/**
	* Clase de servicio que se comunica con el repositorio
	* para obtener los datos del modelo.
	*/
	
	namespace Dominio\Servicios;
	use Datos\Repositorio\ApuestasRepo;

	class Apuestas{
	
		public function cargarApuestasControl($archivo, $archivoApuestas){
			return $ok = ApuestasRepo::cargarApuestasControl($archivo, $archivoApuestas);
		}

		public function cargarApuestas($archivo, $idjuego, $formatoProcesamiento){
			if(strcasecmp ( $formatoProcesamiento , "Q" )==0)//quinielas - la express
				$okApu= ApuestasRepo::cargarApuestasQuinielas($archivo);
			if(strcasecmp ( $formatoProcesamiento , "E" )==0){//quiniela express
				$okApu=ApuestasRepo::cargarApuestasQExpress($archivo);
			}
			if(strcasecmp ( $formatoProcesamiento , "P" )==0){//poceados
				$okApu=ApuestasRepo::cargarApuestasPoceados($archivo);
			}
			//$okCancelApu = ApuestasRepo::quitarCancelados();
			return $okApu;
		}

	}


?>