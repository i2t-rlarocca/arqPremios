<!doctype html>
<html>
    <head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<!--meta http-equiv="cache-control" content="max-age=0" />
		<meta http-equiv="cache-control" content="no-cache" />
		<meta http-equiv="cache-control" content="no-store" />
		<meta http-equiv="cache-control" content="must-revalidate" />
		<meta http-equiv="expires" content="0" />
		<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
		<meta http-equiv="pragma" content="no-cache" /-->
			<title>
				@section('titulo')
					CAS CUENTA CORRIENTE
				@show
			</title>
			<!-- javasript  -->
					{{HTML::script("js/jquery-1.11.1.min.js", array("type" => "text/javascript"))}} {{HTML::script("js/jquery.validate.js", array("type" => "text/javascript"))}}
					{{HTML::script("js/jquery.validate.js", array("type" => "text/javascript"))}}
					{{--HTML::script("js/additional-methods.js", array("type" => "text/javascript"))--}}
					{{HTML::script("bootstrap-3.1.1-dist/js/bootstrap.js", array("type" => "text/javascript"))}}
					{{HTML::script('js/alertify.js', array('type'=>'text/javascript'))}}
					{{HTML::script('js/js-session.js', array('type'=>'text/javascript'))}}					
				@yield('javascript')
				<!-- CSS  -->
					{{HTML::style("bootstrap-3.1.1-dist/css/bootstrap.css", array("type" => "text/css"))}}
					{{HTML::style("css/basestyles.css", array("type" => "text/css"))}}
					{{HTML::style("css/alertify.css", array("type" => "text/css"))}}
					{{HTML::style("css/bootstrap_alertify.css", array("type" => "text/css"))}}
					
				@yield('css')
				<!-- Estilos para alternar texto del botón -->
				<style>
					/* Por defecto se muestra el texto completo */
					.btn-notusdatos-text-full { display: inline; }
					.btn-notusdatos-text-short { display: none; }

					/* Si el ancho es menor a 665px, se oculta el texto largo y se muestra el corto */
					@media (max-width: 665px) {
						.btn-notusdatos-text-full { display: none; }
						.btn-notusdatos-text-short { display: inline; }
					}
				</style>
				

				<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
				<!--[if lt IE 9]>
					{{HTML::script("http://html5shim.googlecode.com/svn/trunk/html5.js", array("type" => "text/javascript"))}}
				<![endif]-->



				<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
				<!--[if lt IE 9]>
				  {{HTML::script("js/html5shiv.js", array("type" => "text/javascript"))}}
				  {{HTML::script("js/respond.min.js", array("type" => "text/javascript"))}}
				<![endif]-->	
	</head>
<!-- contenido  -->		
	<div class="contenido_modal">
		@yield('contenido_modal')	
	</div>
    <!-- body  -->    
	<body> 
		<!-- contenedor general  -->
		<div class="container-fluid container_gral">
			<!-- contenedor principal  -->
			<div class="container_ppal">
					<!-- header  -->
					
				
								
										
					@if( stristr( URL::current() , "carga-tramites") === false)
					@if(stristr(URL::current(),'acceso-no-autorizado')=== false)
					<div class="menu" id="menu_top">
						<nav class="navbar navbar-default" role="navigation">
							
							<div class="navbar-header"> 
								<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-exl-collapse">
									<span class="sr-only">cambiar navegacion</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
									<!--a href="{{ URL::to('portal') }}" class="navbar-brand"><span class="glyphicon glyphicon-home"></span> Inicio</a-->
									<a href="{{ URL::to('portal') }}" class="navbar-brand">
										<!-- <img src="images/logo_tradicional1.jpg" id="loteria_santa_fe_ch" title="Loteria de Santa Fe" alt="Imagen no encontrada"> -->
										{{ HTML::image(Config::get("ctacte_config/config.logo_cabecera"), 'Imagen no encontrada', array('id'=>'loteria_santa_fe_ch', 'title'=>'Loteria de Santa Fe'))}}
									</a>
							</div>
							
							<div class="collapse navbar-collapse navbar-exl-collapse" ng-controller="HeaderController" id="acolapsar">
									<ul class="nav navbar-nav">
										<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><strong>Procesos</strong><b class="caret"></b></a>
											<ul class="dropdown-menu">
											
											
											
												@foreach (\Session::get('usuarioLogueado.accesos_usuario') as $acceso)
														@if(stristr(URL::current(),$acceso->funcion) === false && stristr('1',$acceso->acceso) !== false)
															<li><a href="{{ url('/').strtolower($acceso->url) }}"><strong> {{ $acceso->funcion  }}</strong></a></li> 
														@else
															<li>	</li>
														@endif
														
												@endforeach
													
											
											</ul>
										</li>
									</ul>
							</div>							
						</nav>
					</div>
					@endif
					@yield('menu')
					@endif
					
					<!-- contenido  -->		
					<div class="contenido">
						@yield('contenido')	
					</div>
					
					<!-- footer  -->	
					<div id="pie">
						@yield('pie')
					</div>
			</div>
		</div>
	</body>
</html>
