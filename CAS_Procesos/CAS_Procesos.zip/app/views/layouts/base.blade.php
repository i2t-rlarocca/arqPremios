<!doctype html>
<html>
    <head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<!--meta http-equiv="cache-control" content="max-age=0" />
		<meta http-equiv="cache-control" content="no-cache" />
		<meta http-equiv="cache-control" content="no-store" />
		<meta http-equiv="cache-control" content="must-revalidate" />
		<meta http-equiv="expires" content="0" />
		<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
		<meta http-equiv="pragma" content="no-cache" /-->
			<title>
				@section('titulo')
					CAS CUENTA CORRIENTE
				@show
			</title>
			<!-- javasript  -->
					{{HTML::script("js/jquery-1.11.1.min.js", array("type" => "text/javascript"))}} {{HTML::script("js/jquery.validate.js", array("type" => "text/javascript"))}}
					{{-- HTML::script("js/additional-methods.js", array("type" => "text/javascript"))--}}
					{{HTML::script("bootstrap-3.1.1-dist/js/bootstrap.js", array("type" => "text/javascript"))}}
					{{HTML::script('js/alertify.js', array('type'=>'text/javascript'))}}
					{{  HTML::script('js/js-session.js?' . rand(), array('type'=>'text/javascript'))}}				
				@yield('javascript')
				<!-- CSS  -->
					{{HTML::style("bootstrap-3.1.1-dist/css/bootstrap.css", array("type" => "text/css"))}}
					{{HTML::style("css/basestyles.css", array("type" => "text/css"))}}
					{{HTML::style("css/alertify.css", array("type" => "text/css"))}}
					{{HTML::style("css/bootstrap_alertify.css", array("type" => "text/css"))}}
					
				@yield('css')
				<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
				<!--[if lt IE 9]>
					{{HTML::script("http://html5shim.googlecode.com/svn/trunk/html5.js", array("type" => "text/javascript"))}}
				<![endif]-->



				<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
				<!--[if lt IE 9]>
				  {{HTML::script("js/html5shiv.js", array("type" => "text/javascript"))}}
				  {{HTML::script("js/respond.min.js", array("type" => "text/javascript"))}}
				<![endif]-->	
	</head>
<!-- contenido  -->		
	<div class="contenido_modal">
		@yield('contenido_modal')	
	</div>
    <!-- body  -->    
	<body> 
		<!-- contenedor general  -->
		<div class="container-fluid container_gral">
			<!-- contenedor principal  -->
			<div class="container_ppal">
					<!-- header  -->
					<a id="header" href="{{URL::to('portal')}}">
						<header class="header">
							<!--?php
							header("Expires: Thu, 27 Mar 1980 23:59:00 GMT"); //la pagina expira en una fecha pasada
							header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); //ultima actualizacion ahora cuando la cargamos
							header("Cache-Control: no-cache, must-revalidate"); //no guardar en CACHE
							header("Pragma: no-cache"); 
							?-->
							<?php
								ini_set('upload_max_filesize', '1024M');
								ini_set('post_max_size', '1024M');
								ini_set('max_execution_time', 14400);
							?>
							{{ HTML::image('images/logo_tradicional_grande.jpg', 'Imagen no encontrada', array('id'=>'loteria_santa_fe', 'title'=>'Loteria de Santa Fe'))}}
							
							@yield('header')
						</header> 
					</a>
										
					
					@if(stristr(URL::current(),'acceso-no-autorizado')=== false)
											
						@yield('menu')
					@endif
					
					<!-- contenido  -->		
					<div class="contenido">
						@yield('contenido')	
					</div>
					
					<!-- footer  -->	
					<div id="pie">
						@yield('pie')
					</div>
			</div>
		</div>
	</body>
</html>