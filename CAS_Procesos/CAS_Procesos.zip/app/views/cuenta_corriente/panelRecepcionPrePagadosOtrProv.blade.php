@extends('layouts.base2')
@section('javascript')
{{HTML::script("js/bootstrap-filestyle.min.js", array("type" => "text/javascript"))}}
{{HTML::script("js/js-panel_recepcion_pre_pagados_otras_prov2.js?v=".rand(), array("type" => "text/javascript"))}}
@stop
		
@section('contenido')
	<!-- PANEL PROCESO -->
	<div class="container-fluid">
		<h1 id="titulo" align="center">RECEPCI&Oacute;N PREMIOS PAGADOS OTRAS PROVINCIAS</h1>
		{{-- Verificamos que exista la variable en sesión --}}
		@if(Session::has('usuarioLogueado.datosTipoUsuario'))

			{{-- Obtenemos el primer registro del resultset --}}
			 <?php
				$datos = Session::get('usuarioLogueado.datosTipoUsuario');
				$usuarioTipo = $datos[0]; // primer objeto devuelto por el SP
				$urlInterno = Session::get('urlInterno');
			?>

			{{-- Condición: si prv_id es distinto de 'S' --}}
			@if(isset($usuarioTipo) && $usuarioTipo->prv_id !== 'S')
				<div class="panel panel-default">
					<div class="panel-heading"><B>Datos del Usuario</B></div>
					<div class="panel-body">
						<p><strong>Usuario:</strong> {{ $usuarioTipo->user_name }}</p>
						<p><strong>Nombre:</strong> {{ $usuarioTipo->user_nombres }} {{ $usuarioTipo->user_apellidos }}</p>
						<p><strong>Lotería:</strong> {{ $usuarioTipo->user_loteria }}</p>
						<p><strong>Provincia:</strong> {{ $usuarioTipo->prv_provincia }} - {{ $usuarioTipo->prv_name }}</p>
						
		                {{-- Texto y formulario con botón submit --}}
						<form onsubmit="
								// Limpia almacenamiento del navegador
								sessionStorage.clear();
								localStorage.clear();

								// Intentar cerrar la pestaña actual
								//window.open('', '_self');
								//window.close();

								// Como fallback, redirigir a login si no se cerró
								setTimeout(function() {
									if (!window.closed) {
										window.location.href = '{{$urlInterno}}';
									}
								}, 500);

								return false; // evita recarga
							" style="margin-top:15px;">
							<p>
								<button type="submit" class="btn btn-danger btn-lg" style="font-weight: bold; font-size: 14px;">
									<span class="btn-notusdatos-text-full">¿No son tus datos? Haz click aquí para cerrar la sesión y volver a ingresar</span>
									<span class="btn-notusdatos-text-short">¿No son tus datos? Haz click aquí...</span>
								</button>
							</p>
						</form>
					</div>
				</div>
			@endif
		@endif
		<div class="panel panel-default">
			<div class="panel-heading"><B>Procesar Premios Pagados</B></div>
			<div class="panel-body">
				<div class="row-fluid" id="div_formulario">
					{{Form::open(array("action" => array("RecepcionPremPagOtrProvController@tratamientoArchivoPremPagOtrProv"), "method" => "post", "name" => "formulario_recepcion_pre_pagados_otr_prov", "id" => "formulario_recepcion_pre_pagados_otr_prov",  'enctype' => 'multipart/form-data'))}}
					{{ $campos }}
					{{ Form::hidden('id_ejec_proc',$id_ejec_proc,  array('id' => 'id_ejec_proc')) }}
					{{Form::close()}}
				</div>
			</div>
		</div>
	</div>
	<!-- PANEL ERROR -->
	<div class="container-fluid">
		<div id="panel_error" class="bs-example col-lg-12" style="display:none">
			<div class="alert alert-danger" role="alert">
				<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
				{{Form::label('titulo', 'Resultado:', array('id'=>'titulo'))}}
				{{Form::label('mensaje_error', '', array('id'=>'mensaje_error'))}}
			</div>
		</div>
	</div>
	<!-- PANEL OK -->
	<div class="container-fluid">
		<div id="panel_ok" class="bs-example col-lg-12" style="display: none">
			<div class="alert alert-success" role="alert">
				<span class="glyphicon glyphicon glyphicon-ok" aria-hidden="true"></span>
				{{Form::label('titulo', 'Resultado:', array('id'=>'titulo'))}}
				{{Form::label('mensaje_ok', '', array('id'=>'mensaje_ok'))}}
			</div>
		</div>
	</div>
	<!-- PANEL WARNING -->
	<div class="container-fluid">
		<div id="panel_warning" class="col-xs-12 col-lg-12" style="display: none">
			<div class="alert alert-warning" role="alert">		
				<span class="glyphicon glyphicon glyphicon-warning-sign" aria-hidden="true"></span>
				{{Form::label('titulo', 'Resultado:', array('id'=>'titulo'))}}
				{{Form::label('mensaje_ok', '', array('id'=>'mensaje_warning'))}}
				{{-- Form::textarea('mensaje_ok', '', array('id'=>'mensaje_ok','readonly'=>'true','rows'=>'4'))--}}
			</div>
		</div>
	</div>
	<!-- PANEL HISTORIAL -->
	<div id="paquetes" name="paquetes" class="container-fluid">
		<div class="panel panel-default">
			<div class="panel-heading"><B>Historial</B></div>
			<div class="panel-body">	
				<div class="center col-xs-12 col-lg-12 ">
					<table class=" col-xs-12 col-lg-12 table table-striped table-hover table-bordered dataTable " name="tabla_res" id="tabla_res">
							<thead>
								<tr>
									<th class="col-lg-4">Paquete</th>
									<th class="col-lg-2">Fecha</th>
									<th class="col-lg-6">Archivo</th>
								</tr>
							</thead>
					</table>
					<div id="cargando"></div>
				</div>
			</div>
		</div>
	</div>
@endsection
	    	
@section('contenido_modal')
	<div id="cargandoModal" class="modal fade" role="dialog" aria-hidden="true" data-keyboard="false">
		<div class="modal-dialog modal-sm">
			<div class="modal-content" id="modal-content">
				 <div class="modal-body" align="center">
				 	<h3>Cargando...</h3>
				    <img src="../public/images/cargando.gif" id="loading-indicator" />
				</div>			
			</div>
		</div>
	</div >
	<div id="sesionModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-sm">
			<div class="modal-content" id="modal-content">
				 <div class="modal-body">
					<h3>Su sesión ha finalizado.</h3>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				</div>
			</div>
		</div>
	</div>
@endsection





