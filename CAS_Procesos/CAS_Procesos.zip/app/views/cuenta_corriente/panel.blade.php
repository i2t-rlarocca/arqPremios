@extends('layouts.base2')
@section('javascript')
{{ HTML::script('js/bootstrap-filestyle.min.js?' . rand(), array('type' => 'text/javascript'))}}
{{ HTML::script('js/js-panel_sorteos.js?' . rand(), array('type' => 'text/javascript'))}}
{{ HTML::script('js/js-panel_transaccion.js?' . rand(), array('type' => 'text/javascript'))}}
{{-- HTML::script('js/js-session.js?' . rand(), array('type'=>'text/javascript')) --}}

@stop
		
@section('contenido')
	<div class="container-fluid">
		<h1 id="titulo" align="center">PROCESOS DIARIOS DE SORTEOS</h1>
	  <div class="row-fluid" id="tablas">
	    <div class="table-responsive col-xs-3 col-sm-5 col-md-5 col-lg-5 igual_alto" id="panel_alertas">
		   	{{$tablas}}
	    	{{Form::hidden('id_seleccionado','',  array('id' => 'id_seleccionado'))}}
	    	{{Form::hidden('nro_sorteo','',  array('id' => 'nro_sorteo'))}}
	    	{{Form::hidden('id_estado_seleccionado','',  array('id' => 'id_estado_seleccionado'))}}
	    	{{Form::hidden('id_formato_procesamiento','',  array('id' => 'id_formato_procesamiento'))}}
	    	{{Form::hidden('id_juego_seleccionado','',  array('id' => 'id_juego_seleccionado'))}}
			{{Form::hidden('fecha_seleccionado','',  array('id' => 'fecha_seleccionado'))}}
	    </div><!-- fin table-responsive -->
	    <div class="col-xs-12 col-sm-7 col-md-7 col-lg-7 igual_alto" id="panel_transaccion"> <!-- row-fluid  --> 
	    	<div id="datos_juego"> 
	     		<!-- completar -->
	    	</div>
			<div class="col-xs-5 col-sm-12 col-lg-12" id='panel_identificador_transaccion'>
				<!--div id="div_captacion_apuestas" class="col-lg-12 div_captacion_apuestas transaccionDesactivada" align="center">
						<label for="cap_ap" id="cap_ap">Fin captación de apuestas</label>
				</div>
				<div id="div_resultados_premiados" class="col-lg-12 div_resultados_premiados transaccionDesactivada" align="center">
						<label for="res_prem" id="res_prem">Resultados y premiados</label>
				</div>
				<div id="div_liquidacion_ap_com" class="col-lg-12 div_liquidacion_ap_com transaccionDesactivada" align="center">
						<label for="liq_ap_com" id="liq_ap_com">Liquidación apuestas y comisiones</label>				
				</div-->
				<div id="div_etapas">
					<div id="div_label_etapa" class="col-lg-12 transaccionDesactivada" align="center">
							<label>ETAPA PROCESO:</label>
					</div>
					<div id="div_captacion_apuestas" class="col-lg-12 transaccionDesactivada" >
							<label for="cap_ap" id="cap_ap">Fin captación de apuestas</label>
							<img id="im_estado_cap_ap" src="images/ok.jpg" alt="" style="height:14px; display:none">
					</div>
					<div id="div_resultados_premiados" class="col-lg-12 transaccionDesactivada">
							<label for="res_prem" id="res_prem">Resultados y premiados</label>
							<img id="im_estado_res_prem" src="images/ok.jpg" alt="" style="height:14px; display:none" >
					</div>
					<div id="div_liquidacion_ap_com" class="col-lg-12 transaccionDesactivada">
							<label for="liq_ap_com" id="liq_ap_com">Liquidación apuestas y comisiones</label>	
							<img id="im_estado_liq_ap_com" src="images/ok.jpg" alt="" style="height:14px; display:none">							
					</div>
				</div>
			</div>
			
	    	<!-- PANEL CARGA ARCHIVOS -->
	    	<div id="panel_carga_archivos" class="col-sm-7 col-lg-12">
	    		{{Form::open(array("action" => array("CuentaCorrienteController@obtenerArchivos"), "method" => "post", "id" => "formulario_archivos","class"=>"formulario_archivos",  'enctype' => 'multipart/form-data'))}}
	    		<!-- completar -->
	    		<div id="sin_sorteo_seleccionado" class="text-center col-xs-2 col-sm-7 col-md-12 col-lg-12"><h1>SELECCIONE UN SORTEO PARA OPERAR...</h1></div>	    		    		
				
	    		<div id="panel_btn_publicar" class="bs-example col-lg-12" style="display: none">
	    			{{Form::button('PUBLICAR', array('id' => 'btn_publicar', 'name'=>'btn_publicar', 'class' => 'btn btn-primary'))}}
	    		</div>
	    		{{Form::close()}}
	    		<div id="panel_btn_diferencias" class="bs-example col-lg-12" style="display: none">
	    			{{Form::button('Ver diferencias', array('id' => 'btn_diferencias', 'name'=>'btn_diferencias', 'class' => 'btn btn-primary'))}}
	    		</div>
	    		<!--div id="panel_btn_datos" class="bs-example col-lg-12" style="display: none">
	    			{{Form::button('Ver datos', array('id' => 'btn_datos', 'name'=>'btn_datos', 'class' => 'btn btn-primary'))}}
	    		</div-->
	    		<div id="panel_error" class="bs-example col-lg-12" style="display: none">
	    			<div class="alert alert-danger" role="alert">
						<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
						{{Form::label('titulo', 'Resultado:', array('id'=>'titulo'))}}
						  {{Form::label('mensaje_error', '', array('id'=>'mensaje_error'))}}
					</div>
	    		</div>
	    		<div id="panel_ok" class="bs-example col-lg-12" style="display: none">
	    			<div class="alert alert-success" role="alert">
						<span class="glyphicon glyphicon glyphicon-ok" aria-hidden="true"></span>
						{{Form::label('titulo', 'Resultado:', array('id'=>'titulo'))}}
						  {{Form::textarea('mensaje_ok', '', array('id'=>'mensaje_ok','readonly'=>'true','rows'=>'4'))}}
					</div>
	    		</div>
	    	</div>
	    </div>
	  </div>
	</div>
@endsection
	    	
	    	
			 

@section('contenido_modal')
	<div id="cargandoModal" class="modal fade" role="dialog" aria-hidden="true" data-keyboard="false">
		<div class="modal-dialog modal-sm">
			<div class="modal-content" id="modal-content">
				 <div class="modal-body" align="center">
				 	<h3>Cargando...</h3>
				    <img src="../public/images/cargando.gif" id="loading-indicator" />
				</div>			
			</div>
		</div>
	</div >
	<div id="sesionModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-sm">
				<div class="modal-content" id="modal-content">
					 <div class="modal-body">
						<h3>Su sesión ha finalizado.</h3>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
					</div>
				</div>
			</div>
		</div>
@endsection





