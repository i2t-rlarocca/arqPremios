@extends('layouts.base2')
@section('javascript')
{{ HTML::script('js/bootstrap-filestyle.min.js?' . rand(), array('type' => 'text/javascript'))}}
{{ HTML::script('js/js-panel_sorteos.js?' . rand(), array('type' => 'text/javascript'))}}
{{ HTML::script('js/js-panel_transaccion.js?' . rand(), array('type' => 'text/javascript'))}}
{{ HTML::script('js/js-session.js?' . rand(), array('type'=>'text/javascript'))}}

@stop
		
@section('contenido')
	<div class="container-fluid">
		<h1 id="titulo" align="center">SISTEMA DE PROCESOS</h1>
	  <div class="row-fluid" id="paneles">
	   	<h3>SELECCIONE EL ITEM DE MENU QUE DESEA EJECUTAR.</h3>
	  </div>	  
	</div>
@endsection

@section('contenido_modal')
	<div id="cargandoModal" class="modal fade" role="dialog" aria-hidden="true" data-keyboard="false">
		<div class="modal-dialog modal-sm">
			<div class="modal-content" id="modal-content">
				 <div class="modal-body" align="center">
				 	<h3>Cargando...</h3>
				    <img src="../public/images/cargando.gif" id="loading-indicator" />
				</div>			
			</div>
		</div>
	</div >
	<div id="sesionModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-sm">
				<div class="modal-content" id="modal-content">
					 <div class="modal-body">
						<h3>Su sesión ha finalizado.</h3>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
					</div>
				</div>
			</div>
		</div>
@endsection





