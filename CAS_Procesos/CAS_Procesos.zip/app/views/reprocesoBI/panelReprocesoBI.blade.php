@extends('layouts.base2')
@section('javascript')
{{ HTML::script("js/bootstrap-filestyle.min.js", array("type" => "text/javascript"))}}

{{ HTML::script("js/js-panel_vuelcos_bi.js", array("type" => "text/javascript"))}}

<!--

{{ HTML::script("js/js-panel_transaccion.js", array("type" => "text/javascript"))}}
-->
@stop

		
		
@section('contenido')


	
		
@foreach ($valida as $val)
{{ Form::hidden('msgret_n',$val['msgret'],  array('id' => 'msgret_id')) }}
		@if($val['msgret']!= '')
		<h1 id="titulo" align="center">REPROCESO VUELCO BI COMERCIAL</h1>
		<div class="row-fluid col-xs-5 col-sm-12 col-lg-12">
		
			<div id="errores_val" class="bs-example col-lg-10 col-lg-offset-1">
				<div class="alert alert-danger fade in">
						
				  {{Form::label('mensaje', $val['msgret'] , array('id'=>'mensaje'))}}
				</div>
			</div>
			
		
		</div>		
	
		@else
			<div class="row-fluid col-xs-5 col-sm-12 col-lg-12">
		
			<div id="errores" class="bs-example col-lg-10 col-lg-offset-1">
				<div class="alert alert-danger fade in">
						
				  {{Form::label('mensaje_in', ' ', array('id'=>'mensaje_in'))}}
				</div>
			</div>
			
		
		</div>	
	<div class="container-fluid">
		<h1 id="titulo" align="center">REPROCESO VUELCO BI COMERCIAL</h1>
	  <div class="row-fluid" id="tablas">
		
		{{Form::open(array('action' => array('ReprocesoBIController@tratamientoReprocesoBI'), 'method' => 'post', 'id' => 'formulario_reproceso_bi', 'class'=>'form-horizontal'))}} 
		<div class="table-responsive col-xs-3 col-sm-5 col-md-5 col-lg-6 igual_alto alto_250" id="panel_alertas">
		<label>Período:</label>
		@foreach ($campos as $campo)
			<div class="col-lg-12" id="periodo_div"> 
				{{ Form::radio('periodo',substr($campo['idMessor'],0,9),false,array('id'=>'periodo', 'required' => 'required','class'=>'col-xs-1 col-sm-1 col-md-1 col-lg-1')) }} 
				@if ($campo['estado'] == '4') 
					{{Form::label('periodol',substr($campo['idMessor'],0,6).'- OK'  ,array('id'=>'periodol', 'class'=>'col-xs-4 col-sm-4 col-md-4 col-lg-4 text-lg-center '))}} 
				@elseif ($campo['estado'] == '3') 
				{{Form::label('periodol',substr($campo['idMessor'],0,6).'- ER'  ,array('id'=>'periodol', 'class'=>'col-xs-4 col-sm-4 col-md-4 col-lg-4 text-md-center'))}} 
				@endif 
			</div>		
		@endforeach
		
		
	
	    </div>
	    <div class="col-xs-12 col-sm-7 col-md-7 col-lg-6 igual_alto alto_250" id="panel_transaccion">
	    	<div id="datos_juego"> 
			<label>A procesar:</label>
				<div class="col-lg-12">
					<div class="col-lg-8">
						 {{Form::label('a_partir_fallo_l','A partir del fallo.' ,array('id'=>'a_partir_fallo_l', 'class'=>'col-xs-4 col-sm-4 col-md-4 col-lg-8'))}} 
					</div>
					<div class="col-lg-4" id="a_partir_fallo_div">
						{{ Form::radio('a_procesar', 1,true,array('id'=>'a_procesar','checked' => 'checked', 'class'=>'col-xs-1 col-sm-1 col-md-1 col-lg-2')) }} 
					</div>
				</div>
				<div class="col-lg-12">
					<div class="col-lg-8">
					 {{Form::label('completo_l','Completo.' ,array('id'=>'completo_l', 'class'=>'col-xs-4 col-sm-4 col-md-4 col-lg-4'))}}
					</div>
					<div class="col-lg-4" id="completo_div">
					  {{ Form::radio('a_procesar', 0,false,array('id'=>'a_procesar', 'class'=>'col-xs-1 col-sm-1 col-md-1 col-lg-2')) }}  
					</div>
				</div>
				<div class="col-lg-12">
				<div class="col-lg-8">
					 {{Form::label('inc_cuad_afec_l','Incluir Cuadratura Af.' ,array('id'=>'inc_cuad_afec_l', 'class'=>'col-xs-4 col-sm-4 col-md-4 col-lg-10'))}}
					</div>
					<div class="col-lg-4">
					{{ Form::checkbox('inc_cuad_afec','',false,array('id'=>'inc_cuad_afec')) }}
					</div>
				</div>
				<div class="col-lg-12">
				<div class="col-lg-8">
					 {{Form::label('dif_ejec_l','Diferir Ejecución.' ,array('id'=>'dif_ejec_l', 'class'=>'col-xs-4 col-sm-4 col-md-4 col-lg-10'))}}
					</div>
					<div class="col-lg-4">
					{{ Form::checkbox('dif_ejec', '', false,array('id'=>'dif_ejec')) }}
					</div>
				</div>
			
			
			<div class="col-xs-5 col-sm-12 col-lg-12" id='panel_identificador_transaccion'>
				<div id="div_etapas">
					<div id="div_label_etapa" class="col-lg-12 transaccionDesactivada" align="center">
							
					</div>
				</div>
			</div>
			
	    	<!-- PANEL CARGA ARCHIVOS -->
<!--	  
	  <div id="panel_carga_archivos" class="col-sm-7 col-lg-12">
	    		{{Form::open(array("action" => array("CuentaCorrienteController@obtenerArchivos"), "method" => "post", "id" => "formulario_archivos","class"=>"formulario_archivos",  'enctype' => 'multipart/form-data'))}}
-->	    	
			<!-- completar -->
<!--	    		<div id="sin_sorteo_seleccionado" class="text-center col-xs-2 col-sm-7 col-md-12 col-lg-12"><h1>SELECCIONE UN SORTEO PARA OPERAR...</h1></div>	    		    		
				
	    		<div id="panel_btn_publicar" class="bs-example col-lg-12" style="display: none">
	    			{{Form::button('PUBLICAR', array('id' => 'btn_publicar', 'name'=>'btn_publicar', 'class' => 'btn btn-primary'))}}
	    		</div>
	    		{{Form::close()}}
	    		<div id="panel_btn_diferencias" class="bs-example col-lg-12" style="display: none">
	    			{{Form::button('Ver diferencias', array('id' => 'btn_diferencias', 'name'=>'btn_diferencias', 'class' => 'btn btn-primary'))}}
	    		</div>
	-->	    		
	    		
	    	</div>
				
	    </div>
		<div id="panel_error" class="bs-example col-lg-12" style="display: none">
	    			<div class="alert alert-danger" role="alert">
						<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
						{{Form::label('titulo', 'Resultado:', array('id'=>'titulo'))}}
						{{Form::label('mensaje_error', '', array('id'=>'mensaje_error'))}}
					</div>
	    		</div>
	    		<div id="panel_ok" class="bs-example col-lg-12" style="display: none">
	    			<div class="alert alert-success" role="alert">
						<span class="glyphicon glyphicon glyphicon-ok" aria-hidden="true"></span>
						{{Form::label('titulo', 'Resultado:', array('id'=>'titulo'))}}
						  {{Form::textarea('mensaje_ok', '', array('id'=>'mensaje_ok','readonly'=>'true','rows'=>'4'))}}
					</div>
	    		</div>
		
		
	  </div>
	<div class="center">	  
		<div class="col-sm-12 col-lg-12">	
				{{Form::button('Procesar', array('id' => 'btn_procesar', 'name'=>'btn_procesar', 'class' => 'btn-primary', 'onfocus'=>'siguienteCampo = "nada";'))}} 
				{{Form::button('Cerrar', array('id'=>'btn_cerrar', 'name'=>'btn_cerrar', 'class'=>'btn-primary', 'onfocus'=>'siguienteCampo = "nada";'))}}		
		</div>
	</div>
{{Form::close()}}		  
	</div>
	
	@endif 	
	@endforeach
@endsection
	    	
	    	
			 

@section('contenido_modal')
	<div id="cargandoModal" class="modal fade" role="dialog" aria-hidden="true" data-keyboard="false">
		<div class="modal-dialog modal-sm">
			<div class="modal-content" id="modal-content">
				 <div class="modal-body" align="center">
				 	<h3>Cargando...</h3>
				    <img src="../public/images/cargando.gif" id="loading-indicator" />
				</div>			
			</div>
		</div>
	</div >
	<div id="sesionModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-sm">
				<div class="modal-content" id="modal-content">
					 <div class="modal-body">
						<h3>Su sesión ha finalizado.</h3>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
					</div>
				</div>
			</div>
		</div>
@endsection





