@extends('layouts.base2')
@section('javascript')
{{ HTML::script("js/bootstrap-filestyle.min.js", array("type" => "text/javascript"))}}
{{ HTML::script("js/js-panel_exportacion.js", array("type" => "text/javascript")) }}
@stop
		
@section('contenido')
	<div class="container-fluid">
		<h1 id="titulo" align="center">{{$titulo}}</h1>
	  <div class="" id="div_formulario">
		{{Form::open(array("action" => array("ExportacionesController@generaExportacion"), "method" => "post","name" => "formulario_exportacion", "id" => "formulario_exportacion","class"=>"formulario_exportacion",  'enctype' => 'multipart/form-data'))}}
			{{$campos}} 
			{{Form::hidden('id_ejec_proc',$id_ejec_proc,  array('id' => 'id_ejec_proc'))}}
		{{Form::close()}}
	  </div>
	  <div id="panel_error" class="bs-example col-lg-12" style="display: none">
		<div class="alert alert-danger" role="alert">
			<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
			{{Form::label('titulo', 'Resultado:', array('id'=>'titulo'))}}
			{{Form::label('mensaje_error', '', array('id'=>'mensaje_error'))}}
		</div>
	  </div>
	  <div id="panel_ok" class="bs-example col-lg-12" style="display: none">
		<div class="alert alert-success" role="alert">
			<span class="glyphicon glyphicon glyphicon-ok" aria-hidden="true"></span>
			{{Form::label('titulo', 'Resultado:', array('id'=>'titulo'))}}
			{{Form::label('mensaje_ok', '', array('id'=>'mensaje_ok'))}}
			{{-- Form::textarea('mensaje_ok', '', array('id'=>'mensaje_ok','readonly'=>'true','rows'=>'4'))--}}
		</div>
	  </div>
	  
	  <div id="paquetes" name="paquetes" class="container-fluid">
		<div class="center col-xs-12 col-lg-12 ">
		<table class=" col-xs-12 col-lg-12 table table-striped table-hover table-bordered dataTable " name="tabla_res" id="tabla_res">
				<thead>
					<tr>
						<th class="col-lg-4">Paquete</th>
						<th class="col-lg-2">Fecha</th>
						<th class="col-lg-6">Archivo</th>
					</tr>
				</thead>
		</table>
			<div id="cargando"></div>	
		</div>
	  </div>
	  
	  
	</div>
@endsection
	    	
	    	
			 

@section('contenido_modal')
	<div id="cargandoModal" class="modal fade" role="dialog" aria-hidden="true" data-keyboard="false">
		<div class="modal-dialog modal-sm">
			<div class="modal-content" id="modal-content">
				 <div class="modal-body" align="center">
				 	<h3>Cargando...</h3>
				    <img src="../../../public/images/cargando.gif" id="loading-indicator" />
				</div>			
			</div>
		</div>
	</div >
	<div id="sesionModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-sm">
				<div class="modal-content" id="modal-content">
					 <div class="modal-body">
						<h3>Su sesión ha finalizado.</h3>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
					</div>
				</div>
			</div>
		</div>
@endsection





