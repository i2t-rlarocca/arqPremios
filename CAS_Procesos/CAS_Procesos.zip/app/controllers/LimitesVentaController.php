<?php
use \Helpers\Macros;
use \Dominio\Servicios\Limites; 
use \Dominio\Servicios\CuentasCorrientes; 
use controllers\UsuarioController; 
use \Helpers\Util;

class LimitesVentaController extends BaseController {
	  public $error_carga_limites_nombre ="Problema al cargar los archivos de %s. Verifique formato de nombre.";
	  public $err_falta_archivo = "Falta archivo de %s";
   	  public $err_mas_archivos = "Hay más archivos de los esperados para %s.";
	  public $err_menos_archivos = "Hay menos archivos de los esperados para %s.";
	  public $err_proces="Problema al procesar %s.";
	  public $error_carga_limites ="Problema al cargar los archivos de %s.";
	function __construct() {
		$ds=DIRECTORY_SEPARATOR;

		$this->servicioLimites = new Limites();
		$this->servicioCtaCte = new CuentasCorrientes();
		$this->controladorUsuario = new UsuarioController();
		
	}

	
	/****************************************************************
	* Ingreso desde el panel principal - carga de usuario
	*****************************************************************/
	public function cargaUsuarioEnAppLimites(){
		$util = new Util();
		if(!Session::has("datos_ingreso")){
			return Redirect::to('/portal');
		}
		$datosIngreso=Session::get("datos_ingreso");
		$datosIngreso=explode("&",$datosIngreso);
		$usuario=explode("usuario=",$datosIngreso[0]);
		$id_portal=explode("id_portal=",$datosIngreso[1])[1];
		$letra_portal=explode("letra_portal=",$datosIngreso[2])[1];
		$nombre_usuario=$util->decrypt($usuario[1],"Pir@mide01");
		
		$usuario=$this->controladorUsuario->buscar($nombre_usuario);
	
		//borra todos los datos anteriores
		Session::flush();
		
		if(is_null($usuario["idUsuario"])|| is_null($usuario)){
			$mensaje='Hay un problema con su usuario.';
			Session::put('mensaje_acceso',$mensaje);
			\Log::error("problema con el usuario - nulo");
			Session::flush();
	       	return Redirect::to('/acceso-no-autorizado');
		}else if (!in_array('Administracion_ctacte',$usuario['funciones'])){
			$mensaje='Su tipo de usuario no posee acceso.';
			Session::put('mensaje_acceso',$mensaje);
	       	return Redirect::to('/acceso-no-autorizado');
		}
		$usuario['id_portal']=$id_portal;
		$usuario['letra_portal']=$letra_portal;
		Session::put('usuarioLogueado',$usuario);
		return Redirect::to('/panel-principal');
	}
		
	
	/***************************************
	* Armado del panel de limites de venta *
	****************************************/
	public function camposPanelLimitesVenta(){
		$archivosApedir=array();
		$datosTransaccion['nombre_file']=array();
		$archivos=$this->servicioCtaCte->especif_arch_x_juego();
		$idJuego=999;
		$lv=0;
		
		foreach ($archivos[$idJuego] as $archJuego) {
			if($archJuego['transaccion']==5 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='LV'){//limites de venta
							$lv++;
							$archivo['nombre']='lv_'.$lv;
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Limites Ctrl.';
							else
								$archivo['buttonText']='Limites';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						$archivo['extension']=str_replace("+" ,"",str_replace("+[[:alpha:]]", "\w", $archJuego['extension']));
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}			

		$datosTransaccion= Response::panelLimites($archivosApedir);
		return $datosTransaccion;
	}
	
	/***************************************
	* Llamada al panel de límites de venta *
	****************************************/
	public function panelLimitesVenta(){
		$campos=$this->camposPanelLimitesVenta();
		return View::make('cuenta_corriente.panelLimitesVenta', array('campos'=>$campos));
	}
		 
	/********************************************************
	* Recepción de los datos desde el panel de límites
	*********************************************************/
	public function tratamientoLimitesVenta(){
		//definición de variables
		$util = new Util();
		list($com,$man,$exito)=0;
		$listaTiposArchivos=array();
		$listaArchivosRequerimiento=array();
		$idJuego=999;
		$ds=DIRECTORY_SEPARATOR;
		$usuario= Session::get('usuarioLogueado.idUsuario');
		$destinoLimites = Config::get('ctacte_config/config.urlDestino').Config::get('ctacte_config/config.urlLimites');
		
		if(!is_dir($destinoLimites) && !file_exists($destinoLimites)){
		  File::makeDirectory($destinoLimites, 0777, true);
		}
		//carpeta del período
		$destinoLimites=$destinoLimites.$ds;
		if(!is_dir($destinoLimites) && !file_exists($destinoLimites)){
		  File::makeDirectory($destinoLimites, 0777, true);
		}
		
		//obtengo todos los archivos subidos para controlar el nombre
		$archivosSubidos=Input::file();
			
		//archivos a pedir
		$archivos = $this->servicioCtaCte->especif_arch_x_juego();

		//archivos para limites de venta
		$archivos=$archivos[$idJuego];
		$archivos=$util->groupArray($archivos,'tipo_archivo');
		foreach ($archivos as $tiposArc) {
			array_push($listaArchivosRequerimiento,$tiposArc);
			array_push($listaTiposArchivos,$tiposArc['tipo_archivo']);
		}
			
		//vemos qué tipo de requerimiento tienen los archivos o=opcional, r=requerido
		$archivosRequerimientos=array();
		foreach ($listaArchivosRequerimiento as $archReq) {
			foreach ($archReq['grupodatos'] as $especificacion) {
				if($especificacion['transaccion']==5){//limites de venta
					$arReq[$archReq['tipo_archivo']]=$especificacion['requerido'];
					$archivosRequerimientos[$archReq['tipo_archivo']]=$arReq;	
				}
			};
		}
			
			//carga de archivos a la carpeta temporal
			if(in_array("LV", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['LV']['LV'],'R')==0)){//limite venta
				
				try{
					
					//verifico cómo deben ser los archivos (individuales, padre=>nº de hijos)
					list($archivosHijos,$archivosPadres,$listaNombresInput)=array([],[],[]);
					$this->listasArchivos($archivos, $listaLV, $archivosHijos, $archivosPadres, "LV",5);
					$listaArchivos["lv_ctrl"]=array();
					$listaArchivos["lv_det"]=array();

					if(count($archivosPadres)>=1){//son archivos unitarios
						$this->estanTodosLosArchivos($destinoLimites,"limites","lv_",$archivosPadres, $listaArchivos);
						$lv=1;
					}else{//hay un padre contenedor
						$lv=2;					
						
						$archivosLv=array();
						foreach ($archivos as $tipoArchivo) {
							if(strcasecmp($tipoArchivo['tipo_archivo'], "LV")===0){
								$archivosLv=$tipoArchivo['grupodatos'];							
							}
						}
						
						$this->archivosPrevios($destinoLimites,$previos,$archivosLv,5);
						/* verr!!!
						$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"lv_", "limites",$archivosPadres,$archivosHijos, $destinoComisiones,$listaComisiones ,$idJuego,$listaArchivos, $previos);
						
						if(!$dezipeoOK['exito']){
							return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje']));       						
						}*/					
					}
					
				}catch(\Exception $e){
					$mensaje=sprintf($this->error_carga_limites_nombre,"limites de venta");
					\Log::info($mensaje);
					\Log::info($e);
					return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
				}
			}
			
			
			//carga de los archivos a las tablas
			if($lv==1){
				$archivoLv = $listaArchivos['lv_det'][0]['archivo'];
				$fechaHoraArchivo = $listaArchivos['lv_det'][0]['fechaHora'];
				//$archivoLvCtrl = $listaArchivos['lv_ctrl'][0];
				$res=$this->archivosLimites($archivoLv, $destinoLimites,$fechaHoraArchivo, 0);//, $archivoLvCtrl
				if($res){
					//elimino el temporal
					//$util->rrmdir($destinoLimites);
					$exito=1;				
				}else{//error carga archivos
					$exito=0;
					$mensaje=sprintf($this->error_carga_limites,"limites de venta");
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));       						
				}
			}else if($lv==2){
				$archivoLv = $listaArchivos['lv_det'][0];		
				//$archivoLvCtrl = $listaArchivos['lv_ctrl'][0];		
				$okLv=$this->servicioLimites->cargarLimitesVenta($archivoLv);
				$okCtrlLv=$this->servicioLimites->cargarLimitesControl($archivoLvCtrl, $archivoLv);
				if($okLv && $okCtrlLv){
						$exito=1;
				}else{
					$exito=0;
					$mensaje=sprintf($this->error_carga_limites,"limites de venta");
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));       						
				}
			}
			
			
			if($exito==1){
				//genero id del proceso
				$idProceso=$this->servicioCtaCte->getNumeroProcesoAuditoriaCtaCte($idJuego, $fechaHoraArchivo);
				//llamo al stored para procesar los límites de venta
				$ok=$this->servicioLimites->sor_procesa_limites($idProceso, $usuario, $fechaHoraArchivo);
				if(strcasecmp($ok,'ok')==0){
					$mensaje="Las diferencias se ven en el reporte PDF.";
				}else{
					$exito=0;
					$mensaje=$ok;
				}
				
			}
			$urlReporte=Config::get('ctacte_config/config.urlJasper').Config::get('ctacte_config/config.urlReporteLVD');
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje, 'urlReporte'=>$urlReporte));
		
	}
	
	
	/******************************************************
	* Función que guarda los archivos de limites de venta *
	*******************************************************/
	public function archivosLimites($archivoLv, $destino, $fechaHora, $guardar){//, $archivoLvCtrl
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreLv = $archivoLv->getClientOriginalName();
				//$nombreLvCtrl = $archivoLvCtrl->getClientOriginalName();
				//$archivoLvCtrl = $destino.$ds.$nombreLvCtrl;
				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessLv = $archivoLv->move($destino, $nombreLv);
		           	//$uploadSuccessLvCtrl = $archivoLvCtrl->move($destino, $archivoLvCtrl);
				}else{
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessLv = $archivoLv->move($destino, $nombreLv);
					$archivoLv=$destino.$nombreLv;
					$okLv=$this->servicioLimites->cargarLimites($archivoLv, $fechaHora);
					//$okLvCtrl=$this->servicioLimites->cargarLimitesControl($archivoLvCtrl, $archivoLv);
				}

				if($okLv )//&& $okLvCtrl)
					return 1;
				else
					return 0;

	}
	
	
/********************* funciones que deben ser genéricas *************************/	
	/*****************************************
	* lista de archivos según la transacción
	******************************************/
	private function listasArchivos($archivos, &$lista, &$hijos, &$padres, $ta, $transac){
		//lista de archivos 
		foreach ($archivos as $archivo) {
			if($archivo['tipo_archivo']==$ta ){
				$lista=$archivo['grupodatos'];
				break;
			}
		}
		if(isset($lista)){
			//busco el arch. padre y los hijos
			foreach ($lista as $archivo) {
				if($archivo['id_padre']=='' && $archivo['transaccion']== $transac){
					array_push($padres,$archivo);								
				}else{
					array_push($hijos,$archivo);
				}
			}			
		}
	}
	
	/**************************************************************************
	* Función que se encarga de buscar los archivos previos si es que existen *
	***************************************************************************/
    private function archivosPrevios($directorioBusqueda, &$resultado, $archivos, $transaccion){
    	
    	if(is_dir($directorioBusqueda)){
				$directorio = File::files($directorioBusqueda);
				if(!empty($directorio)){
					$iteadorArchivosEnDestino=new FilesystemIterator($directorioBusqueda, FilesystemIterator::SKIP_DOTS);//no incluye . ni ..
					$tipo_archivo = basename($directorioBusqueda);
					if(iterator_count($iteadorArchivosEnDestino)>0){
						$files = File::allFiles($directorioBusqueda);
						$arch = [];
						$extension=array();
						//busco qué tipo de archivos previos busco
						foreach ($archivos as $archivo) {
							if($archivo['transaccion']==$transaccion && $archivo['id_padre']==''){
								array_push($extension,$archivo['extension']);
							}
						}
						foreach ($files as $file)
						{
							$extFile=".".pathinfo(basename($file), PATHINFO_EXTENSION);
							if($this->coincideExtension($extension, $extFile)){
							    array_push($arch, basename($file)) ;//nombre del archivo de apuestas
							    $resultado['archivosPrevios']=array('existenArchivosPrevios'=>1,'archivos'=>array(array('tipo_archivo'=>$tipo_archivo,'nombre_archivo'=>$arch)));
							}

						}
					}else{
						$resultado['archivosPrevios']=array('existenArchivosPrevios'=>0,'archivos'=>array());
					}						
				}	
			}
    }
	

	private function estanTodosLosArchivos($destino, $tipoArchivos,$prefijo,$archivosPadres,&$listaArchivos){
		$i=0;

		//armo los nombres de los input files que debe haber
		$cantidad=count($archivosPadres);
		for($x=0;$x<$cantidad;$x++) {
			$i++;
		   	$nombreInputFile = $prefijo.$i;
			
		   	if(Input::hasFile($nombreInputFile)){
		   		$archivo = Input::file($nombreInputFile);
		   		$pathArchivo = $archivo->getRealPath();
				$nombreOriginal=$archivo->getClientOriginalName();//$archivo->getClientOriginalName();//$destino.$archivo->getClientOriginalName();//$destino.$archivo;//

				foreach($archivosPadres as $archP) {				
					$patron="/^".$archP['nombre'];

					if(preg_match($patron, $nombreOriginal) && strtolower($archP['control'])=="s"){
						$datoArchivo=array();
						$datoArchivo['nombreOriginal']=$nombreOriginal;
						$datoArchivo['path']=$pathArchivo;
						$datoArchivo['archivo']=$archivo;
						$datoArchivo['fechaHora']=date ("Ymd", filemtime($pathArchivo)); //File::lastModified($filename);
						array_push($listaArchivos[$prefijo.'ctrl'],$datoArchivo);
						
					}else if(preg_match($patron, $nombreOriginal) && strtolower($archP['control'])=="n"){			//if(preg_match($patron, $archivo->getClientOriginalName())){			//
						$datoArchivo=array();
						$datoArchivo['nombreOriginal']=$nombreOriginal;
						$datoArchivo['path']=$pathArchivo;
						$datoArchivo['archivo']=$archivo;
						$datoArchivo['fechaHora']=date ("Ymd", filemtime($pathArchivo)); //File::lastModified($filename);
						array_push($listaArchivos[$prefijo.'det'],$datoArchivo);						
					}	
				}
		   	}else{
		   		$mensaje=sprintf($this->err_falta_archivo,$tipoArchivos);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		   	}
		}
	}	

	/**************************************************************
	* Función que se encarga de sacar los archivos del contenedor *
	***************************************************************/
	private function tratamientoArchivosEnContenedor($util,$prefijo, $tiposArchivos, $archivosPadres, $archivosHijos,$destinoTemporal,$lista ,$idJuego,&$listaArchivos, $previos){
		$i=1;	
	
		if(Input::hasFile($prefijo.$i)){
		   	$archivo = Input::file($prefijo.$i);
			
		   	//archivos anteriores
		   	if(count($previos)>0){
			   	if($previos['archivosPrevios']['existenArchivosPrevios']){
					//verifico si es el mismo o no subió nada
					$archPrev = $previos['archivosPrevios']['archivos'];
					foreach ($archPrev as $prev) {
						foreach($prev['nombre_archivo'] as $p){
							if(strcasecmp($p, $archivo->getClientOriginalName())==0){//mismo archivo
							//movemos el archivo a la nueva ubicación -->verificar que se obtenga el nombre correcto
								$archivo=$archPrev;
							}else{//uno nuevo
								//borro archivo viejo
								File::delete($destinoTemporal.$ds.$p);
							}								
						}
					}
				}		   		
		   	}
			
		   	$resultado=$util->controlZip($archivo, $destinoTemporal, $lista, $idJuego);

			$mensaje='OK';
		   	if($resultado['exito']){							
				//buscar los archivos en la carpeta y pasarlos a la tabla
				$ficheros =  scandir($destinoTemporal);
				$ficheros1=array();
				foreach ($ficheros as $fichero) {
					$extension = explode(".",$fichero);
					if(strcasecmp($extension[1],'zip')!=0 && $fichero!= "." && $fichero!= ".."){
						array_push($ficheros1, $fichero);
					}
				}
				
				if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
					$mensaje=sprintf($this->err_mas_archivos,$tiposArchivos);
					\Log::info($mensaje);
					$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
					return $resultado;
				}

				foreach ($ficheros1 as $nombreFichero) {
					foreach ($archivosHijos as $hijo) {
						$patron="/^".$hijo['nombre'];
						$pathArchivo = $destinoTemporal.$nombreFichero;
						
						if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
							array_push($listaArchivos[$prefijo.'ctrl'], $pathArchivo);
						}else if(strtolower($hijo['control'])=="s"){
							array_push($listaArchivos[$prefijo.'det'],$pathArchivo);
						}
					}
				}
				$resultado=array('exito'=>1, 'mensaje'=>$mensaje);
				return $resultado;
			}else{//problema al descomprimir
				$mensaje=$resultado['mensaje'];
				\Log::info($mensaje);
				$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
				return $resultado;
			}
	   }else if($previos['archivosPrevios']['existenArchivosPrevios']){
				$mensaje='OK';
				//verifico si es el mismo o no subió nada
				$archPrev = $previos['archivosPrevios']['archivos'];
				foreach ($archPrev as $prev) {
					foreach($prev['nombre_archivo'] as $p){
							$archivo=$destinoTemporal.$p;
					}
				}
				
				$resultado=$util->controlZip($archivo, $destinoTemporal, $lista, $idJuego);

				if($resultado['exito']){							
					//buscar los archivos en la carpeta y pasarlos a la tabla
					$ficheros =  scandir($destinoTemporal);
					$ficheros1=array();
					foreach ($ficheros as $fichero) {
						$extension = explode(".",$fichero);
						if(strcasecmp($extension[1],'zip')!=0 && $fichero!= "." && $fichero!= ".."){
							array_push($ficheros1, $fichero);
						}
					}
					
					if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
						$mensaje=sprintf($this->err_mas_archivos,$tiposArchivos);
						\Log::info($mensaje);
						$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
						return $resultado;
					}

					foreach ($ficheros1 as $nombreFichero) {
						foreach ($archivosHijos as $hijo) {
							$patron="/^".$hijo['nombre'];
							$pathArchivo = $destinoTemporal.$nombreFichero;
							if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
								array_push($listaArchivos[$prefijo.'ctrl'], $pathArchivo);
							}else if(strtolower($hijo['control'])=="s"){
								array_push($listaArchivos[$prefijo.'det'],$pathArchivo);
							}
						}
					}
					$resultado=array('exito'=>1, 'mensaje'=>$mensaje);
					return $resultado;
				}else{//problema al descomprimir
					$mensaje=$resultado['mensaje'];
					\Log::info($mensaje);
					$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
					return $resultado;
				}			
			
				
				
	   }else{
	   	$mensaje=sprintf($this->err_falta_archivo,$tiposArchivos);
		\Log::info($mensaje);
		$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
		return $resultado;
	   }
	}
		
	
}
