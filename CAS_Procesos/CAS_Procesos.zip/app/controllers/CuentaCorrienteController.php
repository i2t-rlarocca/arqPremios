<?php
	
use \Helpers\Macros;
use \Dominio\Servicios\Afectaciones; 
use \Dominio\Servicios\Apuestas; 
use \Dominio\Servicios\Premios; 
use \Dominio\Servicios\VentasTotales; 
use \Dominio\Servicios\Caratulas; 
use \Dominio\Servicios\Resultados; 
use \Dominio\Servicios\Comisiones;
use \Dominio\Servicios\Liquidaciones; 
use \Dominio\Servicios\CuentasCorrientes; 
use controllers\UsuarioController; 
use \Helpers\Util;

class CuentaCorrienteController extends BaseController {
	//MENSAJES ERROR VARIOS 
	  public $error_carga_sorteos_diarios = "Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al juego/sorteo seleccionado."; 
	  public $error_carga_comisiones ="Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al período indicado.";
	  public $err_nro_sorteo_archivo = "El archivo de %s no corresponde al sorteo elegido.";
	  public $err_falta_archivo = "Falta archivo de %s";
	  public $err_datos_sorteo = "Problema al obtener los datos del sorteo: %s";
   	  public $err_mas_archivos = "Hay más archivos de los esperados para %s.";
	  public $err_menos_archivos = "Hay menos archivos de los esperados para %s.";
	  public $err_proces="Problema al procesar %s.";
	  public $err_cant_archivos = "Existe problema de integridad de archivos esperados para %s.";
	  public $err_nomb_archivos ="No se espera el archivo con el nombre %s.";
	  public $err_validacion_archivo ="No se ha completado de forma satisfactoria la validación de la carga de archivos.";

	function __construct() {
		$ds=DIRECTORY_SEPARATOR;

		$this->servicioAfectaciones = new Afectaciones();
		$this->servicioApuestas = new Apuestas();
		$this->servicioPremios = new Premios();
		$this->servicioVentasTotales = new VentasTotales();
		$this->servicioCuentaCorriente = new CuentasCorrientes();
		$this->servicioCaratulas = new Caratulas();
		$this->servicioResultados = new Resultados();
		$this->servicioComisiones = new Comisiones();
		$this->servicioLiquidaciones = new Liquidaciones();
		$this->controladorUsuario = new UsuarioController();
		$this->destinoTemporal = Config::get('ctacte_config/config.urlDestino');
		
		$this->destinoTemporalSinProcesar= $this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalSinProcesar');
		$this->destinoFinalCaratula=$this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalCaratula');
		$this->destinoFinalResultados=$this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalResultados');
		$this->destinoTemporalResultados= $this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalResultados');
		$this->destinoFinalConsolidacion=$this->destinoTemporal;//.Config::get('ctacte_config/config.urlFinalConsolidacion');
		$this->destinoTemporalConsolidacion= $this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalConsolidacion');
		$this->destinoSuite = Config::get('ctacte_config/config.url_s');
		$this->moduloAuditoria = $this->destinoSuite.Config::get('ctacte_config/config.modulo_aud');
		
		$this->destinoComisiones = $this->destinoTemporal.Config::get('ctacte_config/config.urlComisiones');
		$this->destinoCasLog = $this->destinoTemporal.Config::get('ctacte_config/config.urlCasLog');
		$this->destinoLiquidaciones = $this->destinoTemporal.Config::get('ctacte_config/config.urlLiquidaciones');
		$this->destinoTemporalAS400= $this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalAS400');
		
		$this->srcImgError=Config::get("ctacte_config/config.urlImgError");
		$this->srcImgPeligro=Config::get("ctacte_config/config.urlImgPeligro");
		$this->srcImgOk=Config::get("ctacte_config/config.urlImgOk");
	}

	
	/****************************************************************
	* Ingreso desde el panel principal - carga de usuario
	*****************************************************************/
	public function cargaUsuarioEnAppCtaCte(){
		$util = new Util();
		if(!Session::has("datos_ingreso")){
			return Redirect::to('/portal');
		}
		 \Log::info("datos_ingreso", array(Session::get("datos_ingreso")));
		
		$datosIngreso=Session::get("datos_ingreso");
		$datosIngreso=explode("&",$datosIngreso);
		$usuario=explode("usuario=",$datosIngreso[0]);
                $id_portal=explode("id_portal=",$datosIngreso[1])[1];
		$letra_portal=explode("letra_portal=",$datosIngreso[2])[1];
		$nombre_usuario=$util->decrypt($usuario[1],"Pir@mide01");
		
		$usuario=$this->controladorUsuario->buscar($nombre_usuario);
	
		// logueo
		\Log::info("paso por cargaUsuarioEnAppCtaCte - CuentaCorriente");

		//borra todos los datos anteriores
		Session::flush();
		
		if(is_null($usuario["idUsuario"])|| is_null($usuario)){
			$mensaje='Hay un problema con su usuario.';
			Session::put('mensaje_acceso',$mensaje);
			\Log::error("problema con el usuario - nulo");
			Session::flush();
	       	return Redirect::to('/acceso-no-autorizado');
		}else if (!in_array('Administracion_ctacte',$usuario['funciones'])){
			$mensaje='Su tipo de usuario no posee acceso.';
			Session::put('mensaje_acceso',$mensaje);
	       	return Redirect::to('/acceso-no-autorizado');
		}
		$usuario['id_portal']=$id_portal;
		$usuario['letra_portal']=$letra_portal;
		\Log::error("Portal ".$usuario['id_portal']."-letra ".$usuario['letra_portal']);

		Session::put('usuarioLogueado',$usuario);
		
		return Redirect::to('/panel-principal');
	}
	
	/********************************
	* Armado del panel principal
	*********************************/
	public function panelPrincipal(){
		$tablaExcepciones = array();
		$datos['fecha_exc']='2019-01-01';
		$datos['descripcion_exc']='Primero de enero';
		$datos['accion_exc']='Anula todos los sorteos';
		array_push($tablaExcepciones, $datos);
		$datos['fecha_exc']='2019-08-17';
		$datos['descripcion_exc']='Paso a la inmortalidad del General San Martín';
		$datos['accion_exc']='Sorteo especial a la noche';
		array_push($tablaExcepciones, $datos);
		
		$panel1= Response::panelExcepciones($tablaExcepciones);
		$panel2= Response::panelExcepciones($tablaExcepciones);
		$panel3= Response::panelExcepciones($tablaExcepciones);
		$panel4= Response::panelExcepciones($tablaExcepciones);
		return View::make('cuenta_corriente.panel2', array('panel1'=>$panel1, 'panel2'=>$panel2,'panel3'=>$panel3, 'panel4'=>$panel4));
	}
		

	/***********************************
	* Armado del panel de comisiones
	************************************/
	public function camposPanelComisiones(){
		$archivosApedir=array();
		$datosTransaccion['nombre_file']=array();
		$archivos=$this->servicioCuentaCorriente->especif_arch_x_juego();
		$idJuego=999;$ms=0;$com=0;
		
		foreach ($archivos[$idJuego] as $archJuego) {
			if($archJuego['transaccion']==4 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='CA'){//comisiones adicionales
							$com++;
							$archivo['nombre']='com_'.$com;
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Comisiones Ctrl.';
							else
								$archivo['buttonText']='Comisiones';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						if($archJuego['tipo_archivo']=='MS'){//mantenimiento y sellado
							$ms++;
							$archivo['nombre']='man_'.$ms;
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Mant. y Sell. Ctrl.';
							else
								$archivo['buttonText']='Mant. y Sell';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						$archivo['extension']=str_replace("+" ,"",str_replace("+[[:alpha:]]", "\w", $archJuego['extension']));
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}			
		$periodo=$this->servicioComisiones->valida_periodo();
		//$periodo='201505';
		$datosTransaccion= Response::panelComisiones($archivosApedir, $periodo);
		return $datosTransaccion;
	}
	
	/***********************************
	* Llamada al panel de comisiones
	************************************/
	public function panelComisiones(){
		$campos=$this->camposPanelComisiones();
		return View::make('cuenta_corriente.panelComisiones', array('campos'=>$campos));
	}
		
	/********************************************************
	* Recepción de los datos desde el panel de comisiones
	*********************************************************/
	public function tratamientoComisiones(){
		//definición de variables
		$util = new Util();
		list($com,$man,$exito)=0;
		$listaTiposArchivos=array();
		$listaArchivosRequerimiento=array();
		$idJuego=999;
		$ds=DIRECTORY_SEPARATOR;
		$mensaje="";
		$datos= Input::all();
		$destino=$this->destinoComisiones;
		$usuario= Session::get('usuarioLogueado.idUsuario');
		
		$reglas=array('periodo'=>'required|integer');
		
		$mensaje=array(
				"required"=>"Campo requerido",
				"integer"=>"Solo Nº"
		);
		$validar=Validator::make($datos,$reglas,$mensaje);
			
		if($validar->fails()){
			$mensaje=$validar->messages();
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		} else{
			$periodo_completo=Input::get('periodo');
		/*	$periodoValido = $this->servicioComisiones->periodoValido($periodo_completo);
			if(strcasecmp($periodoValido,'ok')!=0){//no es válido
				$mensaje=$periodoValido;
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}*/
			$periodo= substr(Input::get('periodo'),-4);
			//creación de las carpetas
			//carpeta principal -> comisiones
			if(!is_dir($destino) && !file_exists($destino)){
			  File::makeDirectory($destino, 0777, true);
			}
			//carpeta del período
			$destino=$destino.$ds.$periodo.$ds;
			if(!is_dir($destino) && !file_exists($destino)){
			  File::makeDirectory($destino, 0777, true);
			}
			//obtengo todos los archivos subidos para controlar el nombre y el período
			$archivosSubidos=Input::file();
			foreach($archivosSubidos as $archivo){
				$filename = $archivo->getClientOriginalName();
				$arregloNombre=explode(".",$filename);	
				$nombreSinExtension =substr($arregloNombre[0],-4); 
				if($nombreSinExtension!=$periodo){
					$mensaje=sprintf("El archivo %s no corresponde al período ingresado.",$filename);
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
				}
			}
			//archivos a pedir
			$archivos = $this->servicioCuentaCorriente->especif_arch_x_juego();

			//archivos para comisiones
			$archivos=$archivos[$idJuego];
			$archivos=$util->groupArray($archivos,'tipo_archivo');
			foreach ($archivos as $tiposArc) {
				array_push($listaArchivosRequerimiento,$tiposArc);
				array_push($listaTiposArchivos,$tiposArc['tipo_archivo']);
			}
			//vemos qué tipo de requerimiento tienen los archivos o=opcional, r=requerido
			$archivosRequerimientos=array();
			foreach ($listaArchivosRequerimiento as $archReq) {
				foreach ($archReq['grupodatos'] as $especificacion) {
					if($especificacion['transaccion']==4){//comisiones-mant y sellado
						$arReq[$archReq['tipo_archivo']]=$especificacion['requerido'];
						$archivosRequerimientos[$archReq['tipo_archivo']]=$arReq;	
					}
				};
			}
			//carga de archivos a la carpeta temporal
			if(in_array("CA", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['CA']['CA'],'R')==0)){//comisiones adicionales
				try{
					//destino para los archivos de comisiones
					$destinoComisiones =$destino.$ds."comisiones".$ds;
					if(!is_dir($destinoComisiones) && !file_exists($destinoComisiones)){
						File::makeDirectory($destinoComisiones, $mode = 0777, true, true);
					}else{
						array_map('unlink', glob($destinoComisiones."*"));
					}
					//verifico cómo deben ser los archivos (individuales, padre=>nº de hijos)
					list($archivosHijos,$archivosPadres,$listaNombresInput)=array([],[],[]);
					$this->listasArchivos($archivos, $listaComisiones, $archivosHijos, $archivosPadres, "CA",4);
					$listaArchivos["com_ctrl"]=array();
					$listaArchivos["com_det"]=array();

					if(count($archivosPadres)>1){//son archivos unitarios
						$this->estanTodosLosArchivos($destinoComisiones,"comisiones","com_",$archivosPadres, $listaArchivos);
						$com=1;
					}else{//hay un padre contenedor
						$com=2;					
						
						$archivosCA=array();
						
						foreach ($archivos as $tipoArchivo) {
							if(strcasecmp($tipoArchivo['tipo_archivo'], "CA")===0){
								$archivosCA=$tipoArchivo['grupodatos'];							
							}
						}
						$this->archivosPrevios($destinoComisiones,$previos,$archivosCA,4);
						$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"com_", "comisiones",$archivosPadres,$archivosHijos, $destinoComisiones,$listaComisiones ,$idJuego,$listaArchivos, $previos);
						
						if(!$dezipeoOK['exito']){
							return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje']));       						
						}					
					}
				}catch(\Exception $e){
					$mensaje=sprintf($this->error_carga_comisiones,"comisiones");
					\Log::info($mensaje);
					\Log::info($e);
					return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
				}
			}
			if(in_array("MS", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['MS']['MS'],'R')==0)){//mant. y sellado
				try{
					//destino para los archivos de mantenimiento y sellado
					$destinoManSellado =$destino.$ds."mant_sellado".$ds;
					if(!is_dir($destinoManSellado) && !file_exists($destinoManSellado)){
						File::makeDirectory($destinoManSellado, $mode = 0777, true, true);
					}else{
						array_map('unlink', glob($destinoManSellado."*"));
					}
					
					//verifico cómo deben ser los archivos (individuales, padre=>nº de hijos)
					list($archivosHijos,$archivosPadres,$listaNombresInput)=array([],[],[]);
					$this->listasArchivos($archivos, $listaComisiones, $archivosHijos, $archivosPadres, "MS",4);
					$listaArchivos["man_ctrl"]=array();
					$listaArchivos["man_det"]=array();
					
					if(count($archivosPadres)>1){//son archivos unitarios
						$this->estanTodosLosArchivos($destinoManSellado,"mant_sellado","man_",$archivosPadres, $listaArchivos);
						$man=1;
					}else{//hay un padre contenedor
						$man=2;					
						
						$archivosMS=array();
						
						foreach ($archivos as $tipoArchivo) {
							if(strcasecmp($tipoArchivo['tipo_archivo'], "MS")===0){
								$archivosCA=$tipoArchivo['grupodatos'];							
							}
						}
						$this->archivosPrevios($destinoManSellado,$previos, $archivosMS,4);
						$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"man_", "mant_sellado",$archivosPadres,$archivosHijos, $destinoManSellado,$listaComisiones ,$idJuego,$listaArchivos, $previos);
						
						if(!$dezipeoOK['exito']){
							return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje']));       						
						}					
					}
				}catch(\Exception $e){
					$mensaje=sprintf($this->error_carga_comisiones,"mantenimiento y sellado");
					\Log::info($mensaje);
					\Log::info($e);
					return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
				}
			}
			
			//carga de los archivos a las tablas
			if($com==1){
				$archivoCom = $listaArchivos['com_det'][0];		
				$archivoComCtrl = $listaArchivos['com_ctrl'][0];
				$res=$this->archivosComisiones($archivoCom, $archivoComCtrl, $destinoComisiones,1);
				if($res){
					$exito=1;				
				}else{//error carga archivos
					$exito=0;
					$mensaje=sprintf($this->error_carga_comisiones,"comisiones");
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));       						
				}
			}else if($com==2){
				$archivoCom = $listaArchivos['com_det'][0];		
				$archivoComCtrl = $listaArchivos['com_ctrl'][0];		
				$okCom=$this->servicioComisiones->cargarComision($archivoCom);
				$okCtrlCom=$this->servicioComisiones->cargarComisionesControl($archivoComCtrl, $archivoCom);
				if($okCom && $okCtrlCom){
						$exito=1;
				}else{
					$exito=0;
					$mensaje=sprintf($this->error_carga_comisiones,"comisiones");
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));       						
				}
			}
			
			if($exito==1 and $man==1){
				$archivoMan = $listaArchivos['man_det'][0];		
				$archivoManCtrl = $listaArchivos['man_ctrl'][0];
				$res=$this->archivosManSellado($archivoMan, $archivoManCtrl, $destinoManSellado,1);
				if($res){
					$exito=1;				
				}else{//error carga archivos
					$exito=0;
					$mensaje=sprintf($this->error_carga_comisiones,"mantenimiento y sellado");
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));       						
				}		
			}else if($exito==1 and $man==2){
				$archivoMan = $listaArchivos['man_det'][0];		
				$archivoManCtrl = $listaArchivos['man_ctrl'][0];		
				$okMan=$this->servicioComisiones->cargarManSellado($archivoMan);
				$okCtrlMan=$this->servicioComisiones->cargarManSelladoControl($archivoManCtrl, $archivoMan);
				if($okMan && $okCtrlMan){
						$exito=1;
				}else{
					$exito=0;
					$mensaje=sprintf($this->error_carga_comisiones,"mantenimiento y sellado");
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));       						
				}
			}
			if($exito==1){
				//genero id del proceso
				$idProceso=$this->servicioCuentaCorriente->getNumeroProcesoAuditoriaCtaCte($idJuego, $periodo_completo);
				//llamo al stored para procesar las comisiones del período
				$ok=$this->servicioComisiones->sor_procesa_comisiones_adic($periodo_completo, $idProceso, $usuario);
				if(strcasecmp($ok,'ok')==0){
					$mensaje="Carga correcta de los archivos de comisiones y mantenimiento y sellado.";
				}else{
					$exito=0;
					$mensaje=$ok;
				}
			}
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		}
	}

/******************************* original ***************************************/
	/***********************************************************
	* Carga el usuario en la aplicación o lo retorna al portal *
	* si no está logueado o no tiene permiso.                  *
	************************************************************/
	public function cargaUsuarioEnApp(){
		$util = new Util();
		if(!Session::has("datos_ingreso")){
			return Redirect::to('/portal');
		}
		
		$datosIngreso=Session::get("datos_ingreso");
		\Log::info("CuentaCorrienteController.cargaUsuarioEnApp - datos_ingreso", array(Session::get("datos_ingreso")));

		$datosIngreso=explode("&",$datosIngreso);
		$usuario=explode("usuario=",$datosIngreso[0]);
		

		$id_portal=explode("id_portal=",$datosIngreso[1])[1];
		$letra_portal=explode("letra_portal=",$datosIngreso[2])[1];
		$nombre_usuario=$util->decrypt($usuario[1],"Pir@mide01");
		\Log::info("RR - CuentaCorrienteController.cargaUsuarioEnApp - nombre-usuario", array($nombre_usuario));

		$usuario=$this->controladorUsuario->buscar($nombre_usuario);	
		\Log::info("RR - CuentaCorrienteController.cargaUsuarioEnApp - Usuario", array($usuario));
		
		// logueo
		\Log::info("CuentaCorrienteController.cargaUsuarioEnApp - paso por cargaUsuarioEnApp 2 - CuentaCorriente");

		//borra todos los datos anteriores
		Session::flush();
		\Log::info("RR - idUsuario-1", array($usuario["idUsuario"]));
		if(is_null($usuario["idUsuario"])|| is_null($usuario)){
			$mensaje='Hay un problema con su usuario.';
			\Log::info("RR - CuentaCorrienteController.cargaUsuarioEnApp - paso por cargaUsuarioEnApp A - mensaje: $mensaje - idUsuario-2", array($usuario["idUsuario"]));
			Session::put('mensaje_acceso',$mensaje);
			Session::flush();
	       	return Redirect::to('/acceso-no-autorizado');
		}else if (!in_array('Administracion_ctacte',$usuario['funciones'])){
			\Log::info("RR - CuentaCorrienteController.cargaUsuarioEnApp - paso por cargaUsuarioEnApp B - usuario-funciones", array($usuario["funciones"]));
			$mensaje='Su tipo de usuario no posee acceso.';
			Session::put('mensaje_acceso',$mensaje);
	       	return Redirect::to('/acceso-no-autorizado');
		}
		$usuario['id_portal']=$id_portal;
		$usuario['letra_portal']=$letra_portal;
		Session::put('usuarioLogueado',$usuario);
		\Log::info("CuentaCorrienteController.cargaUsuarioEnApp - usuario Logueado correctamente: ", array(Session::get("usuarioLogueado")));

		return Redirect::to('/panel-principal');
	}

			


	/*****************************************
	* Arma la vista de los sorteos diarios 
	******************************************/
	public function paneles(){
		$tablas=$this->tablaSorteos();
		return View::make('cuenta_corriente.panel', array('tablas'=>$tablas));
	}


	/*****************************************************
	* Arma los datos necesarios para la tabla de sorteos *
	******************************************************/
	private function tablaSorteos(){
		Session::forget('tipoArchivoJuegoEstado');
		$sorteos=$this->servicioCuentaCorriente->sorteos_panel_alertas();
		$datos['titulo_tabla']="Sorteos días anteriores";
		$datos['id_tabla']="tabla_sorteos_anteriores";
		$datos['id_body']="cuerpo_sda";
		$datos['dia']=$sorteos['diasAnteriores'];
		$tablaDiasAnteriores=Response::tablaPrimerPanel($datos);
		$datos['titulo_tabla']="Sorteos del día";
		$datos['id_tabla']="tabla_sorteos_del_dia";
		$datos['id_body']="cuerpo_sd";
		$datos['dia']=$sorteos['diaActual'];
		$tablaDiaActual=Response::tablaPrimerPanel($datos);		

		$datos['titulo_tabla']="Sorteos días futuros";
		$datos['id_tabla']="tabla_sorteos_futuros";
		$datos['id_body']="cuerpo_sdf";
		$datos['dia']=$sorteos['diaFuturo'];
		$tablaDiasFuturos=Response::tablaPrimerPanel($datos);		
		

		$tablas = $tablaDiasAnteriores.$tablaDiaActual.$tablaDiasFuturos;
		$archivos = $this->servicioCuentaCorriente->especif_arch_x_juego();
		Session::put('tipoArchivoJuegoEstado', $archivos);
		return $tablas;
	}


	/********************************************
	* Función que carga el panel de transacción *
	*********************************************/
	public function cargarPanelTransaccion(){
		$idsorteo = Input::get('id_seleccionado');
		$idEstado = Input::get('id_estado_seleccionado');
		$idJuego = Input::get('id_juego_seleccionado');
		$nro_sorteo = Input::get('nro_sorteo');

		$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $nro_sorteo);

		return Response::json(array('exito'=>1, 'datosTransaccion'=>$resultado));
	}
	
	private function transacciones($idsorteo, $idEstado,$idJuego, $nro_sorteo){
		$util = new Util();
		//verificación de si puede hacer algo o debe esperar que se procese un sorteo anterior
		$puedeProcesar = $this->servicioCuentaCorriente->puedeProcesar($nro_sorteo, $idJuego);
		// \Log::info('CuentaCorrienteController - transacciones - puedeProcesar', array($puedeProcear) );

		if($puedeProcesar){
		
			// if(Session::has('tipoArchivoJuegoEstado')){
			// 	\Log::info('transacciones - entra a if Linea 523');
			// 	$archivos = Session::get('tipoArchivoJuegoEstado');
			// }else{
				$archivos = $this->servicioCuentaCorriente->especif_arch_x_juego();
				\Log::info('transacciones - entra a else Linea 527');
			// }
			$datosVistaTransaccion=array();
			$datosVistaTransaccion['botones']=array();
			$archivosApedir=array();
			
			$datosVistaTransaccion['puedeProcesar']=1;
			//Armado según la transacción que debe activarse
			if(in_array($idEstado, array(0,10,15))){//carátula
				$datosTransaccion['nombre_file']=array();
				$crt=0;
				$apu=0;
				foreach ($archivos[$idJuego] as $archJuego) {
					if($archJuego['transaccion']==1 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='CT'){//caratula
							$crt++;
							$archivo['nombre']='car_'.$crt;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'CT', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Pozoz Ctrl.';
							else
								$archivo['buttonText']='Pozos';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						if($archJuego['tipo_archivo']=='AP'){//apuesta
							$apu++;
							$archivo['nombre']='apu_'.$apu;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'AP', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Apuesta Ctrl.';
							else
								$archivo['buttonText']='Apuesta';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						$archivo['extension']=str_replace("+" ,"",str_replace("+[[:alpha:]]", "\w", $archJuego['extension']));
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}
				//según el estado cambia el btn
				$btn['id_btn']="btn_caratula";
				$btn['value_btn']="PROCESAR";
				array_push($datosVistaTransaccion['botones'], $btn);

				$datosVistaTransaccion['id_estado']=$idEstado;
				$datosTransaccion['transaccion_activa']=1;
			}else if(in_array($idEstado, array(20,25))){//resultados
				$datosTransaccion['nombre_file']=array();
				$rs=0;
				$su=0;
				$ex=0;

				\Log::info('CuentaCorrienteController - 580 - idJuego: ', array($idJuego));
				\Log::info('CuentaCorrienteController - 580 - archivos:', array($archivos));

				foreach ($archivos[$idJuego] as $archJuego) {
					
					if($archJuego['transaccion']==2 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='RT'){//resultados
							$rs++;
							$archivo['nombre']='res_'.$rs;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'RT', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Resultados Ctrl.';
							else
								$archivo['buttonText']='Resultados';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='SU'){//sueldos
							$su++;
							$archivo['nombre']='sue_'.$su;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'SU', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Sueldos Ctrl.';
							else
								$archivo['buttonText']='Sueldos';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='EX'){//extractos
							$ex++;
							$archivo['nombre']='ex_'.$ex;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'EX', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Extracto Ctrl.';
							else
								$archivo['buttonText']='Extracto';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						$archivo['extension']=str_replace("+" ,"",str_replace("+[[:alpha:]]", "\w", $archJuego['extension']));
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}
				//según el estado cambia el btn
				$btn['id_btn']="btn_resultados";
				$btn['value_btn']="PROCESAR";
				array_push($datosVistaTransaccion['botones'], $btn);
				$datosVistaTransaccion['id_estado']=$idEstado;
				//chequeo si ya existen archivos
				$usuario = Session::get('usuarioLogueado.idUsuario');
				$ds = DIRECTORY_SEPARATOR;
				//paths a las carpetas 
				$destinoTemporalResultados = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$nro_sorteo.$ds."resultados";
				$destinoTemporalSueldos = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$nro_sorteo.$ds."sueldos";
				
				$this->archivosPrevios($destinoTemporalResultados, $datosVistaTransaccion, $archivos[$idJuego],2);
				$this->archivosPrevios($destinoTemporalSueldos, $datosVistaTransaccion, $archivos[$idJuego],2);

				$datosTransaccion['transaccion_activa']=2;
			}else if(in_array($idEstado, array(30,34,36))){//consolidación
				$datosTransaccion['nombre_file']=array();
				$af=0;
				$ap=0;
				$pr=0;
				$dr=0;
				$pc=0; // agregado MM 07-06-2017
				$vt=0; // agregado MM 19-09-2019
				$i=0;

				foreach ($archivos[$idJuego] as $archJuego) {
					if($archJuego['transaccion']==3 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='AP'){//apuestas
							$af++;
							$archivo['nombre']='apu_'.$af;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'AP', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Apuestas Ctrl.';
							else
								$archivo['buttonText']='Apuestas';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='AF'){//afectaciones
							$ap++;
							$archivo['nombre']='afe_'.$ap;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'AF', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Afectaciones Ctrl.';
							else
								$archivo['buttonText']='Afectaciones';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='PR'){//premios
							$pr++;
							$archivo['nombre']='pre_'.$pr;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'PR', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Premios Ctrl.';
							else
								$archivo['buttonText']='Premios';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='DR'){//premios retencion/detalle
							$dr++;
							$archivo['nombre']='dr_'.$dr;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'DR', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s'){//se usa para cdo son archivos individuales
								$archivo['buttonText']='Premios Ret. Ctrl.';
							}else{
								/*if($i==0){ //se usa para cdo son archivos individuales
									$archivo['buttonText']='Premios Ret. Det.';
									$i++;
								}else*/
									$archivo['buttonText']='Premios Ret.';
							}
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
                                                // AGREGADO MM - 07-06-2017 - ini
						else if($archJuego['tipo_archivo']=='PC'){//premios completo/retencion
							$pc++;
							$archivo['nombre']='pc_'.$pc;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'PC', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s'){//se usa para cdo son archivos individuales
								$archivo['buttonText']='Premios Completo Ctrl.';
							}else{
									$archivo['buttonText']='Premios Completo.';
							}
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						// AGREGADO MM - 07-06-2017 - fin
					
					// AGREGADO MM - inicio
						else if($archJuego['tipo_archivo']=='VT'){//ventas totales - ctasctes otras prov
							$vt++;
							$archivo['nombre']='vt_'.$vt;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'VT', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s'){//se usa para cdo son archivos individuales
								$archivo['buttonText']='Ventas Totales Ctrl.';
							}else{
								$archivo['buttonText']='Ventas Totales.';
							}
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						// AGREGADO MM - fin
						//$archivo['extension']=$archJuego['extension'];
						//revisar!!!
						$archivo['extension']=str_replace("+" ,"",str_replace("+[[:alpha:]]", "\w", $archJuego['extension']));
						$archivo['extension']=str_replace("C{1}","[C]",$archivo['extension']);
						$archivo['extension']=str_replace("P{1}","[P]",$archivo['extension']);
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}

				//según el estado cambia el btn
				$btn['id_btn']="btn_procesar";
				$btn['value_btn']="PROCESAR";
				array_push($datosVistaTransaccion['botones'], $btn);
				$datosVistaTransaccion['id_estado']=$idEstado;

				//chequeo si ya existe un archivo para apuestas
				$usuario = Session::get('usuarioLogueado.idUsuario');
				$ds = DIRECTORY_SEPARATOR;
				//paths a las carpetas 
				$destinoTemporalSinProcesar = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$nro_sorteo.$ds."apuestas";
				
				$this->archivosPrevios($destinoTemporalSinProcesar, $datosVistaTransaccion, $archivos[$idJuego],3);

				$datosTransaccion['transaccion_activa']=3;
			}else if(in_array($idEstado, array(38,40))){//consolidado-publicación pte
				$datosVistaTransaccion['id_estado']=$idEstado;
				$datosTransaccion['transaccion_activa']=3;
				//según el estado cambia el btn
				$btn['id_btn']="btn_publicar";
				$btn['value_btn']="PUBLICAR";
				array_push($datosVistaTransaccion['botones'], $btn);
				/*$btn['id_btn']="btn_ver_totales";
				$btn['value_btn']="VER&#x00A;TOTALES";
				array_push($datosVistaTransaccion['botones'], $btn);*/
				$datosVistaTransaccion['id_estado']=$idEstado;
				
				$datos = $this->servicioCuentaCorriente->datosPGMSorteo($nro_sorteo,$idJuego);//nl2br(htmlentities($cadena));
				$datosTransaccion['datos']="Cupones: ".$datos['tck_afe']."\nApuestas: ".$datos['apu_afe']."\nRecaudación: ".$datos['rec_afe']."\nPremios: ".$datos['pre_afe'];
			}else if(in_array($idEstado, array(45))){//probl. en public
				$datosVistaTransaccion['id_estado']=$idEstado;
				$datosTransaccion['transaccion_activa']=3;
				//según el estado cambia el btn
				$btn['id_btn']="btn_publicar";
				$btn['value_btn']="PUBLICAR";
				array_push($datosVistaTransaccion['botones'], $btn);
				/*$btn['id_btn']="btn_ver_totales";
				$btn['value_btn']="VER&#x00A;DIFERENCIAS";
				array_push($datosVistaTransaccion['botones'], $btn);*/
				$datosVistaTransaccion['id_estado']=$idEstado;
			}else if(in_array($idEstado, array(50))){//publicado
				$datosVistaTransaccion['id_estado']=$idEstado;
				$datosTransaccion['transaccion_activa']=4;
			}
			
			$datosVistaTransaccion['nombreFiles']=$archivosApedir;
			
			$datosTransaccion['id_estado']=$idEstado;
			$datosTransaccion['vista']= Response::liquidacion_apu_com($datosVistaTransaccion);
		}else{
			$datosTransaccion['puedeProcesar']=0;
			$datosTransaccion['id_estado']=$idEstado;
			if(in_array($idEstado, array(0,10,15))){
				$datosTransaccion['transaccion_activa']=1;
			}else if(in_array($idEstado, array(20,25))){
				$datosTransaccion['transaccion_activa']=2;
			}else if(in_array($idEstado, array(30,34,36))){
				$datosTransaccion['transaccion_activa']=3;
			}else if(in_array($idEstado, array(38,40,45))){
				$datosTransaccion['transaccion_activa']=3;
			}else if(in_array($idEstado, array(50))){
				$datosTransaccion['transaccion_activa']=4;
			}		
			$datosTransaccion['vista']= Response::liquidacion_apu_com($datosTransaccion);			
		}
		return $datosTransaccion;
	
	}

	/********************************************************
	* Función que obtiene los archivos para consolidación   *
	*********************************************************/
	/*public function obtenerArchivos(Request $request){
		\Log::info(' obtenerArchivos - Estoy recibiendo por post - Request: ',array($request));
		if($request->isMethod('post')){
			\Log::info(' obtenerArchivos - Estoy recibiendo por post - Request: ',array($request));	
			
			$sorteo2 = $request->input("sorteo");	
			
			\Log::info(' obtenerArchivos - Estoy recibiendo por post - Sorteo2: ',array($sorteo2));	
		}
		*/
	public function obtenerArchivos(){	
		$idJuego = Input::get('id_juego_seleccionado');
		$idEstado = Input::get('id_estado_seleccionado');
		$sorteo = Input::get('sorteo');
		$fechaSorteo = Input::get('fecha');
		$formatoProcesamiento = Input::get('id_formato_procesamiento');
		$entrada = Input::all();
		$usuario = Session::get('usuarioLogueado.idUsuario');
		
		\Log::info('MM - obtenerArchivos - entrada: ',array($entrada));	
		\Log::info('MM - obtenerArchivos - idJuego: ',array($idJuego));		
		\Log::info('MM - obtenerArchivos - idEstado: ',array($idEstado));	
		\Log::info('MM - obtenerArchivos - sorteo: ',array($sorteo));
		\Log::info('MM - obtenerArchivos - fechaSorteo: ',array($fechaSorteo));
		\Log::info('MM - obtenerArchivos - formatoProcesamiento: ',array($formatoProcesamiento));
		\Log::info('MM - obtenerArchivos - usuario: ',array($usuario));		
	
		//control si se debe reprocesar las apuestas
		if(Input::has('chk_reprocesar_apu')){
			$reprocesa=1;
		}else{
			$reprocesa=0;
		}

		$ds = DIRECTORY_SEPARATOR;
		list($af,$ap,$pr,$dr,$pc,$vt,$exito)=0;
		$apu_i=1;

		//paths a las carpetas destino
		try{
					
			list($anio,$mes,$dia)=explode("-",$fechaSorteo);

			}catch(\Exception $e){
				$mensaje=sprintf("Problema al intentar el vuelco - fallan variables fecha de sorteo...");
				\Log::info("obtenerArchivos - variables recibidas", array(Input::all()));
				\Log::info($e);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
			}

			
		$destinoFinalConsolidacion= $this->destinoFinalConsolidacion.$anio.$ds.$mes.$ds.$idJuego."_".$sorteo.$ds;
		$destinoTemporalSinProcesar = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		$destinoTemporalConsolidacion = $this->destinoTemporalConsolidacion.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		
		//creación de las carpetas
		if(!is_dir($destinoFinalConsolidacion) && !file_exists($destinoFinalConsolidacion)){
		  File::makeDirectory($destinoFinalConsolidacion, 0777, true);
		}
		if(!is_dir($destinoTemporalSinProcesar) && !file_exists($destinoTemporalSinProcesar)){
		  	File::makeDirectory($destinoTemporalSinProcesar, 0777, true);
		}else{
			$archivosSinProcesar=scandir($destinoTemporalSinProcesar);
		}
		if(!is_dir($destinoTemporalConsolidacion) && !file_exists($destinoTemporalConsolidacion)){
		  File::makeDirectory($destinoTemporalConsolidacion, 0777, true);
		}

		//vemos qué archivos deberían pedirse
		if(Session::has('tipoArchivoJuegoEstado')) {
			$archivos = Session::get('tipoArchivoJuegoEstado');
			\Log::info('MM - obtenerArchivos - archivos x session: ',array($archivos));		
		} else {
			$archivos = $this->servicioCuentaCorriente->especif_arch_x_juego();
			\Log::info('MM - obtenerArchivos - archivos x session: ',array($archivos));		
		}
		//archivos para el juego seleccionado
		$archivos=$archivos[$idJuego];
\Log::info('MM - obtenerArchivos - archivos x idJuego: ',array($archivos));		
		$util = new Util();
		$archivos=$util->groupArray($archivos,'tipo_archivo');
\Log::info('MM - obtenerArchivos - util->groupArray - archivos: ',array($archivos));			
		$listaTiposArchivos=array();
		$listaArchivosRequerimiento=array();
		// aqui se separan los archivos que vamos a procesar segun la configuracion de archivos!
		foreach ($archivos as $tiposArc) {
			array_push($listaArchivosRequerimiento,$tiposArc);
			array_push($listaTiposArchivos,$tiposArc['tipo_archivo']);
		}
		//vemos qué tipo de requerimiento tienen los archivos o=opcional, r=requerido
		$archivosRequerimientos=array();
		foreach ($listaArchivosRequerimiento as $archReq) {
			foreach ($archReq['grupodatos'] as $especificacion) {
				if($especificacion['transaccion']==3){
					$arReq[$archReq['tipo_archivo']]=$especificacion['requerido'];
					$archivosRequerimientos[$archReq['tipo_archivo']]=$arReq;	
				}
			};
		}

		$mensaje="TODO OK";
			
		//afectaciones está en la lista de archivos a de la transacción y es requerido u opcional
		if(in_array("AF", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['AF']['AF'],'R')==0 || strcasecmp($archivosRequerimientos['AF']['AF'],'O')==0)){//afectaciones
		
			try{
				//destino para los archivos de afectaciones
				$destinoTemporalConsolidacionAFE =$destinoTemporalSinProcesar."afectaciones".$ds;
				if(!is_dir($destinoTemporalConsolidacionAFE) && !file_exists($destinoTemporalConsolidacionAFE)){
				    File::makeDirectory($destinoTemporalConsolidacionAFE, $mode = 0777, true, true);
				}else{
					//\File::cleanDirectory($destinoTemporalConsolidacionAFE);
					array_map('unlink', glob($destinoTemporalConsolidacionAFE."*"));
					//\File::deleteDirectory($destinoTemporalConsolidacionAFE, $preserve = false);
				}
				
				//verifico cómo deben ser los archivos (individuales, padre=>nº de hijos)
				list($archivosHijos,$archivosPadres,$listaNombresInput)=array([],[],[]);
				$this->listasArchivos($archivos, $listaAfectaciones, $archivosHijos, $archivosPadres, "AF",3);
				$listaArchivos["afe_ctrl"]=array();
				$listaArchivos["afe_det"]=array();
				if(count($archivosPadres)>1){//son archivos unitarios
					$this->estanTodosLosArchivos($destinoTemporalConsolidacionAFE,"afectaciones","afe_",$archivosPadres, $listaArchivos);
					$af=1;
				}else{//hay un padre contenedor
					$af=2;					
					//verifico si existe uno anterior
					$destinoTemporalSinProcesarAF=$destinoTemporalSinProcesar.'afectaciones'.$ds;
					$archivosAF=array();
					
					foreach ($archivos as $tipoArchivo) {
						if(strcasecmp($tipoArchivo['tipo_archivo'], "AF")===0){
							$archivosAF=$tipoArchivo['grupodatos'];							
						}
					}
					
					$this->archivosPrevios($destinoTemporalSinProcesarAF,$previos, $archivosAF,3);
					$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"afe_", "afectaciones",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionAFE,$listaAfectaciones ,$idJuego,$listaArchivos, $previos);
					
					
					if(!$dezipeoOK['exito']){
						return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
					}
					
				}
				
			}catch(\Exception $e){
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"afectaciones");
				\Log::info($mensaje);
				\Log::info($e);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
			}
		}

		if(Input::hasFile("apu_".$apu_i) && in_array("AP", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['AP']['AP'],'R')==0 || strcasecmp($archivosRequerimientos['AP']['AP'],'O')==0)){//apuestas
			if($reprocesa){
				try{
				
					$destinoTemporalConsolidacionAP =$destinoTemporalSinProcesar."apuestas".$ds;
					if(!is_dir($destinoTemporalConsolidacionAP) && !file_exists($destinoTemporalConsolidacionAP)){
					  File::makeDirectory($destinoTemporalConsolidacionAP, 0777, true);
					}else{
						array_map('unlink', glob($destinoTemporalConsolidacionAP."*"));
					}
					
					$previos=array();
					$archivosHijos =array();
					$archivosPadres =array();
					$listaArchivos["apu_ctrl"]=array();
					$listaArchivos["apu_det"]=array();
					$this->listasArchivos($archivos, $listaApuestas, $archivosHijos, $archivosPadres, "AP",3);
					
					if(count($archivosPadres)>1){//son archivos unitarios
						$ap=1;
						$this->estanTodosLosArchivos($destinoTemporalConsolidacionAP,"apuestas","apu_",$archivosPadres,$listaArchivos);
					}else{//hay un padre contenedor
						
						$ap=2;
						$i=1;
						//verifico si existe uno anterior
						$destinoTemporalSinProcesarAP=$destinoTemporalSinProcesar.'apuestas'.$ds;
						$archivosAP=array();
						foreach ($archivos as $tipoArchivo) {
							if(strcasecmp($tipoArchivo['tipo_archivo'], "AP")===0)
								$archivosAP=$tipoArchivo['grupodatos'];
						}
						
						$this->archivosPrevios($destinoTemporalSinProcesarAP,$previos, $archivosAP,3);
						
						$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"apu_", "apuestas",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionAP,$listaApuestas ,$idJuego,$listaArchivos, $previos);			
						if(!$dezipeoOK['exito']){
							return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
						}
						
					}//fin padre contenedor
				}catch(\Exception $e){
					$mensaje=sprintf($this->error_carga_sorteos_diarios,"apuestas");
					\Log::info($mensaje);
					\Log::info($e);
					return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
				}
			}//fin reprocesa
		}else if(in_array("AP", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['AP']['AP'],'R')==0)){// || strcasecmp($archivosRequerimientos['AP']['AP'],'O')==0
			
			if($reprocesa){
				$mensaje=sprintf($this->err_falta_archivo,'apuestas'); 
				\Log::info($mensaje);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
			}
			
			$ap=2;//porque se que es un zip... ¿y si no lo fuera?
			//verifico si existe uno anterior
			$destinoTemporalSinProcesarAP=$destinoTemporalSinProcesar.'apuestas'.$ds;
			
			$archivosAP=array();
			foreach ($archivos as $tipoArchivo) {
				if(strcasecmp($tipoArchivo['tipo_archivo'], "AP")===0)
					$archivosAP=$tipoArchivo['grupodatos'];
			}
			
			$this->archivosPrevios($destinoTemporalSinProcesarAP,$previos, $archivosAP,3);
			
			if($previos['archivosPrevios']['existenArchivosPrevios']){
				$archPrev = $previos['archivosPrevios']['archivos'];
				foreach ($archPrev as $prev) {
					foreach($prev['nombre_archivo'] as $p){
							$archivoApu=$p;
					}
				}
			}else{
			   	$mensaje=sprintf($this->err_falta_archivo,'apuestas');
				\Log::info($mensaje);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
			}	
			$archivoApu=$destinoTemporalSinProcesarAP.$archivoApu;
			$destinoTemporalConsolidacionAP =$destinoTemporalSinProcesar."apuestas".$ds;
			if(!is_dir($destinoTemporalConsolidacionAP) && !file_exists($destinoTemporalConsolidacionAP)){
			  File::makeDirectory($destinoTemporalConsolidacionAP, 0777, true);
			}
			$archivosHijos =array();
			$archivosPadres =array();
			$listaArchivos["apu_ctrl"]=array();
			$listaArchivos["apu_det"]=array();
			$this->listasArchivos($archivos, $listaApuestas, $archivosHijos, $archivosPadres, "AP",3);
				
			$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"apu_", "apuestas",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionAP,$listaApuestas ,$idJuego,$listaArchivos, $previos);			
			if(!$dezipeoOK['exito']){
				return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
			}
	}
        /*********** agregado MM - 08-06-2017	*******************/
	
		if(in_array("PC", $listaTiposArchivos)&& (strcasecmp($archivosRequerimientos['PC']['PC'],'R')==0 || strcasecmp($archivosRequerimientos['PC']['PC'],'O')==0)){//premios
		try{
			
			$destinoTemporalConsolidacionPC =$destinoTemporalSinProcesar."premios_completo".$ds;
			if(!is_dir($destinoTemporalConsolidacionPC) && !file_exists($destinoTemporalConsolidacionPC)){
			  File::makeDirectory($destinoTemporalConsolidacionPC, 0777, true);
			}else{
				//\File::cleanDirectory($destinoTemporalConsolidacionPC);
				array_map('unlink', glob($destinoTemporalConsolidacionPC."*"));
			}
			
			$previos=array();
			$archivosHijos =array();
			$archivosPadres =array();
			$listaArchivos['pc_ctrl']=array();
			$listaArchivos['pc_det']=array();
			$listaArchivos['pc_ret']=array();
			$this->listasArchivos($archivos, $listaPremios, $archivosHijos, $archivosPadres, "PC",3);
			//\Log::info('archivosPadres',array($archivosPadres));
			
			if(count($archivosPadres)>1){//son archivos unitarios
				$pc=1;				
				$this->estanTodosLosArchivos($destinoTemporalConsolidacionPC,"premios_completo","pc_",$archivosPadres, $listaArchivos);
			}else{//hay un padre contenedor
					$pc=2;
					//verifico si existe uno anterior
					$destinoTemporalSinProcesarPR=$destinoTemporalSinProcesar.'premios_completo'.$ds;
					$archivosPC=array();
					foreach ($archivos as $tipoArchivo) {
						if(strcasecmp($tipoArchivo['tipo_archivo'], "PC")===0)
							$archivosPR=$tipoArchivo['grupodatos'];
					}
			
					$this->archivosPrevios($destinoTemporalSinProcesarPR,$previos, $archivosPR,3);
					$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"pc_", "premios_completo",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionPC,$listaPremios ,$idJuego,$listaArchivos, $previos);
					if(!$dezipeoOK['exito']){
						return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
					}

			}
		}catch(\Exception $e){
			$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios_completo");
			\Log::info($mensaje);
			\Log::info($e);
			return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		}
		
	}
	
	
	
	
	
	/*********** agregado MM - 08-06-2017 fin	*******************/
	if(in_array("PR", $listaTiposArchivos)&& (strcasecmp($archivosRequerimientos['PR']['PR'],'R')==0 || strcasecmp($archivosRequerimientos['PR']['PR'],'O')==0)){//premios
		try{
			
			$destinoTemporalConsolidacionPR =$destinoTemporalSinProcesar."premios".$ds;
			if(!is_dir($destinoTemporalConsolidacionPR) && !file_exists($destinoTemporalConsolidacionPR)){
			  File::makeDirectory($destinoTemporalConsolidacionPR, 0777, true);
			}else{
				//\File::cleanDirectory($destinoTemporalConsolidacionPR);
				array_map('unlink', glob($destinoTemporalConsolidacionPR."*"));
			}
			
			$previos=array();
			$archivosHijos =array();
			$archivosPadres =array();
			$listaArchivos['pre_ctrl']=array();
			$listaArchivos['pre_det']=array();
			$this->listasArchivos($archivos, $listaPremios, $archivosHijos, $archivosPadres, "PR",3);
			
			if(count($archivosPadres)>1){//son archivos unitarios
				$pr=1;				
				$this->estanTodosLosArchivos($destinoTemporalConsolidacionPR,"premios","pre_",$archivosPadres, $listaArchivos);
			}else{//hay un padre contenedor
					$pr=2;
					//verifico si existe uno anterior
					$destinoTemporalSinProcesarPR=$destinoTemporalSinProcesar.'premios'.$ds;
					$archivosPR=array();
					foreach ($archivos as $tipoArchivo) {
						if(strcasecmp($tipoArchivo['tipo_archivo'], "PR")===0)
							$archivosPR=$tipoArchivo['grupodatos'];
					}
			
					$this->archivosPrevios($destinoTemporalSinProcesarPR,$previos, $archivosPR,3);
					$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"pre_", "premios",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionPR,$listaPremios ,$idJuego,$listaArchivos, $previos);
					if(!$dezipeoOK['exito']){
						return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
					}
					
				
			}
		}catch(\Exception $e){
			$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios");
			\Log::info($mensaje);
			\Log::info($e);
			return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		}
		
	}

	if(in_array("DR", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['DR']['DR'],'R')==0 || strcasecmp($archivosRequerimientos['DR']['DR'],'O')==0)){//premios retención/detalle
		try{
			$destinoTemporalConsolidacionDR =$destinoTemporalSinProcesar."premios_retenciones".$ds;
			if(!is_dir($destinoTemporalConsolidacionDR) && !file_exists($destinoTemporalConsolidacionDR)){
			    File::makeDirectory($destinoTemporalConsolidacionDR, $mode = 0777, true, true);
			}else{
				array_map('unlink', glob($destinoTemporalConsolidacionDR."*"));
			}
			$previos=array();
			$archivosHijos =array();
			$archivosPadres =array();
			$this->listasArchivos($archivos, $listaDR, $archivosHijos, $archivosPadres, "DR",3);
			$listaArchivos['dr_ctrl']=array();
			$listaArchivos['dr_det']=array();				
			$listaNombresInput=array();
			if(count($archivosPadres)>1){//son archivos unitarios
				$dr=1;
				$this->estanTodosLosArchivos($destinoTemporalConsolidacionDR,"premios retencion","dr_",$archivosPadres, $listaArchivos);
			}else{//hay un padre contenedor
				$dr=2;
				//verifico si existe uno anterior
				$destinoTemporalSinProcesarRet=$destinoTemporalSinProcesar.'premios_retenciones'.$ds;
				$archivosDR=array();
				foreach ($archivos as $tipoArchivo) {
					if(strcasecmp($tipoArchivo['tipo_archivo'], "DR")===0)
						$archivosDR=$tipoArchivo['grupodatos'];
				}
				$this->archivosPrevios($destinoTemporalSinProcesarRet,$previos, $archivosDR,3);
				$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"dr_", "premios retenciones",$archivosPadres,$archivosHijos, $destinoTemporalSinProcesarRet,$listaDR ,$idJuego,$listaArchivos, $previos);					
				if(!$dezipeoOK['exito']){
					return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
				}
			}
			
		}catch(\Exception $e){
			$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios retención");
			\Log::info($mensaje);
			\Log::info($e);
			return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		}
		
	}

	/*********** agregado MM - 19-09-2019 inicio	*******************/
	/********************* MM ventas totales **************************/
	if(in_array("VT", $listaTiposArchivos)&& (strcasecmp($archivosRequerimientos['VT']['VT'],'R')==0 || strcasecmp($archivosRequerimientos['VT']['VT'],'O')==0)){ // ventas totales
		try{
			
			$destinoTemporalConsolidacionVT =$destinoTemporalSinProcesar."ventas_totales".$ds;
			if(!is_dir($destinoTemporalConsolidacionVT) && !file_exists($destinoTemporalConsolidacionVT)){
			  File::makeDirectory($destinoTemporalConsolidacionVT, 0777, true);
			}else{
				array_map('unlink', glob($destinoTemporalConsolidacionVT."*"));
			}
			
			$previos=array();
			$archivosHijos =array();
			$archivosPadres =array();
			$listaArchivos['vt_ctrl']=array();
			$listaArchivos['vt_det']=array();
			$listaArchivos['vt_rev']=array();
			$listaArchivos['vt_sos']=array();
			$listaArchivos['vt_ret']=array();
				
			$this->listasArchivos($archivos, $listaVentas, $archivosHijos, $archivosPadres, "VT",3);
			\Log::info('MM - in_array "VT" - archivosPadres: ',array($archivosPadres));
			\Log::info('MM - in_array "VT" - archivosHijos: ',array($archivosHijos));
			\Log::info('MM - in_array "VT" - listaVentas: ',array($listaVentas));
			\Log::info('MM - in_array "VT" - count archivosPadres: ',array(count($archivosPadres)));
			
			if(count($archivosPadres)>1){//son archivos unitarios
				$vt=1;				
				$this->estanTodosLosArchivos($destinoTemporalConsolidacionVT,"ventas_totales","vt_",$archivosPadres, $listaArchivos);
			}else{//hay un padre contenedor
			
				\Log::info('MM - in_array "VT" hay un padre contenedor');
			
				$vt=2;
				//verifico si existe uno anterior
				$destinoTemporalSinProcesarVT=$destinoTemporalSinProcesar.'ventas_totales'.$ds;
				$archivosVT=array();
				foreach ($archivos as $tipoArchivo) {
					if(strcasecmp($tipoArchivo['tipo_archivo'], "VT")===0)
						$archivosVT=$tipoArchivo['grupodatos'];
				}
		
				$this->archivosPrevios($destinoTemporalSinProcesarVT,$previos, $archivosVT,3);
				
				\Log::info('MM - in_array "VT" hay un padre contenedor - listaArchivos',array($listaArchivos));
				
				$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"vt_", "ventas_totales",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionVT,$listaVentas ,$idJuego,$listaArchivos, $previos);
				\Log::info('MM - in_array "VT" dezipeoOK',array($dezipeoOK));
				if(!$dezipeoOK['exito']){
					return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
				}else{
					$exito = 1;
				}
			}
		}catch(\Exception $e){
			$mensaje=sprintf($this->error_carga_sorteos_diarios,"ventas_totales");
			\Log::info($mensaje);
			\Log::info($e);
			return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		}
	}
	/*********** agregado MM - 19-09-2019 fin	*******************/
	
		//carga de los archivos
		if($af==1){
			$archivoAfe = $listaArchivos['afe_det'][0];		
			$archivoAfeCtrl = $listaArchivos['afe_ctrl'][0];
			$res=$this->archivosAfectaciones($archivoAfe, $archivoAfeCtrl, $destinoTemporalConsolidacionAFE,1);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,5);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;	
						\Log::info('MM -1255 -> ',array($exito));
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'afectaciones');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{//error carga archivos
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"afectaciones");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}else if($af==2){
			$archivoAfe = $listaArchivos['afe_det'][0];		
			$archivoAfeCtrl = $listaArchivos['afe_ctrl'][0];		
			$okAfe=$this->servicioAfectaciones->cargarAfectacion($archivoAfe);
			$okCtrlAfe=$this->servicioAfectaciones->cargarAfectacionControl($archivoAfeCtrl, $archivoAfe);
			if($okAfe && $okCtrlAfe){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,5);
				
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;	
						\Log::info('MM -1276 -> ',array($exito));
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'afectaciones');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"afectaciones");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}

		if($ap==1 && $exito==1 && $reprocesa){
			$archivoApu = $listaArchivos['apu_det'][0];		
			$archivoApuCtrl = $listaArchivos['apu_ctrl'][0];
			
			$res=$this->archivosApuestas($archivoApu, $archivoApuCtrl, $destinoTemporalConsolidacionAP,1,$idJuego, $formatoProcesamiento);
			
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,2);
				
				if($sorteoCorrecto==1){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'apuestas');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"apuestas");	
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}else if($ap==2 && $exito==1 && $reprocesa){
			$archivoApu = $listaArchivos['apu_det'][0];		
			$archivoApuCtrl = $listaArchivos['apu_ctrl'][0];
			$okCtrlApu=$this->servicioApuestas->cargarApuestasControl($archivoApuCtrl, $archivoApu,$idJuego);
			$okApu=$this->servicioApuestas->cargarApuestas($archivoApu, $idJuego, $formatoProcesamiento);
			
			if($okApu && $okCtrlApu){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,2);
				
				if($sorteoCorrecto==1){					
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'apuestas');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       											
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"apuestas");	
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}

		if($pr==1 && $exito==1){
			$archivoPr = $listaArchivos['pre_det'][0];	
			$archivoPreCtrl = $listaArchivos['pre_ctrl'][0];
			$res=$this->archivosPremios($archivoPr, $archivoPreCtrl, $destinoTemporalConsolidacionPR,1,$idJuego);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,3);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       										
			}
		}else if($pr==2 && $exito==1){
			$archivoPr = $listaArchivos['pre_det'][0];		
			$archivoPreCtrl = $listaArchivos['pre_ctrl'][0];
			$okCtrlPre=$this->servicioPremios->cargarPremiosControl($archivoPreCtrl, $archivoPr);
			$okPre=$this->servicioPremios->cargarPremio($archivoPr);
			if($okPre && $okCtrlPre){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,3);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;			
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}

		if($dr==1){
			$archivosDr = $listaArchivos['dr_det'];		
			$archivoDrCtrl = $listaArchivos['dr_ctrl'][0];
			$res=$this->archivosPremiosRetencion($archivosDr, $archivoDrCtrl, $destinoTemporalConsolidacionDR,1,1);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,6);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios retencion');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{//error carga archivos
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios retención");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}else if($dr==2){
			$archivosDr = $listaArchivos['dr_det'];	
			$archivosDr=array_unique($archivosDr);		
			$archivoDrCtrl = $listaArchivos['dr_ctrl'][0];
			/*foreach($archivosDr as $archivoDr)
				$okDr=$this->servicioPremios->cargarPremiosRetDet($archivoDr);
			$okCtrlDr=$this->servicioPremios->cargarPremiosRetencionControl($archivoDrCtrl, $archivosDr);*/
			$res=$this->archivosPremiosRetencion($archivosDr, $archivoDrCtrl, $destinoTemporalConsolidacionDR,1,2);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,5);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios retencion');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios retención");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}
		/*********** agregado MM - 08-06-2017	*******************/
		if($pc==1 && $exito==1){
			
			$archivoPc = $listaArchivos['pc_det'][0];	
			// $archivoPcRet = $listaArchivos['pc_ret'][0];	
			$archivoPreComCtrl = $listaArchivos['pc_ctrl'][0];
			$res=$this->archivosPremios($archivoPc, $archivoPreComCtrl, $destinoTemporalConsolidacionPC,1,$idJuego);
			
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,3);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios_completo');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios_completo");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       										
			}
		}else if($pc==2 && $exito==1){
			
			
			// $archivoPc = $listaArchivos['pc_det'][0];	
			// $archivoPcRet = $listaArchivos['pc_ret'][0];
			$archivoPreComCtrl = $listaArchivos['pc_ctrl'][0];
			
			foreach ($listaArchivos['pc_det'] as $Arch) {
				\Log::info('lista archivos aden -> ',array($Arch));
				
				$ext = strtoupper(substr($Arch, -3));
				switch ($ext) {
					case "RET":
						$okPreRetC=$this->servicioPremios->cargarPremiosCompletoRetDet($Arch);
						$archivoPcRet = $Arch;
						\Log::info('okPreRetC',array($okPreRetC));
						break;
					case "PRE":
						$okPreC=$this->servicioPremios->cargarPremioCompleto($Arch, $idJuego);
						$archivoPc = $Arch;
						\Log::info('okPreC',array($okPreC));
						break;
				}
			}
			
			\Log::info('archivoPc',array($archivoPc));
			\Log::info('archivoPcRet',array($archivoPcRet));
			\Log::info('archivoPreComCtrl',array($archivoPreComCtrl));
			// carga archivo de control
			$okCtrlPreC=$this->servicioPremios->cargarPremiosCompletoControl($archivoPreComCtrl, $archivoPc, $archivoPcRet);

			if($okPreC && $okCtrlPreC && $okPreRetC){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,3);
				\Log::info('sorteoCorrecto',array($sorteoCorrecto));
				if($sorteoCorrecto){
					$exito=1;
				}else{
				
					$exito=0;			
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios_completo');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios_completo");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}
		
		/****** ventas totales	inicio 20/09/2019 **************/
// MM-24
		if($vt==1 && $exito==1){
			
			$archivoVt = $listaArchivos['vt_det'][0];	
			$archivoVtRet = $listaArchivos['vt_ret'][0];	
			$archivoVtComCtrl = $listaArchivos['vt_ctrl'][0];
			if($idJuego == '4'){
				$archivoVtSos = $listaArchivos['vt_sos'][0];
				$archivoVtRev = $listaArchivos['vt_rev'][0];
			}
			
			$res=$this->archivosVentas($archivoVt, $archivoVtComCtrl, $destinoTemporalConsolidacionVT,1,$idJuego);
			
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,3);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'ventas_totales');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"ventas_totales");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       										
			}
		}else if($vt==2 && $exito==1){
			\Log::info('MM - vt==2 listaArchivos: ',array($listaArchivos));
			$archivoVt 			= $listaArchivos['vt_det'][0];	
			//$archivoVtComCtrl 	= $listaArchivos['vt_ctrl'][0];
			

			\Log::info('MM - listaArchivos[vt_det]',array($listaArchivos['vt_det']));
			\Log::info('MM - archivoVt',array($archivoVt));
			//\Log::info('MM - archivoVtComCtrl',array($archivoVtComCtrl));
			
	
			foreach ($listaArchivos['vt_det'] as $Arch) {
				\Log::info('lista archivos aden -> ',array($Arch));
				
				if (stristr($Arch,'ttran') !== FALSE || stristr($Arch,'totatran') !== FALSE) {
					$okDet=$this->servicioVentasTotales->cargarVtDat($Arch,$idJuego,$sorteo,$usuario); // ttranBR
				}
				
				if (stristr($Arch,'liqvta') !== FALSE ||stristr($Arch,'liqven') !== FALSE) {
					$ext = strtoupper(substr($Arch, -3));
					switch ($ext) {
						case "1ER":
							$okVtModalid=$this->servicioVentasTotales->cargarVtModalidades($Arch,$idJuego,$sorteo,$usuario,'1'); // liqvta 
							break;
						case "REV":
							$okVtModalid=$this->servicioVentasTotales->cargarVtModalidades($Arch,$idJuego,$sorteo,$usuario,'3'); // liqvta 
							break;
						case "SOS":
							$okVtModalid=$this->servicioVentasTotales->cargarVtModalidades($Arch,$idJuego,$sorteo,$usuario,'7'); // liqvta 
							break;
					}
				}
				if (stristr($Arch,'reserv') !== FALSE) {
						$okRes=$this->servicioVentasTotales->cargarVtRes($Arch,$usuario,$idJuego);
				}
			}

				\Log::info('Vuelco cargarVtDat ok -> ',array($okDet));
				\Log::info('Vuelco okVtModalid ok -> ',array($okRes));
				\Log::info('Vuelco cargarVtRes ok -> ',array($okRes));

			if($okDet && $okVtModalid && $okRes){
				// aqui no podemos hacer la validacion ya que en este momento aun no tenemos el idproceso que se utiliza para insartar las auditorias en el SP de validacion, en los otros SP de validacion no se utiliza el idproceso
					//$VentasTotalesCorrecto=$this->servicioVentasTotales->valida_ctasctes($idJuego,$sorteo,$usuario);
					//\Log::info('VentasTotalesCorrecto',array($VentasTotalesCorrecto));
				//	if(strtoupper($VentasTotalesCorrecto) == 'OK'){
				$exito=1;
					//}
				\Log::info('Vuelcos sobre REC de ventas totales finalizado correctamente.');
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"ventas_totales");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
	
			//	return Response::json(array('exito'=>0, 'mensaje'=>'xyz','estado'=>30, 'srcImagen'=>$this->srcImgError));       						

		}
		
		/****** ventas totales	fin 20/09/2019 **************/
		
		
		/*********** agregado MM - 08-06-2017	FIN *******************/
		if($exito){
			//llamo al stored para consolidar
			$idProceso=$this->servicioCuentaCorriente->getNumeroProcesoAuditoriaCtaCte($idJuego, $sorteo);
			\Log::info('MM - idProceso',array($idProceso));
			// MM - 26-09-2019
			$VentasTotalesCorrecto=$this->servicioVentasTotales->valida_ctasctes($idJuego,$sorteo,$idProceso,$usuario);
			\Log::info('MM - VentasTotalesCorrecto',array($VentasTotalesCorrecto));
			if(strtoupper($VentasTotalesCorrecto) != 'OK'){
				$exito=0;
				$mensaje=sprintf($this->err_validacion_archivo,"ventas_totales");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));      	
			}	
			\Log::info('MM - antes de llamar a consolidar');
			$mensaje=$this->servicioCuentaCorriente->consolidar($idJuego, $sorteo, $fechaSorteo, $idProceso, $usuario);
			\Log::info('MM - despues de llamar a consolidar - mensaje:',array($mensaje));
			$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);					
			//si todo da ok armo la vista --> incluyo mensaje de cupones	
			if(strcasecmp (trim(strtoupper($mensaje)), 'OK') ==0){//consolidó correctamente
				if(isset($datos)){
					$idEstado=$datos['idEstado'];
					$idsorteo=$datos['idPgmSorteo'];
					$desc_estado=$datos['de_estado'];
					$mensaje = "Cupones: ".$datos['tck_afe']."\nApuestas: ".$datos['apu_afe']."\nRecaudación: ".$datos['rec_afe']."\nPremios: ".$datos['pre_afe'];
					$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
					if($reprocesa){
						$patron="/^apuestas+$/i";
						$this->moverZipFTP($destinoTemporalSinProcesar, $destinoTemporalSinProcesar,$idJuego,$sorteo,$patron);
					}
					
					$this->moverArchivosTemporalFinal($destinoTemporalSinProcesar,$destinoFinalConsolidacion,$idJuego,1);
					
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
				}else{//acá no debería entrar nunca
					$exito=0;
					$mensaje=sprintf($this->err_datos_sorteo, $sorteo);//ver si acá el estado es 30 o no...
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgPeligro));
				}
			}else{
				$exito=0;
				$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
				$idEstado=$datos['idEstado'];
				$idsorteo=$datos['idPgmSorteo'];
				$desc_estado=$datos['de_estado'];
				$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgError, 'datosTransaccion'=>$resultado));
				//return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>34, 'srcImagen'=>$this->srcImgError));
			}			
		}else{
			$exito=0;
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
		}
	}

	/********************************************************
	* Función que obtiene los archivos para carátula   *
	*********************************************************/
	public function obtenerArchivosCaratula(){
		$idJuego = Input::get('id_juego_seleccionado');
		$idEstado = Input::get('id_estado_seleccionado');
		$idsorteo = Input::get('id_seleccionado');
		$sorteo = Input::get('sorteo');
		$fechaSorteo = Input::get('fecha');
		$formatoProcesamiento = Input::get('id_formato_procesamiento');
		$usuario = Session::get('usuarioLogueado.idUsuario');
		$ds = DIRECTORY_SEPARATOR;
		$ap=0;
			\Log::info("obtenerArchivosCaratula - paso 1 - ",array(date("Y-m-d H:i:s")));
			\Log::info("obtenerArchivosCaratula - paso 1.1 - proviene de la sor_pgmsorteos idsorteo(id_seleccionado) ",array($idsorteo));
			
		//paths a las carpetas destino
		$destinoTemporalSinProcesar = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		$destinoFinal=$this->destinoFinalCaratula.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		if(!is_dir($destinoTemporalSinProcesar) && !file_exists($destinoTemporalSinProcesar)){
		  	\File::makeDirectory($destinoTemporalSinProcesar, 0777, true);
		}else{
			\File::cleanDirectory($destinoTemporalSinProcesar);
		}

		if(!is_dir($destinoFinal) && !file_exists($destinoFinal)){
		  	\File::makeDirectory($destinoFinal, 0777, true);
		}
		
		//obtenemos si requiere resultados
		$requiere=$this->servicioCuentaCorriente->requiereCarResSue($idJuego);
		\Log::info("obtenerArchivosCaratula - paso 2 - ",array(date("Y-m-d H:i:s")));
		//vemos qué archivos deberían pedirse
		// \Log::info("obtenerArchivosCaratula - paso 2 - ESTAN EN SESSION???",array(Session::has('tipoArchivoJuegoEstado')));
		if(Session::has('tipoArchivoJuegoEstado')) {
			$archivos = Session::get('tipoArchivoJuegoEstado');
			// \Log::info("obtenerArchivosCaratula - paso 2 - ESTAN EN SESSION???",array(Session::get('tipoArchivoJuegoEstado')));
		} else {
			$archivos = $this->servicioCuentaCorriente->especif_arch_x_juego();
		}

		//$ver = print_r($archivos, true);
		//\Log::info("obtenerArchivosCaratula - paso 2.2 - archivos - ",array($ver));
		\Log::info("obtenerArchivosCaratula - paso 2.2 - archivos - ",array($archivos));

		//archivos para el juego seleccionado
		try{
			$archivos=$archivos[$idJuego];

			}catch(\Exception $e){
				$mensaje=sprintf("Problema al intentar el vuelco - fallan variables fecha de sorteo...");
				\Log::info("obtenerArchivosCaratula - variables recibidas", array(Input::all()));
				\Log::info($e);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
			}
		
		\Log::info("obtenerArchivosCaratula - paso 3 - ",array(date("Y-m-d H:i:s")));
		\Log::info("obtenerArchivosCaratula - paso 3.1 - ",array($archivos));
		$util = new Util();
		$archivos=$util->groupArray($archivos,'tipo_archivo');
		
		//$ver = print_r($archivos, true);
		//\Log::info("obtenerArchivosCaratula - paso 3.2 - archivos - ",array($ver));
		\Log::info("obtenerArchivosCaratula - paso 3.2 - archivos - ",array($archivos));
		
		$listaTiposArchivos=array();
		$listaArchivosRequerimiento=array();
		foreach ($archivos as $tiposArc) {
			array_push($listaArchivosRequerimiento,$tiposArc);
			array_push($listaTiposArchivos,$tiposArc['tipo_archivo']);
		}
		$archivosRequerimientos=array();
		foreach ($listaArchivosRequerimiento as $archReq) {
			foreach ($archReq['grupodatos'] as $especificacion) {
				if($especificacion['transaccion']==1){
					$arReq[$archReq['tipo_archivo']]=$especificacion['requerido'];
					$archivosRequerimientos[$archReq['tipo_archivo']]=$arReq;	
				}
			};
		}
		\Log::info("obtenerArchivosCaratula - paso 4 - ",array(date("Y-m-d H:i:s")));
		$exito=0;
		$mensaje="OK";
/****************** APUESTAS CARATULA **************************************************/
		//APUESTAS - OPCIONAL => deja de ser opcional 12/16
			
		$archivosHijosA =array();
		$archivosPadresA =array();
		$this->listasArchivos($archivos, $listaApuestas, $archivosHijosA, $archivosPadresA, "AP",1);
		\Log::info("obtenerArchivosCaratula - paso 4b - ",array(date("Y-m-d H:i:s"), count($archivosPadresA)));
			
		$listaNombresInputA=array();
		
		if(count($archivosPadresA)>1){//son archivos unitarios
			$ap=1;
			$listaArchivos['apu_ctrl']=array();
			$listaArchivos['apu_det']=array();
			
		        \Log::info("obtenerArchivosCaratula - paso 4c - ",array(date("Y-m-d H:i:s")));
			$destino=$destinoTemporalSinProcesar."apuestas".$ds;
			$this->estanTodosLosArchivos($destino, "apuestas","apu_",$archivosPadresA,$listaArchivos);
		        \Log::info("obtenerArchivosCaratula - paso 4d - ",array(date("Y-m-d H:i:s")));
		        \Log::info("obtenerArchivosCaratula - paso 4d - archivosPadresA ",array($archivosPadresA));
		        \Log::info("obtenerArchivosCaratula - paso 4d - listaArchivos ",array($listaArchivos));
			
			if(!empty($listaNombresInputA)){//está todo ok
				$archivoApu = $listaArchivos['apu_det'][0];
				$archivoApuCtrl = $listaArchivos['apu_ctrl'][0];
				//nombres - extensiones
				$nombreApu = $archivoApu->getClientOriginalName();
				$nombreApuCtrl = $archivoApuCtrl->getClientOriginalName();
				if(!is_dir($destino) && !file_exists($destino)){
				  \File::makeDirectory($destino, 0777, true);
				}else{
					array_map('unlink', glob($destino."*"));
				}				
				$destinoApu=$destino.$nombreApu;
				$destinoApuCtrl = $destino.$nombreApuCtrl;
				//movemos los archivo a la carpeta que corresponde
				\Log::info("obtenerArchivosCaratula - paso 4e - destinoApu",array($destinoApu));
				\Log::info("obtenerArchivosCaratula - paso 4e - nombreApu",array($nombreApu));
				\Log::info("obtenerArchivosCaratula - paso 4e - destinoApuCtrl",array($destinoApuCtrl));
				\Log::info("obtenerArchivosCaratula - paso 4e - archivoApuCtrl",array($archivoApuCtrl));
				$uploadSuccessApu = $archivoApu->move($destinoApu, $nombreApu);
				$uploadSuccessApuCtrl = $archivoApuCtrl->move($destinoApuCtrl, $archivoApuCtrl);
				$exito=0;
			}
			\Log::info("obtenerArchivosCaratula - paso 5 - ",array(date("Y-m-d H:i:s")));
		}else{//hay un padre contenedor
			$i=1;				
	        \Log::info("obtenerArchivosCaratula - paso 4c else - ",array(date("Y-m-d H:i:s")));
			if(Input::hasFile("apu_".$i)){
				$ap=2;
				$archivoApu = Input::file("apu_".$i);	
				$ver = var_export($archivoApu, true);
				\Log::info("obtenerArchivosCaratula - archivoApu - ",array($ver));
				$destino=$destinoTemporalSinProcesar."apuestas".$ds;				
				\Log::info("obtenerArchivosCaratula - destino - ",array($destino));
				if(!is_dir($destino) && !file_exists($destino)){
				  \File::makeDirectory($destino, 0777, true);
				}else{
					array_map('unlink', glob($destino."*"));
				}
				
				$previos=array();
				$archivosHijos =array();
				$archivosPadres =array();
				$listaArchivos["apu_ctrl"]=array();
				$listaArchivos["apu_det"]=array();

		        \Log::info("obtenerArchivosCaratula - paso 4d else - ",array(date("Y-m-d H:i:s")));
				$this->listasArchivos($archivos, $listaApuestas, $archivosHijos, $archivosPadres, "AP",1);

				\Log::info("MM obtenerArchivosCaratula - paso 5(arch padre) util- ",array($util));
				\Log::info("MM obtenerArchivosCaratula - paso 5(arch padre) archivosPadres- ",array($archivosPadres));
				\Log::info("MM obtenerArchivosCaratula - paso 5(arch padre) archivosHijos- ",array($archivosHijos));
				\Log::info("MM obtenerArchivosCaratula - paso 5(arch padre) destino- ",array($destino));
				\Log::info("MM obtenerArchivosCaratula - paso 5(arch padre) listaApuestas- ",array($listaApuestas));
				\Log::info("MM obtenerArchivosCaratula - paso 5(arch padre) idJuego- ",array($idJuego));
				\Log::info("MM obtenerArchivosCaratula - paso 5(arch padre) listaArchivos- ",array($listaArchivos));
				\Log::info("MM obtenerArchivosCaratula - paso 5(arch padre) previos- ",array($previos));
				
					
				$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"apu_", "apuestas",$archivosPadres,$archivosHijos, $destino,$listaApuestas ,$idJuego,$listaArchivos, $previos);			
				\Log::info("MM obtenerArchivosCaratula - dezipeoOK: ",array($dezipeoOK));
				if(!$dezipeoOK['exito']){
					//$mensaje=$resultado['mensaje'];
					$mensaje=$dezipeoOK['mensaje'];
					if($idEstado==15){
						$imagen= $this->srcImgError;
					}else{
						$imagen=$this->srcImgPeligro;
					}
					return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
					//return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
				}else{
						$exito=1;
					}
			}	
		\Log::info("obtenerArchivosCaratula - paso 6 - ",array(date("Y-m-d H:i:s")));
			
		}
		
		
	/****************** FIN APUESTAS CARATULA **************************************************/	
		
		
		//archivo de carátula
		$destinoTemporalCaratula =$destinoTemporalSinProcesar."caratula".$ds;
		if(in_array("CT", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['CT']['CT'],'R')==0 || strcasecmp($archivosRequerimientos['CT']['CT'],'O')==0)){//carátula
			try{
				if(!is_dir($destinoTemporalCaratula) && !file_exists($destinoTemporalCaratula)){
				  \File::makeDirectory($destinoTemporalCaratula, 0777, true);
				}else{
					array_map('unlink', glob($destinoTemporalCaratula."*"));
				}
				$archivosHijos =array();
				$archivosPadres =array();
				$this->listasArchivos($archivos, $listaCaratula, $archivosHijos, $archivosPadres, "CT",1);
			
				\Log::info("obtenerArchivosCaratula - paso 7 - ",array(date("Y-m-d H:i:s")));

				$listaNombresInput=array();
				if(count($archivosPadres)>1){//son archivos unitarios
					$ct=1;
					//armo los nombres de los input files que debe haber
					$i=0;
					for($x=0;$x<count($archivosPadres);$x++) {
						$i++;
					   	$nombreInputFile = "car_".$i;
					   	if(Input::hasFile($nombreInputFile)){
					   		$archivo = Input::file("car_".$i);
					   		array_push($listaNombresInput,$archivo);
					   	}else{
					   		$mensaje=sprintf($this->err_falta_archivo,'carátula');
							if($idEstado==15){
								$imagen= $this->srcImgError;
							}else{
								$imagen=$this->srcImgPeligro;
							}
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
					   	}
					}

					$archivoCar = $listaNombresInput[1];
					$archivoCarCtrl = $listaNombresInput[0];

				}else{//hay un padre contenedor
				
					$ct=2;
					$i=1;

					if(Input::hasFile("car_".$i) ){
					   	$archivoCar = Input::file("car_".$i);
					   	$resultado=$util->controlZip($archivoCar, $destinoTemporalCaratula, $listaCaratula, $idJuego);
					   	if($resultado['exito']){							
							//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($destinoTemporalCaratula);
							$ficheros1=array();
							foreach ($ficheros as $fichero) {
								$extension = explode(".",$fichero);
								if($extension[1]!='zip' && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
							
							if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
								$mensaje=sprintf($this->err_mas_archivos,"pozos.");
								\Log::info($mensaje);
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>15, 'srcImagen'=>$this->srcImgError));
							}

							foreach ($ficheros1 as $nombreFichero) {
								foreach ($archivosHijos as $hijo) {
									$patron="/^".$hijo['nombre'];
									if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
										$archivoCarCtrl = $destinoTemporalCaratula.$nombreFichero;
									}else if(strtolower($hijo['control'])=="s"){
										$archivoCar = $destinoTemporalCaratula.$nombreFichero;
									}
								}
							}
							
						}else{//ERROR DESCOMPRIMIR
							$mensaje=$resultado['mensaje'];
							\Log::info("Error al descomprimir", array($mensaje));
							if($idEstado==15){
								$imagen= $this->srcImgError;
							}else{
								$imagen=$this->srcImgPeligro;
							}
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
						}
				   }else if(strcasecmp($archivosRequerimientos['CT']['CT'],'O')==0){//es opcional y no subió nada
							$ct=0;
				   			$exito=1;
				   }else{//no subió nada y no es opcional
					   	$mensaje=sprintf($this->err_falta_archivo,'pozos');
						\Log::info($mensaje);
						if($idEstado==15){
							$imagen= $this->srcImgError;
						}else{
							$imagen=$this->srcImgPeligro;
						}
						return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
				   }
					
				}
				
				\Log::info("obtenerArchivosCaratula - paso 8 - ",array(date("Y-m-d H:i:s")));

			}catch(\Exception $e){
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"pozos");
				\Log::info($mensaje);
				\Log::info($e);
				if($idEstado==15){
					$imagen= $this->srcImgError;
				}else{
					$imagen=$this->srcImgPeligro;
				}
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
			}
			
		}else{//no necesita carátula
			$exito=1;
			$ct=3;
		}

		if(isset($ct) && $ct==1){
			$res=$this->archivosCaratula($archivoCar, $archivoCarCtrl, $destinoTemporalCaratula,1,$idJuego, $formatoProcesamiento);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'carátula');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"carátula");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
			}
		\Log::info("obtenerArchivosCaratula - paso 9 - ",array(date("Y-m-d H:i:s")));

		}else if(isset($ct) && $ct==2){
			$okCtrlCar=$this->servicioCaratulas->cargarCaratulaControl($archivoCarCtrl, $archivoCar);
			$okCar=$this->servicioCaratulas->cargarCaratula($archivoCar);
			if($okCtrlCar && $okCar){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'carátula');
					\Log::info(array($mensaje, $sorteo, $idJuego));
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"carátula");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
			}
		\Log::info("obtenerArchivosCaratula - paso 10 - ",array(date("Y-m-d H:i:s")));
		}

		//control sorteo archivo apuesta
		
		if($ap==1){
			$archivoApu = $listaArchivos['apu_det'][0];		
			$archivoApuCtrl = $listaArchivos['apu_ctrl'][0];
			$res=$this->archivosApuestas($archivoApu, $archivoApuCtrl, $destinoTemporalCaratula,1,$idJuego, $formatoProcesamiento);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,2);
				if($sorteoCorrecto){
					$patron="/^apuestas+$/i";
					$this->moverZipFTP($destinoTemporalSinProcesar, $destinoTemporalSinProcesar,$idJuego,$sorteo,$patron);
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'apuestas');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"carátula");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
			}
		\Log::info("obtenerArchivosCaratula - paso 11 - ",array(date("Y-m-d H:i:s")));
		}else if($ap==2){
			$archivoApu = $listaArchivos['apu_det'][0];		
			$archivoApuCtrl = $listaArchivos['apu_ctrl'][0];
			$okCtrlApu=$this->servicioApuestas->cargarApuestasControl($archivoApuCtrl, $archivoApu,$idJuego);
			$okApu=$this->servicioApuestas->cargarApuestas($archivoApu, $idJuego, $formatoProcesamiento);

			if($okApu && $okCtrlApu){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,2);
				
				if($sorteoCorrecto=="1"){
					$patron="/^apuestas+$/i";
					\Log::info("obtenerArchivosCaratula - paso 11.1 - ",array(date("Y-m-d H:i:s")));
					$this->moverZipFTP($destinoTemporalSinProcesar, $destinoTemporalSinProcesar,$idJuego,$sorteo,$patron);
					\Log::info("obtenerArchivosCaratula - paso 11.2 - ",array(date("Y-m-d H:i:s")));
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'apuestas');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       											
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"apuestas");	
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
			}
			\Log::info("obtenerArchivosCaratula - paso 12 - ",array(date("Y-m-d H:i:s")));
		}
			
		if($exito==1){
			
			\Log::info($sorteo);
			\Log::info("obtenerArchivosCaratula - paso 13 - ",array(date("Y-m-d H:i:s")));
//			$okInsertaPGM=$this->servicioCuentaCorriente->insertaPGM($idJuego, $fechaSorteo); -- modificado ADEN - 2025-05-09 ahora hay que pasar el sorteo!
			$okInsertaPGM=$this->servicioCuentaCorriente->insertaPGM($idJuego, $sorteo);
			\Log::info("obtenerArchivosCaratula - paso 14 - ",array(date("Y-m-d H:i:s"), $okInsertaPGM));
			$nro=$this->servicioCuentaCorriente->getNumeroProcesoAuditoriaCtaCte($idJuego, $sorteo);
			
			if(isset($ct) && ($ct==2 || $ct==1) ){
				\Log::info('ct',array($ct));
				\Log::info('datos caratula::: ',array($nro.'--'.$idJuego.'--'.$sorteo.'--'.$mensaje.'--'.$usuario.'--'.$idEstado));
				
				$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
				if(isset($datos)){
					$idEstado=$datos['idEstado'];
					$idsorteo=$datos['idPgmSorteo'];
					$desc_estado=$datos['de_estado'];
					$id_pgmsorteo=$datos['id']; // agregado - 2025-09-01 - aden - necesito el id_pgmsorteo
				
					// ************************************************** 2025-08-29 - INI - ADEN - MANDO EL MENSAJE DE INICIO DE SORTEO ***************************************************

					// Envío el mensaje

					if ($idJuego == 4 || $idJuego == 13 || $idJuego == 30) {   // se agrega que solo despache mensajes de quini6 y brinco - aden - 2025-11-07 - agrega la pf aden 2025-1120
						// Armo el contenido del mensaje
						$datos_mensaje = array(
							'topic' => 'inicio_sorteo',
							'message' => array(
								'id_sorteo' => $id_pgmsorteo,
								'id_producto' => $idJuego,
								'nro_sorteo' => $sorteo
							)
						);
						\Log::info("obtenerArchivosCaratula - paso 14z - Envío del mensaje al Middleware", $datos_mensaje);
						
						// ini hasta tener el middleware
						$envio=$this->enviaMensajeMiddleware($datos_mensaje);
						
						if (!$envio){
							$log = "obtenerArchivosCaratula - paso 15b - Fallo el envío del mensaje al Middleware '" . $datos_mensaje['topic'] . "'.";
							\Log::info($log, array($envio));
						}			
					}
				}else{
					$exito=0;
					$mensaje=sprintf($this->err_datos_sorteo, $sorteo);
					if($idEstado==15){
						$imagen= $this->srcImgError;
					}else{
						$imagen=$this->srcImgPeligro;
					}
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));						
				}

				// ************************************************** 2025-08-29 - FIN - ADEN - MANDO EL MENSAJE DE FIN DE CARATULA OK ***************************************************
				
				$okValidaCaratula=$this->servicioCaratulas->validaCaratula($nro,$idJuego, $sorteo, $mensaje, $usuario, $idEstado);
				\Log::info("obtenerArchivosCaratula - paso 15 - ",array(date("Y-m-d H:i:s")));
				if($okValidaCaratula){
					// Tengo que volver a buscar el estado porque validaCaratula lo cambio de 10 a 20!!!
					$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
					if(isset($datos)){
						$idEstado=$datos['idEstado'];
						$idsorteo=$datos['idPgmSorteo'];
						$desc_estado=$datos['de_estado'];
						$id_pgmsorteo=$datos['id']; // agregado - 2025-09-01 - aden - necesito el id_pgmsorteo

						$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
						if($idEstado==15){
							$exito=0;
						}else{//proceso de carátula terminado
							$this->moverArchivosTemporalFinal($destinoFinal,$destinoTemporalCaratula,$idJuego);
							
						// ************************************************** 2025-08-29 - INI - ADEN - MANDO EL MENSAJE DE FIN DE CARATULA OK ***************************************************
			
						// Envío el mensaje

						if ($idJuego == 4 || $idJuego == 13 || $idJuego == 30) {   // se agrega que solo despache mensajes de quini6 y brinco - aden - 2025-11-07 - agrega la pf aden 2025-1120
							// Armo el contenido del mensaje
							$datos_mensaje = array(
								'topic' => 'caratulas_recibidas',
								'message' => array(
									'id_sorteo' => $id_pgmsorteo,
									'id_producto' => $idJuego,
									'nro_sorteo' => $sorteo
								)
							);
							\Log::info("obtenerArchivosCaratula - paso 15a - Envío del mensaje al Middleware", $datos_mensaje);
							
							// ini hasta tener el middleware
							$envio=$this->enviaMensajeMiddleware($datos_mensaje);
							// $envio = true;
							// fin hasta tener el middleware
							
							if (!$envio){
								$log = "obtenerArchivosCaratula - paso 15b - Fallo el envío del mensaje al Middleware '" . $datos_mensaje['topic'] . "'.";
								\Log::info($log, array($envio));
							}			
						}
						
						// ************************************************** 2025-08-29 - FIN - ADEN - MANDO EL MENSAJE DE FIN DE CARATULA OK ***************************************************
							
						}
						\Log::info("obtenerArchivosCaratula - paso 15c - Devuelvo OK a la pantalla", 
										array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
					}else{
						$exito=0;
						$mensaje=sprintf($this->err_datos_sorteo, $sorteo);
						if($idEstado==15){
							$imagen= $this->srcImgError;
						}else{
							$imagen=$this->srcImgPeligro;
						}
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));						
					}
				}else{//valida carátula
					$exito=0;
					$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
					$idEstado=$datos['idEstado'];
					$idsorteo=$datos['idPgmSorteo'];
					$desc_estado=$datos['de_estado'];
					$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
					if($idEstado==15){
						$imagen= $this->srcImgError;
					}else{
						$imagen=$this->srcImgPeligro;
					}
						
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$imagen, 'datosTransaccion'=>$resultado));

					//return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>15, 'srcImagen'=>$this->srcImgPeligro));
				}
			}else if($ct==3){
				$this->servicioCuentaCorriente->insertaAuditoria($nro,$idJuego, $sorteo,1,$usuario,10,10,"Inicio Procesar carátula.");
			}
			\Log::info("obtenerArchivosCaratula - paso 16 - ",array(date("Y-m-d H:i:s")));
			if($okInsertaPGM){
				//actualizo el estado del pgmsorteo
				if($requiere['requiere_res'])//requiere resultados
					$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,20);
				else
					$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,30);
				\Log::info("obtenerArchivosCaratula - paso 17 - ",array(date("Y-m-d H:i:s")));
				if($okActualizacion){
				
					$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
							
					if(isset($datos)){
						$idEstado=$datos['idEstado'];
						$idsorteo=$datos['idPgmSorteo'];
						$desc_estado=$datos['de_estado'];
						if($ct==3){
							$this->servicioCuentaCorriente->insertaAuditoria($nro,$idJuego, $sorteo,1,$usuario,10,$idEstado,"Ok carátula.");
						}
						$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
					}else{
						$exito=0;
						$mensaje=sprintf($this->err_datos_sorteo, $sorteo);
						if($idEstado==15){
							$imagen= $this->srcImgError;
						}else{
							$imagen=$this->srcImgPeligro;
						}
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
					}
					\Log::info("obtenerArchivosCaratula - paso 18 - ",array(date("Y-m-d H:i:s")));
				}else{
					$exito=0;
					$mensaje="Problema al actualizar el estado";
					if($idEstado==15){
						$imagen= $this->srcImgError;
					}else{
						$imagen=$this->srcImgPeligro;
					}
					\Log::info("obtenerArchivosCaratula - paso 19 - ",array(date("Y-m-d H:i:s")));
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->err_proces,'carátula');
				if($idEstado==15){
					$imagen= $this->srcImgError;
				}else{
					$imagen=$this->srcImgPeligro;
				}
				\Log::info("obtenerArchivosCaratula - paso 20 - ",array(date("Y-m-d H:i:s")));
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
			}
			
			
		}else{
			if($idEstado==15){
				$imagen= $this->srcImgError;
			}else{
				$imagen=$this->srcImgPeligro;
			}
			\Log::info("obtenerArchivosCaratula - paso 21 - ",array(date("Y-m-d H:i:s")));
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
		}
		
     				       			
	}

	// ADEN FIN - 2025-08-29 - HAY QUE AGREGAR EL ENVIO DEL MENSAJE POR FIN OK!

	/*****************************************************
	* Función que obtiene los archivos para resultados   *
	******************************************************/
	public function obtenerArchivosResultados(){
		$idJuego = Input::get('id_juego_seleccionado');
		$idEstado = Input::get('id_estado_seleccionado');
		$idsorteo = Input::get('id_seleccionado');
		$sorteo = Input::get('sorteo');
		$fechaSorteo = Input::get('fecha');
		$formatoProcesamiento = Input::get('id_formato_procesamiento');
		$usuario = Session::get('usuarioLogueado.idUsuario');
		$ds = DIRECTORY_SEPARATOR;
		
		
		//paths a las carpetas destino
		$destinoFinalResultados=$this->destinoTemporalResultados.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		$destinoTemporalSinProcesar =$this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$sorteo.$ds;

		if(!is_dir($destinoTemporalSinProcesar) && !file_exists($destinoTemporalSinProcesar)){
		  	\File::makeDirectory($destinoTemporalSinProcesar, 0777, true);
		}/*else{
			\File::cleanDirectory($destinoTemporalSinProcesar);
		}*/
		
		//obtenemos si requiere resultados
		$requiere=$this->servicioCuentaCorriente->requiereCarResSue($idJuego);
		
		//vemos qué archivos deberían pedirse
		if(Session::has('tipoArchivoJuegoEstado'))
			$archivos = Session::get('tipoArchivoJuegoEstado');
		else
			$archivos = $this->servicioCuentaCorriente->especif_arch_x_juego();

		//archivos para el juego seleccionado
		$archivos=$archivos[$idJuego];

		$util = new Util();
		$archivos=$util->groupArray($archivos,'tipo_archivo');
		$listaTiposArchivos=array();
		$listaArchivosRequerimiento=array();
		foreach ($archivos as $tiposArc) {
			array_push($listaArchivosRequerimiento,$tiposArc);
			array_push($listaTiposArchivos,$tiposArc['tipo_archivo']);
		}
		$archivosRequerimientos=array();
		foreach ($listaArchivosRequerimiento as $archReq) {
			foreach ($archReq['grupodatos'] as $especificacion) {
				if($especificacion['transaccion']==2){
					$arReq[$archReq['tipo_archivo']]=$especificacion['requerido'];
					$archivosRequerimientos[$archReq['tipo_archivo']]=$arReq;	
				}
			};
		}
		
		$exito=0;
		$mensaje="OK";
/****************** SUELDOS **************************************************/
//		\Log::info("MM - SU: ", array($archivosRequerimientos['SU']['SU']));
		//archivo de premios
		/*
		if(in_array("SU", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['SU']['SU'],'R')==0 || strcasecmp($archivosRequerimientos['SU']['SU'],'O')==0)){ //resultados(sueldos)
			try{
				\Log::info("MM - entra if");
				$destinoTemporalSueldos =$destinoTemporalSinProcesar."sueldos".$ds;
				if(!is_dir($destinoTemporalSueldos) && !file_exists($destinoTemporalSueldos)){
				  \File::makeDirectory($destinoTemporalSueldos, 0777, true);
				}else{
					array_map('unlink', glob($destinoTemporalSueldos."*"));
				}
				$archivosHijos =array();
				$archivosPadres =array();
				$this->listasArchivos($archivos, $listaSueldos, $archivosHijos, $archivosPadres, "SU",2);
				$listaArchivos['sue_ctrl']=array();
				$listaArchivos['sue_det']=array();
				$listaNombresInput=array();
				if(count($archivosPadres)>1){//son archivos unitarios
					$su=1;
					$this->estanTodosLosArchivos($destinoTemporalSueldos,"sueldos","sue_",$archivosPadres, $listaArchivos);
					$archivoRes = $listaArchivos['sue_det'][0];
					$archivoResCtrl = $listaArchivos['sue_ctrl'][0];

				}else{//hay un padre contenedor
					$su=2;
					$i=1;
					
					if(Input::hasFile("sue_".$i) ){
					   	$archivoSue= Input::file("sue_".$i);
					   	$resultado=$util->controlZip($archivoSue, $destinoTemporalSueldos, $listaSueldos, $idJuego);
					   	if($resultado['exito']){							
							//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($destinoTemporalSueldos);
							$ficheros1=array();
							foreach ($ficheros as $fichero) {
								$extension = explode(".",$fichero);
								if($extension[1]!='zip' && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
					   							
							if(count($ficheros1)>0 && (count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados'])){
								$mensaje=sprintf($this->err_mas_archivos,"sueldos.");
								\Log::info($mensaje);
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
							}

							foreach ($ficheros1 as $nombreFichero) {
								foreach ($archivosHijos as $hijo) {
									$patron="/^".$hijo['nombre'];
									if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
										$archivoSueCtrl = $destinoTemporalSueldos.$nombreFichero;
									}else if(strtolower($hijo['control'])=="s"){
										$archivoSue = $destinoTemporalSueldos.$nombreFichero;
									}
								}
							}
						}else{//error descomprimir
						\Log::info("MM - error descomprimir ");
							$mensaje=$resultado['mensaje'];
							\Log::info($mensaje);
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
						}
				   }else if(strcasecmp($archivosRequerimientos['SU']['SU'],'O')==0){
					   \Log::info("MM - entra a elseif debe setaqr estado 30");
						//	return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
								$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
							if($sorteoCorrecto){
								$exito=1;
								$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,30);
									
								$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
								$idEstado=$datos['idEstado'];
								$idsorteo=$datos['idPgmSorteo'];
								$desc_estado=$datos['de_estado'];
								$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
							
							return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
						//}catch(\Exception $e){
						}else{
							$exito=0;					
							$mensaje=sprintf($this->err_nro_sorteo_archivo, 'resultados');					
							return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
						}
		//				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			//	   }else{
			//		   \Log::info("MM - entra a else ");
			//		   	$mensaje=sprintf($this->err_falta_archivo,'sueldos');
			//			\Log::info($mensaje);
			//			return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));					
				   }else{
					   \Log::info("MM - entra a else ");
					   	$mensaje=sprintf($this->err_falta_archivo,'sueldos');
						\Log::info($mensaje);
						return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
				   }
					
				}
				
			}catch(\Exception $e){
				$mensaje="Problema al cargar los archivos de sueldos.";
				\Log::info($mensaje);
				\Log::info($e);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}
		}
		*/
		
	/*************************** FIN SUELDOS **************************************************/	
		
		
		//archivo de premios(resultados)
		if(in_array("RT", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['RT']['RT'],'R')==0 || strcasecmp($archivosRequerimientos['RT']['RT'],'O')==0)){//resultados(premios)
			try{
				\Log::info('entró a RT');
				$destinoTemporalResultados =$destinoTemporalSinProcesar."resultados".$ds;
				if(!is_dir($destinoTemporalResultados) && !file_exists($destinoTemporalResultados)){
				  \File::makeDirectory($destinoTemporalResultados, 0777, true);
				}else{
					array_map('unlink', glob($destinoTemporalResultados."*"));
				}
				$archivosHijos =array();
				$archivosPadres =array();
				$this->listasArchivos($archivos, $listaResultados, $archivosHijos, $archivosPadres, "RT",2);
				
				$listaNombresInput=array();
				if(count($archivosPadres)>1){//son archivos unitarios
					$rs=1;
					//armo los nombres de los input files que debe haber
					$i=0;
					for($x=0;$x<count($archivosPadres);$x++) {
						$i++;
					   	$nombreInputFile = "res_".$i;
					   	if(Input::hasFile($nombreInputFile)){
					   		$archivo = Input::file("res_".$i);
					   		array_push($listaNombresInput,$archivo);
					   	}else{
					   		$mensaje=sprintf($this->err_falta_archivo,'resultados');
							\Log::info($mensaje);
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
					   	}
					}

					$archivoRes = $listaNombresInput[1];
					$archivoResCtrl = $listaNombresInput[0];

				}else{//hay un padre contenedor
					$rs=2;
					$i=1;

					if(Input::hasFile("res_".$i) ){
					   	$archivoRes = Input::file("res_".$i);
						if($idJuego==4 || $idJuego==13 || $idJuego==30){
							$resultado=$util->controlZip($archivoRes, $destinoTemporalResultados, $listaResultados, $idJuego,null,1);
						}else{
							$resultado=$util->controlZip($archivoRes, $destinoTemporalResultados, $listaResultados, $idJuego);						
						}
					   	if($resultado['exito']){							
							//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($destinoTemporalResultados);
							$ficheros1=array();
							foreach ($ficheros as $fichero) {
								$extension = explode(".",$fichero);
								if($extension[1]!='zip' && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
							
							if(count($ficheros1)<$archivosPadres[0]['cant_arch_esperados']){
								$mensaje=sprintf($this->err_mas_archivos,"resultados.");
								\Log::info($mensaje);
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
							}
							$fecha=explode("-",$fechaSorteo);//fechaSorteo=aaaa-mm-dd
							$destinoPDF = $this->destinoTemporal.$fecha[0].$ds.$fecha[1].$ds.$idJuego."_".$sorteo.$ds;
							$util->copiarPDF($destinoTemporalResultados, $destinoPDF);
							
							//volvemos a buscar en la carpeta los archivos luego de sacar los pdf
							$ficheros = scandir($destinoTemporalResultados);
							$ficheros1=array();
							foreach ($ficheros as $fichero) {
								$extension = explode(".",$fichero);
								if($extension[1]!='zip' && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
							
							foreach ($ficheros1 as $nombreFichero) {
								foreach ($archivosHijos as $hijo) {
									$patron="/^".$hijo['nombre'];
									if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
										$archivoResCtrl = $destinoTemporalResultados.$nombreFichero;
									}else if(strtolower($hijo['control'])=="s"){
										$archivoRes = $destinoTemporalResultados.$nombreFichero;
									}
								}
							}
							
						}else{//error descomprimir
							$mensaje=$resultado['mensaje'];
							\Log::info($mensaje);
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
						}
						
						\Log::info('obtenerArchivosResultados - RT - controlSorteo linea 2251');
			
						$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,30);
				   }else if(strcasecmp($archivosRequerimientos['RT']['RT'],'O')==0){
							return Response::json(array('exito'=>1, 'mensaje'=>$mensaje));
				   }else{
					   	$mensaje=sprintf($this->err_falta_archivo,'resultados');
						\Log::info($mensaje);
						return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
				   }
					
				}
				
			}catch(\Exception $e){
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"resultados");
				\Log::info($mensaje);
				\Log::info($e);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}
			
		}else if(!in_array("RT", $listaTiposArchivos)){//No necesito archivo	
			$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
			\Log::info('obtenerArchivosResultados - RT - controlSorteo linea 2251');
			if($sorteoCorrecto){
				$exito=1;
				$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,30);
					
				$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
				$idEstado=$datos['idEstado'];
				$idsorteo=$datos['idPgmSorteo'];
				$desc_estado=$datos['de_estado'];
				$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
				
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
			}else{
				$exito=0;					
				$mensaje=sprintf($this->err_nro_sorteo_archivo, 'resultados');					
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}

		}
		
		//********* ARCHIVOS EXTRACTOS*********************
		//archivo de premios(resultados)
		if(in_array("EX", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['EX']['EX'],'R')==0 || strcasecmp($archivosRequerimientos['EX']['EX'],'O')==0)){//resultados(premios)
			try{
				$destinoTemporalExtractos=$destinoTemporalSinProcesar."extractos".$ds;
				if(!is_dir($destinoTemporalExtractos) && !file_exists($destinoTemporalExtractos)){
				  \File::makeDirectory($destinoTemporalExtractos, 0777, true);
				}else{
					array_map('unlink', glob($destinoTemporalExtractos."*"));
				}
				$archivosHijos =array();
				$archivosPadres =array();
				$this->listasArchivos($archivos, $listaExtractos, $archivosHijos, $archivosPadres, "EX",2);
				
				$listaNombresInput=array();
				if(count($archivosPadres)>1){//son archivos unitarios
					$ex=1;
					//armo los nombres de los input files que debe haber
					$i=0;
					for($x=0;$x<count($archivosPadres);$x++) {
						$i++;
					   	$nombreInputFile = "ex_".$i;
					   	if(Input::hasFile($nombreInputFile)){
					   		$archivo = Input::file("ex_".$i);
					   		array_push($listaNombresInput,$archivo);
					   	}else{
					   		$mensaje=sprintf($this->err_falta_archivo,'extractos');
							\Log::info($mensaje);
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
					   	}
					}

					$archivoEx = $listaNombresInput[1];
					$archivoExCtrl = $listaNombresInput[0];

				}else{//hay un padre contenedor
					$ex=2;
					$i=1;

					if(Input::hasFile("ex_".$i) ){
					   	$archivoEx = Input::file("ex_".$i);
					   	$resultado=$util->controlZip($archivoEx, $destinoTemporalExtractos, $listaExtractos, $idJuego);
					   	if($resultado['exito']){							
							//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($destinoTemporalExtractos);
							$ficheros1=array();
							foreach ($ficheros as $fichero) {
								$extension = explode(".",$fichero);
								if($extension[1]!='zip' &&  $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
							
							if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
								$mensaje=sprintf($this->err_menos_archivos,"extractos");
								\Log::info($mensaje);
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
							}
														
							foreach ($ficheros1 as $nombreFichero) {
								foreach ($archivosHijos as $hijo) {
									$patron="/^".$hijo['nombre'];
									if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
										$archivoExCtrl = $destinoTemporalExtractos.$nombreFichero;
									}else if(strtolower($hijo['control'])=="s"){
										$archivoEx = $destinoTemporalExtractos.$nombreFichero;
									}
								}
							}
							
						}else{//error descomprimir
							$mensaje=$resultado['mensaje'];
							\Log::info($mensaje);
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
						}
						
				   }else if(strcasecmp($archivosRequerimientos['EX']['EX'],'O')==0){
							return Response::json(array('exito'=>1, 'mensaje'=>$mensaje));
				   }else{
					   	$mensaje=sprintf($this->err_falta_archivo,'extractos');
						\Log::info($mensaje);
						return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
				   }
					
				}
				
			}catch(\Exception $e){
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"extractos");
				\Log::info($mensaje);
				\Log::info($e);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}
			
		}/*else if(!in_array("EX", $listaTiposArchivos)){//No necesito archivo
			$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
			if($sorteoCorrecto){
				$exito=1;
				$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,30);
					
				$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
				$idEstado=$datos['idEstado'];
				$idsorteo=$datos['idPgmSorteo'];
				$desc_estado=$datos['de_estado'];
				$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
				
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
			}else{
				$exito=0;					
				$mensaje=sprintf($this->err_nro_sorteo_archivo, 'extractos');					
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}

		}*/
		//********** FIN EXTRACTOS ************************

		if(isset($rs) && $rs==1){
			$res=$this->archivosResultados($archivoRes, $archivoResCtrl, $destinoTemporalResultados,1);//,$idJuego, $formatoProcesamiento);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'resultados');	
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));					
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"resultados");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));				
			}
		}else if(isset($rs) && $rs==2){
			$okCtrlRes=$this->servicioResultados->cargarResultadosControl($archivoResCtrl, $archivoRes);
			$okRes=$this->servicioResultados->cargarResultados($archivoRes);
			
			if($okCtrlRes && $okRes){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,4);				
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'resultados');	
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=$this->err_carga_sue;
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));				
			}
		}
		// \Log::info("variable su:", array($su));
//		\Log::info("MM - sueldos: ", array($su));
/*
		if(isset($su) && $su==1){
			$sue=$this->archivosSueldos($archivoSue, $archivoSueCtrl, $destinoTemporalResultados,1,$idJuego, $formatoProcesamiento);
			if($sue){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,7);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'resultados');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=$this->err_carga_sue;	
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
			}
		}else if(isset($su) && $su==2){
			$okCtrlSu=$this->servicioResultados->cargarSueldosControl($archivoSueCtrl, $archivoSue);
			$okSu=$this->servicioResultados->cargarSueldos($archivoSue);
			if($okCtrlSu && $okSu){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,7);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'sueldos');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=$this->err_carga_sue;	
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
			}
		}
*/		
		//******* control extractos *********
		if(isset($ex) && $ex==1){
			$res=$this->archivosExtractos($archivoEx, $archivoExCtrl, $destinoTemporalExtractos,0,$idJuego, $sorteo);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'extractos');	
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));					
				}
			}else{
				$exito=0;
				$mensaje=$this->sprintf($this->error_carga_sorteos_diarios,"extractos");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));				
			}
		}else if(isset($ex) && $ex==2){
			$okCtrlRes=$this->servicioResultados->cargarExtractosControl($archivoExCtrl, $archivoEx);
			$idPgmSorteo =(1000000*$idJuego)+$sorteo;
			$okRes=$this->servicioResultados->cargarExtractos($archivoEx,$idPgmSorteo);
			
			if($okCtrlRes && $okRes){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,4);				
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'extractos');	
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=$this->err_carga_sue;
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));				
			}
		}
		//********extractos

		if($exito==1){
/*VER VALIDACIÓN DE RESULTADOS Y SUELDOS!!!!!!!!!!!*/	
		if(isset($rs) && ($rs==2 || $rs==1) ){
			$nro=$this->servicioCuentaCorriente->getNumeroProcesoAuditoriaCtaCte($idJuego, $sorteo);
				
			$okValidaResultados=$this->servicioResultados->validaResultados($nro,$idJuego, $sorteo, $mensaje, $idEstado, $usuario);

			\Log::info("Llama SOR_VALIDA_RESULTADOS -> okValidaResultados:", array($okValidaResultados));
			
			if($okValidaResultados){
				$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);

				\Log::info("Llama SOR_VALIDA_RESULTADOS -> datos:", array($datos));
				
				if(isset($datos)){
					$idEstado=$datos['idEstado'];
					$idsorteo=$datos['idPgmSorteo'];
					$desc_estado=$datos['de_estado'];
					$id_pgmsorteo=$datos['id']; // agregado - 2025-09-08 - aden - necesito el id_pgmsorteo				
				
					$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
					\Log::info("resultado:", array($resultado));
					if($idEstado==25){
						$exito=0;
					}else{
						//$this->moverArchivosTemporalFinal($destinoTemporalSinProcesar, $destinoFinalResultados, $idJuego);
						$this->moverArchivosTemporalFinal($destinoTemporalSinProcesar, $destinoFinalResultados, $idJuego);
						
						// ************************************************** 2025-09-08 - INI - ADEN - MANDO EL MENSAJE DE FIN DE RESULTADO OK ***************************************************
						// Envío el mensaje

						if ($idJuego == 4 || $idJuego == 13 || $idJuego == 30) {   // se agrega que solo despache mensajes de quini6 y brinco - aden - 2025-11-07 - agrega la pf aden 2025-1120

							// Armo el contenido del mensaje
							$datos_mensaje = array(
								'topic' => 'resultados_recibidos',
								'message' => array(
									'id_sorteo' => $id_pgmsorteo,
									'id_producto' => $idJuego,
									'nro_sorteo' => $sorteo
								)
							);

							\Log::info("obtenerArchivosResultados - paso 25a - Envío del mensaje al Middleware", $datos_mensaje);
							
							// ini hasta tener el middleware
							$envio=$this->enviaMensajeMiddleware($datos_mensaje);
							// $envio = true;
							// fin hasta tener el middleware
							
							if (!$envio){
								$log = "obtenerArchivosResultados - paso 25b - Fallo el envío del mensaje al Middleware '" . $datos_mensaje['topic'] . "'.";
								\Log::info($log, array($envio));
							}
						}
						
						// ************************************************** 2025-09-08 - FIN - ADEN - MANDO EL MENSAJE DE FIN DE RESULTADO OK ***************************************************
						
					}
					\Log::info("Llama SOR_VALIDA_RESULTADOS -> json", array($idEstado));				
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
				}else{
					\Log::info("actualizaEstado - 25a ");
					$exito=0;
					$mensaje=sprintf($this->err_datos_sorteo, $sorteo);
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgPeligro));						
				}
			}else{
				\Log::info("actualizaEstado - 25b ");
				$exito=0;
				//actualizo el estado del pgmsorteo
				//$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,20);
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}
		}
	}else{
		\Log::info("actualizaEstado - 25c ");
		$exito=0;
		return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
	}
		
     				       			
	}

	/********************************************************
	* Función que se encarga de realizar la publicación
	*********************************************************/
	public function publicar(){
		$idJuego = Input::get('id_juego_seleccionado');
		$sorteo=Input::get('sorteo');
		$usuario = Session::get('usuarioLogueado.idUsuario');
		// \Log::info("Publicar -idJuego-: $idJuego");
		
		$ok = $this->servicioCuentaCorriente->publicar($idJuego, $sorteo, $usuario);
		\Log::info("Publicar -controler-: $ok");
		$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
		if(isset($datos)){
			$idEstado=$datos['idEstado'];
			$idsorteo=$datos['idPgmSorteo'];
			$desc_estado=$datos['de_estado'];
			$id=$datos['id'];

			if(strcasecmp(strtoupper($ok), 'OK')==0){
				$mensaje = "PUBLICADO";
				$exito=1;
				$srcImagen=$this->srcImgOk;

				// LLAMAR AL REST
				// AE: * no se necesitan mas los premios en as/400!!!!
				/* RL: 01/11/2023: AE indica que a partir de la migración del AS esto YA no se tiene que ejecutar más

				// Recupero la direccion del servicio
				$url_webservice_premios = Config::get('ctacte_config/config.url_rest');

				try {
					$ctx = stream_context_create(array('http'=>
					array(
						'timeout' => 600,  //10 Minutos
						)
					));

					$baseURL=$url_webservice_premios.$id;
				
					$log =  date("Y-m-d H:i:s") . ' - informaExtracto - invocando al rest -->' . $baseURL . '<--' . PHP_EOL;
					\Log::info($log);
				
					$jsonResponse =file_get_contents($baseURL,false,$ctx);
					$response = json_decode($jsonResponse)->msg;

					if($response->ejecOk == false){
					// enviar correo a listado i2t MM
						$datos_mail['id_sorteo']=$idsorteo;
						$datos_mail['msg']=$response->msg;
						$envio=$this->CtaCte_EnviaMail($datos_mail);
						if (!$envio){
							$log =  date("Y-m-d H:i:s") . ' - informaExtracto - CtaCte_EnviaMail -->' . $response . '<--' . PHP_EOL;
							\Log::info($log);
						}
					}
							
					$log =  date("Y-m-d H:i:s") . ' - informaExtracto - resultado -->' . $response . '<--' . PHP_EOL;
					\Log::info($log);
				}
				catch(\Exception $e)
				{
					// enviar correo a listado i2t MM
						$datos_mail['id_sorteo']=$idsorteo;
						$datos_mail['msg']="Problemas en REST.";
						$envio=$this->CtaCte_EnviaMail($datos_mail);
						if (!$envio){
							$log =  date("Y-m-d H:i:s") . ' - informaExtracto - publicar --> REST <--' . PHP_EOL;
							\Log::info($log);
						}
					\Log::info($e);
				}
				
				// FIN LLAMA AL REST
				FIN RL: 01/11/2023: AE indica que a partir de la migración del AS esto YA no se tiene que ejecutar más*/
			}else{
				$mensaje = $ok;
				$srcImagen=$this->srcImgError;
				$exito=0;
			}

			$idEstado=$datos['idEstado'];
			$idsorteo=$datos['idPgmSorteo'];
			$desc_estado=$datos['de_estado'];
			$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
			
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgOk,'datosTransaccion'=>$resultado));
		}else{
			$exito=0;
			$srcImagen=$this->srcImgError;
			$mensaje=sprintf($this->err_datos_sorteo, $sorteo);
			$desc_estado='Prob. en Publicación';
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>45, 'srcImagen'=>$this->srcImgError));
		}
		if(strcasecmp($ok, 'OK')!=0){
			$mensaje = $ok;
			$srcImagen=$this->srcImgError;
			$exito=0;
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>45, 'srcImagen'=>$srcImagen));	       			
		}
	}

	/*****************************************************************
	* Función que guarda los archivos de afectaciones
	******************************************************************/
	public function archivosAfectaciones($archivoAfe, $archivoAfeCtrl, $destino, $guardar){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreAfe = $archivoAfe->getClientOriginalName();
				$nombreAfeCtrl = $archivoAfeCtrl->getClientOriginalName();
								
				$archivoAfe=$destino.$ds.$nombreAfe;
				$archivoAfeCtrl = $destino.$ds.$nombreAfeCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessAfe = $archivoAfe->move($destino, $nombreAfe);
		           	$uploadSuccessAfeCtrl = $archivoAfeCtrl->move($destino, $archivoAfeCtrl);
				}else{
					$okAfe=$this->servicioAfectaciones->cargarAfectacion($archivoAfe);
					$okAfeCtrl=$this->servicioAfectaciones->cargarAfectacionControl($archivoAfeCtrl, $archivoAfe);
				}

				if($okAfe && $okAfeCtrl)
					return 1;
				else
					return 0;

	}

	/*****************************************************************
	* Función que guarda los archivos de Resultados
	******************************************************************/
	public function archivosResultados($archivoRes, $archivoResCtrl, $destino, $guardar){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreRes = $archivoRes->getClientOriginalName();
				$nombreResCtrl = $archivoResCtrl->getClientOriginalName();
								
				$nombreRes=$destino.$ds.$nombreRes;
				$nombreResCtrl = $destino.$ds.$nombreResCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessRes = $archivoRes->move($destino, $nombreRes);
		           	$uploadSuccessResCtrl = $archivoResCtrl->move($destino, $archivoResCtrl);
				}else{
					$okRes=$this->servicioResultados->cargarResultados($archivoRes);
					$okResCtrl=$this->servicioResultados->cargarResultadosControl($archivoResCtrl, $archivoRes);
				}

				if($okRes && $okResCtrl)
					return 1;
				else
					return 0;

	}
	/*****************************************************************
	* Función que guarda los archivos de Extractos
	******************************************************************/
	public function archivosExtractos($archivoEx, $archivoExCtrl, $destino, $guardar, $juego, $sorteo){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreEx = $archivoEx->getClientOriginalName();
				$nombreExCtrl = $archivoExCtrl->getClientOriginalName();
								
				$nombreEx=$destino.$ds.$nombreEx;
				$nombreExCtrl = $destino.$ds.$nombreExCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessEx = $archivoEx->move($destino, $nombreEx);
		           	$uploadSuccessExCtrl = $archivoExCtrl->move($destino, $archivoExCtrl);
				}else{
					$idpgmsorteo=(1000000*$juego)+$sorteo;
					$okEx=$this->servicioResultados->cargarExtractos($archivoEx,$idpgmsorteo);
					$okExCtrl=$this->servicioResultados->cargarExtractosControl($archivoExCtrl, $archivoEx);
				}

				if($okEx && $okExCtrl)
					return 1;
				else
					return 0;

	}
	/*****************************************************************
	* Función que guarda los archivos de apuestas
	******************************************************************/
	public function archivosApuestas($archivoApu, $archivoApuCtrl, $destino, $guardar, $idJuego, $formatoProcesamiento){
				//nombres - extensiones
				$nombreApu = $archivoApu->getClientOriginalName();
				$nombreApuCtrl = $archivoApuCtrl->getClientOriginalName();
								
				$destinoApu=$destino.$nombreApu;
				$destinoApuCtrl = $destino.$nombreApuCtrl;

				//movemos los archivo a la carpeta que corresponde
				$uploadSuccessApu = $archivoApu->move($destinoApu, $nombreApu);
	           	$uploadSuccessApuCtrl = $archivoApuCtrl->move($destinoApuCtrl, $archivoApuCtrl);
			
				$okApu=$this->servicioApuestas->cargarApuestas($archivoApu, $idJuego, $formatoProcesamiento);
				$okApuCtrl=$this->servicioApuestas->cargarApuestasControl($archivoApuCtrl, $archivoApu,$idJuego);
				
				if($okApu && $okApuCtrl)
					return 1;
				else
					return 0;

	}

	/*****************************************************************
	* Función que guarda los archivos de premios
	******************************************************************/
	public function archivosPremios($archivoPre, $archivoPreCtrl, $destino, $guardar, $idJuego){

				$nombrePre =$archivoPre['path'];//$archivoPre->getClientOriginalName();//basename($archivoPre);// 
				$nombrePreCtrl = $archivoPreCtrl['path'];//$archivoPreCtrl->getClientOriginalName();//basename($archivoPreCtrl);//
				$destinoPre=$destino.$archivoPre['nombreOriginal'];//.$nombrePre;
				$destinoPreCtrl = $destino.$archivoPreCtrl['nombreOriginal'];//$nombrePreCtrl;

				//movemos los archivo a la carpeta que corresponde
				$uploadSuccessPre =move_uploaded_file($nombrePre, $destinoPre); //$archivoPre->move($destino, $nombrePre); //$archivoPre->move($destinoPre, $nombrePre);//
	           	$uploadSuccessPreCtrl = move_uploaded_file($nombrePreCtrl, $destinoPreCtrl);//$archivoPreCtrl->move($destino, $nombrePreCtrl);/$archivoPreCtrl->move($destinoPreCtrl, $nombrePreCtrl);

				$okPre=$this->servicioPremios->cargarPremio($destinoPre, $idJuego);
				$okPreCtrl=$this->servicioPremios->cargarPremiosControl($destinoPreCtrl, $destinoPre);
				

				if($okPre && $okPreCtrl)
					return 1;
				else
					return 0;

	}
	/*****************************************************************
	* Función que guarda los archivos de premios retención
	******************************************************************/
	public function archivosPremiosRetencion($archivosDr, $archivoDrCtrl, $destino, $idJuego, $opcion){
				if($opcion==1){
					$nombreDrCtrl =$archivoDrCtrl['path'];//basename($archivoDrCtrl); //$archivoDrCtrl->getClientOriginalName();//
					$destinoDrCtrl = $destino.$archivoDrCtrl['nombreOriginal'];
				}else{
					$nombreDrCtrl =basename($archivoDrCtrl); //$archivoDrCtrl->getClientOriginalName();//
					$destinoDrCtrl = $destino.$nombreDrCtrl;
				}
	           	$uploadSuccessDrCtrl = move_uploaded_file($nombreDrCtrl, $destinoDrCtrl);//$archivoDrCtrl->move($destino, $nombreDrCtrl); $archivoPreCtrl->move($destinoPreCtrl, $nombrePreCtrl);
	           	$x=1;
				$okDr=1;
				$okDrCtrl=1;
				foreach ($archivosDr as $archivoDr) {
					if($opcion==1){
						$nombreDr = $archivoDr['path'];//basename($archivoDr);//$archivoDr->getClientOriginalName();//
						$destinoDr=$destino.$archivoDr['nombreOriginal'];
					}else{
						$nombreDr = basename($archivoDr);//$archivoDr->getClientOriginalName();//
						$destinoDr=$destino.$nombreDr;					
					}
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessDr =move_uploaded_file($nombreDr, $destinoDr);//$archivoDr->move($destino, $nombreDr); 
					$okDrCtrl=$this->servicioPremios->cargarPremiosRetencionControl($destinoDrCtrl, $destinoDr,$x);					
					$okDr=$this->servicioPremios->cargarPremiosRetDet($destinoDr, $idJuego);
					$x++;										
				}

				if($okDr && $okDrCtrl)
					return 1;
				else
					return 0;

	}

	/*****************************************************************
	* Función que guarda los archivos de carátula
	******************************************************************/
	public function archivosCaratula($archivoCar, $archivoCarCtrl, $destino, $guardar, $idJuego){
				//nombres
				$nombreCar = $archivoCar->getClientOriginalName();
				$nombreCarCtrl = $archivoCarCtrl->getClientOriginalName();
				$destinoCar=$destino.$nombreCar;
				$destinoCarCtrl = $destino.$nombreCarCtrl;


				//movemos los archivo a la carpeta que corresponde
				$uploadSuccessCar =$archivoCar->move($destino, $nombreCar); //move_uploaded_file($archivoPre, $destinoPre); //$archivoPre->move($destinoPre, $nombrePre);//
	           	$uploadSuccessCarCtrl = $archivoCarCtrl->move($destino, $nombreCarCtrl);//move_uploaded_file($archivoPreCtrl, $destinoPreCtrl);//$archivoPreCtrl->move($destinoPreCtrl, $nombrePreCtrl);

				$okCar=$this->servicioCaratulas->cargarCaratula($destinoPre, $idJuego);
				$okCarCtrl=$this->servicioCaratulas->cargarCaratulaControl($destinoCarCtrl, $destinoCar);
				

				if($okCar && $okCarCtrl)
					return 1;
				else
					return 0;

	}
	
	/*****************************************************************
	* Función que guarda los archivos de comisiones
	******************************************************************/
	public function archivosComisiones($archivoCom, $archivoComCtrl, $destino, $guardar){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreCom = $archivoCom->getClientOriginalName();
				$nombreComCtrl = $archivoComCtrl->getClientOriginalName();
								
				$archivoCom=$destino.$ds.$nombreCom;
				$archivoComCtrl = $destino.$ds.$nombreComCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessCom = $archivoCom->move($destino, $nombreCom);
		           	$uploadSuccessComCtrl = $archivoComCtrl->move($destino, $archivoComCtrl);
				}else{
					$okCom=$this->servicioComisiones->cargarComision($archivoCom);
					$okComCtrl=$this->servicioComisiones->cargarComisionesControl($archivoComCtrl, $archivoCom);
				}

				if($okCom && $okComCtrl)
					return 1;
				else
					return 0;

	}
	
	/*****************************************************************
	* Función que guarda los archivos de mantenimiento y sellado
	******************************************************************/
	public function archivosManSellado($archivoMan, $archivoManCtrl, $destino, $guardar){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreMan = $archivoMan->getClientOriginalName();
				$nombreManCtrl = $archivoManCtrl->getClientOriginalName();
								
				$archivoMan=$destino.$ds.$nombreMan;
				$archivoManCtrl = $destino.$ds.$nombreManCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessMan = $archivoMan->move($destino, $nombreMan);
		           	$uploadSuccessManCtrl = $archivoManCtrl->move($destino, $archivoManCtrl);
				}else{
					$okMan=$this->servicioComisiones->cargarManSellado($archivoMan);
					$okManCtrl=$this->servicioComisiones->cargarManSelladoControl($archivoManCtrl, $archivoMan);
				}

				if($okMan && $okManCtrl)
					return 1;
				else
					return 0;

	}
	
	/*****************************************
	* lista de archivos ventas totales	*
	******************************************/

	public function archivosVentas($archivoVenta, $archivoTotal, $destino, $guardar, $idJuego){

		$nombreVenta = $archivoVenta['path'];//$archivoPre->getClientOriginalName();//basename($archivoPre);// 
		$nombreTotal = $archivoTotal['path'];//$archivoPreCtrl->getClientOriginalName();//basename($archivoPreCtrl);//
		$destinoVenta = $destino.$archivoVenta['nombreOriginal'];//.$nombrePre;
		$destinoTotal = $destino.$archivoTotal['nombreOriginal'];//$nombrePreCtrl;

		//movemos los archivo a la carpeta que corresponde
		$uploadSuccessVenta =move_uploaded_file($nombreVenta, $destinoVenta); //$archivoPre->move($destino, $nombrePre); //$archivoPre->move($destinoPre, $nombrePre);//
		$uploadSuccessTotal = move_uploaded_file($nombreTotal, $destinoTotal);//$archivoPreCtrl->move($destino, $nombrePreCtrl);/$archivoPreCtrl->move($destinoPreCtrl, $nombrePreCtrl);

		$okVenta=$this->servicioPremios->cargarPremio($destinoVenta, $idJuego);
		$okTotal=$this->servicioPremios->cargarPremiosControl($destinoTotal, $destinoVenta);
		

		if($okVenta && $okTotal)
			return 1;
		else
			return 0;

	}
	

	/*****************************************
	* lista de archivos según la transacción
	******************************************/
	private function listasArchivos($archivos, &$lista, &$hijos, &$padres, $ta, $transac){
		// listasArchivos($archivos, $listaPremios, $archivosHijos, $archivosPadres, "VT",3)
		//lista de archivos 

		\Log::info("AE listasArchivos -archivos- ",array($archivos));
		
		foreach ($archivos as $archivo) {
			if($archivo['tipo_archivo']==$ta ){
				$lista=$archivo['grupodatos'];
				break;
			}
		}
		\Log::info("AE listasArchivos -lista- ",array($lista));
		
		if(isset($lista)){
			//busco el arch. padre y los hijos
			foreach ($lista as $archivo) {
				if($archivo['id_padre']=='' && $archivo['transaccion']== $transac){
					array_push($padres,$archivo);								
				}else{
					array_push($hijos,$archivo);
				}
			}			
		}
		\Log::info("AE listasArchivos -padres- ",array($padres));
		\Log::info("AE listasArchivos -hijos- ",array($hijos));
	}
	/**************************************************************************
	* Función que se encarga de buscar los archivos previos si es que existen *
	***************************************************************************/
    private function archivosPrevios($directorioBusqueda, &$resultado, $archivos, $transaccion){
    	
    	if(is_dir($directorioBusqueda)){
				$directorio = File::files($directorioBusqueda);
				if(!empty($directorio)){
					$iteadorArchivosEnDestino=new FilesystemIterator($directorioBusqueda, FilesystemIterator::SKIP_DOTS);//no incluye . ni ..
					$tipo_archivo = basename($directorioBusqueda);
					if(iterator_count($iteadorArchivosEnDestino)>0){
						$files = File::allFiles($directorioBusqueda);
						$arch = [];
						$extension=array();
						//busco qué tipo de archivos previos busco
						foreach ($archivos as $archivo) {
							if($archivo['transaccion']==$transaccion && $archivo['id_padre']==''){
								array_push($extension,$archivo['extension']);
							}
						}
						foreach ($files as $file)
						{
							$extFile=".".pathinfo(basename($file), PATHINFO_EXTENSION);
							if($this->coincideExtension($extension, $extFile)){
							    array_push($arch, basename($file)) ;//nombre del archivo de apuestas
							    $resultado['archivosPrevios']=array('existenArchivosPrevios'=>1,'archivos'=>array(array('tipo_archivo'=>$tipo_archivo,'nombre_archivo'=>$arch)));
							}

						}
					}else{
						$resultado['archivosPrevios']=array('existenArchivosPrevios'=>0,'archivos'=>array());
					}						
				}	
			}
    }
	
	
	/****************************************************************************
	* Función que se encarga de mover los archivos del temporal sin procesar al *
	* temporal correcto (según la transacción)                                  *
	*****************************************************************************/
    private function moverArchivosTemporalFinal($directorioBusqueda, $directorioFinal,$idJuego ,$final=0){
    	if(is_dir($directorioBusqueda)){
				$directorio = File::files($directorioBusqueda);
				\Log::info("Directorio directorio: ",array($directorio)); 
				$ds=DIRECTORY_SEPARATOR;
				\Log::info("Directorio origen: ",array($directorioBusqueda)); 
				\Log::info("Directorio destino: ",array($directorioFinal));
				\Log::info("Directorio final: ",array($final));
				//if(!empty($directorio) || $final==1){// || stripos($directorioFinal,'consolidado')!== false
				if($final==1 || !empty($directorio)){			
					//$iterador=new DirectoryIterator($directorioBusqueda, FilesystemIterator::SKIP_DOTS);//no incluye . ni ..
					
					$files = scandir($directorioBusqueda);
				\Log::info("Directorio files: ",array($files)); 
				    $oldfolder = $directorioBusqueda; 
				    $newfolder = $directorioFinal;
					
				    foreach($files as $fname) {
				      if($fname != '.' && $fname != '..') {
						  $success = \File::deleteDirectory($newfolder.$fname, true);
						  \Log::info("Directorio success: ",array($success));
				          rename($oldfolder.$fname, $newfolder.$fname);
				      }
				    }
				    //elimino el contenido del directorio
				    array_map('unlink', glob($oldfolder."*"));
					//elimino el directorio
					
					\Log::info("Directorio idJuego: ",array($idJuego));
					\Log::info("Directorio oldfolder: ",array($oldfolder));
				    $this->rrmdir($oldfolder);
				    //elimino la carpeta del juego_sorteo
				    $dir_js = substr($oldfolder, 0,strpos($oldfolder, basename($oldfolder)));
					\Log::info("Directorio dir_js: ",array($dir_js));
				    //$this->rrmdir($dir_js);

				}		
				
			}
    }
	
	/*
		Movemos los zip por ftp
	*/
	private function moverZipFTP($directorioBusqueda, $directorioFinal,$idJuego,$sorteo,$patron){		

		\Log::info("moverZipFTP - dbusqueda: ", array($directorioBusqueda));
		\Log::info("moverZipFTP - dfinal: ", array($directorioFinal));
		\Log::info("moverZipFTP - patron: ", array($patron));
	
		 $files = scandir($directorioBusqueda);
		 $newfolder = $directorioFinal;
		 $ds=DIRECTORY_SEPARATOR;
		 foreach($files as $fname) {
			if($fname != '.' && $fname != '..') {
				$match=preg_match($patron, $fname);
				if($match){
					$archivos = scandir($newfolder.$fname);
					foreach($archivos as $nombre) {
						 if(strtolower(\File::extension($nombre))=="zip"){
								try{
									$this->moverArchivosPorFTP($idJuego, $newfolder.$fname.$ds.$nombre,$sorteo);
								}catch(\Exception $e){
									\Log::error("Problema al mover apuestas con ftp. Juego: ".$idJuego);
								}
						 }
					}
				}
			}
		}
	}
	
	/***********************************************************
	* Función que se encarga de mandar el archivo de apuestas  *
	* a los servidores indicados, por ftp.                     *
	************************************************************/
	private function moverArchivosPorFTP($idJuego, $pathArchivo, $sorteo){
	\Log::info("Dónde lo busco: ", array($pathArchivo));
		$ds= DIRECTORY_SEPARATOR;
		$servidores = $this->servicioCuentaCorriente->servidoresFTP();
		$producto = $this->servicioCuentaCorriente->ProductoFTP($idJuego);
		$util = new Util();


		foreach($servidores as $servidor){
			
			// Primero creamos un ID de conexión a nuestro servidor
			$cid = ftp_connect($servidor['servidor']);
			// Luego creamos un login al mismo con nuestro usuario y contraseña
			$resultado = ftp_login($cid, $servidor['usuario'],$servidor['password']);
			// Comprobamos que se creo el Id de conexión y se pudo hacer el login
			if ((!$cid) || (!$resultado)) {
				\Log::error("Fallo en la conexión", array($servidor['servidor'])); 
				break;
			}
			// Cambiamos a modo pasivo, esto es importante porque, de esta manera le decimos al 
			//servidor que seremos nosotros quienes comenzaremos la transmisión de datos.
			ftp_pasv($cid, true) ;
			
			\Log::info("moverArchivosPorFTP -> destino segun servidor ", array($servidor['ruta']));
			// intenta cambiar el directorio a somedir
			if ($servidor['ruta'] != '') {
				if (!ftp_chdir($cid, $servidor['ruta'])) {
					\Log::error("moverArchivosPorFTP -> No se pudo cambiar al directorio\n", array($servidor['servidor'])); 
					break;
				}			
			}
			
			//creamos las directorios que no existen
			$sorteo=$util->zerofill($sorteo,6);
			$producto['ruta']=str_replace("xxxxxx",$sorteo,$producto['ruta']);
			\Log::info("moverArchivosPorFTP -> destino segun producto ", array($producto['ruta']));
			$partesRuta = explode('\\',$producto['ruta']); 
			\Log::info("moverArchivosPorFTP -> destino despues de split ", array($partesRuta));
			
			foreach($partesRuta as $part){
				if(!@ftp_chdir($cid, $part)){
					ftp_mkdir($cid, $part);
					ftp_chdir($cid, $part);
				}
			}
			
			//$partesRutaOrigen = explode($ds,$anioMesJuegoSorteo);
			
			if (file_exists($pathArchivo)){
				
				if ( ftp_put($cid, basename($pathArchivo),$pathArchivo, FTP_BINARY )){//basename($pathArchivo) BINARY
					//cerramos la conexión FTP
					ftp_close($cid);
					//actualizamos campo FECHAHORA_CAR
					date_default_timezone_set('America/Argentina/Buenos_Aires');
					$date =date("Y-m-d h:i:sa");
					$resul=$this->servicioCuentaCorriente->actualizaFHC($idJuego, $sorteo,$date);
					\Log::info("moverArchivosPorFTP -> Fin OK ftp");
				}else{
					\Log::info("moverArchivosPorFTP -> Problema al transmitir el archivo por ftp");
					ftp_close($cid);
				}
			}
		}
	}
	

	/********************************************************************
	* Función que verifica si la extensión matchea con alguna expresión *
	* de las contenidas en el arreglo.                                  *
	*********************************************************************/
	private function coincideExtension($extension, $extFile){
		foreach ($extension as $regex) {
			if(preg_match("/^".$regex, $extFile)){
				return true;
			}
		}
		return false;
	}

	/********************************************************************

	*********************************************************************/
	private function estanTodosLosArchivos($destino, $tipoArchivos,$prefijo,$archivosPadres,&$listaArchivos){
		$i=0;
		\Log::info("estanTodosLosArchivos - paso 1 - ",array(date("Y-m-d H:i:s")));

		//armo los nombres de los input files que debe haber
		$cantidad=count($archivosPadres);
		
		for($x=0;$x<$cantidad;$x++) {
			$i++;
		   	$nombreInputFile = $prefijo.$i;
		   	if(Input::hasFile($nombreInputFile)){
		   		$archivo = Input::file($nombreInputFile);
		   		$pathArchivo = $archivo->getRealPath();
				$nombreOriginal=$archivo->getClientOriginalName();//$archivo->getClientOriginalName();//$destino.$archivo->getClientOriginalName();//$destino.$archivo;//

				foreach($archivosPadres as $archP) {				
					$patron="/^".$archP['nombre'];

					if(preg_match($patron, $nombreOriginal) && strtolower($archP['control'])=="s"){
						$datoArchivo=array();
						$datoArchivo['nombreOriginal']=$nombreOriginal;
						$datoArchivo['path']=$pathArchivo;
						array_push($listaArchivos[$prefijo.'ctrl'],$datoArchivo);
						
					}else if(preg_match($patron, $nombreOriginal) && strtolower($archP['control'])=="n"){			//if(preg_match($patron, $archivo->getClientOriginalName())){			//
						$datoArchivo=array();
						$datoArchivo['nombreOriginal']=$nombreOriginal;
						$datoArchivo['path']=$pathArchivo;
						array_push($listaArchivos[$prefijo.'det'],$datoArchivo);						
					}	
				}
		   	}else{
		   		$mensaje=sprintf($this->err_falta_archivo,$tipoArchivos);
				/*\Log::info($mensaje);				*/
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		   	}
		}
	/*	\Log::info("prefijo: ".$prefijo);
		\Log::info($listaArchivos[$prefijo.'ctrl']);
		\Log::info($listaArchivos[$prefijo.'det']);
	*/
	}	

	/**************************************************************
	* Función que se encarga de sacar los archivos del contenedor *
	***************************************************************/
	private function tratamientoArchivosEnContenedor($util,$prefijo, $tiposArchivos, $archivosPadres, $archivosHijos,$destinoTemporal,$lista ,$idJuego,&$listaArchivos, $previos){
		$i=1;	
	
		if(Input::hasFile($prefijo.$i)){
		   	$archivo = Input::file($prefijo.$i);
			
		   	//archivos anteriores
		   	if(count($previos)>0){
			   	if($previos['archivosPrevios']['existenArchivosPrevios']){
					//verifico si es el mismo o no subió nada
					$archPrev = $previos['archivosPrevios']['archivos'];
					foreach ($archPrev as $prev) {
						foreach($prev['nombre_archivo'] as $p){
							if(strcasecmp($p, $archivo->getClientOriginalName())==0){//mismo archivo
							//movemos el archivo a la nueva ubicación -->verificar que se obtenga el nombre correcto
								$archivo=$archPrev;
							}else{//uno nuevo
								//borro archivo viejo
								File::delete($destinoTemporal.$ds.$p);
							}								
						}
					}
				}		   		
		   	}
			//\Log::info("archivo",array($archivo));
			\Log::info("tratamientoArchivosEnContenedor - destinoTemporal: ",array($destinoTemporal));
			\Log::info("tratamientoArchivosEnContenedor - idJuego: ",array($idJuego));
			\Log::info("tratamientoArchivosEnContenedor - archivo: ",array($archivo));
			
			$ver = print_r($lista, true);
			\Log::info("tratamientoArchivosEnContenedor - lista: ",array($ver));
// *********** 2025-01-27 ACA ESTA LA FALLA			
		   	$resultado=$util->controlZip($archivo, $destinoTemporal, $lista, $idJuego);
			\Log::info("tratamientoArchivosEnContenedor - Resultado UNZIP: ",array($resultado));

			$mensaje='OK';
		   	if($resultado['exito']){							
				//buscar los archivos en la carpeta y pasarlos a la tabla, lo que hay en carpeta, queda en $ficheros
				\Log::info("tratamientoArchivosEnContenedor - destino temporal",array($destinoTemporal));
				$ficheros =  scandir($destinoTemporal);
				\Log::info("tratamientoArchivosEnContenedor - destino ficheros: ",array($ficheros));
				
				$ficheros1=array();
				foreach ($ficheros as $fichero) {
					$extension = explode(".",$fichero);
					if(strcasecmp($extension[1],'zip')!=0 && $fichero!= "." && $fichero!= ".."){
						array_push($ficheros1, $fichero);
					}
				}
				\Log::info("tratamientoArchivosEnContenedor: ",array($ficheros1));
				
				// SI VIENEN MÁS LOS IGNORO! AE - 2018-04-13
				// if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
				if(count($ficheros1) < $archivosPadres[0]['cant_arch_esperados']){

					$mensaje=sprintf($this->err_mas_archivos,$tiposArchivos);
					\Log::info($mensaje);
					// \Log::info("Mensaje nuevo", array(count($ficheros1), $archivosPadres[0]['cant_arch_esperados']));
					\Log::info("ficheros1",array(count($ficheros1)));
					\Log::info("cant_arch_esperados",array($archivosPadres[0]['cant_arch_esperados']));
					$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
					return $resultado;
				}

				foreach ($ficheros1 as $nombreFichero) {
					\Log::info('aden->forecha fichero', array($nombreFichero));
					
					foreach ($archivosHijos as $hijo) {
						\Log::info('aden->forecha hijo', array($hijo));
						$patron="/^".$hijo['nombre'];
						$pathArchivo = $destinoTemporal.$nombreFichero;
						$extensionNF = explode(".",$nombreFichero)[1];
						if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
							array_push($listaArchivos[$prefijo.'ctrl'], $pathArchivo);
							\Log::info('aden->else ret 3350', array($pathArchivo));
						} else {
									array_push($listaArchivos[$prefijo.'det'],$pathArchivo);
									\Log::info('aden->else strlow 3362', array($pathArchivo));
				         }
					}
				}
				$resultado=array('exito'=>1, 'mensaje'=>$mensaje);
				return $resultado;
			}else{//problema al descomprimir
				$mensaje=$resultado['mensaje'];
				\Log::info('Mensaje:', array($mensaje));
				$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
				return $resultado;
			}
	   }else if(isset($previos['archivosPrevios']['existenArchivosPrevios'])){
				$mensaje='OK';
				//verifico si es el mismo o no subió nada
				$archPrev = $previos['archivosPrevios']['archivos'];
				foreach ($archPrev as $prev) {
					foreach($prev['nombre_archivo'] as $p){
							$archivo=$destinoTemporal.$p;
					}
				}
				
				$resultado=$util->controlZip($archivo, $destinoTemporal, $lista, $idJuego);

				if($resultado['exito']){							
					//buscar los archivos en la carpeta y pasarlos a la tabla
					$ficheros =  scandir($destinoTemporal);
					$ficheros1=array();
					foreach ($ficheros as $fichero) {
						$extension = explode(".",$fichero);
						if(strcasecmp($extension[1],'zip')!=0 && $fichero!= "." && $fichero!= ".."){
							array_push($ficheros1, $fichero);
						}
					}
					
					\Log::info("MM - tratamientoArchivosEnContenedor - count(ficheros1): ",array(count($ficheros1)));
					\Log::info("MM - tratamientoArchivosEnContenedor - archivosPadres[0]['cant_arch_esperados']: ",array($archivosPadres[0]['cant_arch_esperados']));
					
					
					if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
						$mensaje=sprintf($this->err_mas_archivos,$tiposArchivos);
						\Log::info($mensaje);
						$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
						return $resultado;
					}

					foreach ($ficheros1 as $nombreFichero) {
						foreach ($archivosHijos as $hijo) {
							$patron="/^".$hijo['nombre'];
							$pathArchivo = $destinoTemporal.$nombreFichero;
							if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
								array_push($listaArchivos[$prefijo.'ctrl'], $pathArchivo);
							}else if(strtolower($hijo['control'])=="s"){
								array_push($listaArchivos[$prefijo.'det'],$pathArchivo);
							}
						}
					}
					$resultado=array('exito'=>1, 'mensaje'=>$mensaje);
					return $resultado;
				}else{//problema al descomprimir
					$mensaje=$resultado['mensaje'];
					\Log::info($mensaje);
					$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
					return $resultado;
				}			
			
				
				
	   }else{
	   	$mensaje=sprintf($this->err_falta_archivo,$tiposArchivos);
		\Log::info($mensaje);
		$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
		return $resultado;
	   }
	}
	
	
	private function rrmdir($path) {
		// Remove a dir (all files and folders in it)
		$i = new DirectoryIterator($path);
		foreach($i as $f) {
			if($f->isFile()) {
				unlink($f->getRealPath());
			} else if(!$f->isDot() && $f->isDir()) {
				$this->rrmdir($f->getRealPath());
				rmdir($f->getRealPath());
			}
		}
	}
/********************************* MM - recepción liquidaciones - inicio *****************************************/
	
	/***********************************
	* Armado del panel de liquidaciones
	************************************/
	public function camposPanelLiquidaciones(){
		$archivosApedir=array();
		$datosTransaccion['nombre_file']=array();
		$archivos=$this->servicioCuentaCorriente->especif_arch_liq();
		
		
		$idJuego=999;$ms=0;$com=0;
		foreach ($archivos[$idJuego] as $archJuego) {
			if($archJuego['transaccion']==8 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='RL'){	//comisiones adicionales
							$com++;
							//$archivo['nombre']='com_'.$com;
							$archivo['nombre']='cas';
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Liquidaciones Ctrl.';
							else
								$archivo['buttonText']='Liquidaciones';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						$archivo['extension']=str_replace("+" ,"",$archJuego['extension']);
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}		

		// consulta secuencia esperada se debe cambiar el select una vez que tengamos el dato en una tabla
		
			$secuencia_espe=$this->servicioLiquidaciones->secuenciaEsperada();
			//$secuencia_espe='201505';
		
		$datosTransaccion= Response::recepcionLiquidaciones($archivosApedir, $secuencia_espe);
		return $datosTransaccion;
	}

	/***********************************
	* Llamada al panel de liquidaciones
	************************************/
	public function panelLiquidaciones(){
		$campos=$this->camposPanelLiquidaciones();
		return View::make('cuenta_corriente.panelLiquidaciones', array('campos'=>$campos));
	}
	
	/********************************************************
	* Recepción de los datos desde la recepcion de liquidaciones
	*********************************************************/
	public function tratamientoLiquidaciones(){
		\Log::info("RECEP CAS.ZIP - INICIO ");
		
		//definición de variables
		$util = new Util();
		list($com,$man,$exito)=0;
		$listaTiposArchivos=array();
		$listaArchivosRequerimiento=array();
		$idJuego=-999;
		$fecha_ejec = date("dmY");
		$ds=DIRECTORY_SEPARATOR;
		$mensaje="";
		$datos= Input::all();
		$destino=$this->destinoLiquidaciones;
		// \Log::info("rruiz: ".public_path());
		\Log::info("rruiz: ".$destino);
		// \Log::info("rruiz: ".public_path());
		$destinoCasLog=$this->destinoCasLog;
		$url_modulo_auditoria = $this->moduloAuditoria;
		$destinoAS400=$this->destinoTemporalAS400;
		$usuario= Session::get('usuarioLogueado.idUsuario');

		$nroSecuencia=$this->servicioLiquidaciones->secuenciaEsperada();
		 
		$idProceso=$this->servicioCuentaCorriente->getNumeroProcesoAuditoriaCtaCte($idJuego, $nroSecuencia);
		\Log::info("RECEP CAS.ZIP - idJuego: ",array($idJuego));
		\Log::info("RECEP CAS.ZIP - nroSecuencia: ",array($nroSecuencia));
		\Log::info("RECEP CAS.ZIP - idProceso: ",array($idProceso));
		/***************************************************
			Registro proceso de recepcion en auditoria
		*****************************************************/
		$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,26,$usuario,26,27,"Inicio Proceso de recepción de liquidaciones");
			
		// Inicializo datos e-mail
		$mail_destino_paq = Config::get('mail.operadores');
		\Log::info('mail_destino_paq',array($mail_destino_paq));

		$mail_remite_paq = Config::get('mail.from.address');
		\Log::info('mail_remite_paq',array($mail_remite_paq));
		
		$mail_alias_remite_paq = 'Cta Cte Agencias';
		\Log::info('mail_remite_paq',array($mail_alias_remite_paq));

		$mail_asunto_paq = 'Recepción Cta Cte Agencias - Secuencia '.$nroSecuencia;
		\Log::info('mail_asunto_paq',array($mail_asunto_paq));

		$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
		\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
		
		$arch_adjunto = '';
		\Log::info('arch_adjunto',array($arch_adjunto));
		
		$url_descarga = '';
		\Log::info('url_descarga',array($url_descarga));
		
		$datos_mail['mail_destino_paq']=$mail_destino_paq;
		$datos_mail['mail_remite_paq']=$mail_remite_paq;
		$datos_mail['mail_alias_remite_paq']=$mail_alias_remite_paq;
		$datos_mail['mail_asunto_paq']=$mail_asunto_paq;
		$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
		$datos_mail['arch_adjunto']=$arch_adjunto;
		$datos_mail['url_descarga']=$url_descarga;
		$datos_mail['nroSecuencia']=$nroSecuencia;
		
		//creación de las carpetas
		//carpeta principal -> liquidaciones
		\Log::info("RECEP CAS.ZIP - DIR destino: ".$destino);
		\Log::info("rruiz.....: ".$destino);			
		
		if(!is_dir($destino) && !file_exists($destino)){
			\Log::info("rruiz.....: ".$destino);
		  File::makeDirectory($destino, 0777, true);
		  \Log::info("rruiz.....: ".$destino);
		}
			
		//obtengo todos los archivos subidos para controlar el nombre y el período
		$archivosSubidos = Input::file();
		
		foreach($archivosSubidos as $archivo){
			$filename = $archivo->getClientOriginalName();
		
			$arregloNombre=explode(".",$filename);	
			$nombreSinExtension =substr($arregloNombre[0],-4); 

			\Log::info("RECEP CAS.ZIP - DIR filename: ", array($filename));
			\Log::info("RECEP CAS.ZIP - DIR arregloNombre: ", array($arregloNombre));
			\Log::info("RECEP CAS.ZIP - DIR nombreSinExtension: ", array($nombreSinExtension));
			
			//$nombreSinExtension =substr($arregloNombre[0]); 
			
			if(strtoupper($nombreSinExtension)!='CAS'){
				// valida nombre de archivo cas.zip
				$mensaje=sprintf("El archivo ingresado no corresponde a cas.zip.",$filename);
				\Log::info("RECEP CAS.ZIP - ".$mensaje);
				
				// INI ACA ENVIAR MAIL
				$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
				$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
				\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
				$envio=$this->CtaCte_EnviaMailCasZip($datos_mail);
				if (!$envio){
					$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail -->' .  array($envio) . '<--' . PHP_EOL;
					\Log::info($log);
				}
				// FIN ACA ENVIAR MAIL
				// INI ACA ENVIAR MAIL x MAILCHIMP
				$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
				
				\Log::info(' - RECEP CAS.ZIP - Datos envio mail x mailchimp -->', array($datos_mail));
						
				$envio=$this->CtaCte_EnviaMailCasZip_Mailchimp($datos_mail);
				if (!$envio){
					$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail x mailchimp -->';
					\Log::info($log, array($envio));
				}			
				// FIN ACA ENVIAR MAIL x MAILCHIMP						
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}else{
				//archivos a pedir
				$archivos = $this->servicioCuentaCorriente->especif_arch_liq();

				\Log::info("RECEP CAS.ZIP - DIR archivos: ", array($archivos));
				
				$archivos=$archivos[999];
				$archivos=$util->groupArray($archivos,'tipo_archivo');
				
				$archivosHijosRL =array();
				$archivosPadresRL =array();
				$this->listasArchivos($archivos, $listaRL, $archivosHijosRL, $archivosPadresRL, "RL",8);
				
				// deszipear
				if(Input::hasFile("cas") || Input::hasFile("CAS")){
					
					$destinoLiquidaciones =$destino.$ds;
					
					if(!is_dir($destinoLiquidaciones) && !file_exists($destinoLiquidaciones)){
					
						File::makeDirectory($destinoLiquidaciones, $mode = 0777, true, true);
					
					}else{
						array_map('unlink', glob($destinoLiquidaciones."*"));
					}

					$archivoCas = "";
					if (Input::hasFile("cas")) {
						$archivoCas = Input::file("cas");
					}
					if (Input::hasFile("CAS")) {
						$archivoCas = Input::file("CAS");
					}
					\Log::info("RECEP CAS.ZIP - archivo zipeado ->",array($archivoCas));
					
					// control de archivo zip
					
					$resultado=$util->controlZip($archivoCas, $destinoLiquidaciones, $listaRL, $idJuego,'',8);
					
					$proc_ok=1;
					if($resultado['exito']){
						//buscar los archivos en la carpeta y pasarlos a la tabla
						\Log::info("RECEP CAS.ZIP - dir arch deszipeado ->",array($destinoLiquidaciones));
						$ficheros = scandir($destinoLiquidaciones);
						\Log::info("RECEP CAS.ZIP - lista archivos ->",array($ficheros));
						
						$ficheros1 = array();
						foreach ($ficheros as $fichero){
							if(strpos($fichero,"zip") < 1 && $fichero!= "." && $fichero!= ".."){
								array_push($ficheros1, $fichero);
							}
						}
				
						// control de diferencia de cantidad de archivos esperados en cas.zip
						\Log::info("RECEP CAS.ZIP - cant_arch_esperados: ",array($archivosPadresRL[0]['cant_arch_esperados']));
						//	\Log::info("cant_arch_esperados",array($archivosPadresRL[0]['cant_arch_esperados']));
						if(count($ficheros1)!=$archivosPadresRL[0]['cant_arch_esperados']){
							$mensaje=sprintf($this->err_cant_archivos," liquidaciones");
							\Log::info("RECEP CAS.ZIP - cant_arch_esperados: ".$mensaje);
												
							// INI ACA ENVIAR MAIL
							$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
							$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
							\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
							$envio=$this->CtaCte_EnviaMailCasZip($datos_mail);
							if (!$envio){
								$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail -->' .  array($envio) . '<--' . PHP_EOL;
								\Log::info($log);
							}
							// FIN ACA ENVIAR MAIL
							// INI ACA ENVIAR MAIL x MAILCHIMP
							$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
							
							\Log::info(' - RECEP CAS.ZIP - Datos envio mail x mailchimp -->', array($datos_mail));
									
							$envio=$this->CtaCte_EnviaMailCasZip_Mailchimp($datos_mail);
							if (!$envio){
								$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail x mailchimp -->';
								\Log::info($log, array($envio));
							}			
							// FIN ACA ENVIAR MAIL x MAILCHIMP						
							
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>15, 'srcImagen'=>$this->srcImgError));
						}
						/***************************************************
							indicando la recepcion y validaciones
						*****************************************************/
						foreach ($ficheros1 as $nombreFichero) {
							\Log::info("RECEP CAS.ZIP - destinoLiquidaciones: ".$destinoLiquidaciones);
							\Log::info("RECEP CAS.ZIP - nombreFichero: ".$nombreFichero);
							$dest=$destinoLiquidaciones.$nombreFichero;
							$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,34,$usuario,26,27,"Inicio vuelco archivo ".$nombreFichero);
							switch ($nombreFichero) {
								case "BCF0014":
										$okLiq_BCF0014=$this->servicioLiquidaciones->cargarCodigoJuegos($dest);
										//$proc_ok = 1;
									break;
								case "CCF0001":
										$okLiq_CCF0001=$this->servicioLiquidaciones->cargarComprobantes($dest);
										//$proc_ok = 1;
									break;
								case "CCF0002":
										$okLiq_CCF0002=$this->servicioLiquidaciones->cargarConceptos($dest);
										//$proc_ok = 1;
									break;
								case "CCF0003":
										$okLiq_CCF0003=$this->servicioLiquidaciones->cargarSaldosJuegos($dest);
									//	$proc_ok = 1;
									break;
								case "CCF0004":
										$okLiq_CCF0004=$this->servicioLiquidaciones->cargarAfectaciones($dest);
										//$proc_ok = 1;
									break;
								case "CCF0015":
										$okLiq_CCF0015=$this->servicioLiquidaciones->cargarParametros($dest);
										//$proc_ok = 1;
									break;
								case "CCF0016":
										$okLiq_CCF0016=$this->servicioLiquidaciones->cargarMultijuegos($dest);
										//$proc_ok = 1;
									break;
								case "CCF0017":
										$okLiq_CCF0017=$this->servicioLiquidaciones->cargarSaldosAgente($dest);
										//$proc_ok = 1;
									break;
								case "CCF0079":
										$okLiq_CCF0079=$this->servicioLiquidaciones->cargarTiposGarantias($dest);
										//$proc_ok = 1;
									break;
								case "CCF0301":
										$okLiq_CCF0301=$this->servicioLiquidaciones->cargarMovimientosComprobantes($dest);
										//$proc_ok = 1;
									break;
								case "CCF0302":
										$okLiq_CCF0302=$this->servicioLiquidaciones->cargarConceptosComprobantes($dest);
										//$proc_ok = 1;
									break;
								case "CCF0304":
										$okLiq_CCF0304=$this->servicioLiquidaciones->cargarAplicaciones($dest);
										//$proc_ok = 1;
									break;
								case "CCF0305":
										$okLiq_CCF0305=$this->servicioLiquidaciones->cargarPremios($dest);
										//$proc_ok = 1;
									break;
								case "CCF0306":
										$okLiq_CCF0306=$this->servicioLiquidaciones->cargarNumeroSecuencia($dest);
										//$proc_ok = 1;
									break;
								case "CCF0307":
										$okLiq_CCF0307=$this->servicioLiquidaciones->cargarCreditosEfectivizados($dest);
										//$proc_ok = 1;
									break;
								case "CCF0308":
										$okLiq_CCF0308=$this->servicioLiquidaciones->cargarPremiosPagadosUIF($dest);
										//$proc_ok = 1;
									break;
								default:	
										$proc_ok = 0;
										//$mensaje=$resultado['mensaje'];
									break;
							}
						}
					}else{//ERROR DESCOMPRIMIR
						$mensaje=$resultado['mensaje'];
						// inserta auditoria sobre proceso descrompresion archivo cas.zip
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,35,$usuario,26,27,"Problemas en archivo cas.zip ".$mensaje);
						\Log::info($mensaje);
							if($proc_ok == 0){
								$exito = 0;
							}
												
						// INI ACA ENVIAR MAIL
						$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
						$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
						\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
						$envio=$this->CtaCte_EnviaMailCasZip($datos_mail);
						if (!$envio){
							$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail -->' .  array($envio) . '<--' . PHP_EOL;
							\Log::info($log);
						}							
						// FIN ACA ENVIAR MAIL
						// INI ACA ENVIAR MAIL x MAILCHIMP
						$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
						
						\Log::info(' - RECEP CAS.ZIP - Datos envio mail x mailchimp -->', array($datos_mail));
								
						$envio=$this->CtaCte_EnviaMailCasZip_Mailchimp($datos_mail);
						if (!$envio){
							$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail x mailchimp -->';
							\Log::info($log, array($envio));
						}			
						// FIN ACA ENVIAR MAIL x MAILCHIMP						
						
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					}
				}
				// fin descompresion correcto
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,36,$usuario,34,27,"Fin descompresion archivo cas.zip ".$mensaje);
				
				// validaciones en procedimiento almacenado CC_Valida_CtaCte_Agencia
				$mensaje=$this->servicioLiquidaciones->validarSecuencia($idProceso,$nroSecuencia,$usuario);
				if ($mensaje != "OK"){
					$exito = 0;
					\Log::info($mensaje);
										
					// INI ACA ENVIAR MAIL
					$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
					$envio=$this->CtaCte_EnviaMailCasZip($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail -->' .  array($envio) . '<--' . PHP_EOL;
						\Log::info($log);
					}							
					// FIN ACA ENVIAR MAIL
					// INI ACA ENVIAR MAIL x MAILCHIMP
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					
					\Log::info(' - RECEP CAS.ZIP - Datos envio mail x mailchimp -->', array($datos_mail));
							
					$envio=$this->CtaCte_EnviaMailCasZip_Mailchimp($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail x mailchimp -->';
						\Log::info($log, array($envio));
					}			
					// FIN ACA ENVIAR MAIL x MAILCHIMP						
					
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					die();	
				}
				// validaciones de vuelcos
				$mensaje=$this->servicioLiquidaciones->validarVuelcos($idProceso,$nroSecuencia,$usuario);
				if ($mensaje != "OK"){
					$exito = 0;
					\Log::info($mensaje);
										
					// INI ACA ENVIAR MAIL
					$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
					$envio=$this->CtaCte_EnviaMailCasZip($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail -->' .  array($envio) . '<--' . PHP_EOL;
						\Log::info($log);
					}							
					// FIN ACA ENVIAR MAIL
					// INI ACA ENVIAR MAIL x MAILCHIMP
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					
					\Log::info(' - RECEP CAS.ZIP - Datos envio mail x mailchimp -->', array($datos_mail));
							
					$envio=$this->CtaCte_EnviaMailCasZip_Mailchimp($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail x mailchimp -->';
						\Log::info($log, array($envio));
					}			
					// FIN ACA ENVIAR MAIL x MAILCHIMP						
					
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					die();	
				}
				// validaciones comprobantes
				$mensaje=$this->servicioLiquidaciones->validarComprobantes($idProceso,$nroSecuencia,$usuario);
				if ($mensaje != "OK"){
					$exito = 0;
					\Log::info($mensaje);
										
					// INI ACA ENVIAR MAIL
					$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
					$envio=$this->CtaCte_EnviaMailCasZip($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail -->' .  array($envio) . '<--' . PHP_EOL;
						\Log::info($log);
					}							
					// FIN ACA ENVIAR MAIL
					// INI ACA ENVIAR MAIL x MAILCHIMP
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					
					\Log::info(' - RECEP CAS.ZIP - Datos envio mail x mailchimp -->', array($datos_mail));
							
					$envio=$this->CtaCte_EnviaMailCasZip_Mailchimp($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail x mailchimp -->';
						\Log::info($log, array($envio));
					}			
					// FIN ACA ENVIAR MAIL x MAILCHIMP						
					
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					//die();	
				}
				// validaciones conceptos
				$mensaje=$this->servicioLiquidaciones->validarConceptos($idProceso,$nroSecuencia,$usuario);
				if ($mensaje != "OK"){
					$exito = 0;
					\Log::info($mensaje);
										
					// INI ACA ENVIAR MAIL
					$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
					$envio=$this->CtaCte_EnviaMailCasZip($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail -->' .  array($envio) . '<--' . PHP_EOL;
						\Log::info($log);
					}							
					// FIN ACA ENVIAR MAIL
					// INI ACA ENVIAR MAIL x MAILCHIMP
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					
					\Log::info(' - RECEP CAS.ZIP - Datos envio mail x mailchimp -->', array($datos_mail));
							
					$envio=$this->CtaCte_EnviaMailCasZip_Mailchimp($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail x mailchimp -->';
						\Log::info($log, array($envio));
					}			
					// FIN ACA ENVIAR MAIL x MAILCHIMP						
					
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					//die();	
				}
				// validaciones juegos
				$mensaje=$this->servicioLiquidaciones->validarJuegos($idProceso,$nroSecuencia,$usuario);
				if ($mensaje != "OK"){
					$exito = 0;
					\Log::info($mensaje);
										
					// INI ACA ENVIAR MAIL
					$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
					$envio=$this->CtaCte_EnviaMailCasZip($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail -->' .  array($envio) . '<--' . PHP_EOL;
						\Log::info($log);
					}							
					// FIN ACA ENVIAR MAIL
					// INI ACA ENVIAR MAIL x MAILCHIMP
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					
					\Log::info(' - RECEP CAS.ZIP - Datos envio mail x mailchimp -->', array($datos_mail));
							
					$envio=$this->CtaCte_EnviaMailCasZip_Mailchimp($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail x mailchimp -->';
						\Log::info($log, array($envio));
					}			
					// FIN ACA ENVIAR MAIL x MAILCHIMP						
					
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					//die();	
				}
				// validaciones agencias
				$mensaje=$this->servicioLiquidaciones->validarAgencias($idProceso,$nroSecuencia,$usuario);
				if ($mensaje != "OK"){
					$exito = 0;
					\Log::info($mensaje);
										
					// INI ACA ENVIAR MAIL
					$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
					$envio=$this->CtaCte_EnviaMailCasZip($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail -->' .  array($envio) . '<--' . PHP_EOL;
						\Log::info($log);
					}							
					// FIN ACA ENVIAR MAIL
					// INI ACA ENVIAR MAIL x MAILCHIMP
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					
					\Log::info(' - RECEP CAS.ZIP - Datos envio mail x mailchimp -->', array($datos_mail));
							
					$envio=$this->CtaCte_EnviaMailCasZip_Mailchimp($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail x mailchimp -->';
						\Log::info($log, array($envio));
					}			
					// FIN ACA ENVIAR MAIL x MAILCHIMP						
					
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					//die();	
				}				
				//	validacion afectación
				$mensaje=$this->servicioLiquidaciones->validarAfectaciones($idProceso,$nroSecuencia,$usuario);
				if ($mensaje != "OK"){
					$exito = 0;
					\Log::info($mensaje);
										
					// INI ACA ENVIAR MAIL
					$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
					$envio=$this->CtaCte_EnviaMailCasZip($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail -->' .  array($envio) . '<--' . PHP_EOL;
						\Log::info($log);
					}							
					// FIN ACA ENVIAR MAIL
					// INI ACA ENVIAR MAIL x MAILCHIMP
					$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
					
					\Log::info(' - RECEP CAS.ZIP - Datos envio mail x mailchimp -->', array($datos_mail));
							
					$envio=$this->CtaCte_EnviaMailCasZip_Mailchimp($datos_mail);
					if (!$envio){
						$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail x mailchimp -->';
						\Log::info($log, array($envio));
					}			
					// FIN ACA ENVIAR MAIL x MAILCHIMP						
					
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					//die();	
				}
				// vuelco	
				$exito = 0; // 0=fracaso

				$mensaje = $this->servicioLiquidaciones->Vuelco_CtaCte($idProceso,$nroSecuencia,$usuario);

				// ACA DESASTERISQUEAR
				//$mensaje = "OK";
				//$estado =  "OK";

				\Log::info('CtaCte mensaje:',array($mensaje));
				$link_auditoria = "";
				$idAudit = $this->servicioCuentaCorriente->getIdAuditoriaCtaCte($idProceso);
				$link_auditoria = "<a target='_blank' href='".$url_modulo_auditoria.$idAudit."'> Ir a Auditoria </a>";

				$estado = substr($mensaje, 0, 2); // Extraigo los 2 primeros caracteres del mensaje, o es OK o es ER
				\Log::info('CtaCte estado:',array($estado));

				if ($estado != "OK"){
					$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,41,$usuario,27,29,$mensaje);
					\Log::info($mensaje);
				}else{
					$exito = 1;
					// generar fichero estado OK o DF
					$nombre_exportacion = 'VUELCO_CTACTE';
					$nombre_archivo = 'CAS_ZIP_'.$nroSecuencia.'.log';
					$ruta_archivo =  $destinoCasLog.$ds;
					$contenido = $nroSecuencia .' '. $estado .' '. $mensaje;
					$exportacion_fichero = $this->PrcExp_GrabarRegistros($nombre_exportacion,$nombre_archivo, $ruta_archivo, $contenido);	
					$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,42,$usuario,27,29,$mensaje);
				}						
				if($exito == 1){
					/***************************************************
						Fin correcto de recepcion
					*****************************************************/
					// ruta de destino en archivo de configuracion (modificar desde ese archivo)
					
					$archivo_original = $archivoCas->getClientOriginalName();
					\Log::info('Nombre archivo recibido:', array($archivo_original));
					
					$destinoAS400=$destinoAS400.$ds;
					$ficherocaszip =$destinoAS400.$archivo_original;
					$destinoLiquidaciones = $destinoLiquidaciones.$archivo_original;
					
					$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,39,$usuario,27,29,"Inicio paso de archivo cas.zip para AS");
					if(!is_dir($destinoAS400) && !file_exists($destinoAS400)){
						File::makeDirectory($destinoAS400, $mode = 0777, true, true);
					}else{
						array_map('unlink', glob($destinoAS400."*"));
					}

					if (!copy($destinoLiquidaciones, $ficherocaszip)) {
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,40,$usuario,39,38,"Inicio paso de archivo cas.zip para AS");
						$mensaje="Error al copiar $destinoLiquidaciones...\n";
						\Log::info($mensaje);
					}
					
					$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,38,$usuario,27,29,"Finalización correcta de recepción liquidaciones");
					//$exito = 1;
					//$mensaje="Carga correcta de los archivos de liquidaciones.";
				}else{
					$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,37,$usuario,26,27,"Procesando recepción de liquidaciones ".$mensaje);
					\Log::info($mensaje);
					$exito = 0;
				}
			}
		} // Fin foreach($archivosSubidos as $archivo)
		$mensaje = $mensaje.' '.$link_auditoria;
							
		// INI ACA ENVIAR MAIL
		$mail_cuerpo_paq = 'Vuelco de cta cte Agencias, secuencia '.$nroSecuencia.' finalizado. Resultado: '.$mensaje;
		$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
		\Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));
		$envio=$this->CtaCte_EnviaMailCasZip($datos_mail);
		if (!$envio){
			$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail -->' .  array($envio) . '<--' . PHP_EOL;
			\Log::info($log);
		}			
		// FIN ACA ENVIAR MAIL
		// INI ACA ENVIAR MAIL x MAILCHIMP
		$datos_mail['mail_cuerpo_paq']=$mail_cuerpo_paq;
		
		\Log::info(' - RECEP CAS.ZIP - Datos envio mail x mailchimp -->', array($datos_mail));
				
		$envio=$this->CtaCte_EnviaMailCasZip_Mailchimp($datos_mail);
		if (!$envio){
			$log =  ' - RECEP CAS.ZIP - Falló el envío de e-mail x mailchimp -->';
			\Log::info($log, array($envio));
		}			
		// FIN ACA ENVIAR MAIL x MAILCHIMP						
		
		return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		
	}
	/*************************** MM - recepción liquidaciones - fin ****************************************/
	
	public function PrcExp_GrabarRegistros($nombre_exportacion,$nombre_archivo, $ruta_archivo, $contenido){

		// funcion que graba
		$ds=DIRECTORY_SEPARATOR;
		$destino = $ruta_archivo;
	
		if(!is_dir($destino) && !file_exists($destino)){
		  File::makeDirectory($destino, 0777, true);
		}
		
			//			$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, $contenido. "\r\n",FILE_APPEND);//FILE::put( $destino.$ds.$nombre_archivo, $contenido);
				
						$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, mb_convert_encoding($contenido, "Windows-1252") . "\r\n",FILE_APPEND); //FILE::put( $destino.$ds.$nombre_archivo, $contenido);

				IF ($bytes_written === FALSE)
				{
					//die("Error writing to file");
					//$exito = 0;
					//$mensaje="Error guardando archivo.";
					//return Response::json(array('exito'=>true, 'mensaje'=>$mensaje));
					return false;
				}else{
					//$nombre_archivo_ant = $nombre_archivo;
				//	Session::put('nombre_archivo_ant',$nombre_archivo_ant);
					return true;
				}
	}

	/************************************
	 Envío email envía paquete
	**************************************/
	/*
	public function CtaCte_EnviaMail($datos_mail){
		try{
			\Log::info('Nombre archivo recibido:', array($datos_mail));
				$correosoperadores=Config::get('mail.operadores');
				$mloteria=Config::get('mail.from.address');
				$correos = array(
					'destinatarios'=>$correosoperadores,
					'remitente'=>$mloteria);
				$juegoSorteo=$this->servicioCuentaCorriente->getDatosSorteo($datos_mail['id_sorteo']);
				$mesnaje = $datos_mail['msg'];

				$nombreUsuarioLogueado=Session::get('usuarioLogueado.nombreUsuario');
				$cuerpo_mail='Existe problema para publicar: '.$juegoSorteo.' - '.$mesnaje;

				$data = array(
					'usuarioGenerador'=>$nombreUsuarioLogueado,
					'cuerpo_mail'=>$cuerpo_mail
				);

				Mail::send('emails.email_aviso_publicacion', $data, function ($message) use ($correos){
					
					$concatenoEmails = "";
					$message->from($correos['remitente'], 'Publicación Sorteo');
					$message->subject('Acuse Fallo en Publicación.');
					foreach ((array)$correos['destinatarios'] as $email) {
						$arregloEmail = explode(";", $email);
						foreach ($arregloEmail as $mail) {
							if (isset($mail) && $mail != ""){ 
									$concatenoEmails = $concatenoEmails . $mail .  ";";
							}
						}					    	
					}
					$concatenoEmails = substr($concatenoEmails, 0, -1);
					$message->to(explode(";",$concatenoEmails));

					
				});
				
				if(count(Mail::failures()) > 0){
					\Log::error('Problema al enviar el correo aviso de publicación de sorteo. '.$e);
					return false;
				}else{
					return true;
				}
			}catch(Exception $e){
				\Log::error('Problema al enviar el correo aviso de publicación de sorteo. '.$e);
				return false;
			}
	}
*/
	/***************************************************
	 Envío email recepción cas.zip
	****************************************************/
	public function CtaCte_EnviaMailCasZip($datos_mail){
		try{
				\Log::info(' - CtaCte_EnviaMailCasZip - INI - Secuencia: '.$datos_mail['nroSecuencia'].'.');
				$mail_remite_paq = $datos_mail['mail_remite_paq'];
				$mail_alias_remite_paq = $datos_mail['mail_alias_remite_paq'];
				$mail_destino_paq = $datos_mail['mail_destino_paq'];
				$mails= (explode(";",$mail_destino_paq));
				$adjunto = $datos_mail['arch_adjunto'];
				$url_descarga = $datos_mail['url_descarga'];
				//\Log::info('adjunto',array($adjunto));
				//\Log::info('url_descarga',array($url_descarga));
				$asunto = $datos_mail['mail_asunto_paq'];
				$cuerpo = $datos_mail['mail_cuerpo_paq'];

				$nombreUsuarioLogueado=Session::get('usuarioLogueado.apellido');
				//'usuarioLogueado.nombreUsuario'

				$destinatarios = array();
				$destinatarios = $mails;
				/*
				foreach ($mails as $mail)
					{
						array_push($destinatarios,$mail);	
					}
				*/	
				$correos = array(
					'destinatarios'=>$destinatarios,
					'remitente'=>$mail_remite_paq,
					'remitente_alias'=>$mail_alias_remite_paq,
					'asunto'=>$asunto,
					'adjunto'=>$adjunto
				);
				$data = array(
					'usuarioGenerador'=>$nombreUsuarioLogueado,
					'cuerpo_mail'=>$cuerpo,
					'adjunto'=>$url_descarga
				);
				Mail::send('emails.email_aviso_publicacion', $data, function ($message) use ($correos){
					//$message->from($correos['remitente'], 'Generación Paquete');
					$message->from($correos['remitente'], $correos['remitente_alias']);
					$message->subject($correos['asunto']);
					if($correos['adjunto']!=''){
						$message->attach($correos['adjunto']);	
					}
					
					foreach ($correos['destinatarios'] as $email) {
						//\Log::info(' - CtaCte_EnviaMailCasZip - ENVIANDO EMAIL - Secuencia: '.$datos_mail['nroSecuencia'].' - e-mail: '.array($email));
						if(isset($email))
							$message->to($email);
					}
				});
				
				if(count(Mail::failures()) > 0){
					\Log::error(' - CtaCte_EnviaMailCasZip - ENVIO DE EMAIL ERROR - Secuencia: '.$datos_mail['nroSecuencia']);
					// return false;
					return true;
				}else{
					\Log::info(' - CtaCte_EnviaMailCasZip - ENVIO DE EMAIL OK - Secuencia: '.$datos_mail['nroSecuencia']);
					return true;
				}
				
			}catch(Exception $e){
				\Log::error(' - CtaCte_EnviaMailCasZip - ENVIO DE EMAIL ERROR - Secuencia: '.$datos_mail['nroSecuencia'].' - Error: '.$e);
				// return false;
				return true;
			}
	}

	/***************************************************
	 Envío email recepción cas.zip x mailchimp
	****************************************************/
	public function CtaCte_EnviaMailCasZip_Mailchimp($datos_mail){
		\Log::info(' Recepción cas.zip - Envío mail por mailchimp - INI - Secuencia: '.$datos_mail['nroSecuencia'].'.');
		$mail_remite_paq = $datos_mail['mail_remite_paq'];
		$mail_alias_remite_paq = $datos_mail['mail_alias_remite_paq'];
		$mail_destino_paq = $datos_mail['mail_destino_paq'];
		$mails= (explode(";",$mail_destino_paq));
		$adjunto = $datos_mail['arch_adjunto'];
		$url_descarga = $datos_mail['url_descarga'];


		$nombreUsuarioLogueado=Session::get('usuarioLogueado.apellido');
		//'usuarioLogueado.nombreUsuario'

		//$url_mailchimp_transactional = 'http://devcas2.i2tsa.com.ar/MailchimpTransactional/envia_mail_cmd.php'; // desarrollo
		$url_mailchimp_transactional = 'https://historicos.loteriasantafe.gov.ar/MailchimpTransactional/envia_mail_cmd.php'; //produccion

		$from_email = 'noreply@loteriasantafe.gov.ar';
		$from_name  = $mail_alias_remite_paq;
		//$from_email= $datos_mail['mail_remite_paq'];
		// to:  soporte@i2t.com.ar cdc_santafe@boldt.com.ar
		//$correo_soporte = "soporte@i2t.com.ar; cdc_santafe@boldt.com.ar";
		//$correo_soporte = "cdc_santafe@boldt.com.ar";
		$correo_soporte = "cristian.valle@i2t.com.ar; ruben.larocca@i2t.com.ar; adrian.enrico@i2t.com.ar; luis.mariotti@i2t.com.ar";

		//$asuntomail = $datos_mail['mail_asunto_paq'];
		$asuntomail = "sbx - ".$datos_mail['mail_asunto_paq'];
		$body = $datos_mail['mail_cuerpo_paq'];
		

		//$url_descarga = $datos_mail['url_descarga'];
		//$attach = $datos_mail['arch_adjunto']; // $url_descarga: usar esta como alternativa si falla el attach
		$attach = '';
		$tipo_archivo = '';
		$nombre_archivo = '';
		\Log::info('Recepción cas.zip - Envío mail a BOLDT por mailchimp - INI - Secuencia: '.$datos_mail['nroSecuencia'].' - datos_mail: from_email ->'.$from_email.'<- correo_soporte ->'.$correo_soporte.'<- asuntomail ->'.$asuntomail.'<- body ->'.$body.'<- attach ->'.$attach.'<-');	
		
		try {

			$curl = curl_init();
			// Check if initialization had gone wrong*    
			if ($curl === false) {
				throw new Exception('Envío de MAIL  a BOLDT por mailchimp: No se pudo enviar el e-mail.');
				\Log::info(" Recepción cas.zip - Envío mail  a BOLDT por mailchimp: No se pudo enviar el e-mail. Fallo inicializacion CURL - envio mail a soporte. Destinatarios: ".$correo_soporte);
			}

			$fields = array(
			'from_email'     => $from_email,
			'from_name'      => $from_name,
			'to_email'       => $correo_soporte,
			'subject'        => $asuntomail,
			'cuerpo'         => $body,
			'attach'         => $attach,
			'tipo_archivo'   => $tipo_archivo,
			'nombre_archivo' => $nombre_archivo
			);

			$fields_string = http_build_query($fields);
			curl_setopt($curl, CURLOPT_URL, $url_mailchimp_transactional);
			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

			$data = curl_exec($curl);

			// Check the return value of curl_exec(), too
			if ($data === false) {
				\Log::info(" Recepción cas.zip - Envío mail a BOLDT por mailchimp: Fallo en el envío del mail. Datos de envío ->".$fields_string."<- Resultado: ", array($data));
				throw new Exception(curl_error($curl), curl_errno($curl));
			}

			// Check HTTP return code, too; might be something else than 200
			$httpReturnCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
			\Log::info(" Recepción cas.zip - Envío mail a BOLDT por mailchimp: Correo enviado a ".$correo_soporte.". Status envio mail: " . $httpReturnCode . ' Error: ' . curl_error($curl) . ' Nro. Error: ' . curl_errno($curl) . "\n" );

			//Process $content here 
			\Log::info(' Recepción cas.zip - Envío mail a BOLDT por mailchimp - FIN OK - Secuencia: '.$datos_mail['nroSecuencia'].'.');
			$ret = true;
		} catch(Exception $e) {
			$ret = false;
			\Log::info(' Recepción cas.zip - Envío mail a BOLDT por mailchimp: Se produjo una excepción: Cod->'.$e->getCode().'<- Detalle: ->'.$e->getMessage().'<-');
		} finally {
			// Close curl handle unless it failed to initialize
			if (is_resource($curl)) {
				curl_close($curl);
			}
		}
		
		//$correo_soporte = "soporte@i2t.com.ar";
		$correo_soporte = "cristian.valle@i2t.com.ar; ruben.larocca@i2t.com.ar; adrian.enrico@i2t.com.ar; luis.mariotti@i2t.com.ar";

		\Log::info(' Recepción cas.zip - Envío mail a SOPORTE por mailchimp - INI - Secuencia: '.$datos_mail['nroSecuencia'].' - datos_mail: from_email ->'.$from_email.'<- correo_soporte ->'.$correo_soporte.'<- asuntomail ->'.$asuntomail.'<- body ->'.$body.'<- attach ->'.$attach.'<-');			
		
		try {

			$curl = curl_init();
			// Check if initialization had gone wrong*    
			if ($curl === false) {
				throw new Exception('Envío de MAIL a SOPORTE por mailchimp: No se pudo enviar el e-mail.');
				\Log::info(" Recepción cas.zip - Envío mail a SOPORTE por mailchimp: No se pudo enviar el e-mail. Fallo inicializacion CURL - envio mail a soporte. Destinatarios: ".$correo_soporte);
			}

			$fields = array(
			'from_email'     => $from_email,
			'from_name'      => $from_name,
			'to_email'       => $correo_soporte,
			'subject'        => $asuntomail,
			'cuerpo'         => $body,
			'attach'         => $attach,
			'tipo_archivo'   => $tipo_archivo,
			'nombre_archivo' => $nombre_archivo
			);

			$fields_string = http_build_query($fields);
			curl_setopt($curl, CURLOPT_URL, $url_mailchimp_transactional);
			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

			$data = curl_exec($curl);

			// Check the return value of curl_exec(), too
			if ($data === false) {
				\Log::info(" Recepción cas.zip - Envío mail a SOPORTE por mailchimp: Fallo en el envío del mail. Datos de envío ->".$fields_string."<- Resultado: ", array($data));
				throw new Exception(curl_error($curl), curl_errno($curl));
			}

			// Check HTTP return code, too; might be something else than 200
			$httpReturnCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
			\Log::info(" Recepción cas.zip - Envío mail a SOPORTE por mailchimp: Correo enviado a ".$correo_soporte.". Status envio mail (200 ok): " . $httpReturnCode . ' Error: ' . curl_error($curl) . ' Nro. Error: ' . curl_errno($curl) . "\n" );

			//Process $content here 
			\Log::info(' Recepción cas.zip - Envío mail a SOPORTE por mailchimp - FIN OK - Secuencia: '.$datos_mail['nroSecuencia'].'.');
			$ret = true;
		} catch(Exception $e) {
			$ret = false;
			\Log::info(' Recepción cas.zip - Envío mail a SOPORTE por mailchimp: Se produjo una excepción: Cod->'.$e->getCode().'<- Detalle: ->'.$e->getMessage().'<-');
			\Log::info(' Recepción cas.zip - Envío mail a SOPORTE por mailchimp - FIN ERR - Secuencia: '.$datos_mail['nroSecuencia'].'.');
		} finally {
			// Close curl handle unless it failed to initialize
			if (is_resource($curl)) {
				curl_close($curl);
			}
		}

		return $ret;
	}

	/***************************************************
	 Envío mensaje al MIDDLEWARE
	****************************************************/
	public function enviaMensajeMiddleware($datos_mensaje){
			\Log::info('Envio de mensajes al Middleware - INI - Secuencia: ', array($datos_mensaje));

			// me voy sin enviar el mensaje!!!
			//\Log::info('Envio de mensajes al Middleware - INI - ENVIO DE MENSAJE ANULADO HASTA SOLUCIONAR PROBLEMA HTTPS');
			//$ret = true;
			//return $ret;


			// Recupero la direccion del servicio
			$url_webserservice = Config::get('ctacte_config/config.url_middleware');
			$api_key = Config::get('ctacte_config/config.X-API-KEY');
			$curl = null; // <-- MEJORA: Inicializar a null para el finally			
			
			try {
				$curl = curl_init();
				// Check if initialization had gone wrong*    
				if ($curl === false) {
					// throw new Exception('Envio de mensajes al Middleware - Error en iniciacion del CURL.');
					\Log::info("Envio de mensajes al Middleware -  Envio de mensajes al Middleware: No se pudo enviar el mensaje a Sala de Sorteos.");
				}


			$curl_version_debug = curl_version();

			\Log::info('Envio de mensajes al Middleware - INI - version del curl: ', array($curl_version_debug));
			//echo "Info Completa de cURL: <pre>";
			//print_r($curl_version_debug); 
			//echo "</pre><br>";

/* el modelo de los datos del mensaje es
				$datos_mensaje = array(
					'topic' => 'Sorteador.Apuestas',
					'message' => array(
						'id_sorteo' => "xxxxxxxxxxxxxxxxxxx",
						'nro_sorteo' => "3259",
						'id_producto' => "04",
						'nombre_producto' => "Quini 6",
						'fecha_sorteo' => "07/05/2025",
						'fecha_prescripcion' => "22/05/2025",
						'fecha_proximo' => "11/05/2025"
					)
				);
*/

				// 1. Conviertl el array de datos a un string en formato JSON
				$json_data = json_encode($datos_mensaje);

				// 2. Defino las cabeceras necesarias, incluyendo el tipo de contenido y la API Key
				$headers = [
					'Content-Type: application/json',
					'X-API-KEY: ' . $api_key, 
					'Content-Length: ' . strlen($json_data) // Buena práctica incluir el tamaño
				];

				curl_setopt($curl, CURLOPT_URL, $url_webserservice);
				curl_setopt($curl, CURLOPT_POST, true);
				curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data); // Envía el string JSON
				curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);   // Añade las cabeceras
				curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);   // Para recibir la respuesta como string
				curl_setopt($curl, CURLOPT_TIMEOUT, 30);            // Timeout de 30 segundos (recomendado)

				$response_body = curl_exec($curl);
				
				// <-- MEJORA: Separar la verificación de error de cURL del error de HTTP
				if ($response_body === false) {
					// Error a nivel de conexión (red, timeout, etc.)
					$curl_error_msg = curl_error($curl);
					$curl_error_no = curl_errno($curl);
					// no quiero disparar un error, solo quiero dejar un log!!!
					// throw new Exception($curl_error_msg, $curl_error_no);
					\Log::info("Envio de mensajes al Middleware - Fallo en el envío mensajes. Error ->".$curl_error_no."<- Mensaje: ", array($curl_error_msg));
				}

				$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

				// <-- MEJORA: Verificar el código de estado HTTP para errores de aplicación
				if ($http_status_code >= 400) {
					// throw new Exception("La API devolvió un error. Código HTTP: {$http_status_code}. Respuesta: {$response_body}", $http_status_code);
					\Log::info("Envio de mensajes al Middleware - La API devolvió un error. Código HTTP: ".$http_status_code." Respuesta: ", array($response_body));
				} else {
					// Si todo fue bien, registramos el éxito
					Log::info("Envio de mensajes al Middleware - Mensaje enviado exitosamente.", ['topic' => $datos_mensaje['topic'], 'status' => $http_status_code]);
					$ret = true;
				}
			} catch(Exception $e) {
				$ret = false;
				\Log::info(' Recepción cas.zip - Envío mail a BOLDT por mailchimp: Se produjo una excepción: Cod->'.$e->getCode().'<- Detalle: ->'.$e->getMessage().'<-');
			} finally {
				// Close curl handle unless it failed to initialize
				if (is_resource($curl)) {
					curl_close($curl);
				}
			}
			

			return $ret;
	}
}
