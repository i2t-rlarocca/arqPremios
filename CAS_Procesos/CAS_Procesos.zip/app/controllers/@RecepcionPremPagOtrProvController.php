<?php

use \Helpers\Macros;
use \Dominio\Servicios\RecepcionPrePagados; 
use \Dominio\Servicios\CuentasCorrientes;
use controllers\UsuarioController; 
use \Helpers\Util;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;

class RecepcionPremPagOtrProvController extends BaseController{

	public $error_descomprimir_archivo = "Error al descomprimir el archivo";
	public $error_crear_carpeta_temporal = "Error al crear la carpeta temporal";
	public $error_carga_pre_pagados = "Error al cargar los datos en las tablas temporales";
	public $error_llamada_store_procedure = "Error al llamar al store procedure";
	public $error_proceso_ya_existente = "Proceso ya existente";
	//public $error_carga_sorteos_diarios = "Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al juego/sorteo seleccionado."; 
	//public $error_carga_comisiones ="Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al período indicado.";
	//public $err_nro_sorteo_archivo = "El archivo de %s no corresponde al sorteo elegido.";
	public $err_falta_archivo = "Falta archivo de %s";
	//public $err_datos_sorteo = "Problema al obtener los datos del sorteo: %s";
   	public $err_mas_archivos = "Hay más archivos de los esperados para %s.";
	public $err_menos_archivos = "Hay menos archivos de los esperados para %s.";
	public $err_proces="Problema al procesar %s.";
	public $err_cant_archivos = "Existe problema de integridad de archivos esperados para %s.";
	
	public $err_nomb_archivos ="COD-002;COD-003 No se recibió el archivo de datos o de control.";
	public $err_paquete ="COD-001 El paquete recibido no coincide con el formato esperado.";
	
	function __construct() {
		$this->servicioRecepcionPrePagados = new RecepcionPrePagados();
		$this->servicioCuentaCorriente = new CuentasCorrientes();
		$this->destinoTemporal = Config::get('ctacte_config/config.urlDestino');
		$this->destinoPrePagadosOtrProv = $this->destinoTemporal.Config::get('ctacte_config/config.urlPrePagadosOtrProv');
	
	}
	
	
	public function camposPanelRecepcionPrePagadosOtrProv(){
		$especif_archivo=$this->servicioRecepcionPrePagados->especif_arch_premiospagados_otrprov();
		//Uso una macro como respuesta custom, obtengo un html con la vista 
		return Response::recepcionPrePagOtrProv($especif_archivo);
	}

	//Llamada para la vista, le paso los datos obtenidos de la macro
	public function panelRecepcionPrePagadosOtrProv(){
		$campos=$this->camposPanelRecepcionPrePagadosOtrProv();
		// crear id_proceso char(36) uuid()
		$resultadoGenIdPorc = $this->servicioRecepcionPrePagados->GeneraIdProc();
		$id_ejec_proc = $resultadoGenIdPorc[0]->id_proceso;
		return View::make('cuenta_corriente.panelRecepcionPrePagadosOtrProv', array('campos'=>$campos,'id_ejec_proc'=>$id_ejec_proc));
	}

//Para el log de errores 

	/****************************************/
	/*	nuevo tratamiento para pago			*/
	/****************************************/
	
		public function tratamientoArchivoPremPagOtrProv(){ //Llamada recibida desde el javascript
		// variables
		$util = new Util();
		$ds=DIRECTORY_SEPARATOR;
		$destino=$this->destinoPrePagadosOtrProv;
		$idJuego=999;
			\Log::info('MM - tratamientoArchivoPremPagOtrProv - inputfile: ',array(Input::file()));
			\Log::info('MM - tratamientoArchivoPremPagOtrProv - inputall: ',array(Input::all()));
		$id_ejec_proc = Input::get('id_ejec_proc');

		$exito = 0;
		$mensaje = 'Problema en subida de archivo';
		$usuario= Session::get('usuarioLogueado.idUsuario');
		$flag = '';
		//Obtengo el numero de proceso de Auditoria
		$idProceso = $this->servicioRecepcionPrePagados->getNumeroProcesoAuditoria();		

			if(!is_dir($destino) && !file_exists($destino)){
			  File::makeDirectory($destino, 0777, true);
			}
		
			$archivosSubidos = Input::file();
			
			foreach($archivosSubidos as $archivo){
				$filename = $archivo->getClientOriginalName();
				$arregloNombre=explode(".",$filename);	
				$nombreSinExtension =$arregloNombre[0]; 
				$nombreSinExtension = substr($nombreSinExtension,2,8);
				\Log::info('MM - tratamientoArchivoPremPagOtrProv - nombreSinExtension: ',array($nombreSinExtension));
				$archivos=$this->servicioRecepcionPrePagados->especif_arch_x_juego_otrprov();
				
					try{
						$archivos=$archivos[999];
					}catch(\Exception $e){
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nombreSinExtension,890,$usuario,890,891,"Formato erróneo: ".$filename);
						$exito=0;
						$mensaje=sprintf($this->error_carga_pre_pagados," Problemas de configuración de archivo contactese con el administrador.");
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));  
					}
					
					$archivos=$util->groupArray($archivos,'tipo_archivo');
					$archivosHijosOP =array();
					$archivosPadresOP =array();
					$this->listasArchivos($archivos, $listaOP, $archivosHijosOP, $archivosPadresOP, "OP",9);

						$destinoPrePagadosOtrProv =$destino.$ds;
					
							if(!is_dir($destinoPrePagadosOtrProv) && !file_exists($destinoPrePagadosOtrProv)){
								File::makeDirectory($destinoPrePagadosOtrProv, $mode = 0777, true, true);
							}else{
								array_map('unlink', glob($destinoPrePagadosOtrProv."*"));
							}

					   	$archivoOP = $archivo; //Input::file($nombreSinExtension);

						$resultado=$util->controlZip($archivoOP, $destinoPrePagadosOtrProv, $listaOP, $idJuego,'',9);
						$proc_ok=1;
					   	if($resultado['exito']){
							//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($destinoPrePagadosOtrProv);
							$ficheros1 = array();
							foreach ($ficheros as $fichero){
								if((strpos($fichero,"ZIP") || strpos($fichero,"zip")) < 1 && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}

							if(count($ficheros1)!= $archivosPadresOP[0]['cant_arch_esperados']){
								$mensaje=sprintf($this->err_mas_archivos,"premios pagados otras provincias");
								\Log::info($mensaje);
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
							}
							/***************************************************
								indicando la recepcion y validaciones
							*****************************************************/
						
							$archivoDatos=explode(".",$ficheros1[1]);
							\Log::info('MM - archivoDatos: ',array($archivoDatos));
							\Log::info('MM - sorteo: ',array(substr($archivoDatos[0],2,12)));
							$sorteo = substr($archivoDatos[0],2,12);
							$juego = 999;
							
							foreach ($ficheros1 as $nombreFichero) {
								\Log::info('MM - nombreFichero: ',array($nombreFichero));
								$dest=$destinoPrePagadosOtrProv.$nombreFichero;
								\Log::info('MM - dest: ',array($dest));
								$arch=explode(".",$nombreFichero);	
								$Extension = strtoupper(substr($arch[1],0,3)); 
								\Log::info('MM - Extension: ',array($Extension));
								
								// inserto auditoria de inicio
								$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,890,$usuario,890,891,"Inicio vuelco archivo: ".$nombreFichero." idproceso: ".$idProceso);
								switch ($Extension) {
									case "CTR":
												\Log::info('MM - CTR - destinoPrePagadosOtrProv.ficheros1[1]: ',array($destinoPrePagadosOtrProv.$ficheros1[0]));
											$ok = $this->servicioRecepcionPrePagados->cargarPremiosPagadosOtrasProvinciasControl($idProceso,$dest,$destinoPrePagadosOtrProv.$ficheros1[0]); // enviamos ambos archivos para md5 calculado
										break;
									case "CNA":
												\Log::info('MM - CNA - destinoPrePagadosOtrProv.ficheros1[1]: ',array($destinoPrePagadosOtrProv.$ficheros1[0]));
											$ok = $this->servicioRecepcionPrePagados->cargarPremiosPagadosOtrasProvincias($idProceso,$dest);
										break;
									case "TXT":
												\Log::info('MM - TXT - destinoPrePagadosOtrProv.ficheros1[1]: ',array($destinoPrePagadosOtrProv.$ficheros1[0]));
											$ok = $this->servicioRecepcionPrePagados->cargarPremiosPagadosOtrasProvincias($idProceso,$dest);
										break;
									default:	
											$proc_ok = 0;
											$exito = 0;
											$mensaje=sprintf($this->err_nomb_archivos," - premios pagados otras provincias."); // cod 002 y cod 003
											\Log::info($mensaje);
									break;
								}
							}
						}else{//ERROR DESCOMPRIMIR
							$mensaje=sprintf($this->err_paquete); // cod 001
							$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,890,$usuario,890,891,"Fallo descompresión archivos vuelco - idproceso: ".$idProceso);
							\Log::info($mensaje);
							$exito = 0;
							return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
						}
						// fin descompresion correcto
						
		/****************************************************/
		/*			VALIDACIONES ENVIOS	- 	ENV	(control)	*/
		/****************************************************/
		$datos=$idProceso.'----'.$sorteo.'----'.$usuario;
		\Log::info('MM - datos:',array($datos));
		
		$msj_env = $this->servicioRecepcionPrePagados->validarEnviosOtrProv($idProceso,$sorteo,$usuario,'ENV');
		\Log::info('MM - msj_env',array($msj_env));
		
		if($msj_env->cod_error == '003'){
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-003 vuelco de archivos a tablas rec ".$filename);
    		$mensaje = "COD-003 No se recibió el archivo de control.";
    		$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
    	}
		
		if($msj_env->cod_error == '004'){		
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-004 vuelco de archivos a tablas rec ".$filename);
			$mensaje = "COD-004 La firma md5 del archivo de datos no coincide con la enviada.";
			$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		}
	
		if($msj_env->cod_error == '005'){		
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-005 vuelco de archivos a tablas rec ".$filename);
			$mensaje = "COD-005 No coincide la cantidad de registros recibida con la indicada en el archivo de control.";
			$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		}

		if($msj_env->cod_error == '006'){		
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-006 vuelco de archivos a tablas rec ".$filename);
			$mensaje = "COD-006 No coincide el importe total recibido con la indicada en el archivo de control.";
			$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		}
		
		if($msj_env->cod_error == '007'){		
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-007 vuelco de archivos a tablas rec ".$filename);
			$mensaje = "COD-007 Existen registros que no corresponden a la provincia indicada en el archivo de control.";
			$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		}

		$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,892,$usuario,891,893,"Fin validacion control");

		/*****************************************************/
		/*			VALIDACIONES ENVIOS	- REG	(registros)	**/
		/*****************************************************/

		$msj_reg = $this->servicioRecepcionPrePagados->validarEnviosOtrProv($idProceso,$sorteo,$usuario,'REG');
		if($msj_reg->cod_error != '0'){
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-666 Problema en la ejecución de validacion por registros.");
			$mensaje = "COD-666 Problema en la ejecución de validacion por registros.";
			$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		}else{
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,892,$usuario,890,891,"FIN OK validación por registros de PREMIOS OTRAS PROV");
			\Log::info('Finalizo correctamente la validación de registros');
		}

		$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,893,$usuario,891,892,"INICIO PROCESAMIENTO PREMIOS OTRAS PROV");
		/*	procesa los registros y setea codigo de error o bien 0 si el registro cumple con todas las validaciones */
	
					$msj_process = $this->servicioRecepcionPrePagados->Procesar_pre_pagados_otrporv($idProceso,'IN');

					if ($msj_process->cod_error == '1'){
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,895,$usuario,894,896,"ERROR PROCESAMIENTO PREMIOS OTRAS PROV");
						$mensaje = "Error en el Procesamiento de Premios";	 
						$exito = 0;
						\Log::info($mensaje);
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));	
					}else{
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,894,$usuario,893,896,"PROCESAMIENTO OK PREMIOS OTRAS PROV");
						\Log::info('Finalizo correctamente el procesamiento de registros');
						$nombre_archivo_ant = '0'; 
						Session::put('nombre_archivo_ant',$nombre_archivo_ant);
						$nombre_exportacion = 'PREMIOS_OTRAS_PROVINCIAS';
						$traeRegistros = 0;
						$contenidoRegistro = $this->servicioRecepcionPrePagados->Procesar_pre_pagados_otrporv_out($idProceso,'OUT'); 

						foreach ($contenidoRegistro as $reg){
							$traeRegistros++;
							$contenido = $reg->contenido;																
							$nombre_archivo = $reg->nombre_archivo;
							$path_archivo = $reg->ruta;
							$resGrabarRegistros=$this->PrcExp_GrabarRegistros($nombre_exportacion,$nombre_archivo,$path_archivo,$contenido);
						}
					}
			}

			if($traeRegistros>0){
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,896,$usuario,895,897,"PROCESAMIENTO OK PREMIOS OTRAS PROV");
				$path_archivo= $path_archivo.$ds;
				$nombre_archivo = $path_archivo.$nombre_archivo; 
				$nombre_archivo = str_replace('.TXT', '.ZIP', $nombre_archivo);
					\Log::info('MM - nombre_archivo',array($nombre_archivo)); 
					\Log::info('MM - path_archivo',array($path_archivo)); 
					// empaquetar en zip
					$resPrcExp_Empaquetar=$this->PrcExp_Empaquetar($nombre_archivo, $path_archivo);
					\Log::info('MM - resPrcExp_Empaquetar',array($resPrcExp_Empaquetar)); 
						if (!$resPrcExp_Empaquetar){
							 $this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,897,$usuario,896,898,"ERROR AL GENERAR ZIP");
							// $resultadoUpdateEstFinEr=$this->servicioExportaciones->UpdatePrcExpEstadoFin($nombre_exportacion,$id_exp_tipo,$envio,'',"Finalizado er");
								$exito = 0;
								$mensaje="Error de empaquetado al generar ZIP.";
								return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
						 }else{
							
							// inserto registro para tabla de descargas del zip// realiza insert estado NUEVO
							$resultadoInstNue=$this->servicioRecepcionPrePagados->InsertPrcExpNuevo($nombre_exportacion,$id_ejec_proc,$idProceso,null,$nombre_archivo,null,$sorteo);
						}
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,897,$usuario,896,897,"GENERO ARCHIVO PREMIOS OTRAS PROV CON ERR");
				$exito = 1;
				$mensaje="El proceso de premios pagados otras provincias detecto registros con errores.";
			}else{
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,898,$usuario,897,898,"PROCESAMIENTO OK PREMIOS OTRAS PROV");
				$exito = 1;
				$mensaje="El proceso de premios pagados otras provincias finalizo correctamente.";
			}
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
	}

	/********************************************************
	* tratamiento Grabar Registros
	*********************************************************/
	public function PrcExp_GrabarRegistros($nombre_exportacion,$nombre_archivo, $ruta_archivo, $contenido){

			$ds=DIRECTORY_SEPARATOR;
			$destino = $ruta_archivo;

			if(!is_dir($destino) && !file_exists($destino)){
			  File::makeDirectory($destino, 0777, true);
			}

			$nombre_archivo_ant = Session::get('nombre_archivo_ant');
			
			if($nombre_archivo_ant == '0' || $nombre_archivo_ant != $nombre_archivo){
				if($nombre_exportacion == 'PREMIOS_OTRAS_PROVINCIAS')
				{
					$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, $contenido);//FILE::put( $destino.$ds.$nombre_archivo, $contenido);
				}else{
					$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, mb_convert_encoding($contenido, "Windows-1252") . "\r\n" );//FILE::put( $destino.$ds.$nombre_archivo, $contenido);
				}
			}
			if($nombre_archivo_ant == $nombre_archivo){
					if($nombre_exportacion == 'PREMIOS_OTRAS_PROVINCIAS')
					{
						$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, $contenido. "\r\n",FILE_APPEND);//FILE::put( $destino.$ds.$nombre_archivo, $contenido);
					}else{
						$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, mb_convert_encoding($contenido, "Windows-1252") . "\r\n",FILE_APPEND); //FILE::put( $destino.$ds.$nombre_archivo, $contenido);
					}
			}
			
			IF ($bytes_written === FALSE)
			{	return false;	}else{
									$nombre_archivo_ant = $nombre_archivo;
									Session::put('nombre_archivo_ant',$nombre_archivo_ant);
									return true;
								}
	}
	
	
		public function PrcExp_Empaquetar($nombre_paquete,$paq_path){
			\Log::info('PrcExp_Empaquetar - nombre_paquete',array($nombre_paquete));
			\Log::info('PrcExp_Empaquetar - paq_path',array($paq_path));
			try{
				$ds=DIRECTORY_SEPARATOR;
				// generar zip
						//$zipper = $zip->open('test.zip', ZipArchive::CREATE);
						$zip = new ZipArchive;
							$res = $zip->open($nombre_paquete, ZipArchive::CREATE);
							if ($res === TRUE) {
								//buscar los archivos en la carpeta y pasarlos a la tabla
									$ficheros = scandir($paq_path);
								
									//$ficheros1 = array();
									foreach ($ficheros as $fichero){
										if($fichero!= "." && $fichero!= ".."){
											$zip->addFile($paq_path.$ds.$fichero,$fichero);
										}
									}
								$zip->close();
								return true;
							} 
							
				}catch(\Exception $e){
						\Log::info("Error PrcExp_Empaquetar");
						\Log::info($e);
						return false;
				}
			}
	
	/***********************************************************
	* carga div con paquetes ya procesados  *
	************************************************************/
	
	public function paquetesPremiosOtrasProv(){
		$datos_input_panel = Input::all();
		$nombre_exportacion = $datos_input_panel['tipo_exportacion'];
		\Log::info('paquetesPremiosOtrasProv - datos_input_panel',array($datos_input_panel));
		$resConsultaPaquetesExportacion=$this->servicioRecepcionPrePagados->ConsultaPaquetesPremOtrProv($nombre_exportacion);
			if($resConsultaPaquetesExportacion){
				$exito = 1;
				$mensaje=$resConsultaPaquetesExportacion;
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}else{
				$exito = 0;
				$mensaje="No se registran exportaciones.";
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}
	}
	
	/*****************************************
	* lista de archivos según la transacción
	******************************************/
	private function listasArchivos($archivos, &$lista, &$hijos, &$padres, $ta, $transac){
		//lista de archivos 
		foreach ($archivos as $archivo) {
			if($archivo['tipo_archivo']==$ta ){
				$lista=$archivo['grupodatos'];
				break;
			}
		}
		if(isset($lista)){
			//busco el arch. padre y los hijos
			foreach ($lista as $archivo) {
				if($archivo['id_padre']=='' && $archivo['transaccion']== $transac){
					array_push($padres,$archivo);								
				}else{
					array_push($hijos,$archivo);
				}
			}			
		}
	}
	
}

?>