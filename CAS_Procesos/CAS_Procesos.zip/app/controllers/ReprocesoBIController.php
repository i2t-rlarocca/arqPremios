<?php
	
use \Helpers\Macros;
use \Dominio\Servicios\ReprocesoBI; 

use controllers\UsuarioController; 
use \Helpers\Util;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;

class ReprocesoBIController extends BaseController {
	//MENSAJES ERROR VARIOS 
	  public $error_carga_sorteos_diarios = "Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al juego/sorteo seleccionado."; 
	  public $error_carga_comisiones ="Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al período indicado.";
	  public $err_nro_sorteo_archivo = "El archivo de %s no corresponde al sorteo elegido.";
	  public $err_falta_archivo = "Falta archivo de %s";
	  public $err_datos_sorteo = "Problema al obtener los datos del sorteo: %s";
   	  public $err_mas_archivos = "Hay más archivos de los esperados para %s.";
	  public $err_menos_archivos = "Hay más archivos de los esperados para %s.";
	  public $err_proces="Problema al procesar %s.";
	  public $error_carga_vuelco_bi ="Problema al procesar %s.";
	function __construct() {
		$ds=DIRECTORY_SEPARATOR;

		//$this->servicioAfectaciones = new Afectaciones();
		//$this->servicioApuestas = new Apuestas();
		//$this->servicioPremios = new Premios();
		//$this->servicioCuentaCorriente = new CuentasCorrientes();
		//$this->servicioCaratulas = new Caratulas();
		//$this->servicioResultados = new Resultados();
		//$this->servicioComisiones = new Comisiones();
		$this->controladorUsuario = new UsuarioController();
		
		// Servicio ReprocesoBI
		$this->servicioReprocesoBI = new ReprocesoBI();
		
		//$this->destinoTemporal = Config::get('ctacte_config/config.urlDestino');
		
		//$this->destinoTemporalSinProcesar= $this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalSinProcesar');
		//$this->destinoFinalCaratula=$this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalCaratula');
		//$this->destinoFinalResultados=$this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalResultados');
		//$this->destinoTemporalResultados= $this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalResultados');
		//$this->destinoFinalConsolidacion=$this->destinoTemporal;//.Config::get('ctacte_config/config.urlFinalConsolidacion');
		//$this->destinoTemporalConsolidacion= $this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalConsolidacion');
		
		//$this->destinoComisiones = $this->destinoTemporal.Config::get('ctacte_config/config.urlComisiones');

		//$this->srcImgError=Config::get("ctacte_config/config.urlImgError");
		//$this->srcImgPeligro=Config::get("ctacte_config/config.urlImgPeligro");
		//$this->srcImgOk=Config::get("ctacte_config/config.urlImgOk");
	}

	

	/***********************************
	* Armado del panel de reproceso-bi
	************************************/
	public function camposPanelReprocesoBI(){
		$mesesReprocesoBI=array();
		$datosTransaccion['nombre_mes']=array();
		$mesesReprocesoBI=$this->servicioReprocesoBI->getMesesReprocesoBI();//especif_arch_x_juego();
		
		\Log::info($mesesReprocesoBI);
		$primera_vez = true;
		Session::put('idMessorEstado', $mesesReprocesoBI);

		return $mesesReprocesoBI;
	}

	
	public function validaPeriodoBI(){
		$validaPeriodo=array();
		$validaPeriodo=$this->servicioReprocesoBI->valida_periodo();
		\Log::info($validaPeriodo);

		Session::put('validaPeriodo', $validaPeriodo);
		return $validaPeriodo;
	}
	/***********************************
	* Llamada al panel de reproceso-bi
	************************************/
	public function panelReprocesoBI(){
		$campos=$this->campospanelReprocesoBI();
		$periodosValidados=$this->validaPeriodoBI();
		return View::make('reprocesoBI.panelReprocesoBI', array('campos'=>$campos,'valida'=>$periodosValidados));
	}
		
	/********************************************************
	* Recepción de los datos desde el panel de reproceso-bi  *
	*********************************************************/
	public function tratamientoReprocesoBI(){
		//definición de variables
		$util = new Util();
		$mensaje="";
		$exito=true;
		$datos= Input::all();
		$arr = array();
		$usuario= Session::get('usuarioLogueado.idUsuario');
		$mensaje=array();
		
		try{
		$mensaje=$this->servicioReprocesoBI->procesaPeriodo($datos['p_periodo'],$datos['p_estado'],$datos['p_a_partir_fallo'],$datos['p_completo'],$datos['p_incl_cuad_afec'],$datos['p_dif_ejec']);
		$arr = explode("-",$mensaje);
		
		if($arr[0] == "1"){
			\Log::info("Problema servicioReprocesoBI - procesaPeriodo");
			$exito=false;
			return Response::json(array('mensaje'=>$arr[1],'exito'=>$exito));
		}
		else{
			// ejecuta shell etl
			
			shell_exec("/opt/ETL/BI/Principal/exec_etl_bi.sh");
			//exec('../../../../../opt/ETL/BI/exec_etl_bi.sh');
			
	
			return Response::json(array('mensaje'=>$arr[1],'exito'=>$exito));
		}
		
		
					
				}catch(\Exception $e){
					$mensaje=sprintf($this->error_carga_vuelco_bi," procesa vuelco");
					\Log::info($mensaje);
					\Log::info($e);
					return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
				}
			}

		//	return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		
	
	
	
	
/******************************* original ***************************************/

	/****************************************************************
	* Ingreso desde el panel principal - carga de usuario
	*****************************************************************/
	/*
	public function cargaUsuarioEnAppCtaCte(){
		$util = new Util();
		if(!Session::has("datos_ingreso")){
			return Redirect::to('/portal');
		}
		$datosIngreso=Session::get("datos_ingreso");
		$datosIngreso=explode("&",$datosIngreso);
		$usuario=explode("usuario=",$datosIngreso[0]);
		$id_portal=explode("id_portal=",$datosIngreso[1])[1];
		$letra_portal=explode("letra_portal=",$datosIngreso[2])[1];
		$nombre_usuario=$util->decrypt($usuario[1],"Pir@mide01");
		
		$usuario=$this->controladorUsuario->buscar($nombre_usuario);
	
		//borra todos los datos anteriores
		Session::flush();
		
		if(is_null($usuario["idUsuario"])|| is_null($usuario)){
			$mensaje='Hay un problema con su usuario.';
			Session::put('mensaje_acceso',$mensaje);
			\Log::error("problema con el usuario - nulo");
			Session::flush();
	       	return Redirect::to('/acceso-no-autorizado');
		}else if (!in_array('Administracion_ctacte',$usuario['funciones'])){
			$mensaje='Su tipo de usuario no posee acceso.';
			Session::put('mensaje_acceso',$mensaje);
	       	return Redirect::to('/acceso-no-autorizado');
		}
		$usuario['id_portal']=$id_portal;
		$usuario['letra_portal']=$letra_portal;
		Session::put('usuarioLogueado',$usuario);
		return Redirect::to('/panel-principal');
	}
	
*/
	/***********************************************************
	* Carga el usuario en la aplicación o lo retorna al portal *
	* si no está logueado o no tiene permiso.                  *
	************************************************************/
/*
	public function cargaUsuarioEnApp(){
		$util = new Util();
		if(!Session::has("datos_ingreso")){
			return Redirect::to('/portal');
		}
		
		$datosIngreso=Session::get("datos_ingreso");
		$datosIngreso=explode("&",$datosIngreso);
		$usuario=explode("usuario=",$datosIngreso[0]);
		$id_portal=explode("id_portal=",$datosIngreso[1])[1];
		$letra_portal=explode("letra_portal=",$datosIngreso[2])[1];
		$nombre_usuario=$util->decrypt($usuario[1],"Pir@mide01");
		
		$usuario=$this->controladorUsuario->buscar($nombre_usuario);	
		
		
		//borra todos los datos anteriores
		Session::flush();
		
		if(is_null($usuario["idUsuario"])|| is_null($usuario)){
			$mensaje='Hay un problema con su usuario.';
			Session::put('mensaje_acceso',$mensaje);
			Session::flush();
	       	return Redirect::to('/acceso-no-autorizado');
		}else if (!in_array('Administracion_ctacte',$usuario['funciones'])){
			$mensaje='Su tipo de usuario no posee acceso.';
			Session::put('mensaje_acceso',$mensaje);
	       	return Redirect::to('/acceso-no-autorizado');
		}
		$usuario['id_portal']=$id_portal;
		$usuario['letra_portal']=$letra_portal;
		Session::put('usuarioLogueado',$usuario);
		return Redirect::to('/panel-alertas');
	}

			
// las funciones que siguen a continuación estan solo para "robar" codigo ejemplo :P

*/

	/*****************************************************
	* Arma los datos necesarios para la tabla de sorteos *
	******************************************************/
/*
	private function tablaSorteos(){
		Session::forget('tipoArchivoJuegoEstado');
		$sorteos=$this->servicioCuentaCorriente->sorteos_panel_alertas();
		$datos['titulo_tabla']="Sorteos días anteriores";
		$datos['id_tabla']="tabla_sorteos_anteriores";
		$datos['id_body']="cuerpo_sda";
		$datos['dia']=$sorteos['diasAnteriores'];
		$tablaDiasAnteriores=Response::tablaPrimerPanel($datos);
		$datos['titulo_tabla']="Sorteos del día";
		$datos['id_tabla']="tabla_sorteos_del_dia";
		$datos['id_body']="cuerpo_sd";
		$datos['dia']=$sorteos['diaActual'];
		$tablaDiaActual=Response::tablaPrimerPanel($datos);		
		$tablas = $tablaDiasAnteriores.$tablaDiaActual;
		$archivos = $this->servicioCuentaCorriente->especif_arch_x_juego();
		Session::put('tipoArchivoJuegoEstado', $archivos);
		return $tablas;
	}
*/

	/********************************************
	* Función que carga el panel de transacción *
	*********************************************/
/*
	public function cargarPanelTransaccion(){
		$idsorteo = Input::get('id_seleccionado');
		$idEstado = Input::get('id_estado_seleccionado');
		$idJuego = Input::get('id_juego_seleccionado');
		$nro_sorteo = Input::get('nro_sorteo');

		$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $nro_sorteo);

		return Response::json(array('exito'=>1, 'datosTransaccion'=>$resultado));
	}
	
	private function transacciones($idsorteo, $idEstado,$idJuego, $nro_sorteo){
		$util = new Util();
		//verificación de si puede hacer algo o debe esperar que se procese un sorteo anterior
		$puedeProcesar = $this->servicioCuentaCorriente->puedeProcesar($nro_sorteo, $idJuego);
		if($puedeProcesar){
		
			if(Session::has('tipoArchivoJuegoEstado'))
				$archivos = Session::get('tipoArchivoJuegoEstado');
			else
				$archivos = $this->servicioCuentaCorriente->especif_arch_x_juego();

			$datosVistaTransaccion=array();
			$datosVistaTransaccion['botones']=array();
			$archivosApedir=array();
			
			$datosVistaTransaccion['puedeProcesar']=1;
			//Armado según la transacción que debe activarse
			if(in_array($idEstado, array(0,10,15))){//carátula
				$datosTransaccion['nombre_file']=array();
				$crt=0;
				$apu=0;
				foreach ($archivos[$idJuego] as $archJuego) {
					if($archJuego['transaccion']==1 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='CT'){//caratula
							$crt++;
							$archivo['nombre']='car_'.$crt;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'CT', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Pozoz Ctrl.';
							else
								$archivo['buttonText']='Pozos';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						if($archJuego['tipo_archivo']=='AP'){//apuesta
							$apu++;
							$archivo['nombre']='apu_'.$apu;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'AP', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Apuesta Ctrl.';
							else
								$archivo['buttonText']='Apuesta';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						$archivo['extension']=str_replace("+" ,"",str_replace("+[[:alpha:]]", "\w", $archJuego['extension']));
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}
				//según el estado cambia el btn
				$btn['id_btn']="btn_caratula";
				$btn['value_btn']="PROCESAR";
				array_push($datosVistaTransaccion['botones'], $btn);

				$datosVistaTransaccion['id_estado']=$idEstado;
				$datosTransaccion['transaccion_activa']=1;
			}else if(in_array($idEstado, array(20,25))){//resultados
				$datosTransaccion['nombre_file']=array();
				$rs=0;
				$su=0;
				$ex=0;
				foreach ($archivos[$idJuego] as $archJuego) {
					if($archJuego['transaccion']==2 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='RT'){//resultados
							$rs++;
							$archivo['nombre']='res_'.$rs;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'RT', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Resultados Ctrl.';
							else
								$archivo['buttonText']='Resultados';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='SU'){//sueldos
							$su++;
							$archivo['nombre']='sue_'.$su;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'SU', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Sueldos Ctrl.';
							else
								$archivo['buttonText']='Sueldos';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='EX'){//extractos
							$ex++;
							$archivo['nombre']='ex_'.$ex;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'EX', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Extracto Ctrl.';
							else
								$archivo['buttonText']='Extracto';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						$archivo['extension']=str_replace("+" ,"",str_replace("+[[:alpha:]]", "\w", $archJuego['extension']));
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}
				//según el estado cambia el btn
				$btn['id_btn']="btn_resultados";
				$btn['value_btn']="PROCESAR";
				array_push($datosVistaTransaccion['botones'], $btn);
				$datosVistaTransaccion['id_estado']=$idEstado;
				//chequeo si ya existen archivos
				$usuario = Session::get('usuarioLogueado.idUsuario');
				$ds = DIRECTORY_SEPARATOR;
				//paths a las carpetas 
				$destinoTemporalResultados = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$nro_sorteo.$ds."resultados";
				$destinoTemporalSueldos = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$nro_sorteo.$ds."sueldos";
				
				$this->archivosPrevios($destinoTemporalResultados, $datosVistaTransaccion, $archivos[$idJuego],2);
				$this->archivosPrevios($destinoTemporalSueldos, $datosVistaTransaccion, $archivos[$idJuego],2);

				$datosTransaccion['transaccion_activa']=2;
			}else if(in_array($idEstado, array(30,34,36))){//consolidación
				$datosTransaccion['nombre_file']=array();
				$af=0;
				$ap=0;
				$pr=0;
				$dr=0;
				$i=0;

				foreach ($archivos[$idJuego] as $archJuego) {
					if($archJuego['transaccion']==3 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='AP'){//apuestas
							$af++;
							$archivo['nombre']='apu_'.$af;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'AP', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Apuestas Ctrl.';
							else
								$archivo['buttonText']='Apuestas';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='AF'){//afectaciones
							$ap++;
							$archivo['nombre']='afe_'.$ap;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'AF', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Afectaciones Ctrl.';
							else
								$archivo['buttonText']='Afectaciones';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='PR'){//premios
							$pr++;
							$archivo['nombre']='pre_'.$pr;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'PR', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Premios Ctrl.';
							else
								$archivo['buttonText']='Premios';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='DR'){//premios retencion/detalle
							$dr++;
							$archivo['nombre']='dr_'.$dr;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'DR', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s'){//se usa para cdo son archivos individuales
								$archivo['buttonText']='Premios Ret. Ctrl.';
							}else{
*/								
								/*if($i==0){ //se usa para cdo son archivos individuales
									$archivo['buttonText']='Premios Ret. Det.';
									$i++;
								}else*/
/*								
									$archivo['buttonText']='Premios Ret.';
							}
							array_push($datosTransaccion['nombre_file'],$archivo);
						}

						//$archivo['extension']=$archJuego['extension'];
						//revisar!!!
						$archivo['extension']=str_replace("+" ,"",str_replace("+[[:alpha:]]", "\w", $archJuego['extension']));
						$archivo['extension']=str_replace("C{1}","[C]",$archivo['extension']);
						$archivo['extension']=str_replace("P{1}","[P]",$archivo['extension']);
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}
*
				//según el estado cambia el btn
				$btn['id_btn']="btn_procesar";
				$btn['value_btn']="PROCESAR";
				array_push($datosVistaTransaccion['botones'], $btn);
				$datosVistaTransaccion['id_estado']=$idEstado;

				//chequeo si ya existe un archivo para apuestas
				$usuario = Session::get('usuarioLogueado.idUsuario');
				$ds = DIRECTORY_SEPARATOR;
				//paths a las carpetas 
				$destinoTemporalSinProcesar = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$nro_sorteo.$ds."apuestas";
				
				$this->archivosPrevios($destinoTemporalSinProcesar, $datosVistaTransaccion, $archivos[$idJuego],3);

				$datosTransaccion['transaccion_activa']=3;
			}else if(in_array($idEstado, array(38,40))){//consolidado-publicación pte
				$datosVistaTransaccion['id_estado']=$idEstado;
				$datosTransaccion['transaccion_activa']=3;
				//según el estado cambia el btn
				$btn['id_btn']="btn_publicar";
				$btn['value_btn']="PUBLICAR";
				array_push($datosVistaTransaccion['botones'], $btn);
*/				
				/*$btn['id_btn']="btn_ver_totales";
				$btn['value_btn']="VER&#x00A;TOTALES";
				array_push($datosVistaTransaccion['botones'], $btn);*/
/*				
				$datosVistaTransaccion['id_estado']=$idEstado;
				
				$datos = $this->servicioCuentaCorriente->datosPGMSorteo($nro_sorteo,$idJuego);//nl2br(htmlentities($cadena));
				$datosTransaccion['datos']="Cupones: ".$datos['tck_afe']."\nApuestas: ".$datos['apu_afe']."\nRecaudación: ".$datos['rec_afe']."\nPremios: ".$datos['pre_afe'];
			}else if(in_array($idEstado, array(45))){//probl. en public
				$datosVistaTransaccion['id_estado']=$idEstado;
				$datosTransaccion['transaccion_activa']=3;
				//según el estado cambia el btn
				$btn['id_btn']="btn_publicar";
				$btn['value_btn']="PUBLICAR";
				array_push($datosVistaTransaccion['botones'], $btn);
*/				
				/*$btn['id_btn']="btn_ver_totales";
				$btn['value_btn']="VER&#x00A;DIFERENCIAS";
				array_push($datosVistaTransaccion['botones'], $btn);*/
/*				
				$datosVistaTransaccion['id_estado']=$idEstado;
			}else if(in_array($idEstado, array(50))){//publicado
				$datosVistaTransaccion['id_estado']=$idEstado;
				$datosTransaccion['transaccion_activa']=4;
			}
			
			$datosVistaTransaccion['nombreFiles']=$archivosApedir;
			
			$datosTransaccion['id_estado']=$idEstado;
			$datosTransaccion['vista']= Response::liquidacion_apu_com($datosVistaTransaccion);
		}else{
			$datosTransaccion['puedeProcesar']=0;
			$datosTransaccion['id_estado']=$idEstado;
			if(in_array($idEstado, array(0,10,15))){
				$datosTransaccion['transaccion_activa']=1;
			}else if(in_array($idEstado, array(20,25))){
				$datosTransaccion['transaccion_activa']=2;
			}else if(in_array($idEstado, array(30,34,36))){
				$datosTransaccion['transaccion_activa']=3;
			}else if(in_array($idEstado, array(38,40,45))){
				$datosTransaccion['transaccion_activa']=3;
			}else if(in_array($idEstado, array(50))){
				$datosTransaccion['transaccion_activa']=4;
			}		
			$datosTransaccion['vista']= Response::liquidacion_apu_com($datosTransaccion);			
		}
		return $datosTransaccion;
	
	}
*/
	/********************************************************
	* Función que obtiene los archivos para consolidación   *
	*********************************************************/
/*	public function obtenerArchivos(){
		$idJuego = Input::get('id_juego_seleccionado');
		$idEstado = Input::get('id_estado_seleccionado');
		$sorteo = Input::get('sorteo');
		$fechaSorteo = Input::get('fecha');
		$formatoProcesamiento = Input::get('id_formato_procesamiento');
		$usuario = Session::get('usuarioLogueado.idUsuario');
		$entrada = Input::all();
		$ds = DIRECTORY_SEPARATOR;
		list($af,$ap,$pr,$dr,$exito)=0;
		$apu_i=1;
		//paths a las carpetas destino
		list($anio,$mes,$dia)=explode("-",$fechaSorteo);
		$destinoFinalConsolidacion= $this->destinoFinalConsolidacion.$anio.$ds.$mes.$ds.$idJuego."_".$sorteo.$ds;
		$destinoTemporalSinProcesar = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		$destinoTemporalConsolidacion = $this->destinoTemporalConsolidacion.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		
		//creación de las carpetas
		if(!is_dir($destinoFinalConsolidacion) && !file_exists($destinoFinalConsolidacion)){
		  File::makeDirectory($destinoFinalConsolidacion, 0777, true);
		}
		if(!is_dir($destinoTemporalSinProcesar) && !file_exists($destinoTemporalSinProcesar)){
		  	File::makeDirectory($destinoTemporalSinProcesar, 0777, true);
		}else{
			$archivosSinProcesar=scandir($destinoTemporalSinProcesar);
		}
		if(!is_dir($destinoTemporalConsolidacion) && !file_exists($destinoTemporalConsolidacion)){
		  File::makeDirectory($destinoTemporalConsolidacion, 0777, true);
		}

		//vemos qué archivos deberían pedirse
		if(Session::has('tipoArchivoJuegoEstado'))
			$archivos = Session::get('tipoArchivoJuegoEstado');
		else
			$archivos = $this->servicioCuentaCorriente->especif_arch_x_juego();

		//archivos para el juego seleccionado
		$archivos=$archivos[$idJuego];
		
		$util = new Util();
		$archivos=$util->groupArray($archivos,'tipo_archivo');
		$listaTiposArchivos=array();
		$listaArchivosRequerimiento=array();
		foreach ($archivos as $tiposArc) {
			array_push($listaArchivosRequerimiento,$tiposArc);
			array_push($listaTiposArchivos,$tiposArc['tipo_archivo']);
		}
		//vemos qué tipo de requerimiento tienen los archivos o=opcional, r=requerido
		$archivosRequerimientos=array();
		foreach ($listaArchivosRequerimiento as $archReq) {
			foreach ($archReq['grupodatos'] as $especificacion) {
				if($especificacion['transaccion']==3){
					$arReq[$archReq['tipo_archivo']]=$especificacion['requerido'];
					$archivosRequerimientos[$archReq['tipo_archivo']]=$arReq;	
				}
			};
		}

		$mensaje="TODO OK";
			
		//afectaciones está en la lista de archivos a de la transacción y es requerido u opcional
		if(in_array("AF", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['AF']['AF'],'R')==0 || strcasecmp($archivosRequerimientos['AF']['AF'],'O')==0)){//afectaciones
		
			try{
				//destino para los archivos de afectaciones
				$destinoTemporalConsolidacionAFE =$destinoTemporalSinProcesar."afectaciones".$ds;
				if(!is_dir($destinoTemporalConsolidacionAFE) && !file_exists($destinoTemporalConsolidacionAFE)){
				    File::makeDirectory($destinoTemporalConsolidacionAFE, $mode = 0777, true, true);
				}else{
					//\File::cleanDirectory($destinoTemporalConsolidacionAFE);
					array_map('unlink', glob($destinoTemporalConsolidacionAFE."*"));
					//\File::deleteDirectory($destinoTemporalConsolidacionAFE, $preserve = false);
				}
				
				//verifico cómo deben ser los archivos (individuales, padre=>nº de hijos)
				list($archivosHijos,$archivosPadres,$listaNombresInput)=array([],[],[]);
				$this->listasArchivos($archivos, $listaAfectaciones, $archivosHijos, $archivosPadres, "AF",3);
				$listaArchivos["afe_ctrl"]=array();
				$listaArchivos["afe_det"]=array();
				if(count($archivosPadres)>1){//son archivos unitarios
					$this->estanTodosLosArchivos($destinoTemporalConsolidacionAFE,"afectaciones","afe_",$archivosPadres, $listaArchivos);
					$af=1;
				}else{//hay un padre contenedor
					$af=2;					
					//verifico si existe uno anterior
					$destinoTemporalSinProcesarAF=$destinoTemporalSinProcesar.'afectaciones'.$ds;
					$archivosAF=array();
					
					foreach ($archivos as $tipoArchivo) {
						if(strcasecmp($tipoArchivo['tipo_archivo'], "AF")===0){
							$archivosAF=$tipoArchivo['grupodatos'];							
						}
					}
					
					$this->archivosPrevios($destinoTemporalSinProcesarAF,$previos, $archivosAF,3);
					$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"afe_", "afectaciones",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionAFE,$listaAfectaciones ,$idJuego,$listaArchivos, $previos);
					
					
					if(!$dezipeoOK['exito']){
						return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
					}
					
				}
				
			}catch(\Exception $e){
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"afectaciones");
				\Log::info($mensaje);
				\Log::info($e);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
			}
		}

		if(Input::hasFile("apu_".$apu_i) && in_array("AP", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['AP']['AP'],'R')==0 || strcasecmp($archivosRequerimientos['AP']['AP'],'O')==0)){//apuestas
			try{
				$destinoTemporalConsolidacionAP =$destinoTemporalSinProcesar."apuestas".$ds;
				if(!is_dir($destinoTemporalConsolidacionAP) && !file_exists($destinoTemporalConsolidacionAP)){
				  File::makeDirectory($destinoTemporalConsolidacionAP, 0777, true);
				}else{
					array_map('unlink', glob($destinoTemporalConsolidacionAP."*"));
				}
				
				$previos=array();
				$archivosHijos =array();
				$archivosPadres =array();
				$listaArchivos["apu_ctrl"]=array();
				$listaArchivos["apu_det"]=array();
				$this->listasArchivos($archivos, $listaApuestas, $archivosHijos, $archivosPadres, "AP",3);
				
				if(count($archivosPadres)>1){//son archivos unitarios
					$ap=1;
					$this->estanTodosLosArchivos($destinoTemporalConsolidacionAP,"apuestas","apu_",$archivosPadres,$listaArchivos);
				}else{//hay un padre contenedor
					$ap=2;
					$i=1;
					//verifico si existe uno anterior
					$destinoTemporalSinProcesarAP=$destinoTemporalSinProcesar.'apuestas'.$ds;
					$archivosAP=array();
					foreach ($archivos as $tipoArchivo) {
						if(strcasecmp($tipoArchivo['tipo_archivo'], "AP")===0)
							$archivosAP=$tipoArchivo['grupodatos'];
					}
					
					$this->archivosPrevios($destinoTemporalSinProcesarAP,$previos, $archivosAP,3);
					
					$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"apu_", "apuestas",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionAP,$listaApuestas ,$idJuego,$listaArchivos, $previos);			
					if(!$dezipeoOK['exito']){
						return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
					}
					
				}//fin padre contenedor
			}catch(\Exception $e){
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"apuestas");
				\Log::info($mensaje);
				\Log::info($e);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
			}
		}else if(in_array("AP", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['AP']['AP'],'R')==0)){// || strcasecmp($archivosRequerimientos['AP']['AP'],'O')==0
			$ap=2;//porque se que es un zip... ¿y si no lo fuera?
			//verifico si existe uno anterior
			$destinoTemporalSinProcesarAP=$destinoTemporalSinProcesar.'apuestas'.$ds;
			
			$archivosAP=array();
			foreach ($archivos as $tipoArchivo) {
				if(strcasecmp($tipoArchivo['tipo_archivo'], "AP")===0)
					$archivosAP=$tipoArchivo['grupodatos'];
			}
			
			$this->archivosPrevios($destinoTemporalSinProcesarAP,$previos, $archivosAP,3);
			
			if($previos['archivosPrevios']['existenArchivosPrevios']){
				$archPrev = $previos['archivosPrevios']['archivos'];
				foreach ($archPrev as $prev) {
					foreach($prev['nombre_archivo'] as $p){
							$archivoApu=$p;
					}
				}
			}else{
			   	$mensaje=sprintf($this->err_falta_archivo,'apuestas');
				\Log::info($mensaje);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
			}	
			$archivoApu=$destinoTemporalSinProcesarAP.$archivoApu;
			$destinoTemporalConsolidacionAP =$destinoTemporalSinProcesar."apuestas".$ds;
			if(!is_dir($destinoTemporalConsolidacionAP) && !file_exists($destinoTemporalConsolidacionAP)){
			  File::makeDirectory($destinoTemporalConsolidacionAP, 0777, true);
			}
			$archivosHijos =array();
			$archivosPadres =array();
			$listaArchivos["apu_ctrl"]=array();
			$listaArchivos["apu_det"]=array();
			$this->listasArchivos($archivos, $listaApuestas, $archivosHijos, $archivosPadres, "AP",3);

			$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"apu_", "apuestas",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionAP,$listaApuestas ,$idJuego,$listaArchivos, $previos);			
			if(!$dezipeoOK['exito']){
				return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
			}
	}

	if(in_array("PR", $listaTiposArchivos)&& (strcasecmp($archivosRequerimientos['PR']['PR'],'R')==0 || strcasecmp($archivosRequerimientos['PR']['PR'],'O')==0)){//premios
		try{
			
			$destinoTemporalConsolidacionPR =$destinoTemporalSinProcesar."premios".$ds;
			if(!is_dir($destinoTemporalConsolidacionPR) && !file_exists($destinoTemporalConsolidacionPR)){
			  File::makeDirectory($destinoTemporalConsolidacionPR, 0777, true);
			}else{
				//\File::cleanDirectory($destinoTemporalConsolidacionPR);
				array_map('unlink', glob($destinoTemporalConsolidacionPR."*"));
			}
			
			$previos=array();
			$archivosHijos =array();
			$archivosPadres =array();
			$listaArchivos['pre_ctrl']=array();
			$listaArchivos['pre_det']=array();
			$this->listasArchivos($archivos, $listaPremios, $archivosHijos, $archivosPadres, "PR",3);
			
			if(count($archivosPadres)>1){//son archivos unitarios
				$pr=1;				
				$this->estanTodosLosArchivos($destinoTemporalConsolidacionPR,"premios","pre_",$archivosPadres, $listaArchivos);
			}else{//hay un padre contenedor
					$pr=2;
					//verifico si existe uno anterior
					$destinoTemporalSinProcesarPR=$destinoTemporalSinProcesar.'premios'.$ds;
					$archivosPR=array();
					foreach ($archivos as $tipoArchivo) {
						if(strcasecmp($tipoArchivo['tipo_archivo'], "PR")===0)
							$archivosPR=$tipoArchivo['grupodatos'];
					}
			
					$this->archivosPrevios($destinoTemporalSinProcesarPR,$previos, $archivosPR,3);
					$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"pre_", "premios",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionPR,$listaPremios ,$idJuego,$listaArchivos, $previos);
					if(!$dezipeoOK['exito']){
						return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
					}
					
				
			}
		}catch(\Exception $e){
			$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios");
			\Log::info($mensaje);
			\Log::info($e);
			return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		}
		
	}

	if(in_array("DR", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['DR']['DR'],'R')==0 || strcasecmp($archivosRequerimientos['DR']['DR'],'O')==0)){//premios retención/detalle
		try{
			$destinoTemporalConsolidacionDR =$destinoTemporalSinProcesar."premios_retenciones".$ds;
			if(!is_dir($destinoTemporalConsolidacionDR) && !file_exists($destinoTemporalConsolidacionDR)){
			    File::makeDirectory($destinoTemporalConsolidacionDR, $mode = 0777, true, true);
			}else{
				array_map('unlink', glob($destinoTemporalConsolidacionDR."*"));
			}
			$previos=array();
			$archivosHijos =array();
			$archivosPadres =array();
			$this->listasArchivos($archivos, $listaDR, $archivosHijos, $archivosPadres, "DR",3);
			$listaArchivos['dr_ctrl']=array();
			$listaArchivos['dr_det']=array();				
			$listaNombresInput=array();
			if(count($archivosPadres)>1){//son archivos unitarios
				$dr=1;
				$this->estanTodosLosArchivos($destinoTemporalConsolidacionDR,"premios retencion","dr_",$archivosPadres, $listaArchivos);
			}else{//hay un padre contenedor
				$dr=2;
				//verifico si existe uno anterior
				$destinoTemporalSinProcesarRet=$destinoTemporalSinProcesar.'premios_retenciones'.$ds;
				$archivosDR=array();
				foreach ($archivos as $tipoArchivo) {
					if(strcasecmp($tipoArchivo['tipo_archivo'], "DR")===0)
						$archivosDR=$tipoArchivo['grupodatos'];
				}
				$this->archivosPrevios($destinoTemporalSinProcesarRet,$previos, $archivosDR,3);
				$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"dr_", "premios retenciones",$archivosPadres,$archivosHijos, $destinoTemporalSinProcesarRet,$listaDR ,$idJuego,$listaArchivos, $previos);					
				if(!$dezipeoOK['exito']){
					return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
				}
			}
			
		}catch(\Exception $e){
			$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios retención");
			\Log::info($mensaje);
			\Log::info($e);
			return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		}
		
	}

		//carga de los archivos
		if($af==1){
			$archivoAfe = $listaArchivos['afe_det'][0];		
			$archivoAfeCtrl = $listaArchivos['afe_ctrl'][0];
			$res=$this->archivosAfectaciones($archivoAfe, $archivoAfeCtrl, $destinoTemporalConsolidacionAFE,1);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,5);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'afectaciones');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{//error carga archivos
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"afectaciones");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}else if($af==2){
			$archivoAfe = $listaArchivos['afe_det'][0];		
			$archivoAfeCtrl = $listaArchivos['afe_ctrl'][0];		
			$okAfe=$this->servicioAfectaciones->cargarAfectacion($archivoAfe);
			$okCtrlAfe=$this->servicioAfectaciones->cargarAfectacionControl($archivoAfeCtrl, $archivoAfe);
			if($okAfe && $okCtrlAfe){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,5);
				
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'afectaciones');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"afectaciones");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}

		if($ap==1 && $exito==1){
			$archivoApu = $listaArchivos['apu_det'][0];		
			$archivoApuCtrl = $listaArchivos['apu_ctrl'][0];
			$res=$this->archivosApuestas($archivoApu, $archivoApuCtrl, $destinoTemporalConsolidacionAP,1,$idJuego, $formatoProcesamiento);
			
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,2);
				
				if($sorteoCorrecto==1){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'apuestas');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"apuestas");	
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}else if($ap==2 && $exito==1){
			$archivoApu = $listaArchivos['apu_det'][0];		
			$archivoApuCtrl = $listaArchivos['apu_ctrl'][0];
			$okCtrlApu=$this->servicioApuestas->cargarApuestasControl($archivoApuCtrl, $archivoApu);
			$okApu=$this->servicioApuestas->cargarApuestas($archivoApu, $idJuego, $formatoProcesamiento);
			
			if($okApu && $okCtrlApu){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,2);
				
				if($sorteoCorrecto==1){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'apuestas');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       											
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"apuestas");	
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}

		if($pr==1 && $exito==1){
			$archivoPr = $listaArchivos['pre_det'][0];	
			$archivoPreCtrl = $listaArchivos['pre_ctrl'][0];
			$res=$this->archivosPremios($archivoPr, $archivoPreCtrl, $destinoTemporalConsolidacionPR,1,$idJuego);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,3);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       										
			}
		}else if($pr==2 && $exito==1){
			$archivoPr = $listaArchivos['pre_det'][0];		
			$archivoPreCtrl = $listaArchivos['pre_ctrl'][0];
			$okCtrlPre=$this->servicioPremios->cargarPremiosControl($archivoPreCtrl, $archivoPr);
			$okPre=$this->servicioPremios->cargarPremio($archivoPr);
			if($okPre && $okCtrlPre){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,3);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;			
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}

		if($dr==1){
			$archivosDr = $listaArchivos['dr_det'];		
			$archivoDrCtrl = $listaArchivos['dr_ctrl'][0];
			$res=$this->archivosPremiosRetencion($archivosDr, $archivoDrCtrl, $destinoTemporalConsolidacionDR,1,1);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,6);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios retencion');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{//error carga archivos
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios retención");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}else if($dr==2){
			$archivosDr = $listaArchivos['dr_det'];	
			$archivosDr=array_unique($archivosDr);		
			$archivoDrCtrl = $listaArchivos['dr_ctrl'][0];
*/			
			/*foreach($archivosDr as $archivoDr)
				$okDr=$this->servicioPremios->cargarPremiosRetDet($archivoDr);
			$okCtrlDr=$this->servicioPremios->cargarPremiosRetencionControl($archivoDrCtrl, $archivosDr);*/
/*			
			$res=$this->archivosPremiosRetencion($archivosDr, $archivoDrCtrl, $destinoTemporalConsolidacionDR,1,2);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,5);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios retencion');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios retención");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		}
		if($exito){
			//llamo al stored para consolidar
			$idProceso=$this->servicioCuentaCorriente->getNumeroProcesoAuditoriaCtaCte($idJuego, $sorteo);
			
			$mensaje=$this->servicioCuentaCorriente->consolidar($idJuego, $sorteo, $fechaSorteo, $idProceso, $usuario);
			$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
						
			//si todo da ok armo la vista --> incluyo mensaje de cupones	
			if(strcasecmp (trim(strtoupper($mensaje)), 'OK') ==0){//consolidó correctamente
				if(isset($datos)){
					$idEstado=$datos['idEstado'];
					$idsorteo=$datos['idPgmSorteo'];
					$desc_estado=$datos['de_estado'];
					$mensaje = "Cupones: ".$datos['tck_afe']."\nApuestas: ".$datos['apu_afe']."\nRecaudación: ".$datos['rec_afe']."\nPremios: ".$datos['pre_afe'];
					$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
					$this->moverArchivosTemporalFinal($destinoTemporalSinProcesar,$destinoFinalConsolidacion,$idJuego,1);
					
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
				}else{//acá no debería entrar nunca
					$exito=0;
					$mensaje=sprintf($this->err_datos_sorteo, $sorteo);//ver si acá el estado es 30 o no...
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgPeligro));
				}
			}else{
				$exito=0;
				$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
				$idEstado=$datos['idEstado'];
				$idsorteo=$datos['idPgmSorteo'];
				$desc_estado=$datos['de_estado'];
				$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgError, 'datosTransaccion'=>$resultado));
				//return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>34, 'srcImagen'=>$this->srcImgError));
			}			
		}else{
			$exito=0;
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
		}
	}
*/
	/********************************************************
	* Función que obtiene los archivos para carátula   *
	*********************************************************/
/*	public function obtenerArchivosCaratula(){
		$idJuego = Input::get('id_juego_seleccionado');
		$idEstado = Input::get('id_estado_seleccionado');
		$idsorteo = Input::get('id_seleccionado');
		$sorteo = Input::get('sorteo');
		$fechaSorteo = Input::get('fecha');
		$formatoProcesamiento = Input::get('id_formato_procesamiento');
		$usuario = Session::get('usuarioLogueado.idUsuario');
		$ds = DIRECTORY_SEPARATOR;
		$ap=0;
		
		//paths a las carpetas destino
		$destinoTemporalSinProcesar = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		$destinoFinal=$this->destinoFinalCaratula.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		if(!is_dir($destinoTemporalSinProcesar) && !file_exists($destinoTemporalSinProcesar)){
		  	\File::makeDirectory($destinoTemporalSinProcesar, 0777, true);
		}else{
			\File::cleanDirectory($destinoTemporalSinProcesar);
		}

		if(!is_dir($destinoFinal) && !file_exists($destinoFinal)){
		  	\File::makeDirectory($destinoFinal, 0777, true);
		}

		//obtenemos si requiere resultados
		$requiere=$this->servicioCuentaCorriente->requiereCarResSue($idJuego);
		
		//vemos qué archivos deberían pedirse
		if(Session::has('tipoArchivoJuegoEstado'))
			$archivos = Session::get('tipoArchivoJuegoEstado');
		else
			$archivos = $this->servicioCuentaCorriente->especif_arch_x_juego();

		//archivos para el juego seleccionado
		$archivos=$archivos[$idJuego];

		$util = new Util();
		$archivos=$util->groupArray($archivos,'tipo_archivo');
		$listaTiposArchivos=array();
		$listaArchivosRequerimiento=array();
		foreach ($archivos as $tiposArc) {
			array_push($listaArchivosRequerimiento,$tiposArc);
			array_push($listaTiposArchivos,$tiposArc['tipo_archivo']);
		}
		$archivosRequerimientos=array();
		foreach ($listaArchivosRequerimiento as $archReq) {
			foreach ($archReq['grupodatos'] as $especificacion) {
				if($especificacion['transaccion']==1){
					$arReq[$archReq['tipo_archivo']]=$especificacion['requerido'];
					$archivosRequerimientos[$archReq['tipo_archivo']]=$arReq;	
				}
			};
		}
		
		$exito=0;
		$mensaje="OK";
*/		
/****************** APUESTAS CARATULA **************************************************/
		//APUESTAS - OPCIONAL
/*			
		$archivosHijosA =array();
		$archivosPadresA =array();
		$this->listasArchivos($archivos, $listaApuestas, $archivosHijosA, $archivosPadresA, "AP",1);
			
		$listaNombresInputA=array();
		
		if(count($archivosPadresA)>1){//son archivos unitarios
			$ap=1;
			$listaArchivos['apu_ctrl']=array();
			$listaArchivos['apu_det']=array();
			
			$destino=$destinoTemporalSinProcesar."apuestas".$ds;
			$this->estanTodosLosArchivos($destino, "apuestas","apu_",$archivosPadresA,$listaArchivos);
			
			if(!empty($listaNombresInputA)){//está todo ok
				$archivoApu = $listaArchivos['apu_det'][0];
				$archivoApuCtrl = $listaArchivos['apu_ctrl'][0];
				//nombres - extensiones
				$nombreApu = $archivoApu->getClientOriginalName();
				$nombreApuCtrl = $archivoApuCtrl->getClientOriginalName();
				if(!is_dir($destino) && !file_exists($destino)){
				  \File::makeDirectory($destino, 0777, true);
				}else{
					array_map('unlink', glob($destino."*"));
				}				
				$destinoApu=$destino.$nombreApu;
				$destinoApuCtrl = $destino.$nombreApuCtrl;
				//movemos los archivo a la carpeta que corresponde
				$uploadSuccessApu = $archivoApu->move($destinoApu, $nombreApu);
				$uploadSuccessApuCtrl = $archivoApuCtrl->move($destinoApuCtrl, $archivoApuCtrl);
				$exito=0;
			}
				
		}else{//hay un padre contenedor
			$i=1;				
			if(Input::hasFile("apu_".$i)){
				$ap=2;
				$archivoApu = Input::file("apu_".$i);	
				$destino=$destinoTemporalSinProcesar."apuestas".$ds;				
				if(!is_dir($destino) && !file_exists($destino)){
				  \File::makeDirectory($destino, 0777, true);
				}else{
					array_map('unlink', glob($destino."*"));
				}

			

			$previos=array();
			$archivosHijos =array();
			$archivosPadres =array();
			$listaArchivos["apu_ctrl"]=array();
			$listaArchivos["apu_det"]=array();

			$this->listasArchivos($archivos, $listaApuestas, $archivosHijos, $archivosPadres, "AP",1);

			$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"apu_", "apuestas",$archivosPadres,$archivosHijos, $destino,$listaApuestas ,$idJuego,$listaArchivos, $previos);			

			if(!$dezipeoOK['exito']){
				return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
			}
*/
				/* ORIGINAL
				$resultado=$util->controlZip($archivoApu, $destino, $listaApuestas, $idJuego);
				
				if($resultado['exito']){*/
/*				
				if($dezipeoOK['exito']){
*/	
					//remuevo los que no son zip
					/*$files = File::allFiles($destino);
					$accepted_types = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed');
						
					foreach ($files as $file)
					{	
						$finfo = finfo_open(FILEINFO_MIME_TYPE);
						$type = finfo_file($finfo, $file);
						if(!in_array($type, $accepted_types)){
							//\File::delete($file);
							array_map('unlink', glob($destino.basename($file)));
						}
					}*/
/*					
					$exito=1;

				}else{
					$mensaje=$resultado['mensaje'];
					if($idEstado==15){
						$imagen= $this->srcImgError;
					}else{
						$imagen=$this->srcImgPeligro;
					}
					return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
				}
			} 
		}
*/		
	/****************** FIN APUESTAS CARATULA **************************************************/	
/*		
		
		//archivo de carátula
		if(in_array("CT", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['CT']['CT'],'R')==0 || strcasecmp($archivosRequerimientos['CT']['CT'],'O')==0)){//carátula
			try{
				$destinoTemporalCaratula =$destinoTemporalSinProcesar."caratula".$ds;
				if(!is_dir($destinoTemporalCaratula) && !file_exists($destinoTemporalCaratula)){
				  \File::makeDirectory($destinoTemporalCaratula, 0777, true);
				}else{
					array_map('unlink', glob($destinoTemporalCaratula."*"));
				}
				$archivosHijos =array();
				$archivosPadres =array();
				$this->listasArchivos($archivos, $listaCaratula, $archivosHijos, $archivosPadres, "CT",1);
				
				$listaNombresInput=array();
				if(count($archivosPadres)>1){//son archivos unitarios
					$ct=1;
					//armo los nombres de los input files que debe haber
					$i=0;
					for($x=0;$x<count($archivosPadres);$x++) {
						$i++;
					   	$nombreInputFile = "car_".$i;
					   	if(Input::hasFile($nombreInputFile)){
					   		$archivo = Input::file("car_".$i);
					   		array_push($listaNombresInput,$archivo);
					   	}else{
					   		$mensaje=sprintf($this->err_falta_archivo,'carátula');
							if($idEstado==15){
								$imagen= $this->srcImgError;
							}else{
								$imagen=$this->srcImgPeligro;
							}
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
					   	}
					}

					$archivoCar = $listaNombresInput[1];
					$archivoCarCtrl = $listaNombresInput[0];

				}else{//hay un padre contenedor
					$ct=2;
					$i=1;

					if(Input::hasFile("car_".$i) ){
					   	$archivoCar = Input::file("car_".$i);
					   	$resultado=$util->controlZip($archivoCar, $destinoTemporalCaratula, $listaCaratula, $idJuego);
					   	if($resultado['exito']){							
							//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($destinoTemporalCaratula);
							$ficheros1=array();
							foreach ($ficheros as $fichero) {
								$extension = explode(".",$fichero);
								if($extension[1]!='zip' && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
							
							if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
								$mensaje=sprintf($this->err_mas_archivos,"pozos.");
								\Log::info($mensaje);
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>15, 'srcImagen'=>$this->srcImgError));
							}

							foreach ($ficheros1 as $nombreFichero) {
								foreach ($archivosHijos as $hijo) {
									$patron="/^".$hijo['nombre'];
									if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
										$archivoCarCtrl = $destinoTemporalCaratula.$nombreFichero;
									}else if(strtolower($hijo['control'])=="s"){
										$archivoCar = $destinoTemporalCaratula.$nombreFichero;
									}
								}
							}
							
						}else{//ERROR DESCOMPRIMIR
							$mensaje=$resultado['mensaje'];
							\Log::info($mensaje);
							if($idEstado==15){
								$imagen= $this->srcImgError;
							}else{
								$imagen=$this->srcImgPeligro;
							}
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
						}
				   }else if(strcasecmp($archivosRequerimientos['CT']['CT'],'O')==0){//es opcional y no subió nada
							$ct=0;
				   			$exito=1;
				   }else{//no subió nada y no es opcional
					   	$mensaje=sprintf($this->err_falta_archivo,'pozos');
						\Log::info($mensaje);
						if($idEstado==15){
							$imagen= $this->srcImgError;
						}else{
							$imagen=$this->srcImgPeligro;
						}
						return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
				   }
					
				}
				
			}catch(\Exception $e){
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"pozos");
				\Log::info($mensaje);
				\Log::info($e);
				if($idEstado==15){
					$imagen= $this->srcImgError;
				}else{
					$imagen=$this->srcImgPeligro;
				}
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
			}
			
		}else{//no necesita carátula
			$exito=1;
			$ct=3;
		}

		if(isset($ct) && $ct==1){
			$res=$this->archivosCaratula($archivoCar, $archivoCarCtrl, $destinoTemporalCaratula,1,$idJuego, $formatoProcesamiento);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'carátula');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"carátula");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
			}
		}else if(isset($ct) && $ct==2){
			$okCtrlCar=$this->servicioCaratulas->cargarCaratulaControl($archivoCarCtrl, $archivoCar);
			$okCar=$this->servicioCaratulas->cargarCaratula($archivoCar);
			if($okCtrlCar && $okCar){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'carátula');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"carátula");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
			}
		}
		//control sorteo archivo apuesta
		if($ap==1){
			$archivoApu = $listaArchivos['apu_det'][0];		
			$archivoApuCtrl = $listaArchivos['apu_ctrl'][0];
			$res=$this->archivosApuestas($archivoApu, $archivoApuCtrl, $destinoTemporalCaratula,1,$idJuego, $formatoProcesamiento);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,2);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'apuestas');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"carátula");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
			}
		}else if($ap==2){
			$archivoApu = $listaArchivos['apu_det'][0];		
			$archivoApuCtrl = $listaArchivos['apu_ctrl'][0];
			$okCtrlApu=$this->servicioApuestas->cargarApuestasControl($archivoApuCtrl, $archivoApu);
			$okApu=$this->servicioApuestas->cargarApuestas($archivoApu, $idJuego, $formatoProcesamiento);
			
			if($okApu && $okCtrlApu){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,2);
				
				if($sorteoCorrecto==1){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'apuestas');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       											
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"apuestas");	
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
			}
		}
		
		if($exito==1){
			$okInsertaPGM=$this->servicioCuentaCorriente->insertaPGM($idJuego, $fechaSorteo);
			$nro=$this->servicioCuentaCorriente->getNumeroProcesoAuditoriaCtaCte($idJuego, $sorteo);
			
			if(isset($ct) && ($ct==2 || $ct==1) ){
				$okValidaCaratula=$this->servicioCaratulas->validaCaratula($nro,$idJuego, $sorteo, $mensaje, $usuario, $idEstado);

				if($okValidaCaratula){
					$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
					if(isset($datos)){
						$idEstado=$datos['idEstado'];
						$idsorteo=$datos['idPgmSorteo'];
						$desc_estado=$datos['de_estado'];
						$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
						if($idEstado==15){
							$exito=0;
						}else{//proceso de carátula terminado
							$this->moverArchivosTemporalFinal($destinoFinal,$destinoTemporalCaratula,$idJuego);
						}
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
					}else{
						$exito=0;
						$mensaje=sprintf($this->err_datos_sorteo, $sorteo);
						if($idEstado==15){
							$imagen= $this->srcImgError;
						}else{
							$imagen=$this->srcImgPeligro;
						}
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));						
					}
				}else{//valida carátula
					$exito=0;
					$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
					$idEstado=$datos['idEstado'];
					$idsorteo=$datos['idPgmSorteo'];
					$desc_estado=$datos['de_estado'];
					$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
					if($idEstado==15){
						$imagen= $this->srcImgError;
					}else{
						$imagen=$this->srcImgPeligro;
					}
						
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$imagen, 'datosTransaccion'=>$resultado));

					//return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>15, 'srcImagen'=>$this->srcImgPeligro));
				}
			}else if($ct==3){
				$this->servicioCuentaCorriente->insertaAuditoria($nro,$idJuego, $sorteo,1,$usuario,10,10,"Inicio Procesar carátula.");
			}
			
			if($okInsertaPGM){
				//actualizo el estado del pgmsorteo
				if($requiere['requiere_res'])//requiere resultados
					$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,20);
				else
					$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,30);
				
				if($okActualizacion){
				
					$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
							
					if(isset($datos)){
						$idEstado=$datos['idEstado'];
						$idsorteo=$datos['idPgmSorteo'];
						$desc_estado=$datos['de_estado'];
						if($ct==3){
							$this->servicioCuentaCorriente->insertaAuditoria($nro,$idJuego, $sorteo,1,$usuario,10,$idEstado,"Ok carátula.");
						}
						$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
					}else{
						$exito=0;
						$mensaje=sprintf($this->err_datos_sorteo, $sorteo);
						if($idEstado==15){
							$imagen= $this->srcImgError;
						}else{
							$imagen=$this->srcImgPeligro;
						}
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
					}
				}else{
					$exito=0;
					$mensaje="Problema al actualizar el estado";
					if($idEstado==15){
						$imagen= $this->srcImgError;
					}else{
						$imagen=$this->srcImgPeligro;
					}
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
				}
			}else{
				$exito=0;
				$mensaje=sprintf($err_proces,'carátula');
				if($idEstado==15){
					$imagen= $this->srcImgError;
				}else{
					$imagen=$this->srcImgPeligro;
				}
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
			}
			
			
		}else{
			if($idEstado==15){
				$imagen= $this->srcImgError;
			}else{
				$imagen=$this->srcImgPeligro;
			}
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$imagen));
		}
		
     				       			
	}


*/
	/*****************************************************
	* Función que obtiene los archivos para resultados   *
	******************************************************/
/*	
	public function obtenerArchivosResultados(){
		$idJuego = Input::get('id_juego_seleccionado');
		$idEstado = Input::get('id_estado_seleccionado');
		$idsorteo = Input::get('id_seleccionado');
		$sorteo = Input::get('sorteo');
		$fechaSorteo = Input::get('fecha');
		$formatoProcesamiento = Input::get('id_formato_procesamiento');
		$usuario = Session::get('usuarioLogueado.idUsuario');
		$ds = DIRECTORY_SEPARATOR;
		
		
		//paths a las carpetas destino
		$destinoFinalResultados=$this->destinoTemporalResultados.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		$destinoTemporalSinProcesar =$this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$sorteo.$ds;

		if(!is_dir($destinoTemporalSinProcesar) && !file_exists($destinoTemporalSinProcesar)){
		  	\File::makeDirectory($destinoTemporalSinProcesar, 0777, true);
			
		}
*/		/*else{
			\File::cleanDirectory($destinoTemporalSinProcesar);
		}*/
/*		
		//obtenemos si requiere resultados
		$requiere=$this->servicioCuentaCorriente->requiereCarResSue($idJuego);
		
		//vemos qué archivos deberían pedirse
		if(Session::has('tipoArchivoJuegoEstado'))
			$archivos = Session::get('tipoArchivoJuegoEstado');
		else
			$archivos = $this->servicioCuentaCorriente->especif_arch_x_juego();

		//archivos para el juego seleccionado
		$archivos=$archivos[$idJuego];

		$util = new Util();
		$archivos=$util->groupArray($archivos,'tipo_archivo');
		$listaTiposArchivos=array();
		$listaArchivosRequerimiento=array();
		foreach ($archivos as $tiposArc) {
			array_push($listaArchivosRequerimiento,$tiposArc);
			array_push($listaTiposArchivos,$tiposArc['tipo_archivo']);
		}
		$archivosRequerimientos=array();
		foreach ($listaArchivosRequerimiento as $archReq) {
			foreach ($archReq['grupodatos'] as $especificacion) {
				if($especificacion['transaccion']==2){
					$arReq[$archReq['tipo_archivo']]=$especificacion['requerido'];
					$archivosRequerimientos[$archReq['tipo_archivo']]=$arReq;	
				}
			};
		}
		
		$exito=0;
		$mensaje="OK";
*/		
/****************** SUELDOS **************************************************/
		
		//archivo de premios
/*		
		if(in_array("SU", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['SU']['SU'],'R')==0 || strcasecmp($archivosRequerimientos['SU']['SU'],'O')==0)){//resultados(sueldos)
			try{
				$destinoTemporalSueldos =$destinoTemporalSinProcesar."sueldos".$ds;
				if(!is_dir($destinoTemporalSueldos) && !file_exists($destinoTemporalSueldos)){
				  \File::makeDirectory($destinoTemporalSueldos, 0777, true);
				}else{
					array_map('unlink', glob($destinoTemporalSueldos."*"));
				}
				$archivosHijos =array();
				$archivosPadres =array();
				$this->listasArchivos($archivos, $listaSueldos, $archivosHijos, $archivosPadres, "SU",2);
				$listaArchivos['sue_ctrl']=array();
				$listaArchivos['sue_det']=array();
				$listaNombresInput=array();
				if(count($archivosPadres)>1){//son archivos unitarios
					$su=1;
					$this->estanTodosLosArchivos($destinoTemporalSueldos,"sueldos","sue_",$archivosPadres, $listaArchivos);
					$archivoRes = $listaArchivos['sue_det'][0];
					$archivoResCtrl = $listaArchivos['sue_ctrl'][0];

				}else{//hay un padre contenedor
					$su=2;
					$i=1;
					
					if(Input::hasFile("sue_".$i) ){
					   	$archivoSue= Input::file("sue_".$i);
					   	$resultado=$util->controlZip($archivoSue, $destinoTemporalSueldos, $listaSueldos, $idJuego);
					   	if($resultado['exito']){							
							//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($destinoTemporalSueldos);
							$ficheros1=array();
							foreach ($ficheros as $fichero) {
								$extension = explode(".",$fichero);
								if($extension[1]!='zip' && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
					   							
							if(count($ficheros1)>0 && (count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados'])){
								$mensaje=sprintf($this->err_mas_archivos,"sueldos.");
								\Log::info($mensaje);
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
							}

							foreach ($ficheros1 as $nombreFichero) {
								foreach ($archivosHijos as $hijo) {
									$patron="/^".$hijo['nombre'];
									if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
										$archivoSueCtrl = $destinoTemporalSueldos.$nombreFichero;
									}else if(strtolower($hijo['control'])=="s"){
										$archivoSue = $destinoTemporalSueldos.$nombreFichero;
									}
								}
							}
						}else{//error descomprimir
							$mensaje=$resultado['mensaje'];
							\Log::info($mensaje);
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
						}
				   }else if(strcasecmp($archivosRequerimientos['SU']['SU'],'O')==0){
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
				   }else{
					   	$mensaje=sprintf($this->err_falta_archivo,'sueldos');
						\Log::info($mensaje);
						return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
				   }
					
				}
				
			}catch(\Exception $e){
				$mensaje="Problema al cargar los archivos de sueldos.";
				\Log::info($mensaje);
				\Log::info($e);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}
			
		}
*/		
	/*************************** FIN SUELDOS **************************************************/	
		
/*		
		//archivo de premios(resultados)
		if(in_array("RT", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['RT']['RT'],'R')==0 || strcasecmp($archivosRequerimientos['RT']['RT'],'O')==0)){//resultados(premios)
			try{
				$destinoTemporalResultados =$destinoTemporalSinProcesar."resultados".$ds;
				if(!is_dir($destinoTemporalResultados) && !file_exists($destinoTemporalResultados)){
				  \File::makeDirectory($destinoTemporalResultados, 0777, true);
				}else{
					array_map('unlink', glob($destinoTemporalResultados."*"));
				}
				$archivosHijos =array();
				$archivosPadres =array();
				$this->listasArchivos($archivos, $listaResultados, $archivosHijos, $archivosPadres, "RT",2);
				
				$listaNombresInput=array();
				if(count($archivosPadres)>1){//son archivos unitarios
					$rs=1;
					//armo los nombres de los input files que debe haber
					$i=0;
					for($x=0;$x<count($archivosPadres);$x++) {
						$i++;
					   	$nombreInputFile = "res_".$i;
					   	if(Input::hasFile($nombreInputFile)){
					   		$archivo = Input::file("res_".$i);
					   		array_push($listaNombresInput,$archivo);
					   	}else{
					   		$mensaje=sprintf($this->err_falta_archivo,'resultados');
							\Log::info($mensaje);
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
					   	}
					}

					$archivoRes = $listaNombresInput[1];
					$archivoResCtrl = $listaNombresInput[0];

				}else{//hay un padre contenedor
					$rs=2;
					$i=1;

					if(Input::hasFile("res_".$i) ){
					   	$archivoRes = Input::file("res_".$i);
						if($idJuego==4 || $idJuego==13 || $idJuego==30){
							$resultado=$util->controlZip($archivoRes, $destinoTemporalResultados, $listaResultados, $idJuego,null,1);
						}else{
							$resultado=$util->controlZip($archivoRes, $destinoTemporalResultados, $listaResultados, $idJuego);						
						}
					   	if($resultado['exito']){							
							//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($destinoTemporalResultados);
							$ficheros1=array();
							foreach ($ficheros as $fichero) {
								$extension = explode(".",$fichero);
								if($extension[1]!='zip' && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
							
							if(count($ficheros1)<$archivosPadres[0]['cant_arch_esperados']){
								$mensaje=sprintf($this->err_mas_archivos,"resultados.");
								\Log::info($mensaje);
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
							}
							$fecha=explode("-",$fechaSorteo);//fechaSorteo=aaaa-mm-dd
							$destinoPDF = $this->destinoTemporal.$fecha[0].$ds.$fecha[1].$ds.$idJuego."_".$sorteo.$ds;
							$util->copiarPDF($destinoTemporalResultados, $destinoPDF);
							
							//volvemos a buscar en la carpeta los archivos luego de sacar los pdf
							$ficheros = scandir($destinoTemporalResultados);
							$ficheros1=array();
							foreach ($ficheros as $fichero) {
								$extension = explode(".",$fichero);
								if($extension[1]!='zip' && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
							
							foreach ($ficheros1 as $nombreFichero) {
								foreach ($archivosHijos as $hijo) {
									$patron="/^".$hijo['nombre'];
									if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
										$archivoResCtrl = $destinoTemporalResultados.$nombreFichero;
									}else if(strtolower($hijo['control'])=="s"){
										$archivoRes = $destinoTemporalResultados.$nombreFichero;
									}
								}
							}
							
						}else{//error descomprimir
							$mensaje=$resultado['mensaje'];
							\Log::info($mensaje);
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
						}
						
				   }else if(strcasecmp($archivosRequerimientos['RT']['RT'],'O')==0){
							return Response::json(array('exito'=>1, 'mensaje'=>$mensaje));
				   }else{
					   	$mensaje=sprintf($this->err_falta_archivo,'resultados');
						\Log::info($mensaje);
						return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
				   }
					
				}
				
			}catch(\Exception $e){
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"resultados");
				\Log::info($mensaje);
				\Log::info($e);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}
			
		}else if(!in_array("RT", $listaTiposArchivos)){//No necesito archivo
			$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
			if($sorteoCorrecto){
				$exito=1;
				$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,30);
					
				$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
				$idEstado=$datos['idEstado'];
				$idsorteo=$datos['idPgmSorteo'];
				$desc_estado=$datos['de_estado'];
				$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
				
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
			}else{
				$exito=0;					
				$mensaje=sprintf($this->err_nro_sorteo_archivo, 'resultados');					
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}

		}
		
		//********* ARCHIVOS EXTRACTOS*********************
				//archivo de premios(resultados)
		if(in_array("EX", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['EX']['EX'],'R')==0 || strcasecmp($archivosRequerimientos['EX']['EX'],'O')==0)){//resultados(premios)
			try{
				$destinoTemporalExtractos=$destinoTemporalSinProcesar."extractos".$ds;
				if(!is_dir($destinoTemporalExtractos) && !file_exists($destinoTemporalExtractos)){
				  \File::makeDirectory($destinoTemporalExtractos, 0777, true);
				}else{
					array_map('unlink', glob($destinoTemporalExtractos."*"));
				}
				$archivosHijos =array();
				$archivosPadres =array();
				$this->listasArchivos($archivos, $listaExtractos, $archivosHijos, $archivosPadres, "EX",2);
				
				$listaNombresInput=array();
				if(count($archivosPadres)>1){//son archivos unitarios
					$ex=1;
					//armo los nombres de los input files que debe haber
					$i=0;
					for($x=0;$x<count($archivosPadres);$x++) {
						$i++;
					   	$nombreInputFile = "ex_".$i;
					   	if(Input::hasFile($nombreInputFile)){
					   		$archivo = Input::file("ex_".$i);
					   		array_push($listaNombresInput,$archivo);
					   	}else{
					   		$mensaje=sprintf($this->err_falta_archivo,'extractos');
							\Log::info($mensaje);
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
					   	}
					}

					$archivoEx = $listaNombresInput[1];
					$archivoExCtrl = $listaNombresInput[0];

				}else{//hay un padre contenedor
					$ex=2;
					$i=1;

					if(Input::hasFile("ex_".$i) ){
					   	$archivoEx = Input::file("ex_".$i);
					   	$resultado=$util->controlZip($archivoEx, $destinoTemporalExtractos, $listaExtractos, $idJuego);
					   	if($resultado['exito']){							
							//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($destinoTemporalExtractos);
							$ficheros1=array();
							foreach ($ficheros as $fichero) {
								$extension = explode(".",$fichero);
								if($extension[1]!='zip' &&  $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
							
							if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
								$mensaje=sprintf($this->err_menos_archivos,"extractos");
								\Log::info($mensaje);
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
							}
														
							foreach ($ficheros1 as $nombreFichero) {
								foreach ($archivosHijos as $hijo) {
									$patron="/^".$hijo['nombre'];
									if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
										$archivoExCtrl = $destinoTemporalExtractos.$nombreFichero;
									}else if(strtolower($hijo['control'])=="s"){
										$archivoEx = $destinoTemporalExtractos.$nombreFichero;
									}
								}
							}
							
						}else{//error descomprimir
							$mensaje=$resultado['mensaje'];
							\Log::info($mensaje);
							return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
						}
						
				   }else if(strcasecmp($archivosRequerimientos['EX']['EX'],'O')==0){
							return Response::json(array('exito'=>1, 'mensaje'=>$mensaje));
				   }else{
					   	$mensaje=sprintf($this->err_falta_archivo,'extractos');
						\Log::info($mensaje);
						return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
				   }
					
				}
				
			}catch(\Exception $e){
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"extractos");
				\Log::info($mensaje);
				\Log::info($e);
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}
			
		}else if(!in_array("EX", $listaTiposArchivos)){//No necesito archivo
			$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
			if($sorteoCorrecto){
				$exito=1;
				$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,30);
					
				$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
				$idEstado=$datos['idEstado'];
				$idsorteo=$datos['idPgmSorteo'];
				$desc_estado=$datos['de_estado'];
				$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
				
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
			}else{
				$exito=0;					
				$mensaje=sprintf($this->err_nro_sorteo_archivo, 'extractos');					
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}

		}
		//********** FIN EXTRACTOS ************************

		if(isset($rs) && $rs==1){
			$res=$this->archivosResultados($archivoRes, $archivoResCtrl, $destinoTemporalResultados,1);//,$idJuego, $formatoProcesamiento);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'resultados');	
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));					
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"resultados");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));				
			}
		}else if(isset($rs) && $rs==2){
			$okCtrlRes=$this->servicioResultados->cargarResultadosControl($archivoResCtrl, $archivoRes);
			$okRes=$this->servicioResultados->cargarResultados($archivoRes);
			
			if($okCtrlRes && $okRes){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,4);				
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'resultados');	
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=$this->err_carga_sue;
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));				
			}
		}
		
		if(isset($su) && $su==1){
			$sue=$this->archivosSueldos($archivoSue, $archivoSueCtrl, $destinoTemporalResultados,1,$idJuego, $formatoProcesamiento);
			if($sue){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,7);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'resultados');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=$this->err_carga_sue;	
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
			}
		}else if(isset($su) && $su==2){
			$okCtrlSu=$this->servicioResultados->cargarSueldosControl($archivoSueCtrl, $archivoSue);
			$okSu=$this->servicioResultados->cargarSueldos($archivoSue);
			if($okCtrlSu && $okSu){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,7);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'sueldos');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=$this->err_carga_sue;	
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
			}
		}
		
		//******* control extractos *********
		if(isset($ex) && $ex==1){
			$res=$this->archivosExtractos($archivoEx, $archivoExCtrl, $destinoTemporalExtractos,0,$idJuego, $sorteo);
			if($res){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,1);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'extractos');	
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));					
				}
			}else{
				$exito=0;
				$mensaje=$this->sprintf($this->error_carga_sorteos_diarios,"extractos");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));				
			}
		}else if(isset($ex) && $ex==2){
			$okCtrlRes=$this->servicioResultados->cargarExtractosControl($archivoExCtrl, $archivoEx);
			$idPgmSorteo =(1000000*$idJuego)+$sorteo;
			$okRes=$this->servicioResultados->cargarExtractos($archivoEx,$idPgmSorteo);
			
			if($okCtrlRes && $okRes){
				$sorteoCorrecto=$this->servicioCuentaCorriente->controlSorteo($sorteo,$idJuego,4);				
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'extractos');	
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));
				}
			}else{
				$exito=0;
				$mensaje=$this->err_carga_sue;
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));				
			}
		}
		//********extractos

		if($exito==1){
*/			
/*VER VALIDACIÓN DE RESULTADOS Y SUELDOS!!!!!!!!!!!*/	
/*		if(isset($rs) && ($rs==2 || $rs==1) ){
			$nro=$this->servicioCuentaCorriente->getNumeroProcesoAuditoriaCtaCte($idJuego, $sorteo);
				
			$okValidaResultados=$this->servicioResultados->validaResultados($nro,$idJuego, $sorteo, $mensaje, $idEstado, $usuario);
			if($okValidaResultados){
				$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
				
				if(isset($datos)){
					$idEstado=$datos['idEstado'];
					$idsorteo=$datos['idPgmSorteo'];
					$desc_estado=$datos['de_estado'];
					$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
					if($idEstado==25){
						$exito=0;
					}else{
						$this->moverArchivosTemporalFinal($destinoTemporalSinProcesar, $destinoFinalResultados, $idJuego);
					}
					
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
				}else{
					$exito=0;
					$mensaje=sprintf($this->err_datos_sorteo, $sorteo);
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgPeligro));						
				}
			}else{
				$exito=0;
				//actualizo el estado del pgmsorteo
				//$okActualizacion = $this->servicioCuentaCorriente->actualizaEstado($sorteo,$idJuego,20);
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
			}
		}
	}else{
		$exito=0;
		return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>25, 'srcImagen'=>$this->srcImgError));
	}
		
     				       			
	}
*/
	/********************************************************
	* Función que se encarga de realizar la publicación
	*********************************************************/
/*	public function publicar(){
		$idJuego = Input::get('id_juego_seleccionado');
		$sorteo=Input::get('sorteo');
		$ok = $this->servicioCuentaCorriente->publicar($idJuego, $sorteo);
		$datos = $this->servicioCuentaCorriente->datosPGMSorteo($sorteo, $idJuego);
		if(isset($datos)){
			$idEstado=$datos['idEstado'];
			$idsorteo=$datos['idPgmSorteo'];
			$desc_estado=$datos['de_estado'];
			if(strcasecmp(strtoupper($ok), 'OK')==0){
				$mensaje = "PUBLICADO";
				$exito=1;
				$srcImagen=$this->srcImgOk;
			}else{
				$mensaje = $ok;
				$srcImagen=$this->srcImgError;
				$exito=0;
			}

			$idEstado=$datos['idEstado'];
			$idsorteo=$datos['idPgmSorteo'];
			$desc_estado=$datos['de_estado'];
			$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgOk,'datosTransaccion'=>$resultado));
		}else{
			$exito=0;
			$srcImagen=$this->srcImgError;
			$mensaje=sprintf($this->err_datos_sorteo, $sorteo);
			$desc_estado='Prob. en Publicación';
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>45, 'srcImagen'=>$this->srcImgError));
		}
		if(strcasecmp($ok, 'OK')!=0){
			$mensaje = $ok;
			$srcImagen=$this->srcImgError;
			$exito=0;
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>45, 'srcImagen'=>$srcImagen));	       			
		}
	}
*/
	/*****************************************************************
	* Función que guarda los archivos de afectaciones
	******************************************************************/
/*	public function archivosAfectaciones($archivoAfe, $archivoAfeCtrl, $destino, $guardar){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreAfe = $archivoAfe->getClientOriginalName();
				$nombreAfeCtrl = $archivoAfeCtrl->getClientOriginalName();
								
				$archivoAfe=$destino.$ds.$nombreAfe;
				$archivoAfeCtrl = $destino.$ds.$nombreAfeCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessAfe = $archivoAfe->move($destino, $nombreAfe);
		           	$uploadSuccessAfeCtrl = $archivoAfeCtrl->move($destino, $archivoAfeCtrl);
				}else{
					$okAfe=$this->servicioAfectaciones->cargarAfectacion($archivoAfe);
					$okAfeCtrl=$this->servicioAfectaciones->cargarAfectacionControl($archivoAfeCtrl, $archivoAfe);
				}

				if($okAfe && $okAfeCtrl)
					return 1;
				else
					return 0;

	}
*/
	/*****************************************************************
	* Función que guarda los archivos de Resultados
	******************************************************************/
/*	public function archivosResultados($archivoRes, $archivoResCtrl, $destino, $guardar){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreRes = $archivoRes->getClientOriginalName();
				$nombreResCtrl = $archivoResCtrl->getClientOriginalName();
								
				$nombreRes=$destino.$ds.$nombreRes;
				$nombreResCtrl = $destino.$ds.$nombreResCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessRes = $archivoRes->move($destino, $nombreRes);
		           	$uploadSuccessResCtrl = $archivoResCtrl->move($destino, $archivoResCtrl);
				}else{
					$okRes=$this->servicioResultados->cargarResultados($archivoRes);
					$okResCtrl=$this->servicioResultados->cargarResultadosControl($archivoResCtrl, $archivoRes);
				}

				if($okRes && $okResCtrl)
					return 1;
				else
					return 0;

	}
*/	
	/*****************************************************************
	* Función que guarda los archivos de Extractos
	******************************************************************/
/*	public function archivosExtractos($archivoEx, $archivoExCtrl, $destino, $guardar, $juego, $sorteo){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreEx = $archivoEx->getClientOriginalName();
				$nombreExCtrl = $archivoExCtrl->getClientOriginalName();
								
				$nombreEx=$destino.$ds.$nombreEx;
				$nombreExCtrl = $destino.$ds.$nombreExCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessEx = $archivoEx->move($destino, $nombreEx);
		           	$uploadSuccessExCtrl = $archivoExCtrl->move($destino, $archivoExCtrl);
				}else{
					$idpgmsorteo=(1000000*$juego)+$sorteo;
					$okEx=$this->servicioResultados->cargarExtractos($archivoEx,$idpgmsorteo);
					$okExCtrl=$this->servicioResultados->cargarExtractosControl($archivoExCtrl, $archivoEx);
				}

				if($okEx && $okExCtrl)
					return 1;
				else
					return 0;

	}
*/
	/*****************************************************************
	* Función que guarda los archivos de apuestas
	******************************************************************/
/*	public function archivosApuestas($archivoApu, $archivoApuCtrl, $destino, $guardar, $idJuego, $formatoProcesamiento){
				//nombres - extensiones
				$nombreApu = $archivoApu->getClientOriginalName();
				$nombreApuCtrl = $archivoApuCtrl->getClientOriginalName();
								
				$destinoApu=$destino.$nombreApu;
				$destinoApuCtrl = $destino.$nombreApuCtrl;

				//movemos los archivo a la carpeta que corresponde
				$uploadSuccessApu = $archivoApu->move($destinoApu, $nombreApu);
	           	$uploadSuccessApuCtrl = $archivoApuCtrl->move($destinoApuCtrl, $archivoApuCtrl);
			
				$okApu=$this->servicioApuestas->cargarApuestas($archivoApu, $idJuego, $formatoProcesamiento);
				$okApuCtrl=$this->servicioApuestas->cargarApuestasControl($archivoApuCtrl, $archivoApu);
				
				if($okApu && $okApuCtrl)
					return 1;
				else
					return 0;

	}
*/
	/*****************************************************************
	* Función que guarda los archivos de premios
	******************************************************************/
/*	public function archivosPremios($archivoPre, $archivoPreCtrl, $destino, $guardar, $idJuego){
				//nombres
				$nombrePre =$archivoPre['path'];//$archivoPre->getClientOriginalName();//basename($archivoPre);// 
				$nombrePreCtrl = $archivoPreCtrl['path'];//$archivoPreCtrl->getClientOriginalName();//basename($archivoPreCtrl);//
				$destinoPre=$destino.$archivoPre['nombreOriginal'];//.$nombrePre;
				$destinoPreCtrl = $destino.$archivoPreCtrl['nombreOriginal'];//$nombrePreCtrl;

				//movemos los archivo a la carpeta que corresponde
				$uploadSuccessPre =move_uploaded_file($nombrePre, $destinoPre); //$archivoPre->move($destino, $nombrePre); //$archivoPre->move($destinoPre, $nombrePre);//
	           	$uploadSuccessPreCtrl = move_uploaded_file($nombrePreCtrl, $destinoPreCtrl);//$archivoPreCtrl->move($destino, $nombrePreCtrl);/$archivoPreCtrl->move($destinoPreCtrl, $nombrePreCtrl);

				$okPre=$this->servicioPremios->cargarPremio($destinoPre, $idJuego);
				$okPreCtrl=$this->servicioPremios->cargarPremiosControl($destinoPreCtrl, $destinoPre);
				

				if($okPre && $okPreCtrl)
					return 1;
				else
					return 0;

	}
*/	
	/*****************************************************************
	* Función que guarda los archivos de premios retención
	******************************************************************/
/*	public function archivosPremiosRetencion($archivosDr, $archivoDrCtrl, $destino, $idJuego, $opcion){
				if($opcion==1){
					$nombreDrCtrl =$archivoDrCtrl['path'];//basename($archivoDrCtrl); //$archivoDrCtrl->getClientOriginalName();//
					$destinoDrCtrl = $destino.$archivoDrCtrl['nombreOriginal'];
				}else{
					$nombreDrCtrl =basename($archivoDrCtrl); //$archivoDrCtrl->getClientOriginalName();//
					$destinoDrCtrl = $destino.$nombreDrCtrl;
				}
	           	$uploadSuccessDrCtrl = move_uploaded_file($nombreDrCtrl, $destinoDrCtrl);//$archivoDrCtrl->move($destino, $nombreDrCtrl); $archivoPreCtrl->move($destinoPreCtrl, $nombrePreCtrl);
	           	$x=1;
				$okDr=1;
				$okDrCtrl=1;
				foreach ($archivosDr as $archivoDr) {
					if($opcion==1){
						$nombreDr = $archivoDr['path'];//basename($archivoDr);//$archivoDr->getClientOriginalName();//
						$destinoDr=$destino.$archivoDr['nombreOriginal'];
					}else{
						$nombreDr = basename($archivoDr);//$archivoDr->getClientOriginalName();//
						$destinoDr=$destino.$nombreDr;					
					}
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessDr =move_uploaded_file($nombreDr, $destinoDr);//$archivoDr->move($destino, $nombreDr); 
					$okDrCtrl=$this->servicioPremios->cargarPremiosRetencionControl($destinoDrCtrl, $destinoDr,$x);					
					$okDr=$this->servicioPremios->cargarPremiosRetDet($destinoDr, $idJuego);
					$x++;										
				}

				if($okDr && $okDrCtrl)
					return 1;
				else
					return 0;

	}
*/
	/*****************************************************************
	* Función que guarda los archivos de carátula
	******************************************************************/
/*	public function archivosCaratula($archivoCar, $archivoCarCtrl, $destino, $guardar, $idJuego){
				//nombres
				$nombreCar = $archivoCar->getClientOriginalName();
				$nombreCarCtrl = $archivoCarCtrl->getClientOriginalName();
				$destinoCar=$destino.$nombreCar;
				$destinoCarCtrl = $destino.$nombreCarCtrl;


				//movemos los archivo a la carpeta que corresponde
				$uploadSuccessCar =$archivoCar->move($destino, $nombreCar); //move_uploaded_file($archivoPre, $destinoPre); //$archivoPre->move($destinoPre, $nombrePre);//
	           	$uploadSuccessCarCtrl = $archivoCarCtrl->move($destino, $nombreCarCtrl);//move_uploaded_file($archivoPreCtrl, $destinoPreCtrl);//$archivoPreCtrl->move($destinoPreCtrl, $nombrePreCtrl);

				$okCar=$this->servicioCaratulas->cargarCaratula($destinoPre, $idJuego);
				$okCarCtrl=$this->servicioCaratulas->cargarCaratulaControl($destinoCarCtrl, $destinoCar);
				

				if($okCar && $okCarCtrl)
					return 1;
				else
					return 0;

	}
*/	
	/*****************************************************************
	* Función que guarda los archivos de comisiones
	******************************************************************/
/*	public function archivosComisiones($archivoCom, $archivoComCtrl, $destino, $guardar){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreCom = $archivoCom->getClientOriginalName();
				$nombreComCtrl = $archivoComCtrl->getClientOriginalName();
								
				$archivoCom=$destino.$ds.$nombreCom;
				$archivoComCtrl = $destino.$ds.$nombreComCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessCom = $archivoCom->move($destino, $nombreCom);
		           	$uploadSuccessComCtrl = $archivoComCtrl->move($destino, $archivoComCtrl);
				}else{
					$okCom=$this->servicioComisiones->cargarComision($archivoCom);
					$okComCtrl=$this->servicioComisiones->cargarComisionesControl($archivoComCtrl, $archivoCom);
				}

				if($okCom && $okComCtrl)
					return 1;
				else
					return 0;

	}
*/	
	/*****************************************************************
	* Función que guarda los archivos de mantenimiento y sellado
	******************************************************************/
/*	public function archivosManSellado($archivoMan, $archivoManCtrl, $destino, $guardar){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreMan = $archivoMan->getClientOriginalName();
				$nombreManCtrl = $archivoManCtrl->getClientOriginalName();
								
				$archivoMan=$destino.$ds.$nombreMan;
				$archivoManCtrl = $destino.$ds.$nombreManCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessMan = $archivoMan->move($destino, $nombreMan);
		           	$uploadSuccessManCtrl = $archivoManCtrl->move($destino, $archivoManCtrl);
				}else{
					$okMan=$this->servicioComisiones->cargarManSellado($archivoMan);
					$okManCtrl=$this->servicioComisiones->cargarManSelladoControl($archivoManCtrl, $archivoMan);
				}

				if($okMan && $okManCtrl)
					return 1;
				else
					return 0;

	}
*/	
	/*****************************************
	* lista de archivos según la transacción
	******************************************/
/*	private function listasArchivos($archivos, &$lista, &$hijos, &$padres, $ta, $transac){
		//lista de archivos 
		foreach ($archivos as $archivo) {
			if($archivo['tipo_archivo']==$ta ){
				$lista=$archivo['grupodatos'];
				break;
			}
		}
		if(isset($lista)){
			//busco el arch. padre y los hijos
			foreach ($lista as $archivo) {
				if($archivo['id_padre']=='' && $archivo['transaccion']== $transac){
					array_push($padres,$archivo);								
				}else{
					array_push($hijos,$archivo);
				}
			}			
		}
	}
*/	
	/**************************************************************************
	* Función que se encarga de buscar los archivos previos si es que existen *
	***************************************************************************/
/*    private function archivosPrevios($directorioBusqueda, &$resultado, $archivos, $transaccion){
    	
    	if(is_dir($directorioBusqueda)){
				$directorio = File::files($directorioBusqueda);
				if(!empty($directorio)){
					$iteadorArchivosEnDestino=new FilesystemIterator($directorioBusqueda, FilesystemIterator::SKIP_DOTS);//no incluye . ni ..
					$tipo_archivo = basename($directorioBusqueda);
					if(iterator_count($iteadorArchivosEnDestino)>0){
						$files = File::allFiles($directorioBusqueda);
						$arch = [];
						$extension=array();
						//busco qué tipo de archivos previos busco
						foreach ($archivos as $archivo) {
							if($archivo['transaccion']==$transaccion && $archivo['id_padre']==''){
								array_push($extension,$archivo['extension']);
							}
						}
						foreach ($files as $file)
						{
							$extFile=".".pathinfo(basename($file), PATHINFO_EXTENSION);
							if($this->coincideExtension($extension, $extFile)){
							    array_push($arch, basename($file)) ;//nombre del archivo de apuestas
							    $resultado['archivosPrevios']=array('existenArchivosPrevios'=>1,'archivos'=>array(array('tipo_archivo'=>$tipo_archivo,'nombre_archivo'=>$arch)));
							}

						}
					}else{
						$resultado['archivosPrevios']=array('existenArchivosPrevios'=>0,'archivos'=>array());
					}						
				}	
			}
    }
	
*/	
	/****************************************************************************
	* Función que se encarga de mover los archivos del temporal sin procesar al *
	* temporal correcto (según la transacción)                                  *
	*****************************************************************************/
/*    private function moverArchivosTemporalFinal($directorioBusqueda, $directorioFinal,$idJuego ,$final=0){
    	if(is_dir($directorioBusqueda)){
				$directorio = File::files($directorioBusqueda);
				$ds=DIRECTORY_SEPARATOR;
				
				if(!empty($directorio) || $final==1){// || stripos($directorioFinal,'consolidado')!== false
				
					//$iterador=new DirectoryIterator($directorioBusqueda, FilesystemIterator::SKIP_DOTS);//no incluye . ni ..
					
					$files = scandir($directorioBusqueda);
					
				    $oldfolder = $directorioBusqueda;
				    $newfolder = $directorioFinal;
					
				    foreach($files as $fname) {
				      if($fname != '.' && $fname != '..') {
						  $success = \File::deleteDirectory($newfolder.$fname, true);
				          rename($oldfolder.$fname, $newfolder.$fname);
						  if($final==1){//movemos apuestas por ftp
							 $patron ="/^apuestas+$/i";
	   						 $match=preg_match($patron, $fname);
							 if($match){
								$archivos = scandir($newfolder.$fname);
								foreach($archivos as $nombre) {
									// if(strtolower(\File::extension($nombre))!="zip" && $nombre!="." && $nombre!=".."){
									 if(strtolower(\File::extension($nombre))=="zip"){
										if($idJuego==4)//ver si es solo para quini 6
											try{
												$this->moverArchivosPorFTP($idJuego, $newfolder.$fname.$ds.$nombre,$newfolder);
											}catch(\Exception $e){
												\Log::error("Problema al mover apuestas con ftp. Juego: ".$idJuego);
											}
									 }
								}
								//acá debería zipear el contenido de la carpeta
							 }
						  }
				      }
				    }
				    //elimino el contenido del directorio
				    array_map('unlink', glob($oldfolder."*"));
					//elimino el directorio
				    $this->rrmdir($oldfolder);
				    //elimino la carpeta del juego_sorteo
				    $dir_js = substr($oldfolder, 0,strpos($oldfolder, basename($oldfolder)));
				    $this->rrmdir($dir_js);

				}		
				
			}
    }
*/	
	/***********************************************************
	* Función que se encarga de mandar el archivo de apuestas  *
	* a los servidores indicados, por ftp.                     *
	************************************************************/
/*	private function moverArchivosPorFTP($idJuego, $pathArchivo, $anioMesJuegoSorteo){
		$ds= DIRECTORY_SEPARATOR;
		$servidores = $this->servicioCuentaCorriente->servidoresFTP();
		$producto = $this->servicioCuentaCorriente->ProductoFTP($idJuego);
		
		foreach($servidores as $servidor){
			
			// Primero creamos un ID de conexión a nuestro servidor
			$cid = ftp_connect($servidor['servidor']);
			// Luego creamos un login al mismo con nuestro usuario y contraseña
			$resultado = ftp_login($cid, $servidor['usuario'],$servidor['password']);
			// Comprobamos que se creo el Id de conexión y se pudo hacer el login
			if ((!$cid) || (!$resultado)) {
				\Log::error("Fallo en la conexión", array($servidor['servidor'])); 
				break;
			}
			// Cambiamos a modo pasivo, esto es importante porque, de esta manera le decimos al 
			//servidor que seremos nosotros quienes comenzaremos la transmisión de datos.
			ftp_pasv($cid, true) ;
			ftp_chdir($cid, $servidor['ruta']);
			
			//creamos las directorios que no existen
			$partesRuta = explode('\\',$producto['ruta']); 
			foreach($partesRuta as $part){
				if(!@ftp_chdir($cid, $part)){
					ftp_mkdir($cid, $part);
					ftp_chdir($cid, $part);
				}
			}
			
			$partesRutaOrigen = explode($ds,$anioMesJuegoSorteo);
			//\Log::info(count($partesRutaOrigen));
						
			if (file_exists($pathArchivo)){
				
				if ( ftp_put($cid, basename($pathArchivo),$pathArchivo, FTP_BINARY )){//basename($pathArchivo) BINARY
					//cerramos la conexión FTP
					ftp_close($cid);
				}else{
					\Log::info("Problema al transmitir el archivo por ftp");
					ftp_close($cid);
				}
			}
		}
	}
	
*/
	/********************************************************************
	* Función que verifica si la extensión matchea con alguna expresión *
	* de las contenidas en el arreglo.                                  *
	*********************************************************************/
/*	private function coincideExtension($extension, $extFile){
		foreach ($extension as $regex) {
			if(preg_match("/^".$regex, $extFile)){
				return true;
			}
		}
		return false;
	}
*/
	/********************************************************************

	*********************************************************************/
/*	private function estanTodosLosArchivos($destino, $tipoArchivos,$prefijo,$archivosPadres,&$listaArchivos){
		$i=0;

		//armo los nombres de los input files que debe haber
		$cantidad=count($archivosPadres);
		
		for($x=0;$x<$cantidad;$x++) {
			$i++;
		   	$nombreInputFile = $prefijo.$i;
		   	if(Input::hasFile($nombreInputFile)){
		   		$archivo = Input::file($nombreInputFile);
		   		$pathArchivo = $archivo->getRealPath();
				$nombreOriginal=$archivo->getClientOriginalName();//$archivo->getClientOriginalName();//$destino.$archivo->getClientOriginalName();//$destino.$archivo;//

				foreach($archivosPadres as $archP) {				
					$patron="/^".$archP['nombre'];

					if(preg_match($patron, $nombreOriginal) && strtolower($archP['control'])=="s"){
						$datoArchivo=array();
						$datoArchivo['nombreOriginal']=$nombreOriginal;
						$datoArchivo['path']=$pathArchivo;
						array_push($listaArchivos[$prefijo.'ctrl'],$datoArchivo);
						
					}else if(preg_match($patron, $nombreOriginal) && strtolower($archP['control'])=="n"){			//if(preg_match($patron, $archivo->getClientOriginalName())){			//
						$datoArchivo=array();
						$datoArchivo['nombreOriginal']=$nombreOriginal;
						$datoArchivo['path']=$pathArchivo;
						array_push($listaArchivos[$prefijo.'det'],$datoArchivo);						
					}	
				}
		   	}else{
		   		$mensaje=sprintf($this->err_falta_archivo,$tipoArchivos);
*/				/*\Log::info($mensaje);				*/
/*				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		   	}
		}
	*/	/*	\Log::info("prefijo: ".$prefijo);
			\Log::info($listaArchivos[$prefijo.'ctrl']);
			\Log::info($listaArchivos[$prefijo.'det']);*/
/*	}	
*/
	/**************************************************************
	* Función que se encarga de sacar los archivos del contenedor *
	***************************************************************/
/*	private function tratamientoArchivosEnContenedor($util,$prefijo, $tiposArchivos, $archivosPadres, $archivosHijos,$destinoTemporal,$lista ,$idJuego,&$listaArchivos, $previos){
		$i=1;	
	
		if(Input::hasFile($prefijo.$i)){
		   	$archivo = Input::file($prefijo.$i);
			
		   	//archivos anteriores
		   	if(count($previos)>0){
			   	if($previos['archivosPrevios']['existenArchivosPrevios']){
					//verifico si es el mismo o no subió nada
					$archPrev = $previos['archivosPrevios']['archivos'];
					foreach ($archPrev as $prev) {
						foreach($prev['nombre_archivo'] as $p){
							if(strcasecmp($p, $archivo->getClientOriginalName())==0){//mismo archivo
							//movemos el archivo a la nueva ubicación -->verificar que se obtenga el nombre correcto
								$archivo=$archPrev;
							}else{//uno nuevo
								//borro archivo viejo
								File::delete($destinoTemporal.$ds.$p);
							}								
						}
					}
				}		   		
		   	}
			
		   	$resultado=$util->controlZip($archivo, $destinoTemporal, $lista, $idJuego);

			$mensaje='OK';
		   	if($resultado['exito']){							
				//buscar los archivos en la carpeta y pasarlos a la tabla
				$ficheros =  scandir($destinoTemporal);
				$ficheros1=array();
				foreach ($ficheros as $fichero) {
					$extension = explode(".",$fichero);
					if(strcasecmp($extension[1],'zip')!=0 && $fichero!= "." && $fichero!= ".."){
						array_push($ficheros1, $fichero);
					}
				}
				
				if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
					$mensaje=sprintf($this->err_mas_archivos,$tiposArchivos);
					\Log::info($mensaje);
					$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
					return $resultado;
				}

				foreach ($ficheros1 as $nombreFichero) {
					foreach ($archivosHijos as $hijo) {
						$patron="/^".$hijo['nombre'];
						$pathArchivo = $destinoTemporal.$nombreFichero;
						
						if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
							array_push($listaArchivos[$prefijo.'ctrl'], $pathArchivo);
						}else if(strtolower($hijo['control'])=="s"){
							array_push($listaArchivos[$prefijo.'det'],$pathArchivo);
						}
					}
				}
				$resultado=array('exito'=>1, 'mensaje'=>$mensaje);
				return $resultado;
			}else{//problema al descomprimir
				$mensaje=$resultado['mensaje'];
				\Log::info($mensaje);
				$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
				return $resultado;
			}
	   }else if($previos['archivosPrevios']['existenArchivosPrevios']){
				$mensaje='OK';
				//verifico si es el mismo o no subió nada
				$archPrev = $previos['archivosPrevios']['archivos'];
				foreach ($archPrev as $prev) {
					foreach($prev['nombre_archivo'] as $p){
							$archivo=$destinoTemporal.$p;
					}
				}
				
				$resultado=$util->controlZip($archivo, $destinoTemporal, $lista, $idJuego);

				if($resultado['exito']){							
					//buscar los archivos en la carpeta y pasarlos a la tabla
					$ficheros =  scandir($destinoTemporal);
					$ficheros1=array();
					foreach ($ficheros as $fichero) {
						$extension = explode(".",$fichero);
						if(strcasecmp($extension[1],'zip')!=0 && $fichero!= "." && $fichero!= ".."){
							array_push($ficheros1, $fichero);
						}
					}
					
					if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
						$mensaje=sprintf($this->err_mas_archivos,$tiposArchivos);
						\Log::info($mensaje);
						$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
						return $resultado;
					}

					foreach ($ficheros1 as $nombreFichero) {
						foreach ($archivosHijos as $hijo) {
							$patron="/^".$hijo['nombre'];
							$pathArchivo = $destinoTemporal.$nombreFichero;
							if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
								array_push($listaArchivos[$prefijo.'ctrl'], $pathArchivo);
							}else if(strtolower($hijo['control'])=="s"){
								array_push($listaArchivos[$prefijo.'det'],$pathArchivo);
							}
						}
					}
					$resultado=array('exito'=>1, 'mensaje'=>$mensaje);
					return $resultado;
				}else{//problema al descomprimir
					$mensaje=$resultado['mensaje'];
					\Log::info($mensaje);
					$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
					return $resultado;
				}			
			
				
				
	   }else{
	   	$mensaje=sprintf($this->err_falta_archivo,$tiposArchivos);
		\Log::info($mensaje);
		$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
		return $resultado;
	   }
	}
	
	*/
/*	
	private function rrmdir($path) {
		// Remove a dir (all files and folders in it)
		$i = new DirectoryIterator($path);
		foreach($i as $f) {
			if($f->isFile()) {
				unlink($f->getRealPath());
			} else if(!$f->isDot() && $f->isDir()) {
				$this->rrmdir($f->getRealPath());
				rmdir($f->getRealPath());
			}
		}
	}
	*/
}
