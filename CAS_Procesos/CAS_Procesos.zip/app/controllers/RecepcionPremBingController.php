<?php
	
use \Helpers\Macros;
use \Dominio\Servicios\Afectaciones; 
use \Dominio\Servicios\Apuestas; 
use \Dominio\Servicios\Premios; 
use \Dominio\Servicios\PremiosBingos; 
use \Dominio\Servicios\Caratulas; 
use \Dominio\Servicios\Resultados; 
use \Dominio\Servicios\Comisiones;
use \Dominio\Servicios\Liquidaciones; 
use \Dominio\Servicios\RecepcionPremBing; 
use controllers\UsuarioController; 
use \Helpers\Util;
class RecepcionPremBingController extends BaseController {
	//MENSAJES ERROR VARIOS 
	  public $error_carga_sorteos_diarios = "Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al juego/sorteo seleccionado."; 
	  public $error_carga_comisiones ="Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al período indicado.";
	  public $err_nro_sorteo_archivo = "El archivo de %s no corresponde al sorteo elegido.";
	  public $err_falta_archivo = "Falta archivo de %s";
	  public $err_datos_sorteo = "Problema al obtener los datos del sorteo: %s";
   	  public $err_mas_archivos = "Hay más archivos de los esperados para %s.";
	  public $err_menos_archivos = "Hay menos archivos de los esperados para %s.";
	  public $err_proces="Problema al procesar %s.";
	  public $err_cant_archivos = "Existe problema de integridad de archivos esperados para %s.";
	  public $err_nomb_archivos ="No se espera el archivo con el nombre %s.";

	function __construct() {
		$ds=DIRECTORY_SEPARATOR;

		$this->servicioAfectaciones = new Afectaciones();
		$this->servicioApuestas = new Apuestas();
		$this->servicioPremios = new Premios();
		$this->servicioPremiosBingos = new PremiosBingos();
		//$this->servicioCuentaCorriente = new CuentasCorrientes();
		$this->servicioRecepcionPremBing = new RecepcionPremBing();
		$this->servicioCaratulas = new Caratulas();
		$this->servicioResultados = new Resultados();
		$this->servicioComisiones = new Comisiones();
		$this->servicioLiquidaciones = new Liquidaciones();
		$this->controladorUsuario = new UsuarioController();
		$this->destinoTemporal = Config::get('ctacte_config/config.urlDestino');
		
		$this->destinoTemporalSinProcesar= $this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalSinProcesar');
		$this->destinoFinalCaratula=$this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalCaratula');
		$this->destinoFinalResultados=$this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalResultados');
		$this->destinoTemporalResultados= $this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalResultados');
		$this->destinoFinalConsolidacion=$this->destinoTemporal;//.Config::get('ctacte_config/config.urlFinalConsolidacion');
		$this->destinoTemporalConsolidacion= $this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalConsolidacion');
		
		$this->destinoComisiones = $this->destinoTemporal.Config::get('ctacte_config/config.urlComisiones');
		$this->destinoLiquidaciones = $this->destinoTemporal.Config::get('ctacte_config/config.urlLiquidaciones');
		$this->destinoTemporalAS400= $this->destinoTemporal.Config::get('ctacte_config/config.urlTemporalAS400');
		
		$this->srcImgError=Config::get("ctacte_config/config.urlImgError");
		$this->srcImgPeligro=Config::get("ctacte_config/config.urlImgPeligro");
		$this->srcImgOk=Config::get("ctacte_config/config.urlImgOk");
	}

	
	/****************************************************************
	* Ingreso desde el panel principal - carga de usuario
	*****************************************************************/
	public function cargaUsuarioEnAppCtaCte(){
		$util = new Util();
		if(!Session::has("datos_ingreso")){
			return Redirect::to('/portal');
		}
		$datosIngreso=Session::get("datos_ingreso");
		$datosIngreso=explode("&",$datosIngreso);
		$usuario=explode("usuario=",$datosIngreso[0]);
                $id_portal=explode("id_portal=",$datosIngreso[1])[1];
		$letra_portal=explode("letra_portal=",$datosIngreso[2])[1];
		$nombre_usuario=$util->decrypt($usuario[1],"Pir@mide01");
		
		$usuario=$this->controladorUsuario->buscar($nombre_usuario);
	
		//borra todos los datos anteriores
		Session::flush();
		
		if(is_null($usuario["idUsuario"])|| is_null($usuario)){
			$mensaje='Hay un problema con su usuario.';
			Session::put('mensaje_acceso',$mensaje);
			\Log::error("problema con el usuario - nulo");
			Session::flush();
	       	return Redirect::to('/acceso-no-autorizado');
		}else if (!in_array('Administracion_ctacte',$usuario['funciones'])){
			$mensaje='Su tipo de usuario no posee acceso.';
			Session::put('mensaje_acceso',$mensaje);
	       	return Redirect::to('/acceso-no-autorizado');
		}
		$usuario['id_portal']=$id_portal;
		$usuario['letra_portal']=$letra_portal;
		Session::put('usuarioLogueado',$usuario);
		return Redirect::to('/panel-principal');
	}
	
	/********************************
	* Armado del panel principal
	*********************************/
	public function panelPrincipal(){
		$tablaExcepciones = array();
		$datos['fecha_exc']='2016-01-01';
		$datos['descripcion_exc']='Primero de enero';
		$datos['accion_exc']='Anula todos los sorteos';
		array_push($tablaExcepciones, $datos);
		$datos['fecha_exc']='2016-08-17';
		$datos['descripcion_exc']='Paso a la inmortalidad del General San Martín';
		$datos['accion_exc']='Sorteo especial a la noche';
		array_push($tablaExcepciones, $datos);
		
		$panel1= Response::panelExcepciones($tablaExcepciones);
		$panel2= Response::panelExcepciones($tablaExcepciones);
		$panel3= Response::panelExcepciones($tablaExcepciones);
		$panel4= Response::panelExcepciones($tablaExcepciones);
		return View::make('cuenta_corriente.panel2', array('panel1'=>$panel1, 'panel2'=>$panel2,'panel3'=>$panel3, 'panel4'=>$panel4));
	}
	
	
/******************************* original ***************************************/
	/***********************************************************
	* Carga el usuario en la aplicación o lo retorna al portal *
	* si no está logueado o no tiene permiso.                  *
	************************************************************/
	public function cargaUsuarioEnApp(){
		$util = new Util();
		if(!Session::has("datos_ingreso")){
			return Redirect::to('/portal');
		}
		
		$datosIngreso=Session::get("datos_ingreso");
		$datosIngreso=explode("&",$datosIngreso);
		$usuario=explode("usuario=",$datosIngreso[0]);
		$id_portal=explode("id_portal=",$datosIngreso[1])[1];
		$letra_portal=explode("letra_portal=",$datosIngreso[2])[1];
		$nombre_usuario=$util->decrypt($usuario[1],"Pir@mide01");
		
		$usuario=$this->controladorUsuario->buscar($nombre_usuario);	
		
		
		//borra todos los datos anteriores
		Session::flush();
		
		if(is_null($usuario["idUsuario"])|| is_null($usuario)){
			$mensaje='Hay un problema con su usuario.';
			Session::put('mensaje_acceso',$mensaje);
			Session::flush();
	       	return Redirect::to('/acceso-no-autorizado');
		}else if (!in_array('Administracion_ctacte',$usuario['funciones'])){
			$mensaje='Su tipo de usuario no posee acceso.';
			Session::put('mensaje_acceso',$mensaje);
	       	return Redirect::to('/acceso-no-autorizado');
		}
		$usuario['id_portal']=$id_portal;
		$usuario['letra_portal']=$letra_portal;
		Session::put('usuarioLogueado',$usuario);
		return Redirect::to('/panel-alertas');
	}

	/*****************************************
	* Arma la vista de los sorteos diarios 
	******************************************/
	public function paneles(){
		$tablas=$this->tablaSorteos();
		//return View::make('cuenta_corriente.panel', array('tablas'=>$tablas));
		return View::make('cuenta_corriente.panelPremBing', array('tablas'=>$tablas));
	}

	/*****************************************************
	* Arma los datos necesarios para la tabla de sorteos *
	******************************************************/
	private function tablaSorteos(){
		Session::forget('tipoArchivoJuegoEstado');
		$sorteos=$this->servicioRecepcionPremBing->sorteos_panel_alertas();
		$datos['titulo_tabla']="Sorteos días anteriores";
		$datos['id_tabla']="tabla_sorteos_anteriores";
		$datos['id_body']="cuerpo_sda";
		$datos['dia']=$sorteos['diasAnteriores'];
		$tablaDiasAnteriores=Response::tablaPrimerPanel($datos);		
		$datos['titulo_tabla']="Sorteos del día";
		$datos['id_tabla']="tabla_sorteos_del_dia";
		$datos['id_body']="cuerpo_sd";
		$datos['dia']=$sorteos['diaActual'];
		$tablaDiaActual=Response::tablaPrimerPanel($datos);		
		
		//$datos['titulo_tabla']="Sorteos días futuros";
		//$datos['id_tabla']="tabla_sorteos_futuros";
		//$datos['id_body']="cuerpo_sdf";
		//$datos['dia']=$sorteos['diaFuturo'];
		//$tablaDiasFuturos=Response::tablaPrimerPanel($datos);		
		

		$tablas = $tablaDiasAnteriores.$tablaDiaActual;//.$tablaDiasFuturos;
		$archivos = $this->servicioRecepcionPremBing->especif_arch_x_juego();
		Session::put('tipoArchivoJuegoEstado', $archivos);
		return $tablas;
	}


	/********************************************
	* Función que carga el panel de transacción *
	*********************************************/
	public function cargarPanelTransaccion(){
		$idsorteo = Input::get('id_seleccionado');
		$idEstado = Input::get('id_estado_seleccionado');
		$idJuego = Input::get('id_juego_seleccionado');
		$nro_sorteo = Input::get('nro_sorteo');

		$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $nro_sorteo);
		
		\Log::info('resultado',array($resultado));
		/*
		if($idEstado == 40){
			$datos = $this->servicioRecepcionPremBing->datosProcesados($nro_sorteo, $idJuego);
			$mensaje = "Tickets: ".$datos['cant_tck']."\nImporte Total Bruto: ".$datos['imp_total_bruto']."\nImporte Total Retención: ".$datos['imp_total_ret']."\nImporte Total Neto: ".$datos['imp_total_neto'];
			//return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
			return Response::json(array('exito'=>1, 'datosTransaccion'=>$resultado, 'mensaje'=>$mensaje));
		}else{
			return Response::json(array('exito'=>1, 'datosTransaccion'=>$resultado));
		}
		*/
		
		return Response::json(array('exito'=>1, 'datosTransaccion'=>$resultado));
	}
	
	private function transacciones($idsorteo, $idEstado,$idJuego, $nro_sorteo){
		
		//\Log::info('xxx_transacciones: ',array($idsorteo.'---'.$idEstado.'---'.$idJuego.'---'.$nro_sorteo));
		
		$util = new Util();
		//verificación de si puede hacer algo o debe esperar que se procese un sorteo anterior
		$puedeProcesar = $this->servicioRecepcionPremBing->puedeProcesar($nro_sorteo, $idJuego);
		
		//\Log::info('puedeProcesar',array($puedeProcesar));
		
		if($puedeProcesar){
			if(Session::has('tipoArchivoJuegoEstado')){
				$archivos = Session::get('tipoArchivoJuegoEstado');
			}
			else{
				$archivos = $this->servicioRecepcionPremBing->especif_arch_x_juego();
			}

			$datosVistaTransaccion=array();
			$datosVistaTransaccion['botones']=array();
			$archivosApedir=array();
			$datosVistaTransaccion['puedeProcesar']=1;
			//Armado según la transacción que debe activarse
			
			
			//if(in_array($idEstado, array(10,15,20,25))){//resultados totob
			if(in_array($idEstado, array(10))){//resultados totob
				$datosTransaccion['nombre_file']=array();
				//$rs=0;
				$totb=0;
			//	$su=0;
				$telk=0;
			//	$ex=0;
				$mara=0;
				foreach ($archivos[$idJuego] as $archJuego) {
					if($archJuego['transaccion']==2 && $archJuego['id_padre']==''){ //  cuendo no tiene padre
						if($archJuego['tipo_archivo']=='TT'){//Premios totobingo
							$totb++;
							$archivo['nombre']='totb_'.$totb;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'TT', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Premios Ctrl.';
							else
								$archivo['buttonText']='Premios';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='TK'){//premios telekino
							$telk++;
							$archivo['nombre']='telk_'.$telk;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'TK', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Premios Ctrl.';
							else
								$archivo['buttonText']='Premios';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='TM'){//premios maradona
							$mara++;
							$archivo['nombre']='mara_'.$mara;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'TM', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Premios Ctrl.';
							else
								$archivo['buttonText']='Premios';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						$archivo['extension']=str_replace("+" ,"",str_replace("+[[:alpha:]]", "\w", $archJuego['extension']));
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}
				//según el estado cambia el btn
				$btn['id_btn']="btn_resultados";
				$btn['value_btn']="PROCESAR";
				array_push($datosVistaTransaccion['botones'], $btn);
				$datosVistaTransaccion['id_estado']=$idEstado;
				//chequeo si ya existen archivos
				$usuario = Session::get('usuarioLogueado.idUsuario');
				$ds = DIRECTORY_SEPARATOR;
				//paths a las carpetas 
				$destinoTemporalSinProcesar = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$nro_sorteo.$ds."premios";
				//$destinoTemporalSueldos = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$nro_sorteo.$ds."sueldos";
				
				$this->archivosPrevios($destinoTemporalSinProcesar, $datosVistaTransaccion, $archivos[$idJuego],2);
				// $this->archivosPrevios($destinoTemporalSueldos, $datosVistaTransaccion, $archivos[$idJuego],2);

				$datosTransaccion['transaccion_activa']=2;
			}else if(in_array($idEstado, array(34,36))){//consolidación
				$datosTransaccion['nombre_file']=array();
				$af=0;
				$ap=0;
				$pr=0;
				$dr=0;
				$pc=0; // agregado MM 07-06-2017
				$i=0;

				foreach ($archivos[$idJuego] as $archJuego) {
					
					// crear para TT y TK
					if($archJuego['transaccion']==3 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='AP'){//apuestas
							$af++;
							$archivo['nombre']='apu_'.$af;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'AP', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Apuestas Ctrl.';
							else
								$archivo['buttonText']='Apuestas';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='AF'){//afectaciones
							$ap++;
							$archivo['nombre']='afe_'.$ap;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'AF', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Afectaciones Ctrl.';
							else
								$archivo['buttonText']='Afectaciones';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='PR'){//premios
							$pr++;
							$archivo['nombre']='pre_'.$pr;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'PR', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Premios Ctrl.';
							else
								$archivo['buttonText']='Premios';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}else if($archJuego['tipo_archivo']=='DR'){//premios retencion/detalle
							$dr++;
							$archivo['nombre']='dr_'.$dr;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'DR', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s'){//se usa para cdo son archivos individuales
								$archivo['buttonText']='Premios Ret. Ctrl.';
							}else{
								/*if($i==0){ //se usa para cdo son archivos individuales
									$archivo['buttonText']='Premios Ret. Det.';
									$i++;
								}else*/
									$archivo['buttonText']='Premios Ret.';
							}
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						// AGREGADO MM - 07-06-2017 - ini
						else if($archJuego['tipo_archivo']=='PC'){//premios completo/retencion
							$pc++;
							$archivo['nombre']='pc_'.$pc;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'PC', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s'){//se usa para cdo son archivos individuales
								$archivo['buttonText']='Premios Completo Ctrl.';
							}else{
									$archivo['buttonText']='Premios Completo.';
							}
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						// AGREGADO MM - 07-06-2017 - fin
						/*
						else if($archJuego['tipo_archivo']=='TT'){//premios
							$tt++;
							$archivo['nombre']='totb_1'.$tt;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'TT', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Premios Totobingo Ctrl.';
							else
								$archivo['buttonText']='Premios Totobingo';
							array_push($datosTransaccion['nombre_file'],$archivo);
						
						}else if($archJuego['tipo_archivo']=='TK'){//premios
							$tk++;
							$archivo['nombre']='telk_1'.$tk;
							$archivo['nombre_ejemplo']=$util->armaNombreArchivo($idJuego, $nro_sorteo, 'TK', $archivos[$idJuego]);
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Premios Telekino Ctrl.';
							else
								$archivo['buttonText']='Premios Telekino';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}*/
						//$archivo['extension']=$archJuego['extension'];
						//revisar!!!
						$archivo['extension']=str_replace("+" ,"",str_replace("+[[:alpha:]]", "\w", $archJuego['extension']));
						$archivo['extension']=str_replace("C{1}","[C]",$archivo['extension']);
						$archivo['extension']=str_replace("P{1}","[P]",$archivo['extension']);
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}

				//según el estado cambia el btn
				$btn['id_btn']="btn_procesar";
				$btn['value_btn']="PROCESAR";
				array_push($datosVistaTransaccion['botones'], $btn);
				$datosVistaTransaccion['id_estado']=$idEstado;

				//chequeo si ya existe un archivo para apuestas
				$usuario = Session::get('usuarioLogueado.idUsuario');
				$ds = DIRECTORY_SEPARATOR;
				//paths a las carpetas 
				$destinoTemporalSinProcesar = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$nro_sorteo.$ds."apuestas";
				
				$this->archivosPrevios($destinoTemporalSinProcesar, $datosVistaTransaccion, $archivos[$idJuego],3);

				$datosTransaccion['transaccion_activa']=3;
			
			}else if(in_array($idEstado, array(38,40))){//consolidado-publicación pte
			
			//	\Log::info('click con estado 40');
			//	\Log::info('idEstado',array($idEstado));
			
			
				$datosVistaTransaccion['id_estado']=$idEstado;
				$datosTransaccion['transaccion_activa']=3;
				//según el estado cambia el btn
				$btn['id_btn']="btn_publicar";
				$btn['value_btn']="PUBLICAR";
				array_push($datosVistaTransaccion['botones'], $btn);
				/*$btn['id_btn']="btn_ver_totales";
				$btn['value_btn']="VER&#x00A;TOTALES";
				array_push($datosVistaTransaccion['botones'], $btn);*/
				//$datosVistaTransaccion['id_estado']=$idEstado;
				
				$datos = $this->servicioRecepcionPremBing->datosProcesados($nro_sorteo,$idJuego);//nl2br(htmlentities($cadena));
	
				$datosTransaccion['datos']= "Tickets: ".$datos['cant_tck']."\nImporte Total Bruto: ".$datos['imp_total_bruto']."\nImporte Total Retención: ".$datos['imp_total_ret']."\nImporte Total Neto: ".$datos['imp_total_neto'];
				
			//	\Log::info('datosTransaccion',array($datosTransaccion));
				
			}else if(in_array($idEstado, array(45))){//probl. en public
				$datosVistaTransaccion['id_estado']=$idEstado;
				$datosTransaccion['transaccion_activa']=3;
				//según el estado cambia el btn
				$btn['id_btn']="btn_publicar";
				$btn['value_btn']="PUBLICAR";
				array_push($datosVistaTransaccion['botones'], $btn);
				/*$btn['id_btn']="btn_ver_totales";
				$btn['value_btn']="VER&#x00A;DIFERENCIAS";
				array_push($datosVistaTransaccion['botones'], $btn);*/
				$datosVistaTransaccion['id_estado']=$idEstado;
			
			}else if(in_array($idEstado, array(50))){//publicado
				$datosVistaTransaccion['id_estado']=$idEstado;
				$datosTransaccion['transaccion_activa']=4;
			}
			
			$datosVistaTransaccion['nombreFiles']=$archivosApedir;
			
			$datosTransaccion['id_estado']=$idEstado;
			$datosTransaccion['vista']= Response::liquidacion_apu_com($datosVistaTransaccion);
			/*
			$datos = $this->servicioRecepcionPremBing->datosProcesados($sorteo, $idJuego);
			$mensaje = "Tickets: ".$datos['cant_tck']."\nImporte Total Bruto: ".$datos['imp_total_bruto']."\nImporte Total Retención: ".$datos['imp_total_ret']."\nImporte Total Neto: ".$datos['imp_total_neto'];
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
			*/
		//	\Log::info('datosTransaccion2',array($datosTransaccion));
		}else{
			$datosTransaccion['puedeProcesar']=0;
			\Log::info('puedeProcesar RecepcionPremBingController',array($datosTransaccion['puedeProcesar']));
			$datosTransaccion['id_estado']=$idEstado;
			if(in_array($idEstado, array(0,10,15))){
				$datosTransaccion['transaccion_activa']=1;
			}else if(in_array($idEstado, array(20,25))){
				$datosTransaccion['transaccion_activa']=2;
			}else if(in_array($idEstado, array(30,34,36))){
				$datosTransaccion['transaccion_activa']=3;
			}else if(in_array($idEstado, array(38,40,45))){
				$datosTransaccion['transaccion_activa']=3;
			}else if(in_array($idEstado, array(50))){
				$datosTransaccion['transaccion_activa']=4;
			}		
			$datosTransaccion['vista']= Response::liquidacion_apu_com($datosTransaccion);			
		}
		return $datosTransaccion;
	
	}

	
	/*****************************************************
	* Función que obtiene los archivos para resultados   *
	******************************************************/
	public function obtenerArchivosResultados(){	
			
		$idJuego = Input::get('id_juego_seleccionado');
		$idEstado = Input::get('id_estado_seleccionado');
		$sorteo = Input::get('sorteo');
		$fechaSorteo = Input::get('fecha');
		$formatoProcesamiento = Input::get('id_formato_procesamiento');
		$usuario = Session::get('usuarioLogueado.idUsuario');
		$entrada = Input::all();
		
		
		$ds = DIRECTORY_SEPARATOR;
		//list($af,$ap,$pr,$dr,$pc,$exito)=0;
		list($tm,$tt,$tk,$exito,$okTk,$okTm,$okTm2)=0;
		$apu_i=1;
		//paths a las carpetas destino
		list($anio,$mes,$dia)=explode("-",$fechaSorteo);
		$destinoFinalConsolidacion= $this->destinoFinalConsolidacion.$anio.$ds.$mes.$ds.$idJuego."_".$sorteo.$ds;
		$destinoTemporalSinProcesar = $this->destinoTemporalSinProcesar.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		$destinoTemporalConsolidacion = $this->destinoTemporalConsolidacion.$usuario.$ds.$idJuego."_".$sorteo.$ds;
		
		//creación de las carpetas
		if(!is_dir($destinoFinalConsolidacion) && !file_exists($destinoFinalConsolidacion)){
		  File::makeDirectory($destinoFinalConsolidacion, 0777, true);
		}
		if(!is_dir($destinoTemporalSinProcesar) && !file_exists($destinoTemporalSinProcesar)){
		  	File::makeDirectory($destinoTemporalSinProcesar, 0777, true);
		}else{
			$archivosSinProcesar=scandir($destinoTemporalSinProcesar);
		}
		if(!is_dir($destinoTemporalConsolidacion) && !file_exists($destinoTemporalConsolidacion)){
		  File::makeDirectory($destinoTemporalConsolidacion, 0777, true);
		}
		
		//vemos qué archivos deberían pedirse
		if(Session::has('tipoArchivoJuegoEstado'))
			$archivos = Session::get('tipoArchivoJuegoEstado');
		else
			$archivos = $this->servicioRecepcionPremBing->especif_arch_x_juego();
	
		//archivos para el juego seleccionado
		$archivos=$archivos[$idJuego];
		\Log::info('RecepcionPremBingController - archivos',array($archivos));
		\Log::info($idJuego);
		$util = new Util();
		
		$archivos=$util->groupArray($archivos,'tipo_archivo');
		$listaTiposArchivos=array();
		$listaArchivosRequerimiento=array();
		foreach ($archivos as $tiposArc) {
			array_push($listaArchivosRequerimiento,$tiposArc);
			array_push($listaTiposArchivos,$tiposArc['tipo_archivo']);
		}
		//vemos qué tipo de requerimiento tienen los archivos o=opcional, r=requerido
		$archivosRequerimientos=array();
		foreach ($listaArchivosRequerimiento as $archReq) {
			foreach ($archReq['grupodatos'] as $especificacion) {
				if($especificacion['transaccion']==2){
					$arReq[$archReq['tipo_archivo']]=$especificacion['requerido'];
					$archivosRequerimientos[$archReq['tipo_archivo']]=$arReq;	
				}
			};
		}

		$mensaje="TODO OK";
			
	// premios totobongo
	
		$idProceso=$this->servicioRecepcionPremBing->getNumeroProcesoAuditoriaCtaCte($idJuego, $sorteo);
	// TOTOBINGO	
		if(in_array("TT", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['TT']['TT'],'R')==0 || strcasecmp($archivosRequerimientos['TT']['TT'],'O')==0)){ //premios totob
		try{
			
			$destinoTemporalConsolidacionTT =$destinoTemporalSinProcesar."premios_bingos".$ds;
			if(!is_dir($destinoTemporalConsolidacionTT) && !file_exists($destinoTemporalConsolidacionTT)){
			  File::makeDirectory($destinoTemporalConsolidacionTT, 0777, true);
			}else{
				//\File::cleanDirectory($destinoTemporalConsolidacionPC);
				array_map('unlink', glob($destinoTemporalConsolidacionTT."*"));
			}
			
			$previos=array();
			$archivosHijos =array();
			$archivosPadres =array();
			//$listaArchivos['tt_ctrl']=array();
			$listaArchivos['totb_det']=array();
			
			$this->listasArchivos($archivos, $listaPremios, $archivosHijos, $archivosPadres, "TT",2); // decia "3" verificar si es la transaccion
			
			if(count($archivosPadres)>=1){//son archivos unitarios
			
				$tt=1;				
				$this->estanTodosLosArchivos($destinoTemporalConsolidacionTT,"premios_bingos","totb_",$archivosPadres, $listaArchivos);
				$exito=1;
			}else{ //hay un padre contenedor en caso de que venga en un zip
				$tt=2;
					//verifico si existe uno anterior
					$destinoTemporalSinProcesarTT=$destinoTemporalSinProcesar.'premios_bingos'.$ds;
					$archivosTT=array();
					foreach ($archivos as $tipoArchivo) {
						if(strcasecmp($tipoArchivo['tipo_archivo'], "TT")===0)
							$archivosTT=$tipoArchivo['grupodatos'];
					}
			
					$this->archivosPrevios($destinoTemporalSinProcesarTT,$previos, $archivosTT,2);
					$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"totb_", "premios_bingos",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionTT,$listaPremios ,$idJuego,$listaArchivos, $previos);

					\Log::info("RecepcionPremBingController deszipeo - exito? ",array($dezipeoOK['exito']));
					
					if(!$dezipeoOK['exito']){
						return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
					}
					
				
			}
		}catch(\Exception $e){
			$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios_bingos");
			\Log::info($mensaje);
			\Log::info($e);
			return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		}
		
	}

	// TELEKINO
	
	if(in_array("TK", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['TK']['TK'],'R')==0 || strcasecmp($archivosRequerimientos['TK']['TK'],'O')==0)){ //premios telekino
		try{
			
			$destinoTemporalConsolidacionTK =$destinoTemporalSinProcesar."premios_telekino".$ds;
			if(!is_dir($destinoTemporalConsolidacionTK) && !file_exists($destinoTemporalConsolidacionTK)){
			  File::makeDirectory($destinoTemporalConsolidacionTK, 0777, true);
			}else{
				//\File::cleanDirectory($destinoTemporalConsolidacionPC);
				array_map('unlink', glob($destinoTemporalConsolidacionTK."*"));
			}
			
			$previos=array();
			$archivosHijos =array();
			$archivosPadres =array();
			//$listaArchivos['tt_ctrl']=array();
			$listaArchivos['telk_det']=array();
			
			$this->listasArchivos($archivos, $listaPremios, $archivosHijos, $archivosPadres, "TK",2); 

			if(count($archivosPadres)>1){//son archivos unitarios

				$tk=1;				
				$this->estanTodosLosArchivos($destinoTemporalConsolidacionTK,"premios_telekino","telk_",$archivosPadres, $listaArchivos);
				$exito=1;
			}else{ //hay un padre contenedor en caso de que venga en un zip
	
				$tk=2;
				$this->estanTodosLosArchivos($destinoTemporalConsolidacionTK,"premios_telekino","telk_",$archivosPadres, $listaArchivos);
				
				$exito=1;
					//verifico si existe uno anterior
					$destinoTemporalSinProcesarTK=$destinoTemporalSinProcesar.'premios_telekino'.$ds;
					$archivosTK=array();
					foreach ($archivos as $tipoArchivo) {
						if(strcasecmp($tipoArchivo['tipo_archivo'], "TK")===0)
							$archivosTK=$tipoArchivo['grupodatos'];
					}
			
					$this->archivosPrevios($destinoTemporalSinProcesarTK,$previos, $archivosTK,2);
					$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"telk_", "premios_telekino",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionTK,$listaPremios ,$idJuego,$listaArchivos, $previos);
				
					if(!$dezipeoOK['exito']){
						return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
					}
			}
		}catch(\Exception $e){
			$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios_telekino");
			\Log::info($mensaje);
			\Log::info($e);
			return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		}
	}
	
	// agregado 20/03/2018 MM
	
	// MARADONA
	
	if(in_array("TM", $listaTiposArchivos) && (strcasecmp($archivosRequerimientos['TM']['TM'],'R')==0 || strcasecmp($archivosRequerimientos['TM']['TM'],'O')==0)){ //premios maradona
		try{
			
			$destinoTemporalConsolidacionTM =$destinoTemporalSinProcesar."premios_maradona".$ds;
			if(!is_dir($destinoTemporalConsolidacionTM) && !file_exists($destinoTemporalConsolidacionTM)){
			  File::makeDirectory($destinoTemporalConsolidacionTM, 0777, true);
			}else{
				//\File::cleanDirectory($destinoTemporalConsolidacionPC);
				array_map('unlink', glob($destinoTemporalConsolidacionTM."*"));
			}
			
			$previos=array();
			$archivosHijos =array();
			$archivosPadres =array();
			$listaArchivos['mara_ctrl']=array();
			$listaArchivos['mara_det']=array();
			
			$this->listasArchivos($archivos, $listaPremios, $archivosHijos, $archivosPadres, "TM",2); 

			if(count($archivosPadres)>1){//son archivos unitarios

				$tm=1;				
				$this->estanTodosLosArchivos($destinoTemporalConsolidacionTM,"premios_maradona","mara_",$archivosPadres, $listaArchivos);
				$exito=1;
			}else{ //hay un padre contenedor en caso de que venga en un zip
	
				$tm=2;
				$this->estanTodosLosArchivos($destinoTemporalConsolidacionTM,"premios_maradona","mara_",$archivosPadres, $listaArchivos);
				
				$exito=1;
					//verifico si existe uno anterior
					$destinoTemporalSinProcesarTM=$destinoTemporalSinProcesar.'premios_maradona'.$ds;
					$archivosTM=array();
					foreach ($archivos as $tipoArchivo) {
						if(strcasecmp($tipoArchivo['tipo_archivo'], "TM")===0)
							$archivosTM=$tipoArchivo['grupodatos'];
					}
			
					$this->archivosPrevios($destinoTemporalSinProcesarTM,$previos, $archivosTM,2);
					$dezipeoOK=$this->tratamientoArchivosEnContenedor($util,"mara_", "premios_maradona",$archivosPadres,$archivosHijos, $destinoTemporalConsolidacionTM,$listaPremios ,$idJuego,$listaArchivos, $previos);
				
					if(!$dezipeoOK['exito']){
						return Response::json(array('exito'=>$dezipeoOK['exito'], 'mensaje'=>$dezipeoOK['mensaje'],'estado'=>$idEstado, 'srcImagen'=>$this->srcImgError));       						
					}
			}
		}catch(\Exception $e){
			$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios_maradona");
			\Log::info($mensaje);
			\Log::info($e);
			return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		}
	}
	
	

		//carga de los archivos totobingo
		
		if($tt==1 && $exito==1){
			$archivoTt = $listaArchivos['totb_det'][0];	
			//$archivoTtCtrl = $listaArchivos['totb_ctrl'][0];
			// vuelco archivo
			$res=$this->archivosPremios($archivoTt,$destinoTemporalConsolidacionTT,1,$idJuego, $idProceso,$usuario,$fechaSorteo);
			if($res){
				$sorteoCorrecto=$this->servicioRecepcionPremBing->controlSorteo($sorteo,$idJuego,3);
				\Log::info("sale de controlSorteo RecepcionPremBingController", array($sorteoCorrecto));
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios_bingos');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios_bingos");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       										
			}
		}else if($tt==2 && $exito==1){
			$archivoTt = $listaArchivos['totb_det'][0];		
			//$archivoTtCtrl = $listaArchivos['totb_ctrl'][0];
			//$okCtrlTt=$this->servicioPremiosBingos->cargarPremiosControl($archivoPreCtrl, $archivoPr);
		
		// CARGA PREMIOS 	
			\Log::info("Ini Cargo el archivo - RecepcionPremBingController ", array($archivoTt));
			$okTt=$this->servicioPremiosBingos->cargarPremioTT($archivoTt);
			\Log::info("Cargo el archivo - RecepcionPremBingController ", array($okTt));
			//if($okPre && $okCtrlPre){
			if($okTt){
				$sorteoCorrecto=$this->servicioRecepcionPremBing->controlSorteo($sorteo,$idJuego,8);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;			
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
		} else if($tk==1 && $exito==1){
			//carga de los archivos telekino
			$archivoTk = $listaArchivos['telk_det'][0];	
			//$archivoTtCtrl = $listaArchivos['telk_cab'][0];

			// vuelco archivo
				$res=$this->archivosPremios($archivoTk,$destinoTemporalConsolidacionTK,1,$idJuego, $idProceso,$usuario,$fechaSorteo);
			
			if($res){
				$sorteoCorrecto=$this->servicioRecepcionPremBing->controlSorteo($sorteo,$idJuego,8);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios_telekino');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios_telekino");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       										
			}
		}else if($tk==2 && $exito==1){
	
			$archivoTk = $listaArchivos['telk_det'][0];		
			//$archivoTtCtrl = $listaArchivos['totb_ctrl'][0];
			//$okCtrlTt=$this->servicioPremiosBingos->cargarPremiosControl($archivoPreCtrl, $archivoPr);
		//esto es para definir el archivo que voy a cargar para el caso de telekino es el gansfe.nnnn
		$ficheros = scandir($destinoTemporalConsolidacionTK);
					
				$ficheros1 = array();
				foreach ($ficheros as $fichero){
					if((strpos($fichero,"ZIP") || strpos($fichero,"zip")) < 1 && $fichero!= "." && $fichero!= ".."){
						array_push($ficheros1, $fichero);
					}
				}
		
				// control de diferencia de cantidad de archivos esperados en cas.zip
				if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
					$mensaje=sprintf($this->err_cant_archivos,"premios_telekino");
					\Log::info($mensaje);
					return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>15, 'srcImagen'=>$this->srcImgError));
				}
				
				
				//	indicando la recepcion y validaciones
				
				foreach ($ficheros1 as $nombreFichero) {
					//$dest=$destinoTemporalConsolidacionTK.$nombreFichero;
					$arch=explode(".",$nombreFichero);	
					$NombreArch = strtoupper(substr($arch[0],0,6)); 
					//$Extension = strtoupper(substr($arch[1],0,3)); 
					
					//$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,201,$usuario,200,202,"Inicio vuelco archivo ".$nombreFichero);
					switch ($NombreArch) {
						case "GANSFE":
								$dest=$destinoTemporalConsolidacionTK.$nombreFichero;
								$archivoTk['path']=$dest;
								$archivoTk['nombreOriginal']=$nombreFichero;
							// vuelco archivo
								//$okTk=$this->archivosPremios($archivoTk,$destinoTemporalConsolidacionTK,1,$idJuego, $idProceso,$usuario,$fechaSorteo);
								$okTk=$this->archivosPremios($archivoTk,$destinoTemporalConsolidacionTK,1,$idJuego, $idProceso,$usuario,$fechaSorteo);
							
						//$okTk = FALSE;
							break;
						
					}
				}
				
				if($okTk){
					$sorteoCorrecto=$this->servicioRecepcionPremBing->controlSorteo($sorteo,$idJuego,8);
					\Log::info('Sorteo Correcto (RecepcionPremBingController) ',array($sorteoCorrecto));
					if($sorteoCorrecto){
						$exito=1;
					}else{
						$exito=0;			
						$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios_telekino');
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
					}
				}else{
					$exito=0;
					$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios_telekino");
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
				
				
			}
			// agregado 20/03/2018 MM
		else if($tm==1 && $exito==1){
			//carga de los archivos maradona
			$archivoTm = $listaArchivos['mara_det'][0];	
			//$archivoTtCtrl = $listaArchivos['telk_cab'][0];

			// vuelco archivo
				$res=$this->archivosPremios($archivoTm,$destinoTemporalConsolidacionTM,1,$idJuego, $idProceso,$usuario,$fechaSorteo);
			
			if($res){
				$sorteoCorrecto=$this->servicioRecepcionPremBing->controlSorteo($sorteo,$idJuego,8);
				if($sorteoCorrecto){
					$exito=1;
				}else{
					$exito=0;					
					$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios_maradona');
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
			}else{
				$exito=0;
				$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios_maradona");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       										
			}
		}else if($tm==2 && $exito==1){
	
			$archivoTm = $listaArchivos['mara_det'][0];		
			//$archivoTtCtrl = $listaArchivos['totb_ctrl'][0];
			//$okCtrlTt=$this->servicioPremiosBingos->cargarPremiosControl($archivoPreCtrl, $archivoPr);
		//esto es para definir el archivo que voy a cargar para el caso de telekino es el gansfe.nnnn
		$ficheros = scandir($destinoTemporalConsolidacionTM);
		\Log::info('ficheros:  ',array($ficheros));
				$ficheros1 = array();
				foreach ($ficheros as $fichero){
					if((strpos($fichero,"ZIP") || strpos($fichero,"zip")) < 1 && $fichero!= "." && $fichero!= ".."){
						array_push($ficheros1, $fichero);
					}
				}
		
				// control de diferencia de cantidad de archivos esperados en cas.zip
				if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
					$mensaje=sprintf($this->err_cant_archivos,"premios_maradona");
					\Log::info($mensaje);
					return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>15, 'srcImagen'=>$this->srcImgError));
				}
				
				
				//	indicando la recepcion y validaciones
				
				foreach ($ficheros1 as $nombreFichero) {
					\Log::info('nombreFichero:  ',array($nombreFichero));
					//$dest=$destinoTemporalConsolidacionTM.$nombreFichero;
					$arch=explode(".",$nombreFichero);	
					//$NombreArch = strtoupper(substr($arch[0],0,6)); 
					$NombreArch = strtoupper($arch[1]); 
					//$Extension = strtoupper(substr($arch[1],0,3)); 
					
					//$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,201,$usuario,200,202,"Inicio vuelco archivo ".$nombreFichero);
					switch ($NombreArch) {
						case "CTL":
								$dest=$destinoTemporalConsolidacionTM.$nombreFichero;
								$archivoTm['path']=$dest;
								$archivoTm['nombreOriginal']=$nombreFichero;
							// vuelco archivo
								//$okTk=$this->archivosPremios($archivoTm,$destinoTemporalConsolidacionTM,1,$idJuego, $idProceso,$usuario,$fechaSorteo);
								$okTm=$this->archivosPremios($archivoTm,$destinoTemporalConsolidacionTM,1,$idJuego, $idProceso,$usuario,$fechaSorteo);
								\Log::info('okTm:  ',array($okTm));
						break;
						case "DAT":
								$dest=$destinoTemporalConsolidacionTM.$nombreFichero;
								$archivoTm['path']=$dest;
								$archivoTm['nombreOriginal']=$nombreFichero;
							// vuelco archivo
								//$okTk=$this->archivosPremios($archivoTm,$destinoTemporalConsolidacionTM,1,$idJuego, $idProceso,$usuario,$fechaSorteo);
								$okTm2=$this->archivosPremios($archivoTm,$destinoTemporalConsolidacionTM,1,$idJuego, $idProceso,$usuario,$fechaSorteo);
							\Log::info('okTm2:  ',array($okTm2));
						break;
					}
				}
				
				if($okTm && $okTm2){
					$sorteoCorrecto=$this->servicioRecepcionPremBing->controlSorteo($sorteo,$idJuego,8);
					\Log::info('Sorteo Correcto (RecepcionPremBingController) ',array($sorteoCorrecto));
					if($sorteoCorrecto){
						$exito=1;
					}else{
						$exito=0;			
						$mensaje=sprintf($this->err_nro_sorteo_archivo, 'premios_maradona');
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
					}
				}else{
					$exito=0;
					$mensaje=sprintf($this->error_carga_sorteos_diarios,"premios_maradona");
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
				}
				
				
			}
		
		\Log::info('Exito RecepcionPremBingController',array($exito));
		
		if($exito){
			// valida vuelco
			\Log::info('inico valida RecepcionPremBingController');
			$mensaje=$this->servicioRecepcionPremBing->validar($idJuego,$sorteo,$idProceso,$usuario,$fechaSorteo);		
			\Log::info('valida RecepcionPremBingController',array($mensaje));

			if($mensaje != 'OK'){
				$actualizaEstado=$this->servicioRecepcionPremBing->actualizaEstado($sorteo,$idJuego,34);
				\Log::info('actualizaEstado RecepcionPremBingController',array($actualizaEstado));
				$exito=0;
				$mensaje=sprintf($mensaje);
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
	
			// vuelco desde las rec a las aux
			$mensaje=$this->servicioRecepcionPremBing->procesa($idJuego,$sorteo,$idProceso,$usuario,$fechaSorteo);		
			\Log::info('procesa RecepcionPremBingController',array($mensaje));

			if($mensaje != 'OK'){
				$actualizaEstado=$this->servicioRecepcionPremBing->actualizaEstado($sorteo,$idJuego,34);
				$exito=0;
				$mensaje=sprintf($mensaje);
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
			}
	
			 $actualizaEstado=$this->servicioRecepcionPremBing->actualizaEstado($sorteo,$idJuego,40);
			 $datos = $this->servicioRecepcionPremBing->datosProcesados($sorteo, $idJuego);

			//si todo da ok armo la vista --> incluyo mensaje de cupones	
			if(strcasecmp (trim(strtoupper($mensaje)), 'OK') ==0){//consolidó correctamente
				if(isset($datos)){
					$idEstado=$datos['idEstado'];
					$idsorteo=$datos['idPgmSorteo'];
					$desc_estado=$datos['de_estado'];
					
					$mensaje = "Tickets: ".$datos['cant_tck']."\nImporte Total Bruto: ".$datos['imp_total_bruto']."\nImporte Total Retención: ".$datos['imp_total_ret']."\nImporte Total Neto: ".$datos['imp_total_neto'];
					$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);

					$this->moverArchivosTemporalFinal($destinoTemporalSinProcesar,$destinoFinalConsolidacion,$idJuego,1);
		
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro, 'datosTransaccion'=>$resultado));
					//return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgPeligro));
				}else{//acá no debería entrar nunca
	
					$exito=0;
					$mensaje=sprintf($this->err_datos_sorteo, $sorteo);//ver si acá el estado es 30 o no...
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgPeligro));
				}
			}else{
	
				$exito=0;
				$datos = $this->servicioRecepcionPremBing->datosProcesados($sorteo, $idJuego);
				$idEstado=$datos['idEstado'];
				$idsorteo=$datos['idPgmSorteo'];
				$desc_estado=$datos['de_estado'];
				$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgError, 'datosTransaccion'=>$resultado));
				//return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>34, 'srcImagen'=>$this->srcImgError));
			}
				
		}else{
			$exito=0;
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'estado'=>30, 'srcImagen'=>$this->srcImgError));       						
		}



	}
	

	/********************************************************
	* Función que se encarga de realizar la publicación
	*********************************************************/
	public function publicar(){
		$idJuego = Input::get('id_juego_seleccionado');
		$sorteo=Input::get('sorteo');
		$fechaSorteo = Input::get('fecha');
		$usuario = Session::get('usuarioLogueado.idUsuario');
		$idEstado = Input::get('id_estado_seleccionado');
		$formatoProcesamiento = Input::get('id_formato_procesamiento');
	//	$entrada = Input::all();
		\Log::info('entro en publicar');
		
		$idProceso=$this->servicioRecepcionPremBing->getNumeroProcesoAuditoriaCtaCte($idJuego, $sorteo);
		
		$ok = $this->servicioRecepcionPremBing->publicar($idJuego,$sorteo,$idProceso,$usuario,$fechaSorteo);
		\Log::info('publicar',array($ok));
		if($ok == 'OK'){
			
			$actualizaEstado=$this->servicioRecepcionPremBing->actualizaEstado($sorteo,$idJuego,50);
			
		}else{
			$actualizaEstado=$this->servicioRecepcionPremBing->actualizaEstado($sorteo,$idJuego,45);
		}
		$datos = $this->servicioRecepcionPremBing->datosProcesados($sorteo, $idJuego);
		
		if(isset($datos)){
			$idEstado=$datos['idEstado'];
			$idsorteo=$datos['idPgmSorteo'];
			$desc_estado=$datos['de_estado'];
			if(strcasecmp(strtoupper($ok), 'OK')==0){
				$mensaje = "PUBLICADO";
				$exito=1;
				$srcImagen=$this->srcImgOk;
			}else{
				$mensaje = $ok;
				$srcImagen=$this->srcImgError;
				$exito=0;
			}

			$idEstado=$datos['idEstado'];
			$idsorteo=$datos['idPgmSorteo'];
			$desc_estado=$datos['de_estado'];
			$resultado=$this->transacciones($idsorteo, $idEstado,$idJuego, $sorteo);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>$idEstado, 'idPgm'=>$idsorteo,'srcImagen'=>$this->srcImgOk,'datosTransaccion'=>$resultado));
		}else{
			$exito=0;
			$srcImagen=$this->srcImgError;
			$mensaje=sprintf($this->err_datos_sorteo, $sorteo);
			$desc_estado='Prob. en Publicación';
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>45, 'srcImagen'=>$this->srcImgError));
		}
		if(strcasecmp($ok, 'OK')!=0){
			$mensaje = $ok;
			$srcImagen=$this->srcImgError;
			$exito=0;
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'de_estado'=>$desc_estado,'estado'=>45, 'srcImagen'=>$srcImagen));	       			
		}
	}

	/*****************************************************************
	* Función que guarda los archivos de afectaciones
	******************************************************************/
	
	public function archivosAfectaciones($archivoAfe, $archivoAfeCtrl, $destino, $guardar){	
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreAfe = $archivoAfe->getClientOriginalName();
				$nombreAfeCtrl = $archivoAfeCtrl->getClientOriginalName();
								
				$archivoAfe=$destino.$ds.$nombreAfe;
				$archivoAfeCtrl = $destino.$ds.$nombreAfeCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessAfe = $archivoAfe->move($destino, $nombreAfe);
		           	$uploadSuccessAfeCtrl = $archivoAfeCtrl->move($destino, $archivoAfeCtrl);
				}else{
					$okAfe=$this->servicioAfectaciones->cargarAfectacion($archivoAfe);
					$okAfeCtrl=$this->servicioAfectaciones->cargarAfectacionControl($archivoAfeCtrl, $archivoAfe);
				}

				if($okAfe && $okAfeCtrl)
					return 1;
				else
					return 0;

	}

	/*****************************************************************
	* Función que guarda los archivos de Resultados
	******************************************************************/
	public function archivosResultados($archivoRes, $archivoResCtrl, $destino, $guardar){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreRes = $archivoRes->getClientOriginalName();
				$nombreResCtrl = $archivoResCtrl->getClientOriginalName();
								
				$nombreRes=$destino.$ds.$nombreRes;
				$nombreResCtrl = $destino.$ds.$nombreResCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessRes = $archivoRes->move($destino, $nombreRes);
		           	$uploadSuccessResCtrl = $archivoResCtrl->move($destino, $archivoResCtrl);
				}else{
					$okRes=$this->servicioResultados->cargarResultados($archivoRes);
					$okResCtrl=$this->servicioResultados->cargarResultadosControl($archivoResCtrl, $archivoRes);
				}

				if($okRes && $okResCtrl)
					return 1;
				else
					return 0;

	}
	/*****************************************************************
	* Función que guarda los archivos de Extractos
	******************************************************************/
	public function archivosExtractos($archivoEx, $archivoExCtrl, $destino, $guardar, $juego, $sorteo){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreEx = $archivoEx->getClientOriginalName();
				$nombreExCtrl = $archivoExCtrl->getClientOriginalName();
								
				$nombreEx=$destino.$ds.$nombreEx;
				$nombreExCtrl = $destino.$ds.$nombreExCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessEx = $archivoEx->move($destino, $nombreEx);
		           	$uploadSuccessExCtrl = $archivoExCtrl->move($destino, $archivoExCtrl);
				}else{
					$idpgmsorteo=(1000000*$juego)+$sorteo;
					$okEx=$this->servicioResultados->cargarExtractos($archivoEx,$idpgmsorteo);
					$okExCtrl=$this->servicioResultados->cargarExtractosControl($archivoExCtrl, $archivoEx);
				}

				if($okEx && $okExCtrl)
					return 1;
				else
					return 0;

	}
	/*****************************************************************
	* Función que guarda los archivos de apuestas
	******************************************************************/
	public function archivosApuestas($archivoApu, $archivoApuCtrl, $destino, $guardar, $idJuego, $formatoProcesamiento){
				//nombres - extensiones
				$nombreApu = $archivoApu->getClientOriginalName();
				$nombreApuCtrl = $archivoApuCtrl->getClientOriginalName();
								
				$destinoApu=$destino.$nombreApu;
				$destinoApuCtrl = $destino.$nombreApuCtrl;

				//movemos los archivo a la carpeta que corresponde
				$uploadSuccessApu = $archivoApu->move($destinoApu, $nombreApu);
	           	$uploadSuccessApuCtrl = $archivoApuCtrl->move($destinoApuCtrl, $archivoApuCtrl);
			
				$okApu=$this->servicioApuestas->cargarApuestas($archivoApu, $idJuego, $formatoProcesamiento);
				$okApuCtrl=$this->servicioApuestas->cargarApuestasControl($archivoApuCtrl, $archivoApu);
				
				if($okApu && $okApuCtrl)
					return 1;
				else
					return 0;

	}

	/*****************************************************************
	* Función que guarda los archivos de premios
	******************************************************************/
	public function archivosPremios($archivoPre, $destino, $guardar, $idJuego, $idProceso,$usuario,$fechaSorteo){
	
				$nombrePre =$archivoPre['path'];//$archivoPre->getClientOriginalName();//basename($archivoPre);// 
				//$nombrePreCtrl = $archivoPreCtrl['path'];//$archivoPreCtrl->getClientOriginalName();//basename($archivoPreCtrl);//
				$destinoPre=$destino.$archivoPre['nombreOriginal'];//.$nombrePre;
				//$destinoPreCtrl = $destino.$archivoPreCtrl['nombreOriginal'];//$nombrePreCtrl;

				//movemos los archivo a la carpeta que corresponde
				$uploadSuccessPre =move_uploaded_file($nombrePre, $destinoPre); //$archivoPre->move($destino, $nombrePre); //$archivoPre->move($destinoPre, $nombrePre);//
	          // 	$uploadSuccessPreCtrl = move_uploaded_file($nombrePreCtrl, $destinoPreCtrl);//$archivoPreCtrl->move($destino, $nombrePreCtrl);/$archivoPreCtrl->move($destinoPreCtrl, $nombrePreCtrl);
				
				if ( $idJuego == "215"){
					
					\Log::info('entre a juego 215');
					$okPre=$this->servicioPremiosBingos->cargarPremioTT($destinoPre,$idJuego, $idProceso,$usuario,$fechaSorteo);
					\Log::info('sale de juego 215', array($okPre));
				}
				
				if ( $idJuego == "217"){
					\Log::info('entre a juego 217');
					$okPre=$this->servicioPremiosBingos->cargarPremioTK($destinoPre,$idJuego, $idProceso,$usuario,$fechaSorteo);
				}
				
				if ( $idJuego == "268"){
					\Log::info('entre a juego 268');
					$okPre=$this->servicioPremiosBingos->cargarPremioTM($destinoPre,$idJuego, $idProceso,$usuario,$fechaSorteo);
				}

				// $okPreCtrl=$this->servicioPremiosBingos->cargarPremiosControl($destinoPreCtrl, $destinoPre);
				

				if($okPre )
					return 1;
				else
					return 0;

	}
	/*****************************************************************
	* Función que guarda los archivos de premios retención
	******************************************************************/
	public function archivosPremiosRetencion($archivosDr, $archivoDrCtrl, $destino, $idJuego, $opcion){
				if($opcion==1){
					$nombreDrCtrl =$archivoDrCtrl['path'];//basename($archivoDrCtrl); //$archivoDrCtrl->getClientOriginalName();//
					$destinoDrCtrl = $destino.$archivoDrCtrl['nombreOriginal'];
				}else{
					$nombreDrCtrl =basename($archivoDrCtrl); //$archivoDrCtrl->getClientOriginalName();//
					$destinoDrCtrl = $destino.$nombreDrCtrl;
				}
	           	$uploadSuccessDrCtrl = move_uploaded_file($nombreDrCtrl, $destinoDrCtrl);//$archivoDrCtrl->move($destino, $nombreDrCtrl); $archivoPreCtrl->move($destinoPreCtrl, $nombrePreCtrl);
	           	$x=1;
				$okDr=1;
				$okDrCtrl=1;
				foreach ($archivosDr as $archivoDr) {
					if($opcion==1){
						$nombreDr = $archivoDr['path'];//basename($archivoDr);//$archivoDr->getClientOriginalName();//
						$destinoDr=$destino.$archivoDr['nombreOriginal'];
					}else{
						$nombreDr = basename($archivoDr);//$archivoDr->getClientOriginalName();//
						$destinoDr=$destino.$nombreDr;					
					}
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessDr =move_uploaded_file($nombreDr, $destinoDr);//$archivoDr->move($destino, $nombreDr); 
					$okDrCtrl=$this->servicioPremios->cargarPremiosRetencionControl($destinoDrCtrl, $destinoDr,$x);					
					$okDr=$this->servicioPremios->cargarPremiosRetDet($destinoDr, $idJuego);
					$x++;										
				}

				if($okDr && $okDrCtrl)
					return 1;
				else
					return 0;

	}

	/*****************************************************************
	* Función que guarda los archivos de carátula
	******************************************************************/
	public function archivosCaratula($archivoCar, $archivoCarCtrl, $destino, $guardar, $idJuego){
				//nombres
				$nombreCar = $archivoCar->getClientOriginalName();
				$nombreCarCtrl = $archivoCarCtrl->getClientOriginalName();
				$destinoCar=$destino.$nombreCar;
				$destinoCarCtrl = $destino.$nombreCarCtrl;


				//movemos los archivo a la carpeta que corresponde
				$uploadSuccessCar =$archivoCar->move($destino, $nombreCar); //move_uploaded_file($archivoPre, $destinoPre); //$archivoPre->move($destinoPre, $nombrePre);//
	           	$uploadSuccessCarCtrl = $archivoCarCtrl->move($destino, $nombreCarCtrl);//move_uploaded_file($archivoPreCtrl, $destinoPreCtrl);//$archivoPreCtrl->move($destinoPreCtrl, $nombrePreCtrl);

				$okCar=$this->servicioCaratulas->cargarCaratula($destinoPre, $idJuego);
				$okCarCtrl=$this->servicioCaratulas->cargarCaratulaControl($destinoCarCtrl, $destinoCar);
				

				if($okCar && $okCarCtrl)
					return 1;
				else
					return 0;

	}
	
	/*****************************************************************
	* Función que guarda los archivos de comisiones
	******************************************************************/
	public function archivosComisiones($archivoCom, $archivoComCtrl, $destino, $guardar){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreCom = $archivoCom->getClientOriginalName();
				$nombreComCtrl = $archivoComCtrl->getClientOriginalName();
								
				$archivoCom=$destino.$ds.$nombreCom;
				$archivoComCtrl = $destino.$ds.$nombreComCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessCom = $archivoCom->move($destino, $nombreCom);
		           	$uploadSuccessComCtrl = $archivoComCtrl->move($destino, $archivoComCtrl);
				}else{
					$okCom=$this->servicioComisiones->cargarComision($archivoCom);
					$okComCtrl=$this->servicioComisiones->cargarComisionesControl($archivoComCtrl, $archivoCom);
				}

				if($okCom && $okComCtrl)
					return 1;
				else
					return 0;

	}
	
	/*****************************************************************
	* Función que guarda los archivos de mantenimiento y sellado
	******************************************************************/
	public function archivosManSellado($archivoMan, $archivoManCtrl, $destino, $guardar){
				$ds=DIRECTORY_SEPARATOR;
				//nombres - extensiones
				$nombreMan = $archivoMan->getClientOriginalName();
				$nombreManCtrl = $archivoManCtrl->getClientOriginalName();
								
				$archivoMan=$destino.$ds.$nombreMan;
				$archivoManCtrl = $destino.$ds.$nombreManCtrl;

				if($guardar){
					//movemos los archivo a la carpeta que corresponde
					$uploadSuccessMan = $archivoMan->move($destino, $nombreMan);
		           	$uploadSuccessManCtrl = $archivoManCtrl->move($destino, $archivoManCtrl);
				}else{
					$okMan=$this->servicioComisiones->cargarManSellado($archivoMan);
					$okManCtrl=$this->servicioComisiones->cargarManSelladoControl($archivoManCtrl, $archivoMan);
				}

				if($okMan && $okManCtrl)
					return 1;
				else
					return 0;

	}
	
	/*****************************************
	* lista de archivos según la transacción
	******************************************/
	private function listasArchivos($archivos, &$lista, &$hijos, &$padres, $ta, $transac){
		//lista de archivos 
		foreach ($archivos as $archivo) {
			if($archivo['tipo_archivo']==$ta ){
				$lista=$archivo['grupodatos'];
				break;
			}
		}
		if(isset($lista)){
			//busco el arch. padre y los hijos
			foreach ($lista as $archivo) {
				if($archivo['id_padre']=='' && $archivo['transaccion']== $transac){
					array_push($padres,$archivo);								
				}else{
					array_push($hijos,$archivo);
				}
			}			
		}
	}
	/**************************************************************************
	* Función que se encarga de buscar los archivos previos si es que existen *
	***************************************************************************/
    private function archivosPrevios($directorioBusqueda, &$resultado, $archivos, $transaccion){
    	
    	if(is_dir($directorioBusqueda)){
				$directorio = File::files($directorioBusqueda);
				if(!empty($directorio)){
					$iteadorArchivosEnDestino=new FilesystemIterator($directorioBusqueda, FilesystemIterator::SKIP_DOTS);//no incluye . ni ..
					$tipo_archivo = basename($directorioBusqueda);
					if(iterator_count($iteadorArchivosEnDestino)>0){
						$files = File::allFiles($directorioBusqueda);
						$arch = [];
						$extension=array();
						//busco qué tipo de archivos previos busco
						foreach ($archivos as $archivo) {
							if($archivo['transaccion']==$transaccion && $archivo['id_padre']==''){
								array_push($extension,$archivo['extension']);
							}
						}
						foreach ($files as $file)
						{
							$extFile=".".pathinfo(basename($file), PATHINFO_EXTENSION);
							if($this->coincideExtension($extension, $extFile)){
							    array_push($arch, basename($file)) ;//nombre del archivo de apuestas
							    $resultado['archivosPrevios']=array('existenArchivosPrevios'=>1,'archivos'=>array(array('tipo_archivo'=>$tipo_archivo,'nombre_archivo'=>$arch)));
							}

						}
					}else{
						$resultado['archivosPrevios']=array('existenArchivosPrevios'=>0,'archivos'=>array());
					}						
				}	
			}
    }
	
	
	/****************************************************************************
	* Función que se encarga de mover los archivos del temporal sin procesar al *
	* temporal correcto (según la transacción)                                  *
	*****************************************************************************/
    private function moverArchivosTemporalFinal($directorioBusqueda, $directorioFinal,$idJuego ,$final=0){
    	if(is_dir($directorioBusqueda)){
				$directorio = File::files($directorioBusqueda);
				$ds=DIRECTORY_SEPARATOR;
				\Log::info("Directorio origen: ",array($directorioBusqueda)); 
				\Log::info("Directorio destino: ",array($directorioFinal));
				//if(!empty($directorio) || $final==1){// || stripos($directorioFinal,'consolidado')!== false
				if($final==1 || !empty($directorio)){				
					//$iterador=new DirectoryIterator($directorioBusqueda, FilesystemIterator::SKIP_DOTS);//no incluye . ni ..
					
					$files = scandir($directorioBusqueda);
					
				    $oldfolder = $directorioBusqueda;
				    $newfolder = $directorioFinal;
					
				    foreach($files as $fname) {
				      if($fname != '.' && $fname != '..') {
						  $success = \File::deleteDirectory($newfolder.$fname, true);
				          rename($oldfolder.$fname, $newfolder.$fname);
				      }
				    }
				    //elimino el contenido del directorio
				    array_map('unlink', glob($oldfolder."*"));
					//elimino el directorio
				    $this->rrmdir($oldfolder);
				    //elimino la carpeta del juego_sorteo
				    $dir_js = substr($oldfolder, 0,strpos($oldfolder, basename($oldfolder)));
				    $this->rrmdir($dir_js);

				}		
				
			}
    }
	
	/*
		Movemos los zip por ftp
	*/
	private function moverZipFTP($directorioBusqueda, $directorioFinal,$idJuego,$sorteo,$patron){
		 $files = scandir($directorioBusqueda);
		 $newfolder = $directorioFinal;
		 $ds=DIRECTORY_SEPARATOR;
		 foreach($files as $fname) {
			if($fname != '.' && $fname != '..') {
				$match=preg_match($patron, $fname);
				if($match){
					$archivos = scandir($newfolder.$fname);
					foreach($archivos as $nombre) {
						 if(strtolower(\File::extension($nombre))=="zip"){
								try{
									$this->moverArchivosPorFTP($idJuego, $newfolder.$fname.$ds.$nombre,$sorteo);
								}catch(\Exception $e){
									\Log::error("Problema al mover apuestas con ftp. Juego: ".$idJuego);
								}
						 }
					}
				}
			}
		}
	}
	
	/***********************************************************
	* Función que se encarga de mandar el archivo de apuestas  *
	* a los servidores indicados, por ftp.                     *
	************************************************************/
	private function moverArchivosPorFTP($idJuego, $pathArchivo, $sorteo){
	\Log::info("Dónde lo busco: ", array($pathArchivo));
		$ds= DIRECTORY_SEPARATOR;
		$servidores = $this->servicioRecepcionPremBing->servidoresFTP();
		$producto = $this->servicioRecepcionPremBing->ProductoFTP($idJuego);
		$util = new Util();
		
		
		foreach($servidores as $servidor){
			
			// Primero creamos un ID de conexión a nuestro servidor
			$cid = ftp_connect($servidor['servidor']);
			// Luego creamos un login al mismo con nuestro usuario y contraseña
			$resultado = ftp_login($cid, $servidor['usuario'],$servidor['password']);
			// Comprobamos que se creo el Id de conexión y se pudo hacer el login
			if ((!$cid) || (!$resultado)) {
				\Log::error("Fallo en la conexión", array($servidor['servidor'])); 
				break;
			}
			// Cambiamos a modo pasivo, esto es importante porque, de esta manera le decimos al 
			//servidor que seremos nosotros quienes comenzaremos la transmisión de datos.
			ftp_pasv($cid, true) ;
			ftp_chdir($cid, $servidor['ruta']);
			
			//creamos las directorios que no existen
			$sorteo=$util->zerofill($sorteo,6);
			$producto['ruta']=str_replace("xxxxxx",$sorteo,$producto['ruta']);
			$partesRuta = explode('\\',$producto['ruta']); 
			
			foreach($partesRuta as $part){
				if(!@ftp_chdir($cid, $part)){
					ftp_mkdir($cid, $part);
					ftp_chdir($cid, $part);
				}
			}
			
			//$partesRutaOrigen = explode($ds,$anioMesJuegoSorteo);
			
			if (file_exists($pathArchivo)){
				
				if ( ftp_put($cid, basename($pathArchivo),$pathArchivo, FTP_BINARY )){//basename($pathArchivo) BINARY
					//cerramos la conexión FTP
					ftp_close($cid);
					//actualizamos campo FECHAHORA_CAR
					date_default_timezone_set('America/Argentina/Buenos_Aires');
					$date =date("Y-m-d h:i:sa");
					$resul=$this->servicioRecepcionPremBing->actualizaFHC($idJuego, $sorteo,$date);
				}else{
					\Log::info("Problema al transmitir el archivo por ftp");
					ftp_close($cid);
				}
			}
		}
	}
	

	/********************************************************************
	* Función que verifica si la extensión matchea con alguna expresión *
	* de las contenidas en el arreglo.                                  *
	*********************************************************************/
	private function coincideExtension($extension, $extFile){
		foreach ($extension as $regex) {
			if(preg_match("/^".$regex, $extFile)){
				return true;
			}
		}
		return false;
	}

	/********************************************************************

	*********************************************************************/
	private function estanTodosLosArchivos($destino, $tipoArchivos,$prefijo,$archivosPadres,&$listaArchivos){
		$i=0;//$destinoTemporalConsolidacionTK,"premios_telekino","telek_",$archivosPadres, $listaArchivos
		/*\Log::info('destino', array($destino));
		\Log::info('tipoArchivos', array($tipoArchivos));
		\Log::info('prefijo', array($prefijo));
		\Log::info('archivosPadres', array($archivosPadres));
		\Log::info('listaArchivos', array($listaArchivos));*/
		
		//armo los nombres de los input files que debe haber
		$cantidad=count($archivosPadres);
		
		for($x=0;$x<$cantidad;$x++) {
			$i++;
		   	$nombreInputFile = $prefijo.$i;
			
		   	if(Input::hasFile($nombreInputFile)){
				
				
		   		$archivo = Input::file($nombreInputFile);
				
		   		$pathArchivo = $archivo->getRealPath();
				
				$nombreOriginal=$archivo->getClientOriginalName();//$archivo->getClientOriginalName();//$destino.$archivo->getClientOriginalName();//$destino.$archivo;//
				

				foreach($archivosPadres as $archP) {	
				
					$patron="/^".$archP['nombre'];
				
					if(preg_match($patron, $nombreOriginal) && strtolower($archP['control'])=="s"){
					
						
						$datoArchivo=array();
						$datoArchivo['nombreOriginal']=$nombreOriginal;
						$datoArchivo['path']=$pathArchivo;
						array_push($listaArchivos[$prefijo.'ctrl'],$datoArchivo);
						
					}else if(preg_match($patron, $nombreOriginal) && strtolower($archP['control'])=="n"){			//if(preg_match($patron, $archivo->getClientOriginalName())){			//
					
					
						$datoArchivo=array();
						$datoArchivo['nombreOriginal']=$nombreOriginal;
						$datoArchivo['path']=$pathArchivo;
						
						array_push($listaArchivos[$prefijo.'det'],$datoArchivo);						
					}	
				}
		   	}else{
		   		$mensaje=sprintf($this->err_falta_archivo,$tipoArchivos);
				/*\Log::info($mensaje);				*/
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
		   	}
		}
		/*\Log::info("prefijo: ".$prefijo);
		\Log::info($listaArchivos[$prefijo.'ctrl']);
		\Log::info($listaArchivos[$prefijo.'det']);*/
	}	

	/**************************************************************
	* Función que se encarga de sacar los archivos del contenedor *
	***************************************************************/
	private function tratamientoArchivosEnContenedor($util,$prefijo, $tiposArchivos, $archivosPadres, $archivosHijos,$destinoTemporal,$lista ,$idJuego,&$listaArchivos, $previos){
		$i=1;	
	
		if(Input::hasFile($prefijo.$i)){
		   	$archivo = Input::file($prefijo.$i);
			
		   	//archivos anteriores
		   	if(count($previos)>0){
			   	if($previos['archivosPrevios']['existenArchivosPrevios']){
					//verifico si es el mismo o no subió nada
					$archPrev = $previos['archivosPrevios']['archivos'];
					foreach ($archPrev as $prev) {
						foreach($prev['nombre_archivo'] as $p){
							if(strcasecmp($p, $archivo->getClientOriginalName())==0){//mismo archivo
							//movemos el archivo a la nueva ubicación -->verificar que se obtenga el nombre correcto
								$archivo=$archPrev;
							}else{//uno nuevo
								//borro archivo viejo
								File::delete($destinoTemporal.$ds.$p);
							}								
						}
					}
				}		   		
		   	}
			
		   	$resultado=$util->controlZip($archivo, $destinoTemporal, $lista, $idJuego);

			$mensaje='OK';
		   	if($resultado['exito']){							
				//buscar los archivos en la carpeta y pasarlos a la tabla
				$ficheros =  scandir($destinoTemporal);
				$ficheros1=array();
				foreach ($ficheros as $fichero) {
					$extension = explode(".",$fichero);
					if(strcasecmp($extension[1],'zip')!=0 && $fichero!= "." && $fichero!= ".."){
						array_push($ficheros1, $fichero);
					}
				}
				
				if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
					$mensaje=sprintf($this->err_mas_archivos,$tiposArchivos);
					\Log::info($mensaje);
					$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
					return $resultado;
				}

				foreach ($ficheros1 as $nombreFichero) {
					foreach ($archivosHijos as $hijo) {
						$patron="/^".$hijo['nombre'];
						$pathArchivo = $destinoTemporal.$nombreFichero;
						$extensionNF = explode(".",$nombreFichero)[1];
						if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
							array_push($listaArchivos[$prefijo.'ctrl'], $pathArchivo);
						}else if(strtolower($hijo['control'])=="s"){
							if(strcmp($extensionNF,'RET')==0){
								array_push($listaArchivos[$prefijo.'ret'],$pathArchivo);
							}else{
								array_push($listaArchivos[$prefijo.'det'],$pathArchivo);
							}
						}
					}
				}
				$resultado=array('exito'=>1, 'mensaje'=>$mensaje);
				return $resultado;
			}else{//problema al descomprimir
				$mensaje=$resultado['mensaje'];
				\Log::info($mensaje);
				$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
				return $resultado;
			}
	   }else if(isset($previos['archivosPrevios']['existenArchivosPrevios'])){
				$mensaje='OK';
				//verifico si es el mismo o no subió nada
				$archPrev = $previos['archivosPrevios']['archivos'];
				foreach ($archPrev as $prev) {
					foreach($prev['nombre_archivo'] as $p){
							$archivo=$destinoTemporal.$p;
					}
				}
				
				$resultado=$util->controlZip($archivo, $destinoTemporal, $lista, $idJuego);

				if($resultado['exito']){							
					//buscar los archivos en la carpeta y pasarlos a la tabla
					$ficheros =  scandir($destinoTemporal);
					$ficheros1=array();
					foreach ($ficheros as $fichero) {
						$extension = explode(".",$fichero);
						if(strcasecmp($extension[1],'zip')!=0 && $fichero!= "." && $fichero!= ".."){
							array_push($ficheros1, $fichero);
						}
					}
					
					if(count($ficheros1)!=$archivosPadres[0]['cant_arch_esperados']){
						$mensaje=sprintf($this->err_mas_archivos,$tiposArchivos);
						\Log::info($mensaje);
						$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
						return $resultado;
					}

					foreach ($ficheros1 as $nombreFichero) {
						foreach ($archivosHijos as $hijo) {
							$patron="/^".$hijo['nombre'];
							$pathArchivo = $destinoTemporal.$nombreFichero;
							if(preg_match($patron, $nombreFichero) && strtolower($hijo['control'])=="s"){
								array_push($listaArchivos[$prefijo.'ctrl'], $pathArchivo);
							}else if(strtolower($hijo['control'])=="s"){
								array_push($listaArchivos[$prefijo.'det'],$pathArchivo);
							}
						}
					}
					$resultado=array('exito'=>1, 'mensaje'=>$mensaje);
					return $resultado;
				}else{//problema al descomprimir
					$mensaje=$resultado['mensaje'];
					\Log::info($mensaje);
					$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
					return $resultado;
				}			
			
				
				
	   }else{
	   	$mensaje=sprintf($this->err_falta_archivo,$tiposArchivos);
		\Log::info($mensaje);
		$resultado=array('exito'=>0, 'mensaje'=>$mensaje);
		return $resultado;
	   }
	}
	
	
	private function rrmdir($path) {
		// Remove a dir (all files and folders in it)
		$i = new DirectoryIterator($path);
		foreach($i as $f) {
			if($f->isFile()) {
				unlink($f->getRealPath());
			} else if(!$f->isDot() && $f->isDir()) {
				$this->rrmdir($f->getRealPath());
				rmdir($f->getRealPath());
			}
		}
	}
/********************************* MM - recepción liquidaciones - inicio *****************************************/
	
	/***********************************
	* Armado del panel de liquidaciones
	************************************/
	public function camposPanelLiquidaciones(){
		$archivosApedir=array();
		$datosTransaccion['nombre_file']=array();
		$archivos=$this->servicioRecepcionPremBing->especif_arch_liq();
		
		
		$idJuego=999;$ms=0;$com=0;
		foreach ($archivos[$idJuego] as $archJuego) {
			if($archJuego['transaccion']==8 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='RL'){	//comisiones adicionales
							$com++;
							//$archivo['nombre']='com_'.$com;
							$archivo['nombre']='cas';
							if(strtolower($archJuego['control'])=='s')
								$archivo['buttonText']='Liquidaciones Ctrl.';
							else
								$archivo['buttonText']='Liquidaciones';
							array_push($datosTransaccion['nombre_file'],$archivo);
						}
						$archivo['extension']=str_replace("+" ,"",$archJuego['extension']);
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}		

		// consulta secuencia esperada se debe cambiar el select una vez que tengamos el dato en una tabla
		
			$secuencia_espe=$this->servicioLiquidaciones->secuenciaEsperada();
			//$secuencia_espe='201505';
		
		$datosTransaccion= Response::recepcionLiquidaciones($archivosApedir, $secuencia_espe);
		return $datosTransaccion;
	}

	/***********************************
	* Llamada al panel de liquidaciones
	************************************/
	public function panelLiquidaciones(){
		$campos=$this->camposPanelLiquidaciones();
		return View::make('cuenta_corriente.panelLiquidaciones', array('campos'=>$campos));
	}
	
	/********************************************************
	* Recepción de los datos desde la recepcion de liquidaciones
	*********************************************************/
	public function tratamientoLiquidaciones(){
		//definición de variables
		$util = new Util();
		list($com,$man,$exito)=0;
		$listaTiposArchivos=array();
		$listaArchivosRequerimiento=array();
		$idJuego=999;
		//$nroSecuencia=2034;
		$fecha_ejec = date("dmY");
		$ds=DIRECTORY_SEPARATOR;
		$mensaje="";
		$datos= Input::all();
		$destino=$this->destinoLiquidaciones;
		$destinoAS400=$this->destinoTemporalAS400;
		$usuario= Session::get('usuarioLogueado.idUsuario');
		
		$nroSecuencia=$this->servicioLiquidaciones->secuenciaEsperada();
		
		$idProceso=$this->servicioRecepcionPremBing->getNumeroProcesoAuditoriaCtaCte($idJuego, $nroSecuencia);
		
		/***************************************************
			Registro proceso de recepcion en auditoria
		*****************************************************/
		$this->servicioRecepcionPremBing->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,26,$usuario,26,27,"Inicio Proceso de recepción de liquidaciones");
		
			//creación de las carpetas
			//carpeta principal -> liquidaciones
			if(!is_dir($destino) && !file_exists($destino)){
			  File::makeDirectory($destino, 0777, true);
			}
			
			//obtengo todos los archivos subidos para controlar el nombre y el período
			
			$archivosSubidos = Input::file();
			
			foreach($archivosSubidos as $archivo){
				$filename = $archivo->getClientOriginalName();
			
				$arregloNombre=explode(".",$filename);	
				$nombreSinExtension =substr($arregloNombre[0],-4); 
					
				//$nombreSinExtension =substr($arregloNombre[0]); 
				
				if($nombreSinExtension!='cas'){
					// valida nombre de archivo cas.zip
					$mensaje=sprintf("El archivo ingresado no corresponde a cas.zip.",$filename);
					\Log::info($mensaje);
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
				}else{					
					//archivos a pedir
					$archivos = $this->servicioRecepcionPremBing->especif_arch_liq();
					
					$archivos=$archivos[999];					
					$archivos=$util->groupArray($archivos,'tipo_archivo');
					
					$archivosHijosRL =array();
					$archivosPadresRL =array();
					$this->listasArchivos($archivos, $listaRL, $archivosHijosRL, $archivosPadresRL, "RL",8);
					
					// deszipear
					if(Input::hasFile("cas") ){
						
						$destinoLiquidaciones =$destino.$ds;
							if(!is_dir($destinoLiquidaciones) && !file_exists($destinoLiquidaciones)){
								File::makeDirectory($destinoLiquidaciones, $mode = 0777, true, true);
							}else{
								array_map('unlink', glob($destinoLiquidaciones."*"));
							}
						
					   	$archivoCas = Input::file("cas");
						// control de archivo zip
						
						$resultado=$util->controlZip($archivoCas, $destinoLiquidaciones, $listaRL, $idJuego,'',8);
						
						$proc_ok=1;
					   	if($resultado['exito']){
							//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($destinoLiquidaciones);
						
							$ficheros1 = array();
							foreach ($ficheros as $fichero){
								if(strpos($fichero,"zip") < 1 && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
					
							// control de diferencia de cantidad de archivos esperados en cas.zip
                                                //	\Log::info("ficheros1",array($ficheros1));
						//	\Log::info("cant_arch_esperados",array($archivosPadresRL[0]['cant_arch_esperados']));
							if(count($ficheros1)!=$archivosPadresRL[0]['cant_arch_esperados']){
								$mensaje=sprintf($this->err_cant_archivos,"liquidacioness");
								\Log::info($mensaje);
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>15, 'srcImagen'=>$this->srcImgError));
							}
							/***************************************************
								indicando la recepcion y validaciones
							*****************************************************/
							foreach ($ficheros1 as $nombreFichero) {
								$dest=$destinoLiquidaciones.$nombreFichero;
								$this->servicioRecepcionPremBing->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,34,$usuario,26,27,"Inicio vuelco archivo ".$nombreFichero);
								switch ($nombreFichero) {
									case "BCF0014":
											$okLiq_BCF0014=$this->servicioLiquidaciones->cargarCodigoJuegos($dest);
											//$proc_ok = 1;
										break;
									case "CCF0001":
											$okLiq_CCF0001=$this->servicioLiquidaciones->cargarComprobantes($dest);
											//$proc_ok = 1;
										break;
									case "CCF0002":
											$okLiq_CCF0002=$this->servicioLiquidaciones->cargarConceptos($dest);
											//$proc_ok = 1;
										break;
									case "CCF0003":
											$okLiq_CCF0003=$this->servicioLiquidaciones->cargarSaldosJuegos($dest);
										//	$proc_ok = 1;
										break;
									case "CCF0004":
											$okLiq_CCF0004=$this->servicioLiquidaciones->cargarAfectaciones($dest);
											//$proc_ok = 1;
										break;
									case "CCF0015":
											$okLiq_CCF0015=$this->servicioLiquidaciones->cargarParametros($dest);
											//$proc_ok = 1;
										break;
									case "CCF0016":
											$okLiq_CCF0016=$this->servicioLiquidaciones->cargarMultijuegos($dest);
											//$proc_ok = 1;
										break;
									case "CCF0017":
											$okLiq_CCF0017=$this->servicioLiquidaciones->cargarSaldosAgente($dest);
											//$proc_ok = 1;
										break;
									case "CCF0079":
											$okLiq_CCF0079=$this->servicioLiquidaciones->cargarTiposGarantias($dest);
											//$proc_ok = 1;
										break;
									case "CCF0301":
											$okLiq_CCF0301=$this->servicioLiquidaciones->cargarMovimientosComprobantes($dest);
											//$proc_ok = 1;
										break;
									case "CCF0302":
											$okLiq_CCF0302=$this->servicioLiquidaciones->cargarConceptosComprobantes($dest);
											//$proc_ok = 1;
										break;
									case "CCF0304":
											$okLiq_CCF0304=$this->servicioLiquidaciones->cargarAplicaciones($dest);
											//$proc_ok = 1;
										break;
									case "CCF0305":
											$okLiq_CCF0305=$this->servicioLiquidaciones->cargarPremios($dest);
											//$proc_ok = 1;
										break;
									case "CCF0306":
											$okLiq_CCF0306=$this->servicioLiquidaciones->cargarNumeroSecuencia($dest);
											//$proc_ok = 1;
										break;
									case "CCF0307":
											$okLiq_CCF0307=$this->servicioLiquidaciones->cargarCreditosEfectivizados($dest);
											//$proc_ok = 1;
										break;
									case "CCF0308":
											$okLiq_CCF0308=$this->servicioLiquidaciones->cargarPremiosPagadosUIF($dest);
											//$proc_ok = 1;
										break;
									default:	
											$proc_ok = 0;
											//$mensaje=$resultado['mensaje'];
										break;
								}
							}
						}else{//ERROR DESCOMPRIMIR
							$mensaje=$resultado['mensaje'];
							// inserta auditoria sobre proceso descrompresion archivo cas.zip
							$this->servicioRecepcionPremBing->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,35,$usuario,26,27,"Problemas en archivo cas.zip ".$mensaje);
							\Log::info($mensaje);
								if($proc_ok == 0){
									$exito = 0;
								}
							return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
						}
					}
					// fin descompresion correcto
					$this->servicioRecepcionPremBing->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,36,$usuario,34,27,"Fin descompresion archivo cas.zip ".$mensaje);
					/*					
					// validaciones en procedimiento almacenado CC_Valida_CtaCte_Agencia
					$mensaje=$this->servicioLiquidaciones->validarSecuencia($idProceso,$nroSecuencia,$usuario);
						if ($mensaje != "OK"){
							\Log::info($mensaje);
						}
					
					// validaciones de vuelcos
					$mensaje=$this->servicioLiquidaciones->validarVuelcos($idProceso,$nroSecuencia,$usuario);
						if ($mensaje != "OK"){
							\Log::info($mensaje);
						}
					// validaciones comprobantes
					$mensaje=$this->servicioLiquidaciones->validarComprobantes($idProceso,$nroSecuencia,$usuario);
						if ($mensaje != "OK"){
							\Log::info($mensaje);
						}
					// validaciones conceptos
					$mensaje=$this->servicioLiquidaciones->validarConceptos($idProceso,$nroSecuencia,$usuario);
						if ($mensaje != "OK"){
							\Log::info($mensaje);
						}
					// validaciones juegos
					$mensaje=$this->servicioLiquidaciones->validarJuegos($idProceso,$nroSecuencia,$usuario);
						if ($mensaje != "OK"){
							\Log::info($mensaje);
						}	
					// validaciones agencias
					$mensaje=$this->servicioLiquidaciones->validarAgencias($idProceso,$nroSecuencia,$usuario);
						if ($mensaje != "OK"){
							\Log::info($mensaje);
						}						
					//	validacion afectación
						$mensaje=$this->servicioLiquidaciones->validarAfectaciones($idProceso,$nroSecuencia,$usuario);
						if ($mensaje != "OK"){
							\Log::info($mensaje);
						}	
						
					//	validacion vuelco datos final
						$mensaje=$this->servicioLiquidaciones->validarVuelcoDatosFinal($idProceso,$nroSecuencia,$usuario);
						if ($mensaje != "OK"){
							\Log::info($mensaje);
						}		
					*/	

					//if($okLiq_BCF0014 && $okLiq_CCF0001 && $okLiq_CCF0002 && $okLiq_CCF0003 && $okLiq_CCF0004 && $okLiq_CCF0015 && $okLiq_CCF0016 && $okLiq_CCF0017 && $okLiq_CCF0079 && $okLiq_CCF0301 && $okLiq_CCF0302 && $okLiq_CCF0304 && $okLiq_CCF0305 && $okLiq_CCF0306 && $okLiq_CCF0307 && $okLiq_CCF0308 && $mensaje =='OK'){
						if(1==1){
						/***************************************************
							Fin correcto de recepcion
						*****************************************************/
						// ruta de destino en archivo de configuracion (modificar desde ese archivo)
						$destinoAS400=$destinoAS400.$ds;
						$ficherocaszip =$destinoAS400.'cas.zip';
						$destinoLiquidaciones = $destinoLiquidaciones.'cas.zip';
						
						$this->servicioRecepcionPremBing->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,39,$usuario,27,29,"Inicio paso de archivo cas.zip para AS");
							if(!is_dir($destinoAS400) && !file_exists($destinoAS400)){
								File::makeDirectory($destinoAS400, $mode = 0777, true, true);
							}else{
								array_map('unlink', glob($destinoAS400."*"));
							}

							if (!copy($destinoLiquidaciones, $ficherocaszip)) {
								$this->servicioRecepcionPremBing->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,40,$usuario,39,38,"Inicio paso de archivo cas.zip para AS");
								$mensaje="Error al copiar $destinoLiquidaciones...\n";
								\Log::info($mensaje);
							}
						
						$this->servicioRecepcionPremBing->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,38,$usuario,27,29,"Finalización correcta de recepción liquidaciones");
						$exito = 1;
						$mensaje="Carga correcta de los archivos de liquidaciones.";
					}else{
						$this->servicioRecepcionPremBing->insertaAuditoria($idProceso,$idJuego, $nroSecuencia,37,$usuario,26,27,"Procesando recepción de liquidaciones ".$mensaje);
						\Log::info($mensaje);
						$exito = 0;
					}
				}
			}
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		
	}
	/*************************** MM - recepción liquidaciones - fin ****************************************/
	
	
}
