<?php
use Illuminate\Support\Facades\File;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;

use \Helpers\Macros;
use \Helpers\Util;

use \Dominio\Servicios\RecepcionPrePagados; 
use \Dominio\Servicios\CuentasCorrientes;
use \Dominio\Servicios\Exportaciones; 

use controllers\UsuarioController; 

class RecepcionPremPagOtrProvController extends BaseController{

	public $error_descomprimir_archivo = "Error al descomprimir el archivo";
	public $error_crear_carpeta_temporal = "Error al crear la carpeta temporal";
	public $error_carga_pre_pagados = "Error al cargar los datos en las tablas temporales";
	public $error_llamada_store_procedure = "Error al llamar al store procedure";
	public $error_proceso_ya_existente = "Proceso ya existente";
	public $err_falta_archivo = "Falta archivo de %s";
	public $err_mas_archivos = "Hay más archivos de los esperados para %s.";
	public $err_menos_archivos = "Hay menos archivos de los esperados para %s.";
	public $err_proces="Problema al procesar %s.";
	public $err_cant_archivos = "Existe problema de integridad de archivos esperados para %s.";	
	public $err_paquete ="COD-001 El paquete recibido no coincide con el formato esperado.";
	public $err_nomb_archivos ="COD-002;COD-003 No se recibió el archivo de datos o de control.";
	public $err_cod_002 = "COD-002 No se recibió archivo de datos o su formato no es el esperado.";
	public $err_cod_003 = "COD-003 No se recibió archivo de control o su formato no es el esperado.";
	public $err_general = "Problema al intentar procesar el paquete. Consulte a Soporte.";
	
	function __construct() {
		$this->servicioRecepcionPrePagados = new RecepcionPrePagados();
		$this->servicioCuentaCorriente = new CuentasCorrientes();
		$this->destinoTemporal = Config::get('ctacte_config/config.urlDestino');
		$this->destinoPrePagadosOtrProv = $this->destinoTemporal.Config::get('ctacte_config/config.urlPrePagadosOtrProv');
	}
	
	public function camposPanelRecepcionPrePagadosOtrProv(){
		$especif_archivo=$this->servicioRecepcionPrePagados->especif_arch_premiospagados_otrprov();
		//Uso una macro como respuesta custom, obtengo un html con la vista 
		return Response::recepcionPrePagOtrProv($especif_archivo);
	}

	//Llamada para la vista, le paso los datos obtenidos de la macro
	public function panelRecepcionPrePagadosOtrProv(){
		$campos=$this->camposPanelRecepcionPrePagadosOtrProv();
		// crear id_proceso char(36) uuid()
		$resultadoGenIdPorc = $this->servicioRecepcionPrePagados->GeneraIdProc();
		$id_ejec_proc = $resultadoGenIdPorc[0]->id_proceso;
		return View::make('cuenta_corriente.panelRecepcionPrePagadosOtrProv', array('campos'=>$campos,'id_ejec_proc'=>$id_ejec_proc));
	}

	/****************************************/
	/*	nuevo tratamiento para pago			*/
	/****************************************/
	public function tratamientoArchivoPremPagOtrProv()
	{
		// Variables del Request
		$id_ejec_proc = Input::get('id_ejec_proc');
		$archivosSubidos = Input::file();

		// Variables de Session
		$usuario = Session::get('usuarioLogueado.idUsuario');

		// Variables del proceso
		$idJuego = 999;
		$exito = 0;
		$mensaje = '';
		$traeRegistros = 0; 
		$path_archivo = ''; 
		$nombreSinExtension = '';

		// Variables para manejo de Archivos
		$ds = DIRECTORY_SEPARATOR;
		$destino = $this->destinoPrePagadosOtrProv;
		$util = new Util();

		// LOG INICIAL
		\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - Inicio proceso", [
			'destino' => $destino,
			'input_file' => Input::file(),
			'input_all' => Input::all()
		]);

		$nroSecuencia = $this->servicioRecepcionPrePagados->secuenciaEsperada();
		$idProceso = $this->servicioRecepcionPrePagados->getNumeroProcesoAuditoria();

		\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - idProceso: $idProceso");

		if (!File::isDirectory($destino)) {
			File::makeDirectory($destino, 0777, true, true);
			\Log::info('RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - Creacion del directorio destino realizada');
		}

		foreach ($archivosSubidos as $archivo) {
			$filename = $archivo->getClientOriginalName();
			$nombreSinExtensionRaw = pathinfo($filename, PATHINFO_FILENAME);
			$nombreSinExtension = substr($nombreSinExtensionRaw, 2, 8);

			\Log::info('RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - MM - Procesando archivo', ['nombreSinExtension' => $nombreSinExtension]);

			$archivos = $this->servicioRecepcionPrePagados->especif_arch_x_juego_otrprov();

			try {
				$archivos = $archivos[999];
			} catch (\Exception $e) {
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $idJuego, $nombreSinExtension, 890, $usuario, 890, 891, "Formato erróneo: " . $filename);
				return Response::json([
					'exito' => 0,
					'mensaje' => sprintf($this->error_carga_pre_pagados, " Problemas de configuración de archivo contactese con el administrador.")
				]);
			}

			$archivos = $util->groupArray($archivos, 'tipo_archivo');
			$archivosHijosOP = [];
			$archivosPadresOP = [];
			$listaOP = []; 

			$this->listasArchivos($archivos, $listaOP, $archivosHijosOP, $archivosPadresOP, "OP", 9);

			$destinoPrePagadosOtrProv = $destino . $ds;
			\Log::info('RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - Rutas definidas', ['destinoPrePagados' => $destinoPrePagadosOtrProv]);

			if (!File::isDirectory($destinoPrePagadosOtrProv)) {
				File::makeDirectory($destinoPrePagadosOtrProv, 0777, true, true);
			} else {
				$files = glob($destinoPrePagadosOtrProv . '/*.*');
				if ($files) {
					array_map('unlink', $files);
				}
			}

			$archivoOP = $archivo;
			
			$resultado = $util->controlZip($archivoOP, $destinoPrePagadosOtrProv, $listaOP, $idJuego, '', 9);

			if ($resultado['exito']) {
				$ficheros = scandir($destinoPrePagadosOtrProv);
				$ficheros1 = [];

				foreach ($ficheros as $fichero) {
					if (!in_array($fichero, ['.', '..']) && stripos($fichero, 'ZIP') === false && strpos($fichero, '.') !== false) {
						$ficheros1[] = $fichero;
					}
				}

				$cantArchivos = count($ficheros1);
				$cantEsperados = $archivosPadresOP[0]['cant_arch_esperados'];

				if ($cantArchivos > $cantEsperados) {
					$mensaje = sprintf($this->err_mas_archivos, "premios pagados otras provincias");
					\Log::warning("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - $mensaje");
					return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
				} elseif ($cantArchivos < $cantEsperados) {
					$mensaje = sprintf($this->err_menos_archivos, "premios pagados otras provincias");
					\Log::warning("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - $mensaje");
					return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
				}

				$archivoDatos = explode(".", $ficheros1[1]);
				$sorteo = substr($archivoDatos[0], 2, 12);
				$juego = 999;

				foreach ($ficheros1 as $nombreFichero) {
					$dest = $destinoPrePagadosOtrProv . $nombreFichero;
					$Extension = strtoupper(pathinfo($nombreFichero, PATHINFO_EXTENSION));
					$loteria = 8;
\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - nombreFichero: $nombreFichero - extension: $Extension");
					$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 890, $usuario, 890, 891, "Inicio vuelco archivo: " . $nombreFichero . " idproceso: " . $idProceso);

					switch ($Extension) {
						case "CTR":
						case "ctr":
							$ret = $this->servicioRecepcionPrePagados->cargarPremiosPagadosOtrasProvinciasControl($idProceso, $dest, $destinoPrePagadosOtrProv . $ficheros1[0]);
							if ($ret == 2){
								$mensaje = sprintf($this->err_cod_003);
								return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
							}elseif($ret==0){
								$mensaje = sprintf($this->err_general);
								return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
							}
							break;
						case "CNA":
						case "cna":
							$ret = $this->servicioRecepcionPrePagados->cargarPremiosPagadosOtrasProvincias($idProceso, $dest, $destinoPrePagadosOtrProv . $ficheros1[0]);
							if ($ret == 2){
								$mensaje = sprintf($this->err_cod_002);
								return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
							}elseif($ret==0){
								$mensaje = sprintf($this->err_general);
								return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
							}
							break;
						case "TXT":
						case "txt":
							$ret = $this->servicioRecepcionPrePagados->cargarPremiosPagadosOtrasProvincias($idProceso, $dest, $destinoPrePagadosOtrProv . $ficheros1[0]);
							if ($ret == 2){
								$mensaje = sprintf($this->err_cod_002);
								return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
							}elseif($ret==0){
								$mensaje = sprintf($this->err_general);
								return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
							}
							break;
						default:
							$mensaje = sprintf($this->err_nomb_archivos, " - premios pagados otras provincias.");
							\Log::error("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - $mensaje");
							return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
							break;
					}
				}
			} else {
				$mensaje = sprintf($this->err_paquete);
				\Log::error("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - Fallo ZIP: $mensaje");
				return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
			}

			$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 890, $usuario, 890, 891, "Fin descompresion archivo - idproceso: " . $idProceso);

			// VALIDACIÓN SECUENCIA
			$msj_sec = $this->servicioRecepcionPrePagados->validarSecuencia($idProceso, $sorteo, $usuario, $loteria, 'SEC');
			
			if ($msj_sec->cod_error == '555') {
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 891, $usuario, 890, 892, "Error COD-000 Problema en la ejecución de validacion de secuencia.");
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - Error Secuencia: " . $msj_sec->mensaje);
				return Response::json(['exito' => 0, 'mensaje' => $msj_sec->mensaje]);
			}
			
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 892, $usuario, 890, 891, "FIN OK validación de secuencia");

			// VALIDACIONES ENVIOS (CONTROL)
			$msj_env = $this->servicioRecepcionPrePagados->validarEnviosOtrProv($idProceso, $sorteo, $usuario, $loteria, 'ENV');
\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - msj_env: ", array($msj_env));
			$erroresEnvio = [
				'002' => "Error COD-003 vuelco de archivos a tablas rec $filename",
				'003' => "Error COD-003 vuelco de archivos a tablas rec $filename",
				'004' => "Error COD-004 vuelco de archivos a tablas rec $filename",
				'005' => "Error COD-005 vuelco de archivos a tablas rec $filename",
				'006' => "Error COD-006 vuelco de archivos a tablas rec $filename",
				'007' => "Error COD-007 vuelco de archivos a tablas rec $filename",
			];
			$mensajeRetorno = "";
			if (array_key_exists($msj_env->cod_error, $erroresEnvio)) {
				$auditoriaMsg = $erroresEnvio[$msj_env->cod_error];
				$mensajeRetorno = ($msj_env->cod_error == '002' || $msj_env->cod_error == '003') ? $msj_env->mensaje : "COD-{$msj_env->cod_error} " . $msj_env->mensaje; 
				
				if ($msj_env->cod_error == '000') $mensajeRetorno = "COD-004 La firma md5 del archivo de datos no coincide con la enviada.";
				if ($msj_env->cod_error == '004') $mensajeRetorno = "COD-004 La firma md5 del archivo de datos no coincide con la enviada.";
				if ($msj_env->cod_error == '005') $mensajeRetorno = "COD-005 No coincide la cantidad de registros recibida con la indicada en el archivo de control.";
				if ($msj_env->cod_error == '006') $mensajeRetorno = "COD-006 No coincide el importe total recibido con la indicada en el archivo de control.";
				if ($msj_env->cod_error == '007') $mensajeRetorno = "COD-007 Existen registros que no corresponden a la provincia indicada en el archivo de control.";
				
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 891, $usuario, 890, 892, $auditoriaMsg);
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - Error Validación ENV: $mensajeRetorno");
				return Response::json(['exito' => 0, 'mensaje' => $mensajeRetorno]);
			}

			$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 892, $usuario, 891, 893, "Fin validacion control");

			// VALIDACIONES REGISTROS
			$msj_reg = $this->servicioRecepcionPrePagados->validarEnviosOtrProv($idProceso, $sorteo, $usuario, $loteria, 'REG');
			if ($msj_reg->cod_error != '0') {
				$mensaje = "COD-666 Problema en la ejecución de validacion por registros.";
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 891, $usuario, 890, 892, "Error " . $mensaje);
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - $mensaje");
				return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
			}
			
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 892, $usuario, 890, 891, "FIN OK validación por registros");

			// PROCESAMIENTO
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 893, $usuario, 891, 892, "INICIO PROCESAMIENTO PREMIOS OTRAS PROV");
			/*
			return Response::json([
					'exito' => 0,
					'mensaje' => sprintf( " kk")
				]);
			*/
			$msj_process = $this->servicioRecepcionPrePagados->Procesar_pre_pagados_otrprov($idProceso, 'IN');

			if ($msj_process->cod_error == '1') {
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 895, $usuario, 894, 896, "ERROR PROCESAMIENTO PREMIOS OTRAS PROV");
				$mensaje = "Error en el Procesamiento de Premios";
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - RR - $mensaje");
				return Response::json(['exito' => 0, 'mensaje' => $mensaje]);
			} else {
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 894, $usuario, 893, 896, "PROCESAMIENTO OK PREMIOS OTRAS PROV");

				\Log::info("RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - LLAMA DESDE CONTROLLER Procesar_pre_pagados_otrprov_out($idProceso, 'OUT')");
				$contenidoRegistro = $this->servicioRecepcionPrePagados->Procesar_pre_pagados_otrprov_out($idProceso, 'OUT');
				\Log::info("RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - VUELVE DE CONTROLLER Procesar_pre_pagados_otrprov_out($idProceso, 'OUT')");
/*				
				foreach ($contenidoRegistro as $reg) {
					$traeRegistros++;
					$contenido = $reg->contenido;
					$nombre_archivo = $reg->nombre_archivo;
					$path_archivo = $reg->ruta;
					$this->PrcExp_GrabarRegistros($nombre_exportacion, $nombre_archivo, $path_archivo, $contenido);
				}
*/
				// Graba registros en archivo destino de la exportación
				$nombre_exportacion = 'RESULTADO_PREMIOS_OTRAS_PROVINCIAS';
				$buffer = [];
				$traeRegistros = 0;
				$contador = 0;
				$bloque = 50;
				$encoding = "UTF-8";
				$primeraVez = true;

				foreach ($contenidoRegistro as $reg) { // se arman bloques de hasta $bloque registros para grabarlos juntos y disminuir acceso a disco
					$traeRegistros++;
					$contador++;
					$buffer[] = $reg->contenido;

					if ($contador % $bloque == 0 || $contador == count($contenidoRegistro)) {
						// Armado del bloque con separador de línea
						$contenidoBloque = implode("\r\n", $buffer) . "\r\n";

						$nombre_archivo = $reg->nombre_archivo;
						$path_archivo   = $reg->ruta;

						$resGrabarRegistros = $this->PrcExp_GrabarRegistros(
							$nombre_exportacion,
							$nombre_archivo,
							$path_archivo,
							$primeraVez,   // por referencia. la primera vez elimina el archivo y directorio destino, si existen, y crea nuevos. A partir del segundo bloque sólo hace append
							$contenidoBloque,
							$encoding      // parámetro de encoding
						);

						$buffer = [];
					}
				}
			}
		} 

		if ($traeRegistros > 0) {
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 896, $usuario, 895, 897, "PROCESAMIENTO OK PREMIOS OTRAS PROV");
			
			$path_archivo = $path_archivo . $ds;
			$nombre_archivo_zip = $path_archivo . $nombreSinExtension . '.zip'; 
			if (isset($nombre_archivo)) {
				 $nombre_archivo_zip = str_replace('.txt', '.zip', $path_archivo . $nombre_archivo);
			}
			\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - Llama a PrcExp_Empaquetar($nombre_archivo_zip, $path_archivo)");
			$resPrcExp_Empaquetar = $this->PrcExp_Empaquetar($nombre_archivo_zip, $path_archivo);

			if (!$resPrcExp_Empaquetar) {
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 897, $usuario, 896, 898, "ERROR AL GENERAR ZIP");
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - MM - Error de empaquetado");
				return Response::json(['exito' => 0, 'mensaje' => "Error de empaquetado al generar ZIP."]);
			}

			$this->servicioRecepcionPrePagados->InsertPrcExpNuevo($nombre_exportacion, $id_ejec_proc, $idProceso, null, $nombre_archivo_zip, null, $sorteo);
			
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 897, $usuario, 896, 897, "GENERO ARCHIVO PREMIOS OTRAS PROV CON ERR");
			$exito = 2;
			$mensaje = "El proceso de premios pagados otras provincias detecto registros con errores.";
		} else {
			$this->servicioRecepcionPrePagados->actualizaSecuencia($idProceso, 'UPD');
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso, $juego, $nombreSinExtension, 898, $usuario, 897, 898, "PROCESAMIENTO OK PREMIOS OTRAS PROV");
			$exito = 1;
			$mensaje = "El proceso de premios pagados otras provincias finalizo correctamente.";
		}

		return Response::json(['exito' => $exito, 'mensaje' => $mensaje]);
	}	
	public function tratamientoArchivoPremPagOtrProvANT(){ //Llamada recibida desde el javascript
		// Variables del Request
		$id_ejec_proc = Input::get('id_ejec_proc');
		
		// Variables de Session
		$usuario= Session::get('usuarioLogueado.idUsuario');
		
		// Variables del proceso
		$idJuego=999;
		$exito = 0;
		$mensaje = '';
		$flag = '';
		
		// Variables para manejo de Archivos
		$ds=DIRECTORY_SEPARATOR;
		$destino=$this->destinoPrePagadosOtrProv;
		$util = new Util();

		\Log::info("RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - carpeta destino: $destino");
		\Log::info('MM - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - inputfile: ',array(Input::file()));
		\Log::info('MM - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - inputall: ',array(Input::all()));

		
		\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - llama a: servicioRecepcionPrePagados->secuenciaEsperada()');
		$nroSecuencia=$this->servicioRecepcionPrePagados->secuenciaEsperada();
		//Obtengo el numero de proceso de Auditoria
		//$idProceso=$this->servicioCuentaCorriente->getNumeroProcesoAuditoriaCtaCte($idJuego, $nroSecuencia); // RR segun caso de uso
		$idProceso = $this->servicioRecepcionPrePagados->getNumeroProcesoAuditoria(); // RR	
		\Log::info("RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - idProceso: $idProceso");
		if(!is_dir($destino) && !file_exists($destino)){
			File::makeDirectory($destino, 0777, true);
		}
		\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - PASE creacion del directorio destino');
		$archivosSubidos = Input::file();
		
		foreach($archivosSubidos as $archivo){
			$filename = $archivo->getClientOriginalName();
			$arregloNombre=explode(".",$filename);	
			$nombreSinExtension =$arregloNombre[0]; 
			$nombreSinExtension = substr($nombreSinExtension,2,8);
			\Log::info('MM - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - nombreSinExtension: ',array($nombreSinExtension));
			$archivos=$this->servicioRecepcionPrePagados->especif_arch_x_juego_otrprov();
			
			try{
				$archivos=$archivos[999];
			}catch(\Exception $e){
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $nombreSinExtension,890,$usuario,890,891,"Formato erróneo: ".$filename);
				$exito=0;
				$mensaje=sprintf($this->error_carga_pre_pagados," Problemas de configuración de archivo contactese con el administrador.");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));  
			}
			
			$archivos=$util->groupArray($archivos,'tipo_archivo');
			$archivosHijosOP =array();
			$archivosPadresOP =array();
			$this->listasArchivos($archivos, $listaOP, $archivosHijosOP, $archivosPadresOP, "OP",9);
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - destino2: ',array($destino));
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - separador: ',array($ds));
			$destinoPrePagadosOtrProv =$destino.$ds;
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - destinoPrePagadosOtrProv2: ',array($destinoPrePagadosOtrProv));

			
			if(!is_dir($destinoPrePagadosOtrProv) && !file_exists($destinoPrePagadosOtrProv)){
				\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - if: ',array($destinoPrePagadosOtrProv));
				File::makeDirectory($destinoPrePagadosOtrProv, $mode = 0777, true, true);								
			}else{							
				\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - else: ',array($destinoPrePagadosOtrProv));
				//array_map('unlink', glob($destinoPrePagadosOtrProv."*"));
				array_map('unlink', glob($destinoPrePagadosOtrProv."/*.*")); //RR
			}

			$archivoOP = $archivo; //Input::file($nombreSinExtension);
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - controlZip: ',array($archivoOP));
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - controlZip: ',array($destinoPrePagadosOtrProv));
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - controlZip: ',array($listaOP));
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - controlZip: ',array($idJuego));
			$resultado=$util->controlZip($archivoOP, $destinoPrePagadosOtrProv, $listaOP, $idJuego,'',9);
			$proc_ok=1;
			if($resultado['exito']){
				//buscar los archivos en la carpeta y pasarlos a la tabla
				$ficheros = scandir($destinoPrePagadosOtrProv);
				$ficheros1 = array();
				\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - control zip OK!! - ficheros1: ',array($ficheros1));
				foreach ($ficheros as $fichero){
					//if((strpos($fichero,"ZIP") || strpos($fichero,"zip")) < 1 && $fichero!= "." && $fichero!= ".."){
					if((strpos($fichero,"ZIP") || strpos($fichero,"zip")) < 1 && $fichero!= "." && $fichero!= ".." && strpos($fichero,".") != false){ // RR
						array_push($ficheros1, $fichero);
					}
					\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - fichero: ',array($fichero));
					\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - strpos: ',array(strpos($fichero,".")));
				}							
				
				if(count($ficheros1) > $archivosPadresOP[0]['cant_arch_esperados']){								
					\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - estoy en el if: HAY MAS ARCHIVOS EN EL ZIP QUE LOS ESPERADOS');
					$mensaje=sprintf($this->err_mas_archivos,"premios pagados otras provincias");								
					\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
					return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
				}else if(count($ficheros1) < $archivosPadresOP[0]['cant_arch_esperados']){
					\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - estoy en el else: HAY MENOS ARCHIVOS EN EL ZIP QUE LOS ESPERADOS');
					$mensaje=sprintf($this->err_menos_archivos,"premios pagados otras provincias");								
					\Log::info($mensaje);
					return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
				}
				
				/***************************************************
					indicando la recepcion y validaciones
				*****************************************************/
				$archivoDatos=explode(".",$ficheros1[1]);
				\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - archivoDatos: ',array($archivoDatos));
				\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - sorteo: ',array(substr($archivoDatos[0],2,12)));
				$sorteo = substr($archivoDatos[0],2,12);
				$juego = 999;
				\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - ficheros1: ',array($ficheros1));
				foreach ($ficheros1 as $nombreFichero) {
					\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - nombreFichero: ',array($nombreFichero));
					$dest=$destinoPrePagadosOtrProv.$nombreFichero;
					\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - dest: ',array($dest));
					$arch=explode(".",$nombreFichero);	
					$Extension = strtoupper(substr($arch[1],0,3)); 
					\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - Extension: ',array($Extension));
					
					// inserto auditoria de inicio
					$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,890,$usuario,890,891,"Inicio vuelco archivo: ".$nombreFichero." idproceso: ".$idProceso);
					switch ($Extension) {
						
					case "CTR":												
						\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - CTR - destinoPrePagadosOtrProv.ficheros1[0]: ',array($destinoPrePagadosOtrProv.$ficheros1[0]));											
						\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - CTR - destinoPrePagadosOtrProv.ficheros1[1]: ',array($destinoPrePagadosOtrProv.$ficheros1[1]));
						$ok = $this->servicioRecepcionPrePagados->cargarPremiosPagadosOtrasProvinciasControl($idProceso,$dest,$destinoPrePagadosOtrProv.$ficheros1[0]); // enviamos ambos archivos para md5 calculado
						break;
					case "CNA":
						\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - CNA - destinoPrePagadosOtrProv.ficheros1[0]: ',array($destinoPrePagadosOtrProv.$ficheros1[0]));
						$ok = $this->servicioRecepcionPrePagados->cargarPremiosPagadosOtrasProvincias($idProceso,$dest);
						break;
					case "TXT":
						\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - TXT - destinoPrePagadosOtrProv.ficheros1[0]: ',array($destinoPrePagadosOtrProv.$ficheros1[0]));
						$ok = $this->servicioRecepcionPrePagados->cargarPremiosPagadosOtrasProvincias($idProceso,$dest);
						break;
					default:	
						$proc_ok = 0;
						$exito = 0;
						$mensaje=sprintf($this->err_nomb_archivos," - premios pagados otras provincias."); // cod 002 y cod 003
						\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
						break;
					}
				}
				\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - ficheros1: ',array($ficheros1));
			}else{//ERROR DESCOMPRIMIR						
				// $this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,890,$usuario,890,891,"Fallo descompresión archivos vuelco - idproceso: ".$idProceso);
				$mensaje=sprintf($this->err_paquete); // cod 001
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
				$exito = 0;
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}

			// fin descompresion correcto
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,890,$usuario,890,891,"Fin descompresion archivo  - idproceso: ".$idProceso); //RR Traido de CuentaCorrienteController
			
			$msj_sec = $this->servicioRecepcionPrePagados->validarSecuencia($idProceso,$sorteo,$usuario,'SEC');
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - msj_sec',array($msj_sec));
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - msj_sec->cod_error', array($msj_sec->cod_error));
			if($msj_sec->cod_error == '555'){
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-000 Problema en la ejecución de validacion de secuencia.");
				$mensaje = $msj_sec->mensaje;
				$exito = 0;
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}else{
				
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,892,$usuario,890,891,"FIN OK validación de secuencia de PREMIOS OTRAS PROV");
				\Log::info('RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - Finalizo correctamente la validación de secuencia');
			}
			
			/****************************************************/
			/*			VALIDACIONES ENVIOS	- 	ENV	(control)	*/
			/****************************************************/
			$datos=$idProceso.'----'.$sorteo.'----'.$usuario;
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - datos para validarEnviosOtrProv:',array($datos));
			
			$msj_env = $this->servicioRecepcionPrePagados->validarEnviosOtrProv($idProceso,$sorteo,$usuario,'ENV');
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - msj_env',array($msj_env));

			if($msj_env->cod_error == '002'){
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-003 vuelco de archivos a tablas rec ".$filename);
				$mensaje = $msj_env->mensaje;
				$exito = 0;
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}
			
			if($msj_env->cod_error == '003'){
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-003 vuelco de archivos a tablas rec ".$filename);
				// $mensaje = "COD-003 No se recibió el archivo de control.";
				$mensaje = $msj_env->mensaje;
				$exito = 0;
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}
			
			if($msj_env->cod_error == '004'){		
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-004 vuelco de archivos a tablas rec ".$filename);
				$mensaje = "COD-004 La firma md5 del archivo de datos no coincide con la enviada.";
				$exito = 0;
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}
			
			if($msj_env->cod_error == '005'){		
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-005 vuelco de archivos a tablas rec ".$filename);
				$mensaje = "COD-005 No coincide la cantidad de registros recibida con la indicada en el archivo de control.";
				$exito = 0;
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}

			if($msj_env->cod_error == '006'){		
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-006 vuelco de archivos a tablas rec ".$filename);
				$mensaje = "COD-006 No coincide el importe total recibido con la indicada en el archivo de control.";
				$exito = 0;
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}
			
			if($msj_env->cod_error == '007'){		
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-007 vuelco de archivos a tablas rec ".$filename);
				$mensaje = "COD-007 Existen registros que no corresponden a la provincia indicada en el archivo de control.";
				$exito = 0;
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}

			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,892,$usuario,891,893,"Fin validacion control");

			/*****************************************************/
			/*			VALIDACIONES ENVIOS	- REG	(registros)	**/
			/*****************************************************/

			$msj_reg = $this->servicioRecepcionPrePagados->validarEnviosOtrProv($idProceso,$sorteo,$usuario,'REG');
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - msj_reg->cod_error', array($msj_reg->cod_error));
			if($msj_reg->cod_error != '0'){
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,891,$usuario,890,892,"Error COD-666 Problema en la ejecución de validacion por registros.");
				$mensaje = "COD-666 Problema en la ejecución de validacion por registros.";
				$exito = 0;
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}else{
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,892,$usuario,890,891,"FIN OK validación por registros de PREMIOS OTRAS PROV");
				\Log::info('RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - Finalizo correctamente la validación de registros');
			}
			
			/*	procesa los registros y setea codigo de error o bien 0 si el registro cumple con todas las validaciones */					
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,893,$usuario,891,892,"INICIO PROCESAMIENTO PREMIOS OTRAS PROV");
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - LLAMA DESDE CONTROLLER Procesar_pre_pagados_otrprov');
			$msj_process = $this->servicioRecepcionPrePagados->Procesar_pre_pagados_otrprov($idProceso,'IN');					
			if ($msj_process->cod_error == '1'){
				\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - ENTRO AL IF Procesar_pre_pagados_otrprov');			
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,895,$usuario,894,896,"ERROR PROCESAMIENTO PREMIOS OTRAS PROV");
				$mensaje = "Error en el Procesamiento de Premios";	 
				$exito = 0;
				\Log::info("RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - $mensaje");
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));	
			}else{
				\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - ESTOY EN EL ELSE Procesar_pre_pagados_otrprov');			
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,894,$usuario,893,896,"PROCESAMIENTO OK PREMIOS OTRAS PROV");
				\Log::info('RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - Finalizo correctamente el procesamiento de registros');
				
				$nombre_exportacion = 'RESULTADO_PREMIOS_OTRAS_PROVINCIAS';
				
				\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - LLAMA DESDE CONTROLLER Procesar_pre_pagados_otrprov_out');
				$contenidoRegistro = $this->servicioRecepcionPrePagados->Procesar_pre_pagados_otrprov_out($idProceso,'OUT'); 
				\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - VUELVE del Procesar_pre_pagados_otrprov_out - contenidoRegistro',array($contenidoRegistro)); 

				// Graba registros en archivo destino de la exportación
				$buffer = [];
				return false;
				$traeRegistros = 0;
				$contador = 0;
				$bloque = 50;
				$enconding = "UTF-8";
				$primeraVez = true;

				foreach ($contenidoRegistro as $reg) { // se arman bloques de hasta $bloque registros para grabarlos juntos y disminuir acceso a disco
					$traeRegistros++;
					$contador++;
					$buffer[] = $reg->contenido;

					if ($contador % $bloque == 0 || $contador == count($contenidoRegistro)) {
						// Armado del bloque con separador de línea
						$contenidoBloque = implode("\r\n", $buffer) . "\r\n";

						$nombre_archivo = $reg->nombre_archivo;
						$path_archivo   = $reg->ruta;

						$resGrabarRegistros = $this->PrcExp_GrabarRegistros(
							$nombre_exportacion,
							$nombre_archivo,
							$path_archivo,
							$primeraVez,   // por referencia. la primera vez elimina el archivo y directorio destino, si existen, y crea nuevos. A partir del segundo bloque sólo hace append
							$contenidoBloque,
							$encoding      // parámetro de encoding
						);

						$buffer = [];
					}
				}
			}
		}

		if($traeRegistros>0){
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,896,$usuario,895,897,"PROCESAMIENTO OK PREMIOS OTRAS PROV");
			$path_archivo= $path_archivo.$ds;
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - IF traeRegistros>0 - path_archivo',array($path_archivo)); 
			$nombre_archivo = $path_archivo.$nombre_archivo; 
			$nombre_archivo = str_replace('.TXT', '.ZIP', $nombre_archivo);
			\Log::info('MM - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - nombre_archivo',array($nombre_archivo)); 
			\Log::info('MM - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - path_archivo',array($path_archivo)); 
			// empaquetar en zip
			$resPrcExp_Empaquetar=$this->PrcExp_Empaquetar($nombre_archivo, $path_archivo);
			\Log::info('MM - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - resPrcExp_Empaquetar',array($resPrcExp_Empaquetar)); 
			if (!$resPrcExp_Empaquetar){
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,897,$usuario,896,898,"ERROR AL GENERAR ZIP");
				// $resultadoUpdateEstFinEr=$this->servicioExportaciones->UpdatePrcExpEstadoFin($nombre_exportacion,$id_exp_tipo,$envio,'',"Finalizado er");
				$exito = 0;
				$mensaje="Error de empaquetado al generar ZIP.";
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}else{
				
				// inserto registro para tabla de descargas del zip// realiza insert estado NUEVO
				$resultadoInstNue=$this->servicioRecepcionPrePagados->InsertPrcExpNuevo($nombre_exportacion,$id_ejec_proc,$idProceso,null,$nombre_archivo,null,$sorteo);
			}
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,897,$usuario,896,897,"GENERO ARCHIVO PREMIOS OTRAS PROV CON ERR");
			// $exito = 1;
			$exito = 2; //RR
			$mensaje="El proceso de premios pagados otras provincias detecto registros con errores.";
		}else{				
			$msj_upd_sec = $this->servicioRecepcionPrePagados->actualizaSecuencia($idProceso,'UPD');
			\Log::info('RR - RecepcionPremPagOtrProvController.tratamientoArchivoPremPagOtrProv - msj_upd_sec->cod_error',array($msj_upd_sec->cod_error));
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $nombreSinExtension,898,$usuario,897,898,"PROCESAMIENTO OK PREMIOS OTRAS PROV");
			$exito = 1;
			$mensaje="El proceso de premios pagados otras provincias finalizo correctamente.";
		}
		return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
	}

	/********************************************************
	* tratamiento Grabar Registros
	*********************************************************/
	public function PrcExp_GrabarRegistros($nombre_exportacion, $nombre_archivo, $path_archivo, &$primeraVez, $contenido, $encoding = 'UTF-8'){
		$fullPath = $path_archivo . DIRECTORY_SEPARATOR . $nombre_archivo;

		// Primera vez: borrar archivo si existe
		if ($primeraVez) {
			if (File::exists($path_archivo)) {
				File::delete($path_archivo);
			}
			$primeraVez = false;
		}

		// Crear directorio si no existe
		if (!File::isDirectory($path_archivo)) {
			File::makeDirectory($path_archivo, 0755, true);
		}

		// Convertir al encoding indicado
		$contenidoEncoded = mb_convert_encoding($contenido, $encoding, 'auto');

		// Grabar exactamente lo que recibe
		File::append($fullPath, $contenidoEncoded);

		return true;
	}

	
	
	public function PrcExp_Empaquetar($nombre_paquete,$paq_path){
		\Log::info('PrcExp_Empaquetar - nombre_paquete',array($nombre_paquete));
		\Log::info('PrcExp_Empaquetar - paq_path',array($paq_path));
		try{
			$ds=DIRECTORY_SEPARATOR;
			// generar zip
			//$zipper = $zip->open('test.zip', ZipArchive::CREATE);
			$zip = new ZipArchive;
			$res = $zip->open($nombre_paquete, ZipArchive::CREATE);
			if ($res === TRUE) {
				//buscar los archivos en la carpeta y pasarlos a la tabla
				$ficheros = scandir($paq_path);

				foreach ($ficheros as $fichero){
					if($fichero!= "." && $fichero!= ".."){
						\Log::info('RR - PrcExp_Empaquetar - fichero',array($fichero));
						$zip->addFile($paq_path.$ds.$fichero,$fichero);
					}
				}
				
				$zip->close();
				return true;
			} 
		}catch(\Exception $e){
			\Log::info("Error PrcExp_Empaquetar");
			\Log::info($e);
			return false;
		}
	}
	
	/***********************************************************
	* carga div con paquetes ya procesados  *
	************************************************************/
	public function paquetesPremiosOtrasProv(){
		\Log::info('Estoy en el metodo - paquetesPremiosOtrasProv');
		$datos_input_panel = Input::all();
		$nombre_exportacion = 'RESULTADO_PREMIOS_OTRAS_PROVINCIAS';
		\Log::info('paquetesPremiosOtrasProv - datos_input_panel',array($datos_input_panel));
		\Log::info('RR - LLAMA DESDE CONTROLLER - ConsultaPaquetesPremOtrProv');
		try{
			$resConsultaPaquetesExportacion=$this->servicioRecepcionPrePagados->ConsultaPaquetesPremOtrProv($nombre_exportacion);
			\Log::info("RR - fin - Resultado: ", array($resConsultaPaquetesExportacion));
			if(!isset($resConsultaPaquetesExportacion)){
				\Log::info("RR - fin ERR SQL, entro al if not isset - error acceso al servidor");
				$mensaje = "Se ha producido un error de acceso al servidor. Consulte a Soporte.";
				$exito = 0;
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
				//return false;
			}else{
				if($resConsultaPaquetesExportacion != "2"){
					\Log::info("RR - fin CON HISTORIAL, entro al if - Resultado: ", array($resConsultaPaquetesExportacion));
					$exito = 1;
					$mensaje=$resConsultaPaquetesExportacion;
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
				}else{
					\Log::info("RR - fin SIN HISTORIAL, entro al else - Resultado: ", array($resConsultaPaquetesExportacion));
					$exito = 2;
					$mensaje="Aún no se registran paquetes procesados.";
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
				}
			}
		}catch(\Exception $e){
			\Log::info("fin ERR EN METODO, entro al catch - Resultado: ", array($e));
			$exito = 0;
			$mensaje = "Problema al ejecutar la petición. Consulte a Soporte.";
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			//return false;
		}
	}
	
	/*****************************************
	* lista de archivos según la transacción
	******************************************/
	private function listasArchivos($archivos, &$lista, &$hijos, &$padres, $ta, $transac){
		//lista de archivos 
		foreach ($archivos as $archivo) {
			if($archivo['tipo_archivo']==$ta ){
				$lista=$archivo['grupodatos'];
				break;
			}
		}
		if(isset($lista)){
			//busco el arch. padre y los hijos
			foreach ($lista as $archivo) {
				if($archivo['id_padre']=='' && $archivo['transaccion']== $transac){
					array_push($padres,$archivo);								
				}else{
					array_push($hijos,$archivo);
				}
			}			
		}
	}
	
}

?>