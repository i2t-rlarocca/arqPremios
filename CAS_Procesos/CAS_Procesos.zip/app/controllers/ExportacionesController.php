<?php
	
use \Helpers\Macros;
use \Dominio\Servicios\Exportaciones; 
use \Dominio\Servicios\CuentasCorrientes; 
use controllers\UsuarioController; 
use \Helpers\Util;

class ExportacionesController extends BaseController {
	//MENSAJES ERROR VARIOS 
	  public $error_carga_sorteos_diarios = "Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al juego/sorteo seleccionado."; 
	  public $error_carga_comisiones ="Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al período indicado.";
	  public $err_nro_sorteo_archivo = "El archivo de %s no corresponde al sorteo elegido.";
	  public $err_falta_archivo = "Falta archivo de %s";
	  public $err_datos_sorteo = "Problema al obtener los datos del sorteo: %s";
   	  public $err_mas_archivos = "Hay más archivos de los esperados para %s.";
	  public $err_menos_archivos = "Hay menos archivos de los esperados para %s.";
	  public $err_proces="Problema al procesar %s.";
	  public $err_cant_archivos = "Existe problema de integridad de archivos esperados para %s.";
	  public $err_nomb_archivos ="No se espera el archivo con el nombre %s.";
	  public $ds=DIRECTORY_SEPARATOR;

	function __construct() {
		$ds=DIRECTORY_SEPARATOR;

		$this->servicioCuentaCorriente = new CuentasCorrientes();
		$this->controladorUsuario = new UsuarioController();
		$this->servicioExportaciones = new Exportaciones();
		$this->destinoTemporal = Config::get('ctacte_config/config.urlDestino');
		$this->destinoManuales= Config::get('ctacte_config/config.urlManuales');
		$this->destino= Config::get('ctacte_config/config.urlEnvioEXP');
		$this->destinoBingo= Config::get('ctacte_config/config.urlEnvioBing');
		$this->destinoInst= Config::get('ctacte_config/config.urlEnvioInst');
		$this->destinoTlk= Config::get('ctacte_config/config.urlEnvioTlk');
		
		$this->srcImgError=Config::get("ctacte_config/config.urlImgError");
		$this->srcImgPeligro=Config::get("ctacte_config/config.urlImgPeligro");
		$this->srcImgOk=Config::get("ctacte_config/config.urlImgOk");
		
		
	}
	/********************************* MM - Exportaciones - inicio *****************************************/
	
	/***********************************
	* Armado del panel de Exportaciones
	************************************/
	public function camposPanelExportaciones($tipo_proceso){
		$valores=array();
		$campos=array();
		
		// traer para manuales campos
		$datos['label']=array();
		$datos['valor']=array();
		// trae registros de paquete
		$resultado=$this->servicioExportaciones->consultaTipoExportacion($tipo_proceso);
	//	\Log::info('adentro de camposPanelExportaciones');
	//	\Log::info('resultado',array($resultado));
		// traer el campo con el SP/SQL para ejecutar
		if($resultado[0]->cmps_tipo_sql = 'SP'){
			$resultadoSP=$this->servicioExportaciones->EjecutaSP($resultado[0]->cmps_sql);
		}elseif($resultado[0]->cmps_tipo_sql = 'SQL'){
			$resultadoSP=$this->servicioExportaciones->EjecutaSQL($resultado[0]->cmps_sql);
		}else{
			$resultadoSP=array();
		}

		\Log::info('camposPanelExportaciones - resultado[0]->paq_path',array($resultado[0]->paq_path));
		if($tipo_proceso != 'LIQUIDADOS_BOLDT_BING' || $tipo_proceso != 'LIQUIDADOS_BOLDT_INST'){
			if($resultado[0]->paq_tipo == 'ZIP'){
				if(!is_dir($resultado[0]->paq_path) && !file_exists($resultado[0]->paq_path)){				
				  File::makeDirectory($resultado[0]->paq_path, 0777, true);
				}
			}
		}
		\Log::info('fin mkdir');
		// traer configuracion de archivos
		$resultadoConfArch=$this->servicioExportaciones->PrcExp_ObtenerLstArchivos($resultadoSP[0]->nombre_exportacion);
		$labels= (explode(";",$resultado[0]->cmps_label));
		\Log::info('obtener archivos');

		// con los datos de el tipo de proceso y los datos de campos del SP los enviamos a la macro para generar los datos de pantalla		
		// datos de configuración para vista
		$dato['nombre_exportacion']=$resultadoSP[0]->nombre_exportacion;
		$label['nombre_exportacion']=$labels[0];
		
		$dato['tipo_paquete']=$resultadoSP[0]->tipo_paquete;
		$label['tipo_paquete']=$labels[1];
		
		$dato['formato_nombre_paq']=$resultadoSP[0]->formato_nombre_paq;
		$label['formato_nombre_paq']=$labels[2];
		
		$dato['ruta_paq']=$resultadoSP[0]->ruta_paq;
		$label['ruta_paq']=$labels[3];
		
		/* datos correo */
		
		$dato['mail_destino_paq']=$resultadoSP[0]->mail_destino_paq;
		$label['mail_destino_paq']=$labels[4];

		\Log::info('Datos ');
		
		$mail_destino_paq = $resultadoSP[0]->mail_destino_paq;
		if(!empty($mail_destino_paq)){ 
			Session::put($tipo_proceso.'mail_destino_paq',$mail_destino_paq);
		}
	
		$dato['mail_remite_paq']=$resultadoSP[0]->mail_remite_paq;
		$label['mail_remite_paq']=$labels[5];
		
		$mail_remite_paq = $resultadoSP[0]->mail_remite_paq;
		if(!empty($mail_remite_paq)){ 
			Session::put($tipo_proceso.'mail_remite_paq',$mail_remite_paq);
		}
		
		$dato['mail_asunto_paq']=$resultadoSP[0]->mail_asunto_paq;
		$label['mail_asunto_paq']=$labels[6];
		
		$mail_asunto_paq = $resultadoSP[0]->mail_asunto_paq;
		if(!empty($mail_asunto_paq)){ 
			Session::put($tipo_proceso.'mail_asunto_paq',$mail_asunto_paq);
		}
		
		$dato['mail_cuerpo_paq']=$resultadoSP[0]->mail_cuerpo_paq;
		$label['mail_cuerpo_paq']=$labels[7];
		
		$mail_cuerpo_paq = $resultadoSP[0]->mail_cuerpo_paq;
		if(!empty($mail_cuerpo_paq)){ 
			Session::put($tipo_proceso.'mail_cuerpo_paq',$mail_cuerpo_paq);
		}
		
		$dato['mail_destino_aviso']=$resultadoSP[0]->mail_destino_aviso;
		$label['mail_destino_aviso']=$labels[8];
		
		$mail_destino_aviso = $resultadoSP[0]->mail_destino_aviso;
		if(!empty($mail_destino_aviso)){ 
			Session::put($tipo_proceso.'mail_destino_aviso',$mail_destino_aviso);
		}
		
		$dato['mail_remite_aviso']=$resultadoSP[0]->mail_remite_aviso;
		$label['mail_remite_aviso']=$labels[9];
		
		$mail_remite_aviso = $resultadoSP[0]->mail_remite_aviso;
		if(!empty($mail_remite_aviso)){ 
			Session::put($tipo_proceso.'mail_remite_aviso',$mail_remite_aviso);
		}
		
		/* datos correo  fin */
		
		$dato['etapa_audit']=$resultadoSP[0]->etapa_audit;
		$label['etapa_audit']=$labels[10];
		
		$dato['cant_archivos']=$resultadoSP[0]->cant_archivos;
		$label['cant_archivos']=$labels[11];
		
		$dato['ult_envio']=$resultadoSP[0]->ult_envio;
		$label['ult_envio']=$labels[12];
		
		array_push($valores,$dato);
		array_push($campos,$label);
		
		// pasar datos de configuracion de archivo
		Session::put($tipo_proceso.'paq_tipo',$resultado[0]->paq_tipo);
		Session::put('titulo',$resultado[0]->titulo);
		Session::put('nombre_exportacion',$resultadoSP[0]->nombre_exportacion);
		Session::put($tipo_proceso.'tipo_comando',$resultado[0]->cmps_tipo_sql);
		Session::put($tipo_proceso.'id_exp_tipo',$resultadoSP[0]->id_relacion_archivos);
		Session::put($tipo_proceso.'paq_fmt_nombre',$resultado[0]->paq_fmt_nombre);

		\Log::info('Datos ');
		foreach($dato as $clave => $valor)
			\Log::info("$clave: $valor");

		$audit_etapa = $resultado[0]->aud_etapa;
		if(!empty($audit_etapa)){ 
			Session::put($tipo_proceso.'aud_etapa',$audit_etapa);
		}
		
		$paq_path = $resultado[0]->paq_path;
		if(!empty($paq_path)){ 
			Session::put($tipo_proceso.'ruta_paq',$paq_path);
		}
		$datosTransaccion= Response::Exportaciones($valores,$campos);
		\Log::info("Transaccion $datosTransaccion");
		return $datosTransaccion;
	}

	/***********************************
	* Llamada al panel de Exportaciones
	************************************/
	public function panelExportacion(){
		$proc_ok = 0;
		$urlFull=$_SERVER["REQUEST_URI"];

		$tipo= (explode("/",$urlFull));

		switch ($tipo[count($tipo)-1]) {
			case "reserva-loteria":
					$campos = $this->camposPanelExportaciones('RESERVA_LOTERIA');
					break;
			case "manuales":
					$campos=$this->camposPanelExportaciones('MANUALES_BOLDT');
				break;
			case "uif":
					$campos=$this->camposPanelExportaciones('ENVIO_UIF');
				break;
			case "afip":
					$campos=$this->camposPanelExportaciones('ENVIO_AFIP');
				break;
			case "conceptos-liquidados-bing":
					$campos=$this->camposPanelExportaciones('LIQUIDADOS_BOLDT_BING');
				break;
			case "conceptos-liquidados-inst":
					$campos=$this->camposPanelExportaciones('LIQUIDADOS_BOLDT_INST');
				break;
			case "otro":
					$campos=$this->camposPanelExportaciones('OTRO_BOLDT');
				break;
			case "panel-exportacion-rangos-cupones-telekino":
					$campos=$this->camposPanelExportaciones('RANGOS_TELEKINO');
				break;
			default:	
			
			\Log::info('MM-panelExportacion-urlFull',array($urlFull));
					$proc_ok = 0;
				break;
		}
		$titulo = Session::get('titulo');
		
		// crear id_proceso char(36) uuid()
		$resultadoGenIdPorc = $this->servicioExportaciones->GeneraIdProc();
		$id_ejec_proc = $resultadoGenIdPorc[0]->id_proceso;
		
		\Log::info('MM-panelExportacion-resultadoGenIdPorc',array($resultadoGenIdPorc));
		\Log::info('MM-panelExportacion-id_ejec_proc',array($id_ejec_proc));

		return View::make('exportacion.panelExportacion', array('campos'=>$campos,'titulo'=>$titulo,'id_ejec_proc'=>$id_ejec_proc));
	}
	
	
	/********************************************************
	* PrcExp_Crear
	*********************************************************/
	
	public function PrcExp_Crear($nombre_proceso,$datos_input){
		
	try{
		// crear id_proceso char(36) uuid()
		//$resultadoGenIdPorc = $this->servicioExportaciones->GeneraIdProc();
		//$id_proceso = $resultadoGenIdPorc[0]->id_proceso;
		$id_ejec_proc = $datos_input['id_ejec_proc'];
		// obtener id_auditoria si existe dato de etapa_auditoria
		$aud_etapa = $datos_input['etapa_audit'];
		$id_exp_tipo = Session::get($nombre_proceso.'id_exp_tipo');
		$mail_destino_paq = $datos_input['mail_destino_paq'];
		
		if (!isset($mail_destino_paq)){
			$mail_destino_paq ='';
		}
		
		if (isset($aud_etapa)){
			// obtener max id auditoria
			$resultadoObtIdAudit=$this->servicioExportaciones->TraeIdAuditoria();
			$id_auditoria = $resultadoObtIdAudit[0]->id_auditoria;
			\Log::info('RR-id_auditoria',array($id_auditoria));
			Session::put($nombre_proceso.'id_auditoria',$id_auditoria);
		}else{
			// OBSERVACIÓN: aqui debería enviar un mensaje al usuario indicando que no ha sido seteado en la configuracion una etapa de auditoria
			
			$id_auditoria='';
			Session::put($nombre_proceso.'id_auditoria',$id_auditoria);
		}
		
		// si es SP llama al procedimiento almacenado
		$tipo_comando = Session::get($nombre_proceso.'tipo_comando');
		\Log::info('MM-tipo_comando: ',array($tipo_comando));
		if(strtoupper($tipo_comando) == 'SP'){
			$resultadoCrea=$this->servicioExportaciones->PrcExp_CrearSP($nombre_proceso);
		}
		if(strtoupper($tipo_comando) == 'SQL'){
			$resultadoCrea=$this->servicioExportaciones->PrcExp_CrearSQL($nombre_proceso);
		}
		
		
		
		$paq_path = $resultadoCrea[0]->paq_path;
		\Log::info('MM-resultadoCrea-paq_path',array($paq_path));
		$envio = $resultadoCrea[0]->envio;
		\Log::info('PrcExp_CrearSP - envio ',array($envio));
			
		if($envio == null){ 
		\Log::info('ENTRAAAARR ',array($envio));
					//	$resultadoDeleteNue=$this->servicioExportaciones->DeletePrcExpNuevo($id_ejecucion_elim);
					//	\Log::info('resultadoDeleteNue',array($resultadoDeleteNue));
						$exito = 0;
						$mensaje="Error no se encuentra envío para generar.";
						// return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
						return false;
		}
		//$nom_nenvio = $nombre_proceso.'_envio';
		
		// envio y paquete a generar
		Session::put($nombre_proceso.'_envio',$envio);
		Session::put($nombre_proceso.'paq_path',$paq_path);
		
		// realiza insert estado NUEVO
		$resultadoInstNue=$this->servicioExportaciones->InsertPrcExpNuevo($nombre_proceso,$id_ejec_proc,$id_auditoria,$id_exp_tipo,$paq_path,$mail_destino_paq,$envio);
		\Log::info('RR-resultadoInstNue',array($resultadoInstNue));
		 
		
		
		return $resultadoInstNue;
		
		
		
		}catch(\Exception $e){
				\Log::info("Error PrcExp_Crear");
				\Log::info($e);
				return false;
		}
	}

	/********************************************************
	* PrcExp_ObtenerLstArchivos
	*********************************************************/
	
	public function PrcExp_ObtenerLstArchivos($nombre_exportacion){
		// listado de archivos
		$resultadoConfArch=$this->servicioExportaciones->PrcExp_ObtenerLstArchivos($nombre_exportacion);
		return $resultadoConfArch;
	}
	
	/********************************************************
	* tratamiento Exportaciones
	*********************************************************/
	public function PrcExp_GrabarRegistros($nombre_exportacion,$nombre_archivo, $ruta_archivo, $contenido){

		// funcion que graba
		$ds=DIRECTORY_SEPARATOR;
		//carpeta principal -> exportacion manuales
		
			//$destino=$this->destinoManuales;
			
			$destino = $ruta_archivo;
	
\Log::info('PrcExp_GrabarRegistros - destino: ',array($destino));
			if(!is_dir($destino) && !file_exists($destino)){
			  File::makeDirectory($destino, 0777, true);
			}

			// crear if para cuando el nombre de archivo cambia, que vaya al 
			$nombre_archivo_ant = Session::get('nombre_archivo_ant');
			
			if($nombre_archivo_ant == '0' || $nombre_archivo_ant != $nombre_archivo){
				//$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, $contenido);//FILE::put( $destino.$ds.$nombre_archivo, $contenido);
				//$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, $contenido."\n");//FILE::put( $destino.$ds.$nombre_archivo, $contenido);
				if($nombre_exportacion == 'ENVIO_UIF')
				{
						$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, $contenido);//FILE::put( $destino.$ds.$nombre_archivo, $contenido);
				}else{
					$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, mb_convert_encoding($contenido, "Windows-1252") . "\r\n" );//FILE::put( $destino.$ds.$nombre_archivo, $contenido);
				}
				//file_put_contents('mc_error.log', print_r($error_detail, true) . "\n\n", FILE_APPEND);
			}
			if($nombre_archivo_ant == $nombre_archivo){
				//$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, "\n".$contenido,FILE_APPEND); //FILE::put( $destino.$ds.$nombre_archivo, $contenido);
					if($nombre_exportacion == 'ENVIO_UIF')
					{
							$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, $contenido. "\r\n",FILE_APPEND);//FILE::put( $destino.$ds.$nombre_archivo, $contenido);
					}else{
						$bytes_written = file_put_contents($destino.$ds.$nombre_archivo, mb_convert_encoding($contenido, "Windows-1252") . "\r\n",FILE_APPEND); //FILE::put( $destino.$ds.$nombre_archivo, $contenido);
					}
				}

				IF ($bytes_written === FALSE)
				{
					//die("Error writing to file");
					//$exito = 0;
					//$mensaje="Error guardando archivo.";
					//return Response::json(array('exito'=>true, 'mensaje'=>$mensaje));
					return false;
				}else{
					$nombre_archivo_ant = $nombre_archivo;
					Session::put('nombre_archivo_ant',$nombre_archivo_ant);
					return true;
				}
	}
	
	
	
	/********************************************************
	* tratamiento Exportaciones
	*********************************************************/
	public function PrcExp_GeneraHuella($huella_tipo, $archivo){
	
			switch ($huella_tipo) {
							case "MD5":
									$huella_calculada = md5_file($archivo);
								break;
							case "otro":
									$huella_calculada='NI';
									//$proc_ok = 1;
								break;
							default:	
									//$exito = 0;
									$huella_calculada='NI';
									//$mensaje=$resultado['mensaje'];
							break;
						}
						return $huella_calculada;
	}
	
	/********************************************************
	* tratamiento Exportaciones
	*********************************************************/
	public function PrcExp_Empaquetar($nombre_paquete,$paq_path){
	\Log::info('PrcExp_Empaquetar - nombre_paquete',array($nombre_paquete));
	\Log::info('PrcExp_Empaquetar - paq_path',array($paq_path));
	try{
		$ds=DIRECTORY_SEPARATOR;
		// generar zip
				//$zipper = $zip->open('test.zip', ZipArchive::CREATE);
				$zip = new ZipArchive;
					$res = $zip->open($nombre_paquete, ZipArchive::CREATE);
					if ($res === TRUE) {
						//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($paq_path);
						
							//$ficheros1 = array();
							foreach ($ficheros as $fichero){
								if($fichero!= "." && $fichero!= ".."){
									$zip->addFile($paq_path.$ds.$fichero,$fichero);
								}
							}
						$zip->close();
						return true;
					} 
					
		}catch(\Exception $e){
				\Log::info("Error PrcExp_Empaquetar");
				\Log::info($e);
				return false;
		}
	}
	
	/********************************************************
	* tratamiento Exportaciones
	*********************************************************/
	public function generaExportacion(){
		
		//$nombre_exportacion = Session::get('nombre_exportacion');
		
		//$id_proceso_eje = 
		$nombre_archivo_sin_path = '';
		\Log::info('WB - generaExportacion');
		try{
					$ds = DIRECTORY_SEPARATOR;
					// LLAMADO A PrcExp_Crear
					$datos_input = Input::all();
					$nombre_exportacion = $datos_input['nombre_exportacion'];
					$id_ejecucion_elim = $datos_input['id_ejec_proc'];
					$id_exp_tipo = Session::get($nombre_exportacion.'id_exp_tipo'); 
					$resPrcExp_Crear = $this->PrcExp_Crear($nombre_exportacion,$datos_input);
					$envio = Session::get($nombre_exportacion.'_envio'); 
					if ($envio == false){
						 // insert de auditoria
						//$resultadoUpdateEstFinEr=$this->servicioExportaciones->UpdatePrcExpEstadoFin($nombre_exportacion,$id_exp_tipo,$envio,'',"Finalizado er");
						$resultadoDeleteNue=$this->servicioExportaciones->DeletePrcExpNuevo($id_ejecucion_elim);

						$exito = 0;
						$mensaje="Error generando nuevo envío comuniquese con el administrador.";
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					 }

					if ($resPrcExp_Crear == false){
						 // insert de auditoria
						$resultadoUpdateEstFinEr=$this->servicioExportaciones->UpdatePrcExpEstadoFin($nombre_exportacion,$id_exp_tipo,$envio,'',"Finalizado er");
						$exito = 0;
						$mensaje="Problemas con el siguiente envío a exportar, comuniquese con el administrador.";
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					 }
					
					if($nombre_exportacion == 'RESERVA_LOTERIA'){
						 $idJuego = 50;
					}else{
						$idJuego = 99;
					}
					\Log::info('RR-nombre_exportacion',array($nombre_exportacion));	
					$id_auditoria = Session::get($nombre_exportacion.'id_auditoria');					
					// la variable ruta puede ser esta o bien Session::get('paq_path');
					$ruta = $datos_input['ruta_paq'];					
					//$usuario = 1 ;
					$usuario = Session::get('usuarioLogueado.idUsuario');
					
					/***************************************************
						Registro proceso de exporta en auditoria
					*****************************************************/
					\Log::info('RR-id_auditoria - 1',array($id_auditoria));	
					$this->servicioCuentaCorriente->insertaAuditoria($id_auditoria,$idJuego, $envio,101,$usuario,101,102,"Inicio exportación - ".$nombre_exportacion);
					\Log::info('RR-Registro proceso de exporta en auditoria - 1');			
					// para envios liquidados a bold rasp y bing la variable 'envio' tiene calculada la version que debe generar
					$successdelete = File::deleteDirectory($ruta.$envio);
					$resPrcExp_ObtenerLstArchivos= $this->PrcExp_ObtenerLstArchivos($nombre_exportacion);
					

						/* recorre archivos*/
						// proceso que obtine los registros y los graba para UIF
						foreach ($resPrcExp_ObtenerLstArchivos as $archivo)
							{
								
								$generaHuella=0;
								if( $nombre_exportacion == 'LIQUIDADOS_BOLDT_INST' || $nombre_exportacion == 'LIQUIDADOS_BOLDT_BING' || $nombre_exportacion == 'RESERVA_LOTERIA' || $nombre_exportacion == 'RANGOS_TELEKINO'){  // || $nombre_exportacion == 'RESERVA_LOTERIA'
									$id_ejecucion = $datos_input['id_ejec_proc'];
								}else{
									$id_ejecucion = $envio;
								}
								$id_archivo = $archivo->id;
								$tipo_comando = $archivo->tipo_comando;
								$listArch=$this->servicioExportaciones->PrcExp_ObtenerLstArchivos2($nombre_exportacion,$envio,$id_archivo);
								\Log::info('RR- foreach - listArch',array($listArch));
								if($archivo->huella != ''){
									$huella = $archivo->huella;
									$generaHuella =1;
								}
								$contenidoRegistro = $this->servicioExportaciones->PrcExp_ObtenerRegistros($nombre_exportacion,$id_ejecucion, $id_archivo,0, $huella); 
								//\Log::info('RR- foreach - contenidoRegistro',array($contenidoRegistro));
								if(count($contenidoRegistro) == 0){
									// borrado de registro en tabla exp_exportacion_ejecucion por id ya que qeda ocupado el id
									$resultadoDeleteNue=$this->servicioExportaciones->DeletePrcExpNuevo($id_ejecucion);
									$exito = 0;
									$mensaje="No existen datos pendientes de envío";
									return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
								}else{
									if (isset($contenidoRegistro[0]->secuencia)) {
										if($contenidoRegistro[0]->secuencia <= 0){
											// borrado de registro en tabla exp_exportacion_ejecucion por id ya que qeda ocupado el id
											$resultadoDeleteNue=$this->servicioExportaciones->DeletePrcExpNuevo($id_ejecucion);
											$exito = 0;
											$mensaje=$contenidoRegistro[0]->msgRet;
											return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
										}
									}
								}
								$nombre_archivo_ant = '0';
								Session::put('nombre_archivo_ant',$nombre_archivo_ant);
								
								// INI - Agregado - 2025-07-23 - ADEN PARA QUE EL "SUB" -> chr(26) lo escriba al final de cada archivo!
								// Inicialización para corte de control y agregado de chr(26)
								$nombre_archivo_actual = '';
								$path_archivo_actual = '';
								// FIN - Agregado - 2025-07-23
								
								// recorremos cada fila y obtenemos los campos a guardar en el xml a generar.
								if ($nombre_exportacion == 'RESERVA_LOTERIA'){
									$path_archivo = $listArch[0]->path_archivo;
									$path_archivo = $path_archivo."/".$id_ejecucion;
									$nombre_archivo = $listArch[0]->nom_archivo;
									if(!is_dir($path_archivo) && !file_exists($path_archivo)){
			  							File::makeDirectory($path_archivo, 0777, true);
									}
									$contenido ="";
									foreach ($contenidoRegistro as $reg){
										//\Log::info('RR- foreach - contenidoRegistro',array($reg->tmp_registro));
										if (trim($reg->tmp_registro) != ''){
											//$contenido = $reg->tmp_registro;
											$contenido .= mb_convert_encoding($reg->tmp_registro, "Windows-1252") . "\r\n" ;
											//$resGrabarRegistros = File::append($path_archivo.$ds.$nombre_archivo, "\n".$contenido);	
											//$resGrabarRegistros=$this->PrcExp_GrabarRegistros($nombre_exportacion,$nombre_archivo,$path_archivo,$contenido);
																												    	
										}
									}
									$bytes_written = file_put_contents($path_archivo.$ds.$nombre_archivo, mb_convert_encoding($contenido, "Windows-1252") );//FILE::put( $destino.$ds.$nombre_archivo, $contenido);
											if ($bytes_written === false){
												$resGrabarRegistros = false;
												$exito = 0;
												$mensaje="Exportacion realizada de forma erronea - Error Grabando registro.";
												return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));		
											}else{
												$resGrabarRegistros = true;
											}
								}else {
									// INI - Agregado - 2025-07-23 - ADEN PARA QUE EL "SUB" -> chr(26) lo escriba al final de cada archivo!
									if (!empty($contenidoRegistro)) {
										// Tomamos el nombre y la ruta del primer registro, ya que debería ser el mismo para todos.
										$nombre_archivo_actual = $contenidoRegistro[0]->nombre_archivo;
										$path_archivo_actual = $contenidoRegistro[0]->ruta;
									}
									// FIN - Agregado - 2025-07-23
									foreach ($contenidoRegistro as $reg){
										$contenido = $reg->contenido;																
										// INI - Agregado - 2025-07-23 - ADEN PARA QUE EL "SUB" -> chr(26) lo escriba al final de cada archivo!
										$nombre_archivo = $reg->nombre_archivo;
										$path_archivo = $reg->ruta;
										if($nombre_archivo_actual != $nombre_archivo || $path_archivo_actual != $path_archivo) {
											if( $nombre_exportacion == 'LIQUIDADOS_BOLDT_INST'){
												$resGrabarRegistros=$this->PrcExp_GrabarRegistros($nombre_exportacion,$nombre_archivo_actual,$path_archivo_actual,chr(26));
												\Log::info('AE - resGrabarRegistros - agrego el <sub> al final del archivo',array($resGrabarRegistros));
											}
											$nombre_archivo_actual = $nombre_archivo;
											$path_archivo_actual = $path_archivo;
										}
										// FIN - Agregado - 2025-07-23
										$resGrabarRegistros=$this->PrcExp_GrabarRegistros($nombre_exportacion,$nombre_archivo_actual,$path_archivo_actual,$contenido);
										\Log::info('RR- foreach - resGrabarRegistros',array($resGrabarRegistros));
									}
									
								// Agregado 2024-06-18 para ARCHIVO DE RASPADITAS, pone un registro al final del archivo con <sub> (chr(26))
								if( $nombre_exportacion == 'LIQUIDADOS_BOLDT_INST'){
									$resGrabarRegistros=$this->PrcExp_GrabarRegistros($nombre_exportacion,$nombre_archivo_actual,$path_archivo_actual,chr(26));
									\Log::info('AE - resGrabarRegistros - agrego el <sub> al final del archivo',array($resGrabarRegistros));
								}

								}
						$opcCtrl = '0';
								
								if($resGrabarRegistros){
										/***************************************************
											Registro proceso de exporta en auditoria
										*****************************************************/
										\Log::info('RR-id_auditoria - 2',array($id_auditoria));	
										$this->servicioCuentaCorriente->insertaAuditoria($id_auditoria,$idJuego, $envio,102,$usuario,101,103,"Genera ficheros exportación - ".$nombre_exportacion);
										\Log::info('RR-Registro proceso de exporta en auditoria - 2');
										// realiza update de estado a iniciado en tabla de exportacion tipo
										$resultadoUpdateEst=$this->servicioExportaciones->UpdatePrcExpEstado($nombre_exportacion,$id_exp_tipo,$envio,"Iniciado");
										
										// genera md5 u otra huella
										if($generaHuella == 1){
											$huella = $archivo->huella;		
											$archivo_huella = $path_archivo.$ds.$nombre_archivo;
											
											// funcion crea huella
											$reshuella=$this->PrcExp_GeneraHuella($huella,$archivo_huella);
										}
										// debe generar archivo de control?
										\Log::info('archivo->formato_nombre_arch_ctrl',array($archivo->formato_nombre_arch_ctrl));
										if(($archivo->formato_nombre_arch_ctrl != "") && ($archivo->formato_nombre_arch_ctrl != "N/I")){
											
											\Log::info('archivo->formato_nombre_arch_ctrl',array($archivo->formato_nombre_arch_ctrl));
											$opcCtrl = '1';
										}
								}else{
										// actualiza estado finlizado con error
										$resultadoUpdateEstFinEr=$this->servicioExportaciones->UpdatePrcExpEstadoFin($nombre_exportacion,$id_exp_tipo,$envio,'',"Finalizado er");
										// actualizar estado a 'P' de tabla dis_conceptos_liquidados para procesarlos y que no queden tomados y sin generar el zip
										if( $nombre_exportacion == 'LIQUIDADOS_BOLDT_INST' || $nombre_exportacion == 'LIQUIDADOS_BOLDT_BING' ){
											$UpdateEstDisConLiq=$this->servicioExportaciones->UpdateEstadoDisConLiq($nombre_exportacion,$id_exp_tipo,$envio,$id_ejecucion);
										}
										$exito = 0;
										$mensaje="Exportación realizada de forma erronea - Grabando registro.";
										return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
								}
								\Log::info('opcCtrl',array($opcCtrl));
							if 	($opcCtrl == '1'){
									// opcion 1 de SP EXP_[NOM_PRC]_GET_REGISTROS -> obtiene registros de archivo de control
									$contenidoRegistroCtrl=$this->servicioExportaciones->PrcExp_ObtenerRegistrosCtrl($nombre_exportacion,$id_ejecucion, $id_archivo,1, $reshuella);
									\Log::info('contenidoRegistroCtrl',array($contenidoRegistroCtrl));
									
									if ($nombre_exportacion == 'RESERVA_LOTERIA'){
										$path_archivo = $listArch[0]->path_archivo;
										$path_archivo = $path_archivo."/".$id_ejecucion;
										$nombre_archivo = $listArch[0]->nom_archivo;
										$nombre_archivo_ctrl = $listArch[0]->nom_archivo_ctrl;
										// MM -- ini comenta 21/12/2017
										
										if(!is_dir($path_archivo) && !file_exists($path_archivo)){
											File::makeDirectory($path_archivo, 0777, true);
										}
										$bytes_written = File::put($path_archivo.$ds.$nombre_archivo_ctrl,$contenidoRegistroCtrl[0]->registro . "\r\n");	
										if ($bytes_written === false){
    											// die("Error writing to file");
    											$exito = 0;
											$mensaje="Exportación realizada de forma erronea - Grabando archivo de control.";
											return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));

										} 

									}else{									
										// llamado a prcExp_GrabaRegistros
										foreach ($contenidoRegistroCtrl as $regCtrl){
											
											$resGrabarRegistrosCtrl=$this->PrcExp_GrabarRegistros($nombre_exportacion,$regCtrl->nombre_archivo_ctrl,$regCtrl->ruta,$regCtrl->contenido);
											//$resGrabarRegistrosCtrl=$this->PrcExp_GrabarRegistros($regCtrl->nombre_archivo,$regCtrl->ruta,$regCtrl->contenido);
										}
										
										if(!$resGrabarRegistrosCtrl){
											if( $nombre_exportacion == 'LIQUIDADOS_BOLDT_INST' || $nombre_exportacion == 'LIQUIDADOS_BOLDT_BING' ){
												$UpdateEstDisConLiq=$this->servicioExportaciones->UpdateEstadoDisConLiq($nombre_exportacion,$id_exp_tipo,$envio,$id_ejecucion);
											}
										
										}
									}	
								}
							}
							
							
					// }
					
					// todos estos datos deberían venir en la configuracion de paquete, pero solo algunos se setean ahí...
					
					$paq_path = Session::get($nombre_exportacion.'paq_path');
					
					$paq_fmt_nombre = Session::get($nombre_exportacion.'paq_fmt_nombre');

					if($nombre_exportacion == 'RESERVA_LOTERIA'){
						// $download_name =  str_replace('SSSSS', $envio, $paq_fmt_nombre);
						$get_paquete = $this->servicioExportaciones->PrcExp_CrearSP($nombre_exportacion);
						$download_name = $get_paquete[0]->paq_nombre;
						$paq_path = $paq_path.$ds.$id_ejecucion;

						$paq_fmt_nombre =  $get_paquete[0]->paq_nombre;
						$nombre_archivo =$paq_path.$ds.$paq_fmt_nombre;
						\Log::info('exp RESERVA_LOTERIA - nombre_archivo ->',array($nombre_archivo));
						// $nombre_archivo = str_replace('SSSSS', $envio, $nombre_archivo);
						$destino=$this->destino;
						// $url_descarga = $destino.$nombre_exportacion.'/'.$download_name;						
						$url_descarga = $destino.$nombre_exportacion.$ds.$id_ejecucion.$ds.$download_name;														
						$nombre_archivo_sin_path = 'BLC'.$envio.'.ZIP';
						\Log::info('exp RESERVA_LOTERIA - nombre_archivo_sin_path ->',array($nombre_archivo_sin_path));
					}
					elseif($nombre_exportacion == 'MANUALES_BOLDT'){
						$nombre_archivo = $paq_path.$ds.'M'.$envio.'.ZIP';
						$nombre_archivo_sin_path = 'M'.$envio.'.ZIP';
						$destino=$this->destinoManuales;
						\Log::info('MM-destino',array($destino));
						$url_descarga= $destino.$ds.$envio.$ds.'M'.$envio.'.ZIP';
						\Log::info('MM-url_descarga',array($url_descarga));

					}elseif($nombre_exportacion == 'LIQUIDADOS_BOLDT_INST' || $nombre_exportacion == 'LIQUIDADOS_BOLDT_BING'){
						// $nombre_archivo = $paq_path.$ds.'M'.$envio.'.ZIP';
						
						
						$paq_path = $paq_path.substr($envio,2,5).$ds;
						$nombre_archivo = $paq_path.$paq_fmt_nombre;
						//\Log::info('paq_path',array($paq_path));
						//\Log::info('paq_fmt_nombre',array($paq_fmt_nombre));
						
						$nombre_archivo = str_replace('AAMMDDS', $envio, $nombre_archivo);

						
						if($nombre_exportacion == 'LIQUIDADOS_BOLDT_INST'){
								$destino=$this->destinoInst;
								$url_descarga= $destino.substr($envio,2,5).$ds.'I'.$envio.'.ZIP';
						}  elseif($nombre_exportacion == 'LIQUIDADOS_BOLDT_BING'){
								$destino=$this->destinoBingo;
								$url_descarga= $destino.substr($envio,2,5).$ds.'B'.$envio.'.ZIP';	
						}
					}elseif($nombre_exportacion == 'RANGOS_TELEKINO'){
						$paq_path = $paq_path.$ds;
						$nombre_archivo = $paq_path.$paq_fmt_nombre;
						
						$envio_ajustado = substr($envio,3,6);
						\Log::info('MM - envio_ajustado final ->',array($envio_ajustado));
						\Log::info('MM - paq_path final ->',array($paq_path));
					
						$nombre_archivo = str_replace('SSSSSS', substr($envio,3,6), $nombre_archivo);
						\Log::info('MM - nombre_archivo22 ->',array($nombre_archivo));
						
						$destino=$this->destinoTlk;
						$url_descarga= $destino.$envio.$ds.$envio.$ds.'RTE'.substr($envio,3,6).'.ZIP';
						\Log::info('url_descarga ->',array($url_descarga));

					}else{
						$paq_path = $paq_path.$envio.$ds;
						$nombre_archivo = $paq_path.$paq_fmt_nombre;
						$nombre_archivo = str_replace('AAAAMM', $envio, $nombre_archivo);
						//\Log::info('nombre_archivo', array($nombre_archivo));
						
						$destino=$this->destino;
						$destino=$destino.$nombre_exportacion.'_'.$envio.$ds;
						//\Log::info('destino', array($destino));
						
						$url_descarga= $destino.str_replace('AAAAMM', $envio, $paq_fmt_nombre);
						//\Log::info('url_descarga', array($url_descarga));
					}
					
	
					// insert auditoría inicio empaquetado
					$paq_tipo = Session::get($nombre_exportacion.'paq_tipo');
					
					if ($paq_tipo == 'ZIP'){
						
						$resPrcExp_Empaquetar=$this->PrcExp_Empaquetar($nombre_archivo, $paq_path);
						
						 if (!$resPrcExp_Empaquetar){
							 // insert de auditoria
							 $resultadoUpdateEstFinEr=$this->servicioExportaciones->UpdatePrcExpEstadoFin($nombre_exportacion,$id_exp_tipo,$envio,'',"Finalizado er");
								$exito = 0;
								$mensaje="Error de empaquetado al generar ZIP.";
								return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
						 }else{
							 /***************************************************
								Registro proceso de exporta en auditoria
							*****************************************************/
							\Log::info('RR-id_auditoria - 3',array($id_auditoria));	
							$this->servicioCuentaCorriente->insertaAuditoria($id_auditoria,$idJuego, $envio,103,$usuario,102,104,"Crea .zip exportación - ".$nombre_exportacion);
							\Log::info('RR-Registro proceso de exporta en auditoria - 3');
						}
					}
					
					// creacion de nuevo id para procesar siguiente
					$nuevoIdProceso = $this->servicioExportaciones->GeneraIdProc();
					$nuevo_id_ejec_proc = $nuevoIdProceso[0]->id_proceso;
					
					\Log::info('nuevo_id_ejec_proc',array($nuevo_id_ejec_proc));
					
					if($nombre_exportacion == 'MANUALES_BOLDT'){
						$UpdateManualesOk=$this->servicioExportaciones->UpdateManualesOk($nombre_exportacion,$envio);
						\Log::info('UpdateManualesOk', array($UpdateManualesOk));
					}
					
					 /* datos correo */
					 //envío de correo de paquete
					 $mail_destino_paq = Session::get($nombre_exportacion.'mail_destino_paq');
					 \Log::info('mail_destino_paq',array($mail_destino_paq));

					 $mail_remite_paq = Session::get($nombre_exportacion.'mail_remite_paq');
					 \Log::info('mail_remite_paq',array($mail_remite_paq));

					 $mail_asunto_paq = Session::get($nombre_exportacion.'mail_asunto_paq');
					 \Log::info('mail_asunto_paq',array($mail_asunto_paq));

					 $mail_cuerpo_paq = Session::get($nombre_exportacion.'mail_cuerpo_paq');
					 \Log::info('mail_cuerpo_paq',array($mail_cuerpo_paq));

					 // envio de correo de paquete
					 if ($mail_destino_paq != '' || $mail_remite_paq != '')
					 {
						\Log::info('if - mail_destino_paq',array($mail_destino_paq));
						$datos_mail_paq['mail_destino_paq']= $mail_destino_paq;
						$datos_mail_paq['mail_remite_paq']= $mail_remite_paq;
						$datos_mail_paq['mail_asunto_paq']= $mail_asunto_paq;
						
						if($nombre_exportacion == 'RANGOS_TELEKINO'){
							$sorteo_enviar = '  '.substr($envio,5,4);
							$mail_cuerpo_paq = str_replace('SSSSSS', $sorteo_enviar, $mail_cuerpo_paq);
							$datos_mail_paq['mail_cuerpo_paq']= $mail_cuerpo_paq;
						}else{
							$datos_mail_paq['mail_cuerpo_paq']= $mail_cuerpo_paq;
						}
						$datos_mail_paq['arch_adjunto']=$nombre_archivo;
						$datos_mail_paq['url_descarga']=$url_descarga;
						$datos_mail_paq['nombre_archivo_sin_path']= $nombre_archivo_sin_path;
						
						// en cas-zip y manuales envio a soporte y boldt por mailchimp
						if (($nombre_exportacion == 'MANUALES_BOLDT') || ($nombre_exportacion == 'RESERVA_LOTERIA')){
							if ($nombre_exportacion == 'RESERVA_LOTERIA'){
								$datos_mail_paq['mail_alias_remite_paq'] = 'Reserva de Billetes de Lotería Tradicional para Boldt';
							}else{
								$datos_mail_paq['mail_alias_remite_paq'] = 'Operaciones manuales Ctas Ctes Agencias para Boldt';
							}
							\Log::info('enviar correo mailchimp - ini - datos_mail_paq',array($datos_mail_paq));
							$resenviar_email_paquete=$this->PrcExp_EnviaPaquete_MailChimp($datos_mail_paq,$nombre_exportacion);
							\Log::info('enviar correo mailchimp - fin - datos_mail_paq',array($datos_mail_paq));
						}else{
							// enviar correo
							\Log::info('enviar correo - datos_mail_paq',array($datos_mail_paq));
							$resenviar_email_paquete=$this->PrcExp_EnviaPaquete($datos_mail_paq);
							\Log::info('enviar correo - fin - datos_mail_paq',array($datos_mail_paq));							
						}
						
						\Log::info('resenviar_email_paquete',array($resenviar_email_paquete));
						if (!$resenviar_email_paquete){
							  // insert de auditoria
							 $resultadoUpdateEstFinEr=$this->servicioExportaciones->UpdatePrcExpEstadoFin($nombre_exportacion,$id_exp_tipo,$envio,$url_descarga,"Finalizado ok");
							// actualiza de todas formas la tabla correspondiente aunque no envio correo	
							if ($nombre_exportacion == 'RESERVA_LOTERIA'){
								$UpdateReservaBilletesLoteria=$this->servicioExportaciones->UpdateReservaBilletesLoteria($nombre_exportacion,$envio);
								\Log::info('UpdateReservaBilletesLoteriaOk - ', array($UpdateReservaBilletesLoteria));
							}
							if($nombre_exportacion == 'ENVIO_UIF'){
								$UpdatePreEnviosUIFOk=$this->servicioExportaciones->UpdatePreEnviosUIFOk($nombre_exportacion,$envio);
								//\Log::info('UpdatePreEnviosUIFOk', array($UpdatePreEnviosUIFOk));
							}
							if($nombre_exportacion == 'ENVIO_AFIP'){
								$UpdatePreEnviosAFIPOk=$this->servicioExportaciones->UpdatePreEnviosAFIPOk($nombre_exportacion,$envio);
								//\Log::info('UpdatePreEnviosAFIPOk', array($UpdatePreEnviosAFIPOk));
							}
							if($nombre_exportacion == 'MANUALES_BOLDT'){
								$UpdateManualesOk=$this->servicioExportaciones->UpdateManualesOk($nombre_exportacion,$envio);
								\Log::info('UpdateManualesOk', array($UpdateManualesOk));
							}
							$UpdateExpExportacionTipoOk=$this->servicioExportaciones->UpdateExpExportacionTipoOk($nombre_exportacion,$envio);
							//\Log::info('UpdateExpExportacionTipoOk', array($UpdateExpExportacionTipoOk));
							// exportacion exitosa pero no se envió mail con paquete
							$exito = 1;
							$mensaje="Exportación exitosa.";
							return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'envio'=>$envio,'nuevo_id_ejec_proc'=>$nuevo_id_ejec_proc));
						 }else{
							 /***************************************************
								Registro proceso de exporta en auditoria
							*****************************************************/
							\Log::info('RR-id_auditoria - 4',array($id_auditoria));	
							$this->servicioCuentaCorriente->insertaAuditoria($id_auditoria,$idJuego, $envio,104,$usuario,103,105,"Envío correo con paquete - ".$nombre_exportacion);
							\Log::info('RR-Registro proceso de exporta en auditoria - 4');
						}
					 }
					 
					//envío de correo de aviso
					 $mail_destino_aviso = Session::get($nombre_exportacion.'mail_destino_aviso');
					 $mail_remite_aviso = Session::get($nombre_exportacion.'mail_remite_aviso');
					 if ($mail_destino_aviso != '' || $mail_remite_aviso != '')
					 {
						if ($nombre_exportacion == 'RESERVA_LOTERIA'){
							$datos_mail_aviso['mail_destino_aviso']= $mail_destino_aviso;
							$datos_mail_aviso['mail_remite_aviso']= $mail_remite_aviso;
							$datos_mail_aviso['mail_archivo_nenvio']= $download_name;							
						} elseif($nombre_exportacion == 'LIQUIDADOS_BOLDT_INST'){
								//$destino=$this->destinoInst;
								$datos_mail_aviso['mail_archivo_nenvio']= 'I'.$envio.'.ZIP';
								
						} elseif($nombre_exportacion == 'LIQUIDADOS_BOLDT_BING'){
								//$destino=$this->destinoBingo;
								$datos_mail_aviso['mail_archivo_nenvio']= 'B'.$envio.'.ZIP';
						}elseif($nombre_exportacion == 'RANGOS_TELEKINO'){
								//$destino=$this->destinoBingo;
								$datos_mail_aviso['mail_archivo_nenvio']= 'RTE'.substr($envio,3,6).'.ZIP';
						}
						else{
							$datos_mail_aviso['mail_destino_aviso']= $mail_destino_aviso;
							$datos_mail_aviso['mail_remite_aviso']= $mail_remite_aviso;
							$datos_mail_aviso['mail_archivo_nenvio']= 'M'.$envio.'.ZIP';
						}
					// envia correo
					$resenviar_email_aviso=$this->PrcExp_EnviaAviso($datos_mail_aviso);
						 if (!$resenviar_email_aviso){
							 // insert de auditoria
							 //$resultadoUpdateEstFinEr=$this->servicioExportaciones->UpdatePrcExpEstadoFin($nombre_exportacion,$id_exp_tipo,$envio,'',"Finalizado er");
							 $resultadoUpdateEstFinEr=$this->servicioExportaciones->UpdatePrcExpEstadoFin($nombre_exportacion,$id_exp_tipo,$envio,$url_descarga,"Finalizado ok");
							 // actualiza de todas formas la tabla correspondiente aunque no envio correo	
								if($nombre_exportacion == 'ENVIO_UIF'){
									$UpdatePreEnviosUIFOk=$this->servicioExportaciones->UpdatePreEnviosUIFOk($nombre_exportacion,$envio);
									\Log::info('UpdatePreEnviosUIFOk', array($UpdatePreEnviosUIFOk));
								}
								if($nombre_exportacion == 'ENVIO_AFIP'){
									$UpdatePreEnviosAFIPOk=$this->servicioExportaciones->UpdatePreEnviosAFIPOk($nombre_exportacion,$envio);
									\Log::info('UpdatePreEnviosAFIPOk', array($UpdatePreEnviosAFIPOk));
								}
								if($nombre_exportacion == 'MANUALES_BOLDT'){
									$UpdateManualesOk=$this->servicioExportaciones->UpdateManualesOk($nombre_exportacion,$envio);
									\Log::info('UpdateManualesOk', array($UpdateManualesOk));
								}
							
							$UpdateExpExportacionTipoOk=$this->servicioExportaciones->UpdateExpExportacionTipoOk($nombre_exportacion,$envio);
								\Log::info('UpdateExpExportacionTipoOk', array($UpdateExpExportacionTipoOk));
								
								
								
								// exportacion exitosa pero no se envio correo de aviso
								$exito = 1;
								$mensaje="Exportación exitosa.";
								return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje,'envio'=>$envio,'nuevo_id_ejec_proc'=>$nuevo_id_ejec_proc));
						 }else{
							 /***************************************************
								Registro proceso de exporta en auditoria
							*****************************************************/
							\Log::info('RR-id_auditoria - 5',array($id_auditoria));	
							$this->servicioCuentaCorriente->insertaAuditoria($id_auditoria,$idJuego, $envio,105,$usuario,104,106,"Envío correo aviso - ".$nombre_exportacion);
							\Log::info('RR-Registro proceso de exporta en auditoria - 5');
						}
					//
					 }
						// realizaer update estado finalizado
					$resultadoUpdateEstFinOk=$this->servicioExportaciones->UpdatePrcExpEstadoFin($nombre_exportacion,$id_exp_tipo,$envio,$url_descarga,"Finalizado ok");
					// actualiza tabla con mes/año a procesar y los deja en estado E (exportado) y fecha de exportacion.
					if ($nombre_exportacion == 'RESERVA_LOTERIA'){
						$UpdateReservaBilletesLoteria=$this->servicioExportaciones->UpdateReservaBilletesLoteria($nombre_exportacion,$envio);
						\Log::info('UpdateReservaBilletesLoteriaOk', array($UpdateReservaBilletesLoteria));
					}
					if($nombre_exportacion == 'ENVIO_UIF'){
						$UpdatePreEnviosUIFOk=$this->servicioExportaciones->UpdatePreEnviosUIFOk($nombre_exportacion,$envio);
						\Log::info('UpdatePreEnviosUIFOk', array($UpdatePreEnviosUIFOk));
					}
					if($nombre_exportacion == 'ENVIO_AFIP'){
						$UpdatePreEnviosAFIPOk=$this->servicioExportaciones->UpdatePreEnviosAFIPOk($nombre_exportacion,$envio);
						\Log::info('UpdatePreEnviosAFIPOk', array($UpdatePreEnviosAFIPOk));
					}
					/* Se llevó a antes de enviar el mail porque si fallaba el mail los registros no quedaban con la marca de "generado"
					if($nombre_exportacion == 'MANUALES_BOLDT'){
						$UpdateManualesOk=$this->servicioExportaciones->UpdateManualesOk($nombre_exportacion,$envio);
						\Log::info('UpdateManualesOk', array($UpdateManualesOk));
					}
					*/
					$UpdateExpExportacionTipoOk=$this->servicioExportaciones->UpdateExpExportacionTipoOk($nombre_exportacion,$envio);
					\Log::info('UpdateExpExportacionTipoOk', array($UpdateExpExportacionTipoOk));
					
					 if (!$resultadoUpdateEstFinOk){
							  // insert de auditoria
							  \Log::info('WB - fallo exportacion');
							 $resultadoUpdateEstFinEr=$this->servicioExportaciones->UpdatePrcExpEstadoFin($nombre_exportacion,$id_exp_tipo,$envio,'',"Finalizado er");
								$exito = 0;
								$mensaje="Exportación realizada de forma erronea - Actualizando estados.";
								return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
						 }else{
							 /***************************************************
								Registro proceso de exporta en auditoria
							*****************************************************/
							\Log::info('RR-id_auditoria - 6',array($id_auditoria));	
							$this->servicioCuentaCorriente->insertaAuditoria($id_auditoria,$idJuego, $envio,106,$usuario,105,106,"Fin ok - ".$nombre_exportacion);
							\Log::info('RR-Registro proceso de exporta en auditoria - 6');
						}
					
					
					
					//$nuevoIdProceso = $this->servicioExportaciones->GeneraIdProc();
					//$nuevo_id_ejec_proc = $nuevoIdProceso[0]->id_proceso;
					//$nuevoIdProceso=$this->servicioCuentaCorriente->getNumeroProcesoAuditoriaCtaCte($idJuego, $nroSecuencia);
					//\Log::info('nuevo_id_ejec_proc',array($nuevo_id_ejec_proc));
					/***************************************************
						Registro proceso de recepcion en auditoria
					*****************************************************/
						\Log::info('WB - generaExportacion -FIN');
						\Log::info('RR -  generaExportacion - envio', array($envio));
						\Log::info('RR -  generaExportacion - nuevo_id_ejec_proc', array($nuevo_id_ejec_proc ));						
						$exito = 1;
						$mensaje="Exportación realizada de forma correcta.";
						return Response::json(array('exito'=>true, 'mensaje'=>$mensaje,'envio'=>$envio,'nuevo_id_ejec_proc'=>$nuevo_id_ejec_proc));
			
		}catch(\Exception $e){
				\Log::info("Error generaExportacion");
				\Log::info($e);
				
		}
	}
		
		
		/***************************************************
			* Envío email envía paquete
		*****************************************************/
		public function PrcExp_EnviaPaquete($datos_mail){
			try{
					\Log::info('En el metodo - PrcExp_EnviaPaquete',array($datos_mail));
					$mail_remite_paq = $datos_mail['mail_remite_paq'];
					$mail_destino_paq = $datos_mail['mail_destino_paq'];
						$mails= (explode(";",$mail_destino_paq));
					$adjunto = $datos_mail['arch_adjunto'];
					$url_descarga = $datos_mail['url_descarga'];
					//\Log::info('adjunto',array($adjunto));
					//\Log::info('url_descarga',array($url_descarga));
					$asunto = $datos_mail['mail_asunto_paq'];
					
					$cuerpo = $datos_mail['mail_cuerpo_paq'];
					
					
					$nombreUsuarioLogueado=Session::get('usuarioLogueado.apellido');
					//$destinatarios = array(
					//	  $mail_destino_paq//, $usuarioCas
					//	);
					$destinatarios = array();
					$destinatarios = $mails;
					/*
					foreach ($mails as $mail)
						{
							array_push($destinatarios,$mail);	
						}
					*/	
					$correos = array(
						'destinatarios'=>$destinatarios,
						'remitente'=>$mail_remite_paq,
						'asunto'=>$asunto,
						'adjunto'=>$adjunto
					);
					\Log::info('correos_paquete',array($correos));
					$data = array(
						'usuarioGenerador'=>$nombreUsuarioLogueado,
						'cuerpo'=>$cuerpo,
						'adjunto'=>$url_descarga
					);
					//\Log::info('data_paquete',array($data));
					Mail::send('emails.email_paquete', $data, function ($message) use ($correos){
						//$message->from($correos['remitente'], 'Generación Paquete');
						$message->from($correos['remitente'], $correos['asunto']);
					    $message->subject($correos['asunto']);
						$message->attach($correos['adjunto']);
					    foreach ($correos['destinatarios'] as $email) {
							\Log::info('email_paq',array($email));
							if(isset($email))
								$message->to($email);
						}
					});
					
					if(count(Mail::failures()) > 0){
						\Log::error('Problema al enviar el correo con paquete adjunto. '.$e);
						return false;
					}else{
						return true;
					}
					
				}catch(Exception $e){
					\Log::error('Problema al enviar el correo con paquete adjunto. '.$e);
					return false;
				}
		}

		/***************************************************
			* Envío email envía paquete por mailchimp
		*****************************************************/
		public function PrcExp_EnviaPaquete_MailChimp($datos_mail,$nombre_exportacion){

			//$url_mailchimp_transactional = 'http://devcas2.i2tsa.com.ar/MailchimpTransactional/envia_mail_cmd.php'; // desarrollo
			$url_mailchimp_transactional = 'https://historicos.loteriasantafe.gov.ar/MailchimpTransactional/envia_mail_cmd.php'; //produccion

			$from_email= 'noreply@loteriasantafe.gov.ar';
			$from_name = $datos_mail['mail_alias_remite_paq'];
			//$from_email= $datos_mail['mail_remite_paq'];
			// to:  soporte@i2t.com.ar cdc_santafe@boldt.com.ar
			//$correo_soporte = "soporte@i2t.com.ar; BG_SF_Operaciones@boldt.com.ar";
		
			if ($nombre_exportacion == 'RESERVA_LOTERIA'){
				//$correo_soporte = "BG_SF_Operaciones@boldt.com.ar";
				$correo_soporte = "cristian.valle@i2t.com.ar;ruben.larocca@i2t.com.ar";
			}else{
				//$correo_soporte = "BG_SF_Operaciones@boldt.com.ar";
				$correo_soporte = "cristian.valle@i2t.com.ar;ruben.larocca@i2t.com.ar";
			}			
			
			$asuntomail = "sbx - ".$datos_mail['mail_asunto_paq'];
			$body = $datos_mail['mail_cuerpo_paq'];
			
			//$url_descarga = $datos_mail['url_descarga'];
			//$attach = $datos_mail['arch_adjunto']; // $url_descarga: usar esta como alternativa si falla el attach

			// Encode the image string data into base64
			$data = base64_encode(file_get_contents($datos_mail['arch_adjunto']));

			$attach = $data;
			$tipo_archivo = 'application/zip';
			$nombre_archivo = $datos_mail['nombre_archivo_sin_path'];
			
			\Log::info('Envío de Paquete A BOLDT por mailchimp: datos: from_email ->'.$from_email.'<- correo_soporte ->'.$correo_soporte.'<- asuntomail ->'.$asuntomail.'<- body ->'.$body.'<- attach ->'.$attach.'<-');			
			
			try {

				$curl = curl_init();
				// Check if initialization had gone wrong*    
				if ($curl === false) {
					throw new Exception('Envío de Paquete A BOLDT por mailchimp: No se pudo enviar el e-mail.');
					\Log::info("Envío de Paquete A BOLDT por mailchimp: No se pudo enviar el e-mail. Fallo inicializacion CURL - envio mail a soporte. Destinatarios: ".$correo_soporte);
				}

				$fields = array(
				'from_email'     => $from_email,
				'from_name'      => $from_name,
				'to_email'       => $correo_soporte,
				'subject'        => $asuntomail,
				'cuerpo'         => $body,
				'attach'         => $attach,
				'tipo_archivo'   => $tipo_archivo,
				'nombre_archivo' => $nombre_archivo
				);

				$fields_string = http_build_query($fields);
				curl_setopt($curl, CURLOPT_URL, $url_mailchimp_transactional);
				curl_setopt($curl, CURLOPT_POST, TRUE);
				curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
				curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

				$result = curl_exec($curl);

				// Check the return value of curl_exec(), too
				if ($result === false) {
					\Log::info("Envío de Paquete A BOLDT por mailchimp: Fallo en el envío del mail. Datos de envío ->".$fields_string."<- Resultado: ", array($result));
					throw new Exception(curl_error($curl), curl_errno($curl));
				}

				// Check HTTP return code, too; might be something else than 200
				$httpReturnCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
				\Log::info("Envío de Paquete A BOLDT por mailchimp: Correo enviado a ".$correo_soporte.". Status envio mail (200 ok): " . $httpReturnCode . ' Error: ' . curl_error($curl) . ' Nro. Error: ' . curl_errno($curl) . "\n" );

				//Process $content here 
				$ret = true;
			} catch(Exception $e) {
				$ret = false;
				\Log::info('Envío de Paquete A BOLDT por mailchimp: Se produjo una excepción: Cod->'.$e->getCode().'<- Detalle: ->'.$e->getMessage().'<-');

			} finally {
				// Close curl handle unless it failed to initialize
				if (is_resource($curl)) {
					curl_close($curl);
				}
			}
			
			if ($nombre_exportacion == 'RESERVA_LOTERIA'){
				//$correo_soporte = "soporte@i2t.com.ar";
				$correo_soporte = "cristian.valle@i2t.com.ar;ruben.larocca@i2t.com.ar";
			}else{
				//$correo_soporte = "soporte@i2t.com.ar";
				$correo_soporte = "cristian.valle@i2t.com.ar;ruben.larocca@i2t.com.ar";
			}
			\Log::info('Envío de Paquete A SOPORTE por mailchimp: datos: from_email ->'.$from_email.'<- correo_soporte ->'.$correo_soporte.'<- asuntomail ->'.$asuntomail.'<- body ->'.$body.'<- attach ->'.$attach.'<-');			
			
			try {

				$curl = curl_init();
				// Check if initialization had gone wrong*    
				if ($curl === false) {
					throw new Exception('Envío de Paquete A SOPORTE por mailchimp: No se pudo enviar el e-mail.');
					\Log::info("Envío de Paquete A SOPORTE por mailchimp: No se pudo enviar el e-mail. Fallo inicializacion CURL - envio mail a soporte. Destinatarios: ".$correo_soporte);
				}

				$fields = array(
				'from_email'     => $from_email,
				'from_name'      => $from_name,
				'to_email'       => $correo_soporte,
				'subject'        => $asuntomail,
				'cuerpo'         => $body,
				'attach'         => $attach,
				'tipo_archivo'   => $tipo_archivo,
				'nombre_archivo' => $nombre_archivo
				);

				$fields_string = http_build_query($fields);
				curl_setopt($curl, CURLOPT_URL, $url_mailchimp_transactional);
				curl_setopt($curl, CURLOPT_POST, TRUE);
				curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
				curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

				$result = curl_exec($curl);

				// Check the return value of curl_exec(), too
				if ($result === false) {
					\Log::info("Envío de Paquete A SOPORTE por mailchimp: Fallo en el envío del mail. Datos de envío ->".$fields_string."<- Resultado: ", array($result));
					throw new Exception(curl_error($curl), curl_errno($curl));
				}

				// Check HTTP return code, too; might be something else than 200
				$httpReturnCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
				\Log::info("Envío de Paquete A SOPORTE por mailchimp: Correo enviado a ".$correo_soporte.". Status envio mail (200 ok): " . $httpReturnCode . ' Error: ' . curl_error($curl) . ' Nro. Error: ' . curl_errno($curl) . "\n" );

				//Process $content here 
				$ret = true;
			} catch(Exception $e) {
				$ret = false;
				\Log::info('Envío de Paquete A SOPORTE por mailchimp: Se produjo una excepción: Cod->'.$e->getCode().'<- Detalle: ->'.$e->getMessage().'<-');

			} finally {
				// Close curl handle unless it failed to initialize
				if (is_resource($curl)) {
					curl_close($curl);
				}
			}

			return $ret;
		}
		/************************************
		 Envío email envía paquete
		**************************************/
		public function PrcExp_EnviaAviso($datos_mail){
			try{
					$mail_remite_aviso = $datos_mail['mail_remite_aviso'];
					$mail_destino_aviso = $datos_mail['mail_destino_aviso'];
					$archivo = $datos_mail['mail_archivo_nenvio'];
						$mails= (explode(";",$mail_destino_aviso));
					$nombreUsuarioLogueado=Session::get('usuarioLogueado.apellido');
					$cuerpo_mail='Se ha generado satisfactoriamente el paquete '.$archivo;
					$destinatarios = array();
					$destinatarios = $mails;
										
					$correos = array(
						'destinatarios'=>$destinatarios,
						'remitente'=>$mail_remite_aviso);
					\Log::info('correos_aviso',array($correos));
					
					$data = array(
						'usuarioGenerador'=>$nombreUsuarioLogueado,
						'cuerpo_mail'=>$cuerpo_mail
					);

					Mail::send('emails.email_aviso', $data, function ($message) use ($correos){
						$message->from($correos['remitente'], 'Generación de Exportación');
					    $message->subject('Acuse Generación de Exportación.');
					    foreach ($correos['destinatarios'] as $email) {
							\Log::info('email_aviso',array($email));
							if(isset($email))
								$message->to($email);
						}
					});
					
					if(count(Mail::failures()) > 0){
						\Log::error('Problema al enviar el correo aviso generación Exportación. '.$e);
						return false;
					}else{
						return true;
					}
					
				}catch(Exception $e){
					\Log::error('Problema al enviar el correo aviso generación Exportación. '.$e);
					return false;
				}
		}
	
	/***********************************************************
	* carga div con paquetes ya procesados  *
	************************************************************/
	
	public function paquetesExportacion(){
		\Log::info("WB - paquetesExportacion");
		$datos_input_panel = Input::all();
		$nombre_exportacion = $datos_input_panel['tipo_exportacion'];
		$resConsultaPaquetesExportacion=$this->servicioExportaciones->ConsultaPaquetesExportacion($nombre_exportacion);
			\Log::info("Fin consulta");
			if($resConsultaPaquetesExportacion){
				$exito = 1;
				$mensaje=$resConsultaPaquetesExportacion;
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}else{
				\Log::info("Failure");
				$exito = 0;
				$mensaje="No se registran exportaciones.";
				return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
			}
	}

/*************************** MM - Exportaciones - fin ****************************************/

/******************************* original ***************************************/
	/***********************************************************
	* Carga el usuario en la aplicación o lo retorna al portal *
	* si no está logueado o no tiene permiso.                  *
	************************************************************/
	public function cargaUsuarioEnApp(){
		$util = new Util();
		if(!Session::has("datos_ingreso")){
			return Redirect::to('/portal');
		}
		
		$datosIngreso=Session::get("datos_ingreso");
		$datosIngreso=explode("&",$datosIngreso);
		$usuario=explode("usuario=",$datosIngreso[0]);
		$id_portal=explode("id_portal=",$datosIngreso[1])[1];
		$letra_portal=explode("letra_portal=",$datosIngreso[2])[1];
		$nombre_usuario=$util->decrypt($usuario[1],"Pir@mide01");
		
		$usuario=$this->controladorUsuario->buscar($nombre_usuario);	
	
		// logueo
		\Log::info("paso por cargaUsuarioEnApp - Exportaciones");
	
		//borra todos los datos anteriores
		Session::flush();
		
		if(is_null($usuario["idUsuario"])|| is_null($usuario)){
			$mensaje='Hay un problema con su usuario.';
			Session::put('mensaje_acceso',$mensaje);
			Session::flush();
	       	return Redirect::to('/acceso-no-autorizado');
		}else if (!in_array('Administracion_ctacte',$usuario['funciones'])){
			$mensaje='Su tipo de usuario no posee acceso.';
			Session::put('mensaje_acceso',$mensaje);
	       	return Redirect::to('/acceso-no-autorizado');
		}
		$usuario['id_portal']=$id_portal;
		$usuario['letra_portal']=$letra_portal;
		Session::put('usuarioLogueado',$usuario);
		return Redirect::to('/panel-alertas');
	}
}
