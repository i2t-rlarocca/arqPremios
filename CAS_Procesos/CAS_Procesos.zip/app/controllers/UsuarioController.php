<?php
namespace controllers;	
	use Dominio\Servicios\Usuarios;
	

	class UsuarioController extends \BaseController{
		
		function __construct() {
			$this->servicio = new Usuarios();
		}
		
		/**
		* Función que busca un usuario según el nombre de usuario
		* que llega por parámetro.
		*/
		public function buscar($nombreUsuario){
			return $this->servicio->buscar($nombreUsuario);
		}
		
		/**
		* Función para ver si el usuario tiene sesión activa en el portal
		**
		public function controlSesion(){
			$nombreUsuario = \Session::get('usuarioLogueado')['nombreUsuario'];
			$sesionPortal = $this->servicio->controlSesion($nombreUsuario);
			
			if($sesionPortal['sesionActiva']){
				return \Response::json(array('mensaje'=>'in'));
			}else{
				$url="portal";
				return \Response::json(array('mensaje'=>'out', 'url'=>$url));
			}
			
		}

                /**
		* Función para ver si el usuario tiene sesión activa en el portal
		* al iniciar la app de trámites
		**/
		/*public function controlSesionPrimeraVez(){
		
			$nombreUsuario = \Session::get('usuarioLogueado')['nombreUsuario'];
			
			$sesionPortal = $this->servicio->controlSesion($nombreUsuario);
			if($sesionPortal['sesionActiva']){
				return ;
			}else{
				return \Redirect::to('/portal');
			}
			
		}*/
		
		public function controlSesion(){			
			// \Log::info("controlSesion",array(\Session::get('usuarioLogueado'))); 
		    $id_portal = NULL;
			$letra_portal = NULL;
			if(\Session::has('usuarioLogueado')){ // RL 2019-03-08: Para evitar errores de referencia, primero se pregunta si existe la variable en el objeto Session!!
				// RL 2019-03-08: Error no existe indice id_portal -> mal referenciado en el objeto Session!!!!!
				//$id_portal = \Session::get('usuarioLogueado')['id_portal'];
				//$letra_portal = \Session::get('usuarioLogueado')['letra_portal'];
				$id_portal = \Session::get('usuarioLogueado.id_portal');
				$letra_portal = substr(\Session::get('usuarioLogueado.letra_portal'), 0, 3);
				if (is_null($id_portal) || empty($id_portal)){
					$id_portal = "";
				}
				if (is_null($letra_portal) || empty($letra_portal)){
					$letra_portal = "";
				}
				// \Log::info("UsuarioController.controlSesion: la sesion tiene usuario logueado: id_portal: $id_portal - letra_portal: $letra_portal");
				// FIN RL 2019-03-08: Error no existe indice id_portal -> mal referenciado en el objeto Session!!!!!
			}
			if(is_null($id_portal)||is_null($letra_portal)){
				$url=\Config::get('ctacte_config/config.url_i');	
				\Log::info("UsuarioController.controlSesion: id_portal o letra_portal son nulos, se obtiene url= $url");				
				return \Response::json(array('mensaje'=>'out', 'url'=>$url));
			}
			// \Log::info("UsuarioController.controlSesion: llama a servicio->controlSesion");				
			$sesionPortal = $this->servicio->controlSesion($id_portal, $letra_portal);
			if($sesionPortal['sesionActiva']){
				//\Log::info("UsuarioController.controlSesion: sesionPortal devuelto por servicio->controlSesion,  sesionActiva: $sesionPortal['sesionActiva'] ");			
				return \Response::json(array('mensaje'=>'in'));
			}else{
				//\Session::flush();
				// se agrega replace para detectar la url (url_i) de configuración ctacte_config
				$letra_portal=str_replace("'","",$letra_portal);
				$url=\Config::get('ctacte_config/config.url_'.$letra_portal);			
				//\Log::info("UsuarioController.controlSesion: sesionPortal devuelto por servicio->controlSesion,  sesionActiva no está activa: $sesionPortal['sesionActiva'] - letra_portal: $letra_portal - url: $url");							
				return \Response::json(array('mensaje'=>'out', 'url'=>$url));
			}
		}
		
		public function controlSesionPrimeraVez(){
			$id_portal = \Session::get('usuarioLogueado')['id_portal'];
			$letra_portal = \Session::get('usuarioLogueado')['letra_portal'];
			$sesionPortal = $this->servicio->controlSesion($id_portal, $letra_portal);
			if($sesionPortal['sesionActiva']){
				return ;
			}else{
				\Session::flush();
				$url=\Config::get('ctacte_config/config.url_'.$letra_portal);			
				return \Redirect::to('/portal/'.$url);
			}
			
		}

		public function ControlAcceso(){
			// se comenta para ver si el problema de cierre de sesion viene por aqui
			/*
			$ficheros1 = array();
			$files = scandir(storage_path().'/views/');
			foreach ($files as $fichero){
								if(strpos($fichero,".") < 1 && $fichero!= ".gitignore" && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
			 
			foreach($ficheros1 as $file){ // iterate files
					  \Log::info('file',array($file));
				unlink(storage_path().'/views/'.$file); // delete file
			}
			*/
			$usuario = \Session::get("usuarioLogueado.nombreUsuario");
			$datos =  \Session::get("usuarioLogueado");
			\Log::info("ControlAcceso - usuario: ",array($usuario)); 
			\Log::info("ControlAcceso - datos: ",array($datos)); 
			// el sistema -- puede ser Procesos o Auditoria? de ser así debemos determinar en el SP el sistema del usuario 
			$sistema = "Procesos";
			
			$accesos = '';
			$accesos = $this->servicio->ControlAcceso($sistema,$usuario);
			
			\Session::put('usuarioLogueado.accesos_usuario',$accesos);
			
			// Recupera datos extendidos del usuario segun su tipo de usuario (provincia, loteria, etc)
			$datosTipoUsuario = '';
			$datosTipoUsuario = $this->servicio->GetDatosTipoUsuario($usuario);
			
			\Session::put('usuarioLogueado.datosTipoUsuario',$datosTipoUsuario);
			\Session::put('urlInterno',\Config::get('ctacte_config/config.urlInterno'));
			
		}

	}

?>