<?php
	
use \Helpers\Macros;
use \Dominio\Servicios\Camaras; 
use \Dominio\Servicios\CuentasCorrientes;
use controllers\UsuarioController; 
use \Helpers\Util;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;

class CamarasController extends BaseController {

	public $error_descomprimir_archivo = "Error al descomprimir el archivo";
	public $error_crear_carpeta_temporal = "Error al crear la carpeta temporal";
	public $error_carga_camaras = "Error al cargar los datos en las tablas temporales";
	public $error_nombre_archivo = "Error no coincide el archivo procesado con la cámara y mes ingresados";
	public $error_archivo_extension = "Error extension de archivo a procesar";
	public $err_cant_archivos = "Cantidad de archivos no conincide";
	
	
	public $error_llamada_store_procedure = "Error al llamar al store procedure";
	public $error_proceso_ya_existente = "Proceso ya existente";

	function __construct() {
		$ds=DIRECTORY_SEPARATOR;
		
		
		$this->servicioCamaras = new Camaras();
		$this->controladorUsuario = new UsuarioController();
		$this->servicioCuentaCorriente = new CuentasCorrientes();
		$this->destinoTemporal = Config::get('ctacte_config/config.urlDestino');
		$this->destinoCamaras = $this->destinoTemporal.Config::get('ctacte_config/config.urlCamaras');

	}

	public function cargaUsuarioEnAppCtaCte(){
		$util = new Util();
		if(!Session::has("datos_ingreso")){
			return Redirect::to('/portal');
		}
		$datosIngreso=Session::get("datos_ingreso");
		$datosIngreso=explode("&",$datosIngreso);
		$usuario=explode("usuario=",$datosIngreso[0]);
		$id_portal="'".explode("id_portal=",$datosIngreso[1])[1]."'";
		$letra_portal=explode("letra_portal=",$datosIngreso[2])[1];
		$nombre_usuario=$util->decrypt($usuario[1],"Pir@mide01");
		
		$usuario=$this->controladorUsuario->buscar($nombre_usuario);
	
		//borra todos los datos anteriores
		Session::flush();
		
		if(is_null($usuario["idUsuario"])|| is_null($usuario)){
			$mensaje='Hay un problema con su usuario.';
			Session::put('mensaje_acceso',$mensaje);
			\Log::error("problema con el usuario - nulo");
			Session::flush();
	       	return Redirect::to('/acceso-no-autorizado');
		}else if (!in_array('Administracion_ctacte',$usuario['funciones'])){
			$mensaje='Su tipo de usuario no posee acceso.';
			Session::put('mensaje_acceso',$mensaje);
	       	return Redirect::to('/acceso-no-autorizado');
		}
		$usuario['id_portal']=$id_portal;
		$usuario['letra_portal']=$letra_portal;
		Session::put('usuarioLogueado',$usuario);
		return Redirect::to('/panel-principal');
	}

	
	/************************************************/
	/*			CAMPOS AL VIEW						*/
	/************************************************/
	
	
	public function camposPanelCamaras(){
	
		$archivosApedir=array();
		$datosTransaccion['nombre_file']=array();
		
		$archivos=$this->servicioCamaras->especif_arch_pre();
		
		//\Log::info('archivos',array($archivos));
		// consulta secuencia esperada se debe cambiar el select una vez que tengamos el dato en una tabla
		$secuencia_espe=$this->servicioCamaras->secuenciaEsperada();
		Session::put('secuencia_esperada',$secuencia_espe);
		$idJuego=999;$ms=0;$com=0;
		foreach ($archivos[$idJuego] as $archJuego) {

			if($archJuego['transaccion']==12 && $archJuego['id_padre']==''){
						if($archJuego['tipo_archivo']=='CM'){	
							$com++;
							$archivo['nombre']=$archJuego['nombre']; //'A'.$secuencia_espe;
							$archivo['camara']='cacoplyt|canr';
							if(strtolower($archJuego['control'])=='n')
								$archivo['buttonText']='Camaras';
							else
								$archivo['buttonText']='CamarasCtrl';
								array_push($datosTransaccion['nombre_file'],$archivo);
						}
						$archivo['extension']=str_replace("+" ,"",$archJuego['extension']);
						$archivo['requerido']=$archJuego['requerido'];
						array_push($archivosApedir,$archivo);					
					}
				}		
		//\Log::info('archivosApedir',array($archivosApedir));	
		$datosTransaccion= Response::panelCamaras($archivosApedir, $secuencia_espe);
		return $datosTransaccion;
	}

	
	
	/************************************************/
	/*			 VIEW	panel camaras				*/
	/************************************************/
	
	public function panelRecepcionCamaras(){
		$campos=$this->camposPanelCamaras();
		return View::make('cuenta_corriente.panelCamaras', array('campos'=>$campos));
	}

	
	
	/************************************************/
	/*	controlador proceso archivo  camaras		*/
	/************************************************/
	
	
	public function tratamientoCamaras(){
		// variables
		$util = new Util();
		$ds=DIRECTORY_SEPARATOR;
		$destino=$this->destinoCamaras;
		// datos para obtener id_proceso
		$mensaje="";
		$archivo= Input::file();
		$datos= Input::all();
		$input_mes = $datos['id_mes'];
		$input_camara = $datos['id_camara'];

		$idJuego=99;
		if ($input_camara == 'CANR'){
			$cc_nro_envio='4'.date("m").date("Y").'01';
		}
		if ($input_camara == 'CACOPLYT'){
			$cc_nro_envio='4'.date("m").date("Y").'02';
		}

		\Log::info('cc_nro_envio',array($cc_nro_envio));
		
		$input_totalafiliados = $datos['id_totalafiliados'];
		$input_totalimporte = $datos['id_totalimporte'];		

		$exito = 0;
		$usuario= Session::get('usuarioLogueado.idUsuario');
		// obtengo el id proceso
		$idProceso = $this->servicioCuentaCorriente->getNumeroProcesoAuditoriaCtaCte($idJuego,$cc_nro_envio);

		\Log::info('idProceso',array($idProceso));
	
		// *********************************************
		// CREO LA CARPETA TEMPORAL PARA GUARDAR EL ZIP
		// *********************************************
		
		$nroSecuencia=Session::get('secuencia_esperada');
		/***************************************************
			Registro proceso de recepcion en auditoria
		*****************************************************/
		$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,60,$usuario,60,61,"Inicio Proceso de recepción de cámaras");
		
			try{
				//destino para los archivos de recepcion de pagos de bancos
				$destinoCamaras =$destino.$ds.$input_camara.$input_mes.$ds;
				if(!is_dir($destinoCamaras) && !file_exists($destinoCamaras)){
					File::makeDirectory($destinoCamaras, $mode = 0777, true, true);
				}else{
					array_map('unlink', glob($destinoCamaras."*"));
				}
				$exito = 1;
			}catch(\Exception $e){
				$mensaje=sprintf($this->error_crear_carpeta_temporal,"recepcion camaras");
				return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
			}
		
			$nom_archivo_input = $input_camara.$input_mes;
			foreach($archivo as $arch1){
				$filename = $arch1->getClientOriginalName();
				$arregloNombre=explode(".",$filename);	
				

				if(strtoupper($arregloNombre[0]) != strtoupper($nom_archivo_input) ){
					/***************************************************
						Registro error nombre de archivo
					*****************************************************/
					$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,61,$usuario,62,60,"Error nombre de archivo cámaras");
					$exito=0;
					$mensaje=sprintf($this->error_nombre_archivo,"recepción cámaras");
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));  
					
				}
				// ajustar cambiar string 'txt' por campo extension de la configuración
				if($arregloNombre[1] != 'txt' ){
					/***************************************************
						Registro error extension de archivo
					*****************************************************/
					$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,61,$usuario,62,60,"Error extensión de archivo cámaras");
					$exito=0;
					$mensaje=sprintf($this->error_archivo_extension,"recepción cámaras");
					return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));  
				}
			}
	
		
		
		// *****************************************
		//	MUEVO EL ARCHIVO A A LA CARPETA
		// *****************************************
		$target_path = $destinoCamaras;
		foreach($archivo as $arch){
			$filename = $arch->getClientOriginalName();
			$arch->move($destinoCamaras, $filename);		
		}
		
		//archivos a pedir
		/*				
					$archivos=$this->servicioCamaras->especif_arch_pre();
					
					$archivos=$archivos[999];
					
					$archivos=$util->groupArray($archivos,'tipo_archivo');
					
					$archivosHijosRL =array();
					$archivosPadresRL =array();
					$this->listasArchivos($archivos, $listaCM, $archivosHijosCM, $archivosPadresCM, "CM",12);
			
		\Log::info('listaCM',array($listaCM));
		\Log::info('archivosHijosCM',array($archivosHijosCM));
		\Log::info('archivosPadresCM',array($archivosPadresCM));
		*/
		//obtengo el nombre sin extension
		//$filename = explode('.',$filename); 
		//$filename = $filename[0]; 
		$file = $destinoCamaras.$filename;
		//\Log::info('file',array($file));
		
		$ficheros = scandir($destinoCamaras);
			/*			
							$ficheros1 = array();
							foreach ($ficheros as $fichero){
								if((strpos($fichero,"ZIP") || strpos($fichero,"zip")) < 1 && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
							\Log::info('ficheros1',array($ficheros1));
							// control de diferencia de cantidad de archivos esperados en cas.zip
								//\Log::info("ficheros1",array($ficheros1));
								//\Log::info("cant_arch_esperados",array($archivosPadresPP[0]['cant_arch_esperados']));
							if(count($ficheros1)!=$archivosPadresCM[0]['cant_arch_esperados']){
								$mensaje=sprintf($this->err_cant_archivos,"cámaras");
								//\Log::info($mensaje);
								//return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>15, 'srcImagen'=>$this->srcImgError));
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
							}
							
							
							foreach ($ficheros1 as $nombreFichero) {
								$dest=$destinoPrescripciones.$nombreFichero;
								
							//	\Log::info("idProceso",array($idProceso));
							//$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,51,$usuario,50,52,"Inicio vuelco archivo ".$nombreFichero); 
								switch ($nombreFichero) {
									case "A000040435.txt":
											$okPres_CFE=$this->servicioPrescriptos->cargarPrescriptosControl($dest,$idProceso);
											//$proc_ok = 1;
										break;
									case "A000040435.AFE":
											$okPres_AFE=$this->servicioPrescriptos->cargarPrescriptos($dest,$idProceso);
											//$proc_ok = 1;
										break;
									default:	
											$proc_ok = 0;
											//$mensaje=$resultado['mensaje'];
										break;
								}
							}
				*/
		
		/*****************************************/
		/*	CARGAR EN TABLAS TMP				*/
		/*****************************************/
		
		try{
			//\Log::info('datos',array($file.'|'.$idProceso.'|'.$input_camara.'|'.$cc_nro_envio));
			$resCargaCamara = $this->servicioCamaras->cargarCamaras($file,$idProceso,$input_camara,$cc_nro_envio);
			//\Log::info('resCargaCamara',array($resCargaCamara));
			
		}catch(\Exception $e){
			/***************************************************
			Registro error al procesar el archivo a tabla temporal
			*****************************************************/
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,62,$usuario,61,63,"Error en vuelco de archivo a tabla temporal - recepción de cámaras");
			$exito = 0;
			$mensaje=sprintf($this->error_carga_camaras,"recepción archivo cámaras");
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));  
		}
		
		
		     	
				
	$msj_env = $this->servicioCamaras->validarEnvios($idProceso,$cc_nro_envio,$usuario,'ENV');			
	\Log::info('msj_env',array($msj_env[0]->cod_error));
	
	
	
	//valido los registros si la validacion de envios fyue correcta
    $msj_reg = $this->servicioCamaras->validarEnvios($idProceso,$cc_nro_envio,$usuario,'REG');
  //	\Log::info('msj_reg',array($msj_reg));
//	\Log::info('error',array($msj_reg[0]->cod_error));
//	\Log::info('afiliados',array($msj_reg[0]->cant_afiliados));
//	\Log::info('sum_importe',array($msj_reg[0]->sum_importe));
//	\Log::info('concepto_faltante',array($msj_reg[0]->concepto_faltante));
	
    if ($msj_reg[0]->cod_error != '0' or $msj_env[0]->cod_error != '0'){
   // if ($msj_reg[0]->cod_error != '0' ){
		
		if($msj_env[0]->cod_error == '1'){
			/***************************************************
			Registro proceso de recepcion en auditoria - total afiliados
			*****************************************************/
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,62,$usuario,61,63,"El archivo ya se encuentra procesado.");
    		$mensaje = "Ya se encuentra procesado el archivo.";
    		$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
    	}
		
		
		if($msj_reg[0]->cod_error == '2'){
			/***************************************************
			Registro proceso de recepcion en auditoria - total afiliados
			*****************************************************/
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,62,$usuario,61,63,"Problema al generar vuelco de archivo a tabla temporal rec_cam");
			
    		$mensaje = "Error en vuelco de tabla temporal.";
    		$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
    	}
    	
       	if($msj_reg[0]->cod_error == '3'){
			/***************************************************
			Registro proceso de recepcion en auditoria - total afiliados
			*****************************************************/
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,63,$usuario,62,64,"Problema al generar vuelco, el concepto ".$msj_reg[0]->concepto_faltante." no se encuentra en suite");
			
    		$mensaje = "El concepto ".$msj_reg[0]->concepto_faltante." no se encuentra en suite";
    		$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
    	}
		
    	if($msj_reg[0]->cod_error == '4'){
			/***************************************************
			Registro proceso de recepcion en auditoria - total afiliados
			*****************************************************/
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,64,$usuario,63,65,"Problema al generar vuelco, el concepto cta. cte. ".$msj_reg[0]->concepto_faltante." no se encuentra en suite configurado");
    		$mensaje = "El concepto cta. cte. ".$msj_reg[0]->concepto_faltante." no se encuentra en suite configurado";
    		$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
    	}
		
		if($msj_reg[0]->cod_error == '5'){
			/***************************************************
			Registro proceso de recepcion en auditoria - total afiliados
			*****************************************************/
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,62,$usuario,61,63,"Existen importes en 0 en el archivo".$msj_reg[0]->agencia_importe_cero);
    		$mensaje = "Existen importes en 0 en el archivo agencia: ".$msj_reg[0]->agencia_importe_cero;
    		$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
    	}
		
		if($msj_reg[0]->cod_error == '6'){
			/***************************************************
			Registro proceso de recepcion en auditoria - total afiliados
			*****************************************************/
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,65,$usuario,64,66,"Error Validación el archivo contiene agencias que no existen en suite.");
    		$mensaje = "Error Validación el archivo contiene agencias que no existen en suite.";
    		$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
    	}
		
    }else {
		
		if($input_totalafiliados != $msj_reg[0]->cant_afiliados){
			/***************************************************
			Registro proceso de recepcion en auditoria - total afiliados
			*****************************************************/
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,61,$usuario,60,62,"Problema en la cantidad de afiliados informados y la cantidad encontrada en archivo");
		
			$mensaje = "Error en Validación Cantidad de afiliados informados y los recibidos en archivo.";
    		$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		}
		
		$input_totalimporte = str_replace(',','.',$input_totalimporte);
		$sum_importe = str_replace(',','.',$msj_reg[0]->sum_importe);
		
		if($input_totalimporte != $sum_importe){
			/***************************************************
			Registro proceso de recepcion en auditoria - total afiliados
			*****************************************************/
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,61,$usuario,60,62,"Problema el importe informado y el monto sumarizado del archivo");
		
			$mensaje = "Error en Validación importe informado y el monto sumarizado en el archivo.";
    		$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		}
		
    	// inserto auditoria de inicio de proceso de recepcion DB/CR auto si las validaciones fueron correctas
    	//$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$cc_nro_envio,63,$usuario,62,64,"Finalización correcta de validaciones de archivo y vuelco en tabla temporal rec_cam.");  
    	// inserto auditoria de validacion correcta de envios
    	//$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$cc_nro_envio,44,$usuario,43,45,"Validacion correcta de envios.");
    	//$exito = 1;
    	//$mensaje = "Validacion correcta del archivo subido.";
      }

	  
		/*****************************************************/
		/*				 INICIO resumen						*/
		/*****************************************************/
	  $this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$cc_nro_envio,66,$usuario,65,67,"");  
	   $msj_process_resumen = $this->servicioCamaras->ProcesarResumenCamaras($idProceso,4,$usuario,$input_camara,$idJuego,$cc_nro_envio);
	   \Log::info('msj_process_resumen',array($msj_process_resumen));
	   if($msj_process_resumen[0]->cod_error != '0'){
		   $this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,67,$usuario,66,68,"Problema en proceso genera resumen cod_err ". $msj_process_resumen[0]->cod_error);
		
			$mensaje = "Error en proceso de generacion de resumen";
    		$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		   
	   }else{
		    $this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,67,$usuario,66,68,"Finalizacion correcta de generación de resumen");
	   }
	      
      
		/*****************************************************/
		/*					proceso movimientos				*/
		/*****************************************************/
		$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,68,$usuario,67,69,"Inicio generacion de movimientos");	
		
		$msj_process = $this->servicioCamaras->Procesar_Camaras($idProceso,4,$idJuego,$cc_nro_envio);
		\Log::info('msj_process',array($msj_process));
		
		if ($msj_process[0]->msgret != 'OK'){
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,71,$usuario,69,70,"Finalizacion con error en movimientos");	
			
		}else{
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,69,$usuario,68,70,"Finalizacion correcta de movimientos");	
			
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $cc_nro_envio,70,$usuario,69,68,"Finalizacion correcta de generación de resumen");
			$mensaje = "Finalización correcta de proceso de recepción cámaras."; 
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		}
		
    /*
	if ($msj_process == 'Success'){
    	//inserto auditoria de validacion de pagos exitosa
    	$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$cc_nro_envio,45,$usuario,46,44,"Validación correcta de pagos de proceso de recepcion de pagos bancos.");

    	//inserto auditoria de generacion de comprobantes exitosa
    	$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$cc_nro_envio,46,$usuario,45,47,"Generación correcta de los comprobantes.");

    	//inserto auditoria de exito en proceso de recepcion de banco
    	$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$cc_nro_envio,47,$usuario,46,47,"Fin exitoso proceso de recepción de pagos banco.");
    	$mensaje = "Fin exitoso proceso de recepción cámaras.";
    }else {
    	//inserto auditoria de generacion de comprobantes con fallos
    	$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$cc_nro_envio,47,$usuario,46,48,"Fallo generación de comprobantes.");

    	// inserto auditoria fin de proceso de recepcion de pagos bancos con errores
    	$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$cc_nro_envio,48,$usuario,46,48,"Fallo proceso de Recepción de pagos bancos.");
    	$mensaje = "Fallo proceso de recepción cámaras."; 
    }
		
		return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
    }

	*/
//$mensaje = "Finalización correcta de proceso de recepción cámaras."; 
	//		return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
}
	/*****************************************
	* lista de archivos según la transacción
	******************************************/
	private function listasArchivos($archivos, &$lista, &$hijos, &$padres, $ta, $transac){
		//lista de archivos 
		foreach ($archivos as $archivo) {
			if($archivo['tipo_archivo']==$ta ){
				$lista=$archivo['grupodatos'];
				break;
			}
		}
		if(isset($lista)){
			//busco el arch. padre y los hijos
			foreach ($lista as $archivo) {
				if($archivo['id_padre']=='' && $archivo['transaccion']== $transac){
					array_push($padres,$archivo);								
				}else{
					array_push($hijos,$archivo);
				}
			}			
		}
	}
	
}
