<?php

use \Helpers\Macros;
use \Dominio\Servicios\RecepcionPrePagados; 
use \Dominio\Servicios\CuentasCorrientes;
use controllers\UsuarioController; 
use \Helpers\Util;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;

class RecepcionPrePagadosController extends BaseController{

	public $error_descomprimir_archivo = "Error al descomprimir el archivo";
	public $error_crear_carpeta_temporal = "Error al crear la carpeta temporal";
	public $error_carga_pre_pagados = "Error al cargar los datos en las tablas temporales";
	public $error_llamada_store_procedure = "Error al llamar al store procedure";
	public $error_proceso_ya_existente = "Proceso ya existente";
	//public $error_carga_sorteos_diarios = "Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al juego/sorteo seleccionado."; 
	//public $error_carga_comisiones ="Problema al cargar los archivos de %s. Verifique formato de nombre y que el archivo corresponda al período indicado.";
	//public $err_nro_sorteo_archivo = "El archivo de %s no corresponde al sorteo elegido.";
	public $err_falta_archivo = "Falta archivo de %s";
	//public $err_datos_sorteo = "Problema al obtener los datos del sorteo: %s";
   	public $err_mas_archivos = "Hay más archivos de los esperados para %s.";
	public $err_menos_archivos = "Hay menos archivos de los esperados para %s.";
	public $err_proces="Problema al procesar %s.";
	public $err_cant_archivos = "Existe problema de integridad de archivos esperados para %s.";
	public $err_nomb_archivos ="No se espera el archivo con el nombre %s.";
	
	function __construct() {
		$this->servicioRecepcionPrePagados = new RecepcionPrePagados();
		$this->servicioCuentaCorriente = new CuentasCorrientes();
		$this->destinoTemporal = Config::get('ctacte_config/config.urlDestino');
		$this->destinoPrePagados = $this->destinoTemporal.Config::get('ctacte_config/config.urlPrePagados');
	
	}
	
	
	public function camposPanelRecepcionPrePagados(){
		//$especif_archivo=$this->servicioRecepcionPrePagados->especif_arch_pre();
		$especif_archivo=$this->servicioRecepcionPrePagados->especif_arch_premiospagados();

		//Uso una macro como respuesta custom, obtengo un html con la vista 
		return Response::recepcionPrePagados($especif_archivo);
	}

	//Llamada para la vista, le paso los datos obtenidos de la macro
	public function panelRecepcionPrePagados(){
		$campos=$this->camposPanelRecepcionPrePagados();
		return View::make('cuenta_corriente.panelRecepcionPrePagados', array('campos'=>$campos));
	}

//Para el log de errores 

	
	
	
	/****************************************/
	/*	nuevo tratamiento para pago			*/
	/****************************************/
	
		public function tratamientoArchivoPremPag(){ //Llamada recibida desde el javascript
		// variables
		$util = new Util();
		$ds=DIRECTORY_SEPARATOR;
		$destino=$this->destinoPrePagados;
		$idJuego=999;
				\Log::info('input1',array(Input::file()));
			\Log::info('input2',array(Input::all()));
		//$archivo= Input::file();
		
		$exito = 0;
		$mensaje = 'Problema en subida de archivo';
		$usuario= Session::get('usuarioLogueado.idUsuario');
		$flag = '';
		//Obtengo el numero de proceso de Auditoria
		$idProceso = $this->servicioRecepcionPrePagados->getNumeroProcesoAuditoria();		
		
	
		
		/************/
		/* nuevo	*/
		/**************/
		
		$dia = date("d");
		$mes = date("m");
		$año = date("Y");
		$hora = date("H");
		$minuto = date("i");
		$segundo = date("s");

		$fecha_hora_entero = intval($año . $mes . $dia . $hora . $minuto . $segundo);
		
		$destino =$destino.$ds.$fecha_hora_entero.$ds;
		if(!is_dir($destino) && !file_exists($destino)){
			  File::makeDirectory($destino, 0777, true);
			}
		
		$archivosSubidos = Input::file();
			
			foreach($archivosSubidos as $archivo){
				$filename = $archivo->getClientOriginalName();
			
				$arregloNombre=explode(".",$filename);	
				$nombreSinExtension =$arregloNombre[0]; 
				
				
				$archivos=$this->servicioRecepcionPrePagados->especif_arch_x_juego();
				
					try{
						$archivos=$archivos[99];
					}catch(\Exception $e){
						//$this->servicioCuentaCorriente->insertaAuditoria($idProceso,99, $sorteo,91,$usuario,90,92,"Formato erróneo: ".$filename);
						$exito=0;
						$mensaje=sprintf($this->error_carga_pre_pagados," Problemas de configuración de archivo contactese con el administrador.");
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));  
					}
					
					$archivos=$util->groupArray($archivos,'tipo_archivo');
					
					$archivosHijosPA =array();
					$archivosPadresPA =array();
					$this->listasArchivos($archivos, $listaPA, $archivosHijosPA, $archivosPadresPA, "PA",13);
					
					
						
						$destinoPrePagados =$destino.$ds;
					
							if(!is_dir($destinoPrePagados) && !file_exists($destinoPrePagados)){
								File::makeDirectory($destinoPrePagados, $mode = 0777, true, true);
							}else{
								array_map('unlink', glob($destinoPrePagados."*"));
							}
						
					  
					   	$archivoPA = $archivo; //Input::file($nombreSinExtension);
						// control de archivo zip
						
						$resultado=$util->controlZip($archivoPA, $destinoPrePagados, $listaPA, $idJuego,'',13);
						
						$proc_ok=1;
					   	if($resultado['exito']){
							//buscar los archivos en la carpeta y pasarlos a la tabla
							$ficheros = scandir($destinoPrePagados);
						
							$ficheros1 = array();
							foreach ($ficheros as $fichero){
								if((strpos($fichero,"ZIP") || strpos($fichero,"zip")) < 1 && $fichero!= "." && $fichero!= ".."){
									array_push($ficheros1, $fichero);
								}
							}
					
							// control de diferencia de cantidad de archivos esperados en cas.zip
								\Log::info('contador ficheros',array(count($ficheros1)));
								\Log::info('contador archivos padre',array($archivosPadresPA[0]['cant_arch_esperados']));
								
							if(count($ficheros1)!=$archivosPadresPA[0]['cant_arch_esperados']){
								$mensaje=sprintf($this->err_mas_archivos,"premios pagados");
								\Log::info($mensaje);
								//return Response::json(array('exito'=>0, 'mensaje'=>$mensaje,'estado'=>15, 'srcImagen'=>$this->srcImgError));
								return Response::json(array('exito'=>0, 'mensaje'=>$mensaje));
							}
							/***************************************************
								indicando la recepcion y validaciones
							*****************************************************/
						
							$archivoDatos=explode(".",$ficheros1[1]);
							$sorteo = $archivoDatos[0].substr($archivoDatos[1],2,3);
							$juego = 99;
							
							foreach ($ficheros1 as $nombreFichero) {
								$dest=$destinoPrePagados.$nombreFichero;
								
								$arch=explode(".",$nombreFichero);	
								$Extension = strtoupper(substr($arch[1],0,2)); 
								// inserto auditoria de inicio
								$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $sorteo,90,$usuario,90,91,"Inicio vuelco archivo: ".$nombreFichero." idproceso: ".$idProceso);
								switch ($Extension) {
									case "CV":
											$okCV = $this->servicioRecepcionPrePagados->cargarPremiosPagadosControl($idProceso,$dest,$destinoPrePagados.$ficheros1[1]); // enviamos ambos archivos para md5 calculado
										break;
									case "GV":
											$okGV = $this->servicioRecepcionPrePagados->cargarPremiosPagados($idProceso,$dest);
										break;
									default:	
											$proc_ok = 0;
											//$mensaje=$resultado['mensaje'];
										break;
								}
							}

						}else{//ERROR DESCOMPRIMIR
							$mensaje=$resultado['mensaje'];
							// inserta auditoria sobre proceso descrompresion archivo cas.zip
							//$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $sorteo,90,$usuario,90,91,"Fallo descompresión archivos vuelco - idproceso: ".$idProceso);
							\Log::info($mensaje);
								if($proc_ok == 0){
									$exito = 0;
								}
							return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
						}
				//	}
					// fin descompresion correcto

					/********************************************/
					/*			VALIDACIONES ENVIOS				*/
					/********************************************/
	    $msj_env = $this->servicioRecepcionPrePagados->validarEnvios($idProceso,$sorteo,$usuario,'ENV');
    	 
		 $datos=$idProceso.'----'.$sorteo.'----'.$usuario;
		\Log::info('idProceso',array($datos));
		\Log::info('msj_env',array($msj_env));
		
		if($msj_env[0]->cod_error == '1'){
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$juego, $sorteo,91,$usuario,90,92,"Error envio a vuelco de archivos a tablas rec ".$filename);
    		$mensaje = "Ya se encuentra procesado el archivo ".$filename;
    		$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
    	}
		
		if($msj_env[0]->cod_error == '7'){		
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $sorteo,92,$usuario,91,93,"El archivo de control indica que existe inconsistencia.");
			$mensaje = "Inconsistencia entre archivos de control y archivo de datos.";
			$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		}
		
		if($msj_env[0]->cod_error == '8'){		
			$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $sorteo,92,$usuario,91,93,"Existen juegos en el archivo que no existe en suite.");
			$mensaje = "Existen juegos en el archivo que no existe en suite.";
			$exito = 0;
			\Log::info($mensaje);
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
		}

    	$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$sorteo,92,$usuario,91,93,"Inicio validacion de PAGOS DE PREMIOS");

		$msj_reg = $this->servicioRecepcionPrePagados->validarEnvios($idProceso,$sorteo,$usuario,'REG');

		\Log::info('msj_reg validacion',array($msj_reg));

		$mensaje = "";
		
				if($msj_reg[0]->cod_error != '0' && $msj_reg[0]->cod_error != '4'){

					$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$sorteo,92,$usuario,91,93,"Fin validación de PAGOS DE PREMIOS CON PROBLEMA.");
					//Identificador de premio 	$flag = Juego+Sorteo+Ticket+" $ "+importe
						$flag = $msj_reg[0]->juego.$msj_reg[0]->sorteo.$msj_reg[0]->ticket."$".$msj_reg[0]->importe;
						
					// descomentar para pasar a testing
					if($msj_reg[0]->cod_error == '1'){
						
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $sorteo,92,$usuario,91,93,"Premio ".$flag." con juego o sorteo inexistentes");
						$mensaje = "El programa de sorteo del Premio no existe. PROCESO CANCELADO. Verifique auditoria de sorteos.";
						$exito = 0;
						\Log::info($mensaje);
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					}
						
					if($msj_reg[0]->cod_error == '2'){		
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $sorteo,92,$usuario,91,93,"Premio ".$flag." con sorteo NO CONSOLIDADO.");
						$mensaje = "El programa de sorteo del Premio no tiene etapa de consolidacion concluida. PROCESO CANCELADO. Verifique auditoria de sorteos.";
						$exito = 0;
						\Log::info($mensaje);
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					}

					if($msj_reg[0]->cod_error == '3'){		
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $sorteo,92,$usuario,91,93,"Premio ".$flag." inexistente.");
						$mensaje = "Ticket no existe en repositorio de premios (premio o premios menores). PROCESO CANCELADO. Verifique auditoria de sorteos.";
						$exito = 0;
						\Log::info($mensaje);
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					}

					if($msj_reg[0]->cod_error == '4'){		
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $sorteo,92,$usuario,91,93,"El premio ".$flag." se encuentra pagado o prescripto");
						$mensaje = "Existen premios ya pagados o prescriptos -se procesa el resto-. EL PROCESO AVANZA CON LOS PREMIOS CORRECTOS. Verifique auditoria de sorteos.";
						$exito = 0;
						\Log::info($mensaje);
						// return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					}

					if($msj_reg[0]->cod_error == '5'){		
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $sorteo,92,$usuario,91,93,"La provincia:".$msj_reg[0]->provincia." no existe en el padron");
						$mensaje = "La provincia de venta no existe en el padron. PROCESO CANCELADO. Verifique auditoria de sorteos.";
						$exito = 0;
						\Log::info($mensaje);
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					}

					if($msj_reg[0]->cod_error == '6'){		
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $sorteo,92,$usuario,91,93,"Premio ".$flag." con agencia: ".$msj_reg[0]->agencia." no existe en el padron");
						$mensaje = "La agencia no existe en el padron. Verifique auditoria de sorteos.";
						$exito = 0;
						\Log::info($mensaje);
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					}
				}else{
					\Log::info('entra al else');
					if($msj_reg[0]->cod_error == '4'){		
						\Log::info('entra al error 4');
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego, $sorteo,92,$usuario,91,93,"El premio ".$flag." se encuentra pagado o prescripto");
						$mensaje = "Existen premios ya pagados o prescriptos -se procesa el resto-. EL PROCESO ACTUALIZO LOS PREMIOS CORRECTOS. Verifique auditoria de sorteos.";
						$exito = 0;
						\Log::info($mensaje);
						// return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
					}
					$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$sorteo,92,$usuario,91,93,"Fin validación de PAGOS DE PREMIOS- OK");
				}

			$mensaje_old = $mensaje;
			
					/*************************************************************/
					/* inicio de vuelco a tablas finales 						*/
					/* paso a tablas definitivas 	*/
					/************************************************************/
					
			//	if ($exito != 0){ //Si no hubo errores
				$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$sorteo,93,$usuario,92,94,"Fin correcto de resumen emisión de PAGOS DE PREMIOS");
				
				$msj_process = $this->servicioRecepcionPrePagados->Procesar_pre_pagados();
					\Log::info('msj_process',array($msj_process));
					\Log::info('msj_process[0]',array($msj_process[0]->msgret),' - msgaux: ', array($msj_process[0]->msgaux ));
					
					//$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$sorteo,96,$usuario,93,94,"Fin resumen PAGOS DE PREMIOS - OK");
					// $msj_process == '2' -> error en generación de resumen
					if ($msj_process[0]->msgret == '2'){
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$sorteo,95,$usuario,94,95,"Error en generación de resumen ".$filename." de PAGOS DE PREMIOS");
						$mensaje = "Error en el Procesamiento de resumen";	 
						$exito = 0;
						\Log::info($mensaje);
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));	
					}
						
					$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$sorteo,97,$usuario,93,94,"Fin resumen PAGOS DE PREMIOS - OK");
						
					if ($msj_process[0]->msgret == '1'){
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$sorteo,95,$usuario,94,95,"Fin procesamiento Envío ".$filename." de PAGOS DE PREMIOS - CON PROBLEMA");
						$mensaje = "Error en el Procesamiento";	 
						$exito = 0;
						\Log::info($mensaje);
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));	
					}else{
						$this->servicioCuentaCorriente->insertaAuditoria($idProceso,$idJuego,$sorteo,94,$usuario,93,97,"Fin correcto de proceso de PAGOS DE PREMIOS");

						$mensaje="Carga correcta de los archivos de premios pagados.";
						if ($mensaje_old != "") {
							$mensaje = $mensaje . "<br><br>" . $mensaje_old;
							$exito = 0;
						}else{	
							$exito = 1;
						}
						return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));	
					}
			//	}
				

					
					

			}
			return Response::json(array('exito'=>$exito, 'mensaje'=>$mensaje));
	       
	}

	
	/*****************************************
	* lista de archivos según la transacción
	******************************************/
	private function listasArchivos($archivos, &$lista, &$hijos, &$padres, $ta, $transac){
		//lista de archivos 
		foreach ($archivos as $archivo) {
			if($archivo['tipo_archivo']==$ta ){
				$lista=$archivo['grupodatos'];
				break;
			}
		}
		if(isset($lista)){
			//busco el arch. padre y los hijos
			foreach ($lista as $archivo) {
				if($archivo['id_padre']=='' && $archivo['transaccion']== $transac){
					array_push($padres,$archivo);								
				}else{
					array_push($hijos,$archivo);
				}
			}			
		}
	}
	
}

?>