<?php
$ds = DIRECTORY_SEPARATOR;
return array(
		// Portal interno
		'urlInterno'  => "https://sbxa.loteriasantafe.gov.ar/jasper/tramites.php?usuario=nalves&tipoUsuario=Provincia&pagina=ingresoCuentaCorriente",
		// Portal de agencias (esta 2 veces, tambien esta como url_a)
		'urlpac' => "https://sbxa.loteriasantafe.gov.ar/pacb",
		// Imagen de error
		'urlImgError'=>'images/error.png',
		// Imagen de peligro
		'urlImgPeligro'=>'images/peligro.jpg',
		// Imagen de Ok
		'urlImgOk'=>'images/ok.jpg',
		// Logo Cabecera
		'logo_cabecera'=>'https://sbxa.loteriasantafe.gov.ar/app/CAS_Procesos/public/images/logo_tradicional.jpg',
		// Donde estoy parado
		'urlDestino'=>public_path().$ds."archivos".$ds,

		// Limite de ventas
		'urlLimites'=>"tmp_lv",
		// datos para el as/400
		'urlTemporalAS400'=>"destino_cas_as400_",
		// datos para prescriptos
        'urlTemporalPrescriptos'=>"destino_cas_prescriptos_",
		// datos para manuales
		'urlManuales'=>"https://sbxa.loteriasantafe.gov.ar/app/CAS_Procesos/public/archivos/exp/man",
		// datos para exportaciones
		'urlEnvioEXP'=>"https://sbxa.loteriasantafe.gov.ar/app/CAS_Procesos/public/archivos/exp/",
		// datos para bingos
		'urlEnvioBing'=>"https://sbxa.loteriasantafe.gov.ar/app/CAS_Procesos/public/archivos/exp/liq_boldt_bing_",
		// datos para raspaditas
		'urlEnvioInst'=>"https://sbxa.loteriasantafe.gov.ar/app/CAS_Procesos/public/archivos/exp/liq_boldt_inst_",
		// datos para telequino
		'urlEnvioTlk'=>"https://sbxa.loteriasantafe.gov.ar/app/CAS_Procesos/public/archivos/exp/rangos_tlk_",

		// Tmp Sin Procesar
		'urlTemporalSinProcesar'=>"temporal_sin_procesar_",
		// Tmp Consolidacion
		'urlTemporalConsolidacion'=>"temporal_consolidacion_",
		// Tmp Liquidaciones
		'urlLiquidaciones'=>"temporal_liquidaciones_",
		// Logs
		'urlCasLog'=>"CasLog",
		// Tmp Prescriptos
		'urlPrescriptos'=>"temporal_prescriptos_",
		// Tmp Caratulas
		'urlTemporalCaratula'=>"temporal_caratula_",
		// Tmp Resultados
		'urlTemporalResultados'=>"temporal_resultados_",
		// Datos CAMARAS (sin uso)
		'urlCamaras'=>"camaras",
		// Premios Pagados
		'urlPrePagados' => "prepagados",
		// Premios Pagados Otras Provincias
		'urlPrePagadosOtrProv' => "prepagados_otrprov",
		// Portales (interno, pac, suite)
		'url_i'=>"https://sbxa.loteriasantafe.gov.ar/interno",
		'url_a'=>"https://sbxa.loteriasantafe.gov.ar/pacb",
		'url_o'=>"https://sbxa.loteriasantafe.gov.ar/portal", 
		'url_s'=>"https://sbxa.loteriasantafe.gov.ar/suite/", 
		// Modulo de auditoria en el suite
		'modulo_aud'=>"index.php?module=SOR_aud_consolidacion&return_module=SOR_aud_consolidacion&action=DetailView&record=",
		
		// Envio extracto al AS/400 (obsoleto!)
		//'url_rest'=>"https://localhost:8080/restAsSuite/premios/informarExtracto/",
		//'url_rest'=>"https://jasper2.loteriasantafe.gov.ar:8080/restAsSuite/premios/informarExtracto/", // pendiente revision
		
		// para conexion al middleware de mensajeria (pubsub)
		'url_middleware'=>"https://sbxa.loteriasantafe.gov.ar:3009/api/publish/",
		'X-API-KEY'=>"supersecreto123",
		
		// Servidor de reportes
		'urlJasper'=>'https://sbxa.loteriasantafe.gov.ar/Ejecutar_Reportes2.php?ruta_reporte=/Reports/', // pendiente revision
		// Reporte de diferencias en LVD recibidos desde BG
		'urlReporteLVD'=>'PAC/Reporte_Ejecutivo/diferencias_recepcion_lvd&formato=PDF',
		
		);
?>
