<?php
namespace models;

	class AfectacionControlModelo extends \Eloquent {
		public $table='sor_rec_afe_ctr';
		protected $primaryKey = 'id_pgm_sorteo';
		public $timestamps = false;

		public function freshTimestamp(){
			return \Carbon\Carbon::now('America/Argentina/Buenos_Aires');
		}
		
	}

?>