<?php
namespace models;

	class ServidorFTPModelo extends \Eloquent {
		public $table='ftp';
		public $timestamps = false;
}

?>