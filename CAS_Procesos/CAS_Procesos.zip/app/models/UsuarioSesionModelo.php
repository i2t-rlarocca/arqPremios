<?php
namespace models;

	class UsuarioSesionModelo extends \Eloquent {
		// public $table='suitecrm_cas.session_usuario_v';
		public $table='session_usuario_v';
		public $timestamps = false;
}

?>
