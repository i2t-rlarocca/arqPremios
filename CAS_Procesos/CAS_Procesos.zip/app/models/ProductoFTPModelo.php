<?php
namespace models;

	class ProductoFTPModelo extends \Eloquent {
		public $table='producto_ftp';
		public $timestamps = false;
}

?>