<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/
/********************* agregados paneles y adicionales **************************/
Route::get('/ingresoPanelCuentaCorriente', function()
{
    $urlFull=$_SERVER["REQUEST_URI"];//URL::full();
	
	if(strstr($urlFull,'?')){
		/*en el caso de venir toda la URL encriptada usamos explode de ? para obtener fragmento con parametros*/
		$parametros= (explode("?",$urlFull));
		//Session::put("datos_ingreso",$parametros[1]);		
		Session::put("datos_ingreso",urldecode(base64_decode($parametros[1])));	
		\Log::info("datos_ingreso", array(Session::get("datos_ingreso")));
		
		return Redirect::to('/ingreso-panel');
	}else{
		return Redirect::to('/portal');
	}
	
});

// Route::get('/tramites', array('before'=>'existe_sesion','uses' => 'TramitesController@listarTramites'));

Route::get('/ingreso-panel', array('before'=>'control_acceso','uses' => 'CuentaCorrienteController@cargaUsuarioEnAppCtaCte'));
Route::get('/panel-principal', array('before'=>'control_acceso','uses'=>'CuentaCorrienteController@panelPrincipal'));
Route::get('/panel-comisiones', array('before'=>'control_acceso','uses'=>'CuentaCorrienteController@panelComisiones'));
Route::post('/carga-archivos-comisiones', array('uses'=>'CuentaCorrienteController@tratamientoComisiones'));
/****************************   Recepción presciptos ******************************/

Route::get('/panel-prescriptos', array('before'=>'control_acceso','uses'=>'PrescriptosController@panelPrescriptos'));
Route::post('/carga-archivos-prescriptos', array('uses'=>'PrescriptosController@tratamientoPrescriptos'));

/****************************   Recepción Debito y Credito Automatico ******************************/

Route::get('/panel-recepcion-deb-cred', array('before'=>'control_acceso','uses'=>'RecepcionDebCredController@panelRecepcionDebCred'));
Route::post('/carga-archivos-recepcion-deb-cred', array('uses'=>'RecepcionDebCredController@tratamientoRecepcionDebCred'));

/**********************Recepcion Pago Bancos*************************************************/

Route::get('/panel-recepcion-pagobco', array('before'=>'control_acceso','uses'=>'RegistroPagoBancosController@panelRecepcion_PagoBco'));
Route::post('/carga-archivos-pagobancos', array('uses'=>'RegistroPagoBancosController@tratamientoPagoBancos'));

/**********************IR: Recepcion Premios Pagados*************************************************/

Route::get('/panel-recepcion-prepagados', array('before'=>'control_acceso','uses'=>'RecepcionPrePagadosController@panelRecepcionPrePagados'));
//Route::post('/carga-archivos-prepagados', array('uses'=>'RecepcionPrePagadosController@tratamientoArchivo'));
Route::post('/carga-archivos-prepagados', array('uses'=>'RecepcionPrePagadosController@tratamientoArchivoPremPag'));

/****************************   Recepción liquidaciones ******************************/

Route::get('/recepcion-liquidaciones', array('before'=>'control_acceso','uses'=>'CuentaCorrienteController@panelLiquidaciones'));
Route::post('/carga-archivos-liquidaciones', array('uses'=>'CuentaCorrienteController@tratamientoLiquidaciones'));

/****************************   reproceso bi ******************************/
Route::get('/panel-reproceso-bi', array('before'=>'control_acceso','uses'=>'ReprocesoBIController@panelReprocesoBI'));
Route::post('/trata-reproceso-bi', array('uses'=>'ReprocesoBIController@tratamientoReprocesoBI'));
//'before'=>'existe_sesion',
/******************************** ORIGINAL ****************************/
/*	exportacion	*/
Route::post('/paquetes-manuales', array('uses'=>'ExportacionesController@paquetesExportacion'));
Route::get('/panel-exportar/manuales', array('before'=>'control_acceso','uses'=>'ExportacionesController@panelExportacion'));
Route::post('/genera-exportacion', array('uses'=>'ExportacionesController@generaExportacion'));

/*	exportacion	UIF */
Route::post('/paquetes-enviouif', array('uses'=>'ExportacionesController@paquetesExportacionUIF'));
Route::get('/panel-exportar/uif', array('before'=>'control_acceso','uses'=>'ExportacionesController@panelExportacion'));
//Route::post('/genera-exportacion-uif', array('uses'=>'ExportacionesController@generaExportacionUIF'));

/*	exportacion	AFIP */
Route::post('/paquetes-envioafip', array('uses'=>'ExportacionesController@paquetesExportacionAFIP'));
Route::get('/panel-exportar/afip', array('before'=>'control_acceso','uses'=>'ExportacionesController@panelExportacion'));
//Route::post('/genera-exportacion-afip', array('uses'=>'ExportacionesController@generaExportacionAFIP'));

/*	exportacion	RESERVA BILLETES DE LOTERIA */
Route::post('/paquetes-reserva-billetes-loteria',array('uses'=>'ExportacionesController@paquetesExportacion'));
Route::get('/panel-exportar/reserva-loteria', array('before'=>'control_acceso','uses'=>'ExportacionesController@panelExportacion'));
Route::post('/genera-exportacion-reserva-billetes-loteria', array('uses'=>'ExportacionesController@generaExportacion'));

/*	exportacion	conceptos liquidados a boldt */
/*bingos*/
Route::get('/panel-exportar/conceptos-liquidados-bing', array('before'=>'control_acceso','uses'=>'ExportacionesController@panelExportacion'));
/*instantaneos*/
Route::get('/panel-exportar/conceptos-liquidados-inst', array('before'=>'control_acceso','uses'=>'ExportacionesController@panelExportacion'));
/*exportacion telekino*/
Route::get('/panel-exportar/panel-exportacion-rangos-cupones-telekino', array('before'=>'control_acceso','uses'=>'ExportacionesController@panelExportacion'));
/*************************************************************/
/* Ingreso desde el portal			 						 */
/*************************************************************/
Route::get('/ingresoCuentaCorriente', function()
{
    $urlFull=$_SERVER["REQUEST_URI"];//URL::full();
	if(strstr($urlFull,'?')){
		/*en el caso de venir toda la URL encriptada usamos explode de ? para obtener fragmento con parametros*/
		$parametros= (explode("?",$urlFull));
		
		Session::put("datos_ingreso",urldecode(base64_decode($parametros[1])));		
		$url = urldecode(base64_decode($parametros[1]));		
		
		// logueo
		\Log::info("paso por ingresoCuentaCorriente - voy a carga-ingreso" . $url);
		return Redirect::to('/carga-ingreso');
	}else{
		\Log::info("paso por ingresoCuentaCorriente - voy a portal" . $url);
		return Redirect::to('/portal');
	}
	
});
/**Para redireccionar al portal**/
Route::get('/portal', function(){
        if(Session::has('usuarioLogueado')){
		$letra_portal=Session::get('usuarioLogueado.letra_portal');
	}else{
		Session::put('mensaje_acceso',"Su sesión ha finalizado.");
		return Redirect::to('/acceso-no-autorizado');
	}
	if($letra_portal=="'o'")
	return Redirect::to(Config::get('ctacte_config/config.url_o'));
	else if($letra_portal=="'i'")
		return Redirect::to(Config::get('ctacte_config/config.url_i'));
	else if($letra_portal=="'a'")
		return Redirect::to(Config::get('ctacte_config/config.url_a'));	
});

/**Para cuando por alguna razón el acceso no es permitido**/
Route::get('/acceso-no-autorizado',function(){
	$mensaje=Session::get('mensaje_acceso');
	Session::forget('mensaje_acceso');
	return View::make('cuenta_corriente.accesoNegado', array('mensaje'=>$mensaje));
});

/** Para controlar la sesión */
Route::get('/control_sesion', array('uses' => 'controllers\\UsuarioController@controlSesion'));
Route::get('/control_sesion_pv',array('uses' =>'controllers\\UsuarioController@controlSesionPrimeraVez'));

Route::get('/carga-ingreso', array('uses' => 'CuentaCorrienteController@cargaUsuarioEnApp'));
Route::get('/panel-alertas', array('before'=>'control_acceso','uses'=>'CuentaCorrienteController@paneles'));
Route::post('/carga-archivos-transaccion', array('uses'=>'CuentaCorrienteController@obtenerArchivos'));
Route::post('/carga-panel-transaccion', array('uses'=>'CuentaCorrienteController@cargarPanelTransaccion'));
Route::post('/publicar', array('uses'=>'CuentaCorrienteController@publicar'));
Route::post('/carga-archivos-caratula', array('uses'=>'CuentaCorrienteController@obtenerArchivosCaratula'));
Route::post('/carga-archivos-resultados', array('uses'=>'CuentaCorrienteController@obtenerArchivosResultados'));
//'before'=>'existe_sesion',

/******************************************* recepcion premios bingos ****************************************/

Route::get('/panel-recepcion-premios-bingos', array('before'=>'control_acceso','uses'=>'RecepcionPremBingController@paneles'));
Route::post('/carga-archivos-transaccion-bingos', array('uses'=>'RecepcionPremBingController@obtenerArchivos'));
Route::post('/carga-panel-transaccion-bingos', array('uses'=>'RecepcionPremBingController@cargarPanelTransaccion'));
Route::post('/publicar-bingos', array('uses'=>'RecepcionPremBingController@publicar'));
Route::post('/carga-archivos-caratula-bingos', array('uses'=>'RecepcionPremBingController@obtenerArchivosCaratula'));
Route::post('/carga-archivos-resultados-bingos', array('uses'=>'RecepcionPremBingController@obtenerArchivosResultados'));

/******************************************* recepcion casinos ****************************************/

Route::get('/panel-recepcion-casinos', array('before'=>'control_acceso','uses'=>'RecepcionCasinosController@paneles'));
Route::post('/carga-archivos-transaccion-casinos', array('uses'=>'RecepcionCasinosController@obtenerArchivos'));
Route::post('/carga-panel-transaccion-casinos', array('uses'=>'RecepcionCasinosController@cargarPanelTransaccion'));
Route::post('/publicar-casinos', array('uses'=>'RecepcionCasinosController@publicar'));
Route::post('/carga-archivos-caratula-casinos', array('uses'=>'RecepcionCasinosController@obtenerArchivosCaratula'));
Route::post('/carga-archivos-resultados-casinos', array('uses'=>'RecepcionCasinosController@obtenerArchivosResultados'));

/******************		Recepción cámaras		***********************************/
Route::get('/panel-camaras', array('before'=>'control_acceso','uses'=>'CamarasController@panelRecepcionCamaras'));
Route::post('/carga-archivo-camaras', array('uses'=>'CamarasController@tratamientoCamaras'));

/********************** limites de venta *********************************/
Route::get('/panel-limites-venta', array('before'=>'control_acceso','uses'=>'LimitesVentaController@panelLimitesVenta'));
Route::post('/carga-archivos-limites', array('uses'=>'LimitesVentaController@tratamientoLimitesVenta'));

/********************** premios pagados otras provincias *********************************/
Route::get('/panel-recepcion-premios-otras-provincias', array('before'=>'control_acceso','uses'=>'RecepcionPremPagOtrProvController@panelRecepcionPrePagadosOtrProv'));
//Route::post('/carga-archivos-transaccion-premios-otras-provincias', array('uses'=>'RecepcionPremPagOtrProvController@tratamientoArchivoPremPagOtrProv'));
Route::post('/carga-archivos-prepagados-otr-prov', array('uses'=>'RecepcionPremPagOtrProvController@tratamientoArchivoPremPagOtrProv'));
Route::post('/paquetes-prem-otras-prov', array('uses'=>'RecepcionPremPagOtrProvController@paquetesPremiosOtrasProv'));
