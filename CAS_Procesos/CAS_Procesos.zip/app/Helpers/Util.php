<?php
namespace Helpers;
class Util {
	//MENSAJES ERROR VARIOS 
  public $mensaje_ext_error = "El archivo '%s' no es .zip, Por favor intentelo de nuevo.";
  public $mensaje_formato_error = "El '%s' no tiene el formato de nombre correcto";
  public $mensaje_error_al_subir = "Ocurrio un problema subiendo el archivo %s. Intentelo de nuevo";
  

	/**
    * Función para agrupar un arreglo en base a una clave
    **/
    public function groupArray($array,$groupkey)
    {
     if (count($array)>0)
     {
		// \Log::info('util keys array', array($array));
		// \Log::info('util keys array', array($array[0]));

		$keys = array_keys($array[0]);
        $removekey = array_search($groupkey, $keys);        
        if ($removekey===false)
            return array("Clave \"$groupkey\" no existe");
        else
            unset($keys[$removekey]);
        $groupcriteria = array();
        $return=array();
        foreach($array as $value)
        {
            $item=null;
            foreach ($keys as $key)
            {
                $item[$key] = $value[$key];
            }
            $busca = array_search($value[$groupkey], $groupcriteria);
            if ($busca === false)
            {
                $groupcriteria[]=$value[$groupkey];
                $return[]=array($groupkey=>$value[$groupkey],'grupodatos'=>array());
                $busca=count($return)-1;
            }
            $return[$busca]['grupodatos'][]=$item;
        }
        return $return;
     }
     else
        return array();
    }


  public function controlZip($archivo, $destino, $archivos, $idJuego,$aniomes='1900-01-01', $transaccion=0)
  {    
	if(is_object ( $archivo)){
		$filename = $archivo->getClientOriginalName();
		$type = $archivo->getMimeType();
	}else{
		$filename = basename($archivo);
		$mime=finfo_open(FILEINFO_MIME_TYPE);
		$type = finfo_file($mime, $archivo);
		finfo_close($mime);
	}
    $name = explode(".", $filename);
    $message ="";
    $accepted_types = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed');
    //controlo que sea un zip
    foreach($accepted_types as $mime_type) {
      if($mime_type == $type) {
        $okay = true;
        break;
      } 
    }

    // CHEQUEO DE LA EXTENSION
    foreach ($archivos as $datosArchivo) {
      if($datosArchivo['id_padre']=='')
        $archivo_zip=$datosArchivo;
    }
    //agregamos el . a la extensión y chequeamos
    $name[1]=".".$name[1];
    $continue = preg_match("/^".$archivo_zip['extension'], $name[1]) ? true : false;
    if(!$continue) {
      $resultado['mensaje'] = sprintf($this->mensaje_ext_error, $filename);
      $resultado['exito']=false;
      return $resultado;
    }elseif ($this->formato_nombre($archivo_zip,$filename,1, $idJuego)['exito']){
      $ds=DIRECTORY_SEPARATOR;
      $target_path = $destino.$filename; //$destino.$ds.$filename; 
	  $nombrePadre = $filename;
	if(is_object($archivo)){
		$movio=move_uploaded_file($archivo, $target_path);
	}else{
		$movio=true;
	}
	  \Log::info("Util.php - move_uploaded_file - archivo ->$archivo<-, target_path ->$target_path<-");
	
      if($movio) {
	    $zip = new \ZipArchive();
        $x = $zip->open($target_path);
        if ($x === true) {
          $todosOK=0;
          //extractTo: descarga toda la ruta completa $zip->extractTo($destino); 
          $cantidad_arch = $zip->numFiles;
  		  \Log::info("Util.php - move_uploaded_file - cant archivos en zip ->$cantidad_arch<-");
		  
		
		  
		  
          for($i = 0; $i < $cantidad_arch; $i++) { 
            $filename = $zip->getNameIndex($i);
			\Log::info("Util.php - move_uploaded_file - archivos en zip - Nro. $i: $filename");
            $fileinfo = pathinfo($filename);
			// \Log::info('fileinfo',array($fileinfo));
			try {
				$extension=".".$fileinfo['extension'];
			}
			catch (\Exception $e) {
				$extension="";
			}
			$patron ='/^[[:alnum:]]+\.pdf+$/i';
			
			if (($idJuego==4 || $idJuego==13 || $idJuego==30) && $transaccion==1){//quini, brinco, pf //transaccion="resultados"
				$match=preg_match($patron, $fileinfo['basename']);
				if($match){
					$nombreOk = $this->formato_nombre_pdf($fileinfo['basename']);
				}else{
					$nombreOk = $this->formato_nombre($archivos,$fileinfo['basename'],0, $idJuego);
				}
			}else{
				$nombreOk = $this->formato_nombre($archivos,$fileinfo['basename'],0, $idJuego);
				\Log::info('nombre',array($nombreOk));
				
				}
            if($nombreOk['exito']){
              $resultado['mensaje']=$nombreOk['mensaje'];
              $resultado['exito']=true;
              $todosOK++;
            }else{
              $resultado['mensaje']=$nombreOk['mensaje']." en el zip de: ".$nombrePadre;
              $resultado['exito']=false;
            }

          }

         $sigo=0;
		
          if(($idJuego==4 && $todosOK > $cantidad_arch && $transaccion==1) or ($idJuego!=4 && $todosOK >=$cantidad_arch && $transaccion==1) or ($todosOK >=$cantidad_arch)){
			$sigo=1;
		  }
		  if($sigo){
			   \Log::info("controlZip - sigo:", array($sigo));
			   \Log::info("controlZip - numFiles:", array($zip->numFiles));
			       $zip->extractTo($destino);
            // for($i = 0; $i < $zip->numFiles; $i++) { 
			 // \Log::info("controlZip - i:", array($i));
              // $filename = $zip->getNameIndex($i);
              // $fileinfo = pathinfo($filename);
              // extraemos todos los archivos sin anidarlos en carpetas
			   // \Log::info("controlZip - target_path:", array($target_path));
			   // \Log::info("controlZip - filename:", array($filename));
			   
			   // \Log::info("controlZip - destino:", array($destino));
			   // \Log::info("controlZip - basename:", array($fileinfo['basename']));
			   // \Log::info("controlZip - parametro 1:", array("zip://".$target_path."#".$filename));
			   // \Log::info("controlZip - parametro 2:", array($destino.$ds.$fileinfo['basename']));
			  
              // copy("zip://".$target_path."#".$filename, $destino.$fileinfo['basename']);
            // }            
            $zip->close();
            return $resultado;
          }else{
            $zip->close();
            unlink($target_path);
            return $resultado;
          }
        }else{
			$message = sprintf($this->mensaje_ext_error,$filename);
			$resultado['mensaje']=$message;
			$resultado['exito']=false;
			return $resultado;
		}
      

      }else{  
        $message = sprintf($this->mensaje_error_al_subir,$filename);
        $resultado['mensaje']=$message;
        $resultado['exito']=false;
        return $resultado;
      }
    }else{
      $message = sprintf($this->mensaje_formato_error,$filename);
      $resultado['mensaje']=$message;
      $resultado['exito']=false;
      return $resultado;
    }
  }


 function formato_nombre_pdf($filename){
	$patron ='/^[[:alnum:]]+\.pdf+$/i';

      $match=preg_match($patron, $filename);
      if($match){
        $resultado['mensaje']='Nombre OK';
        $resultado['exito']=true;
        return $resultado;        
      }else{
        $resultado['mensaje']='El nombre no tiene el patrón correcto '.$filename;
        $resultado['exito']=false;
        return $resultado;
      }
 
 }

  function formato_nombre($archivos,$filename,$padre, $idJuego) {
    if($padre == 1) {
      $patron ="/^".$archivos['nombre'];

      $match=preg_match($patron, $filename);

	  \Log::info("util.php - formato nombre padre = 1 - patron: ".$patron." - filename: ".$filename." - match: ".$match);
	  //\Log::info("util.php - formato nombre - filename ", array($filename));
	  
      if($match){
        $resultado['mensaje']='Nombre OK';
        $resultado['exito']=true;
        return $resultado;        
      }else{
		\Log::info("util.php - formato nombre padre = 1 - error de nombre: ".'El nombre no tiene el patrón correcto: '.$filename);

		$resultado['mensaje']='El nombre no tiene el patrón correcto'.$filename;
        $resultado['exito']=false;
        return $resultado;
      }
    }else{
      foreach ($archivos as $archivo) {
		\Log::info("util.php - formato nombre padre = 1 - padre?: ".$archivo['id_padre']);
        if($archivo['id_padre']!=''){
          $archivosHijos[] =$archivo;
        }
      }

      //controlo que esté el hijo
      $existeHijo=0 ;
      foreach ($archivosHijos as $hijo) {
        $patron ="/^".$hijo['nombre'];//"/^[[:alpha:]]{1}+\d{9}+\.+[[:alpha:]]{3}+$/i"; //
        $match=preg_match($patron, $filename);
		\Log::info("util.php - formato nombre padre = 1 - patron: ".$patron." - filename: ".$filename." - match: ".$match);
        if($match){
          $existeHijo=1;
          break;
        }
      }
      if($existeHijo){        
        $resultado['mensaje']='Nombre OK.';
        $resultado['exito']=true;
        return $resultado;
      }else{
        $resultado['mensaje']='El nombre no tiene el patrón correcto: '.$filename;
        $resultado['exito']=false;
        return $resultado;
      }
    }
  }

   function copiarPDF($carpetaOrigen, $carpetaDestino){
	$ds=DIRECTORY_SEPARATOR;
	//obtenemos todos los archivos de la carpeta origen
	$ficheros = scandir($carpetaOrigen);
	foreach ($ficheros as $fichero) {
	
		$extension = explode(".",$fichero);
		//if(strtoupper($extension[1])=='PDF'){
                if(strcasecmp($extension[1],'pdf')==0){
			//creo la carpeta si no existe
			if(!is_dir($carpetaDestino) && !file_exists($carpetaDestino)){
			  \File::makeDirectory($carpetaDestino, 0777, true);
			}
			//copio el pdf
			rename($carpetaOrigen.$ds.$fichero, $carpetaDestino.$fichero);
		}
	}
	
  }
  
  /****************************
  * Función para desencriptar *
  ******************************/
  function decrypt($string, $key) {

       $result = '';
       $string = base64_decode($string);
       for($i=0; $i<strlen($string); $i++) {
          $char = substr($string, $i, 1);
          $keychar = substr($key, ($i % strlen($key))-1, 1);
          $char = chr(ord($char)-ord($keychar));
          $result.=$char;
       }
       return $result;
    }
  
  function encrypt($string, $key) {
     $result = '';
     for($i=0; $i<strlen($string); $i++) {
      $char = substr($string, $i, 1);
      $keychar = substr($key, ($i % strlen($key))-1, 1);
      $char = chr(ord($char)+ord($keychar));
      $result.=$char;
     }
     return base64_encode($result);
  }

  /*****************************************
  * Función que arma el nombre del archivo
  ******************************************/
  function armaNombreArchivo($juego, $sorteo, $tipo, $datosArchivo){
	$nombreEjemplo="";
	
	switch ($tipo){
		case "CT"://carátula
				$sorteo=$this->zerofill($sorteo,6);
				switch($juego){
					case 4:
						$nombreEjemplo="POZ04".$sorteo.".zip";
						break;
					case 13:
						$nombreEjemplo="POZ13".$sorteo.".zip";
						break;
					case 30:
						$nombreEjemplo="POZ30".$sorteo.".zip";
						break;
					case 49:
						$nombreEjemplo="POZ49".$sorteo.".zip";
						break;
					case 50:
						$nombreEjemplo="POZ50".$sorteo.".zip";
						break;
					case 72:
						$nombreEjemplo="POZ72".$sorteo.".zip";
						break;
				}
			break;
		case "AP"://apuestas
				$sorteo=$this->zerofill($sorteo,5);
				switch($juego){
					case 1:
						$nombreEjemplo="TO".$sorteo."W.ZIP";
						break;
					case 2:
						$nombreEjemplo="QN".$sorteo."W.ZIP";
						break;
					case 3:
						$nombreEjemplo="QV".$sorteo."W.ZIP";
						break;
					case 4:
						$nombreEjemplo="Q6".$sorteo."W.ZIP";
						break;
					case 5:
						$nombreEjemplo="LT".$sorteo."W.ZIP";
						break;
					case 8:
						$nombreEjemplo="QM".$sorteo."W.ZIP";
						break;
					case 13:
						$nombreEjemplo="BR".$sorteo."W.ZIP";
						break;
					case 29:
						$nombreEjemplo="L5".$sorteo."W.ZIP";
						break;
					case 30:
						$nombreEjemplo="PM".$sorteo."W.ZIP";
						break;
					case 39:
						$nombreEjemplo="QX".$sorteo."W.ZIP";
						break;
					case 49:
						$nombreEjemplo="QA".$sorteo."W.ZIP";
						break;
					case 50:
						$nombreEjemplo="BL".$sorteo."W.ZIP";
						break;
					case 56:
						$nombreEjemplo="QD".$sorteo."W.ZIP";
						break;
					case 72:
						$nombreEjemplo="BC".$sorteo."W.ZIP";
						break;
					case 73:
						$nombreEjemplo="TK".$sorteo."W.ZIP";
						break;
				}
			break;
		case "AF"://afectaciones
				$nombreEjemplo="Axxxxxxxxx.zip";
			break;
		case "TT"://totobingo
				$sorteo=$this->zerofill($sorteo,5);
				$nombreEjemplo="TB_PREMIOS_".$sorteo.".txt";
			break;
		case "TK"://telekino
				//$sorteo=$this->zerofill($sorteo,5);
				$nombreEjemplo="santafe.zip";
			break;
		case "TM"://maradona
				$sorteo=$this->zerofill($sorteo,6);
				$nombreEjemplo="PRMAR".$sorteo."-dat.zip";
				//$nombreEjemplo="santafe.zip";
			break;
		case "DR"://premios con retenciones
				$sorteo=$this->zerofill($sorteo,5);
				switch($juego){
					case 1:
						$nombreEjemplo="TOR".$sorteo.".ZIP";
						break;
					case 4:
						$nombreEjemplo="Q6R".$sorteo.".ZIP";
						break;
					case 5:
						$nombreEjemplo="LTR".$sorteo.".ZIP";
						break;
					case 13:
						$nombreEjemplo="BRR".$sorteo.".ZIP";
						break;
					case 29:
						$nombreEjemplo="L5R".$sorteo.".ZIP";
						break;
					case 30:
						$nombreEjemplo="PMR".$sorteo.".ZIP";
						break;
					case 72:
						$nombreEjemplo="CLR".$sorteo.".ZIP";
						break;
				}
			break;
		case "PR"://premios
				$sorteo=$this->zerofill($sorteo,5);
				switch($juego){
					case 1:
						$nombreEjemplo="TOP".$sorteo.".ZIP";
						break;
					case 2:
						$nombreEjemplo="QNP".$sorteo.".ZIP";
						break;
					case 3:
						$nombreEjemplo="QVP".$sorteo.".ZIP";
						break;
					case 4:
						$nombreEjemplo="Q6P".$sorteo.".ZIP";
						break;
					case 5:
						$nombreEjemplo="LTP".$sorteo.".ZIP";
						break;
					case 8:
						$nombreEjemplo="QMP".$sorteo.".ZIP";
						break;
					case 13:
						$nombreEjemplo="BRP".$sorteo.".ZIP"; // MM cambia de BRC a BRP
						break;
					case 29:
						$nombreEjemplo="L5P".$sorteo.".ZIP";
						break;
					case 30:
						$nombreEjemplo="PMP".$sorteo.".ZIP";
						break;
					case 39:
						$nombreEjemplo="QXP".$sorteo.".ZIP";
						break;
					case 49:
						$nombreEjemplo="QAP".$sorteo.".ZIP"; // MM cambia de QAC a QAP
						break;
					case 50:
						$nombreEjemplo="BLP".$sorteo.".ZIP";
						break;
					case 72:
						$nombreEjemplo="CLP".$sorteo.".ZIP";
						break;
				}
			break;
		// agregado MM 07-06-2017
			case "PC"://premios completo
				$sorteo=$this->zerofill($sorteo,6);
				// $nombreEjemplo= "PR".str_pad($juego, 2, "0", STR_PAD_LEFT).$sorteo.".ZIP"; -- para probar.    esto reemplaza a todos los case por juego y funcionaría para juegos futuros
				switch($juego){
					case 1:
						$nombreEjemplo="PR01".$sorteo.".ZIP";
						break;
					case 2:
						$nombreEjemplo="PR02".$sorteo.".ZIP";
						break;
					case 3:
						$nombreEjemplo="PR03".$sorteo.".ZIP";
						break;
					case 4:
						$nombreEjemplo="PR04".$sorteo.".ZIP";
						break;
					case 5:
						$nombreEjemplo="PR05".$sorteo.".ZIP";
						break;
					case 8:
						$nombreEjemplo="PR08".$sorteo.".ZIP";
						break;
					case 13:
						$nombreEjemplo="PR13".$sorteo.".ZIP";
						break;
					case 29:
						$nombreEjemplo="PR29".$sorteo.".ZIP";
						break;
					case 30:
						$nombreEjemplo="PR30".$sorteo.".ZIP";
						break;
					case 39:
						$nombreEjemplo="PR39".$sorteo.".ZIP";
						break;
					case 49:
						$nombreEjemplo="PR24".$sorteo.".ZIP";
						break;
					case 50:
						$nombreEjemplo="PR50".$sorteo.".ZIP";
						break;
					case 56:
						$nombreEjemplo="PR56".$sorteo.".ZIP";
						break;
					case 72:
						$nombreEjemplo="PR72".$sorteo.".ZIP";
						break;
				}
			break;		
		case "RT"://resultados
				$sorteo=$this->zerofill($sorteo,6);
				switch($juego){
					case 4:
						$nombreEjemplo="PRE04".$sorteo.".ZIP";
						break;
					case 13:
						$nombreEjemplo="PRE13".$sorteo.".ZIP";
						break;
					case 30:
						$nombreEjemplo="PRE30".$sorteo.".ZIP";
						break;
					case 50:
						$nombreEjemplo="PRE50".$sorteo.".ZIP";
						break;
					case 72:
						$nombreEjemplo="PRE72".$sorteo.".ZIP";
						break;
				}
			break;
		case "SU"://sueldos
				$sorteo=$this->zerofill($sorteo,5);
				$nombreEjemplo="SUE13".$sorteo.".zip";
			break;
		case "EX"://extractos
			$sorteo=$this->zerofill($sorteo,5);
			switch($juego){
					case 4:
						$nombreEjemplo="Q6C".$sorteo.".ZIP";
						break;
					case 13:
						$nombreEjemplo="BRC".$sorteo.".ZIP";
						break;
				}
		break;
		// agregado MM 12/10/2017
		case "VT"://ventas totales
				$sorteo=$this->zerofill($sorteo,5);
				switch($juego){
					case 13:
						$nombreEjemplo="BR".$sorteo."P.ZIP";
						break;
					case 30:
						$nombreEjemplo="PM".$sorteo."P.ZIP";
						break;
					case 4:
						$nombreEjemplo="Q6".$sorteo."P.ZIP";
						break;
				}
		break;
		// agregado MM 12/10/2017
		case "VS"://ventas totales quini 6
				$sorteo=$this->zerofill($sorteo,5);
				switch($juego){
					case 4:
						$nombreEjemplo="Q6".$sorteo."P.ZIP";
						break;
				}
		break;
	}
	return $nombreEjemplo;
  }
  
  public function rrmdir($path) {
		if(is_dir($path)){
			// Remove a dir (all files and folders in it)
			$i = new DirectoryIterator($path);
			foreach($i as $f) {
				if($f->isFile()) {
					unlink($f->getRealPath());
				} else if(!$f->isDot() && $f->isDir()) {
					$this->rrmdir($f->getRealPath());
					rmdir($f->getRealPath());
				}
			}
		}
	}
	
	/*Función para completar con ceros a la izquierda*/
	function zerofill($valor, $longitud){
		$res = str_pad($valor, $longitud, '0', STR_PAD_LEFT);
		return $res;
	}
}
?>