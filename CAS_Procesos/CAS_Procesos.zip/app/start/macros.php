<?php
Response::macro('liquidacion_apu_com', function($datos){
	$camposTransaccion='';	
	if($datos['puedeProcesar']){
		if(array_key_exists('archivosPrevios', $datos)){

			if($datos['archivosPrevios']['existenArchivosPrevios']){
				$archivos=$datos['archivosPrevios']['archivos'];

				$archivosApuestas=[];
				$archivosAfectaciones=[];
				$archivosPremios=[];
				/*$archivosCaratula=[];
				$archivosResultados=[];
				$archivosSueldos=[];*/
				foreach ($archivos as $archivo) {
					if(strcasecmp($archivo['tipo_archivo'], 'apuestas')==0){
						array_push($archivosApuestas, $archivo['nombre_archivo']);
					}
					if(strcasecmp($archivo['tipo_archivo'], 'afectaciones')==0){
						array_push($archivosAfectaciones, $archivo['nombre_archivo']);
					}
					if(strcasecmp($archivo['tipo_archivo'], 'premios')==0){
						array_push($archivosPremios, $archivo['nombre_archivo']);
					}				
			
				}
				
			}	
		}
		
		if($datos['id_estado']!=50){//50 publicado
	\Log::info('datos[nombreFiles]', array($datos['nombreFiles']));
			foreach ($datos['nombreFiles'] as $archivoApedir) {
				
				$requerido=($archivoApedir['requerido']=="R")?"required":"";

				if(strpos($archivoApedir['nombre'], 'afe')!== false && !empty($archivosAfectaciones)){
					foreach ($archivosAfectaciones as $nombreArchivo) {
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' accept=".zip" title='.$archivoApedir['nombre_ejemplo'].'>';										
						}else{
							$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' accept=".zip" title='.$archivoApedir['nombre_ejemplo'].'>';										
						}
					}
				}else if(strpos($archivoApedir['nombre'], 'apu')!== false && !empty($archivosApuestas)){
					foreach ($archivosApuestas as $archivo) {
						foreach ($archivo as $nombreArchivo) {
							if(strcasecmp($requerido, "required")==0){
								$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required ='.$requerido.' accept=".zip" title='.$archivoApedir['nombre_ejemplo'].'>';										
							}else{
								$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' accept=".zip" title='.$archivoApedir['nombre_ejemplo'].'>';										
							}
						
							$camposTransaccion.='<span id="prev_'.$archivoApedir['nombre'].'">Actualmente cargado: '.$nombreArchivo.'</span>';										
							$camposTransaccion.='</br><span id="span_reprocesar"><input type="checkbox" name="chk_reprocesar_apu" id="chk_reprocesar_apu" tabindex="9" /><label for="chk_reprocesar_apu">Reprocesar apuestas</label></span>';										
						}
					}
				}else if(strpos($archivoApedir['nombre'], 'pre')!== false  && !empty($archivosPremios)){
					foreach ($archivosPremios as $nombreArchivo) {
						if(strcasecmp($requerido, "required")==0)
							$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' accept=".zip" title='.$archivoApedir['nombre_ejemplo'].'>';										
						else
							$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' accept=".zip" title='.$archivoApedir['nombre_ejemplo'].'>';										

					}					
				}else if(strpos($archivoApedir['nombre'], 'dr')!== false  && !empty($archivosPremios)){//retenciones
					foreach ($archivosPremios as $nombreArchivo) {
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' accept=".zip" title='.$archivoApedir['nombre_ejemplo'].'>';										
						}else{
							$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' accept=".zip" title='.$archivoApedir['nombre_ejemplo'].'>';										
						}
					}
				}else if(strpos($archivoApedir['nombre'], 'pc')!== false  && !empty($archivosPremios)){//retenciones
					foreach ($archivosPremios as $nombreArchivo) {
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' accept=".zip" title='.$archivoApedir['nombre_ejemplo'].'>';										
						}else{
							$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' accept=".zip" title='.$archivoApedir['nombre_ejemplo'].'>';										
						}
					}
				}else{	
					if(strcasecmp($requerido, "required")==0)	
						$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' title='.$archivoApedir['nombre_ejemplo'].'>';										
					else
						$camposTransaccion.='<input type="file" class="filestyle apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' title='.$archivoApedir['nombre_ejemplo'].'>';										
				}
			}
			$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
			foreach ($datos['botones'] as $btn) { 
				$camposTransaccion.='<input type="button" id='.$btn['id_btn'].' class="btn btn-primary" value='.$btn['value_btn'].' />';	
			}
			$camposTransaccion.='</div>';
			
		}else{
			$camposTransaccion.='<div class="col-xs-2 col-sm-7 col-md-12 col-lg-12"><h1>No quedan transacciones pendientes para el sorteo</h1></div>';	
		}
	}else{
		$camposTransaccion.='<div class="col-xs-2 col-sm-7 col-md-12 col-lg-12" id="no_procesar"><h1>No puede procesar sin antes terminar el sorteo anterior.</h1></div>';
	}
 	return $camposTransaccion;
});



Response::macro('tablaPrimerPanel', function($datos){
	//creo las tablas con los sorteos 
	$tablas='<caption class="text-left"><strong><h4>'.$datos['titulo_tabla'].'</h4></strong></caption>';
	$tablas.='<table class="table table-hover" id='.$datos['id_tabla'].'>';
	$tablas.='<tbody id='.$datos['id_body'].'>';	//	
	
	foreach ($datos['dia'] as $sorteo) {
		$tablas.='<tr id='.$sorteo['idPgmSorteo'].'>';
		$fecha = new DateTime($sorteo['fecha']);
	    $tablas.='<td id="fecha_sorteo">'.$fecha->format('d/m').'</td>';
	    $tablas.='<td id="nombre_juego">'.$sorteo['nombre_juego'].'</td>';
	    $tablas.='<td id="nro_sorteo">'.$sorteo['nroSorteo'].'</td>';
	    if($sorteo['idEstado']==50 && !in_array($sorteo['idEstado'], array('10','20','30','40')) && $sorteo['idEstado']!=0) //strpos ( $sorteo['de_estado'], 'pendiente')===false && strpos ( $sorteo['de_estado'], 'sortear')===false)
	    	$tablas.='<td id="icono_estado"><img id="im_estado" src="images/ok.jpg" alt="" style="height:14px;margin:0.6em;"></td>';
	    else if(in_array($sorteo['idEstado'], array('10','20','30','38','40')))
	    	$tablas.='<td id="icono_estado"><img id="im_estado" src="images/peligro.jpg" alt="" style="height:14px;margin:0.6em;"></td>';
	    else if($sorteo['idEstado']==0)
	    	$tablas.='<td id="icono_estado"></td>';
	    else
	    	$tablas.='<td id="icono_estado"><img src="images/error.png" alt="" style="height:14px;margin:0.6em;"></td>';
	    $tablas.='<td class="hidden" id="id_estado">'.$sorteo['idEstado'].'</td>';
	    $tablas.='<td id="mensaje_estado">'.$sorteo['de_estado'].'</td>';
	    $fechaPresc = new DateTime($sorteo['fechaHoraPrescripcion']);
	    $fechaProx = new DateTime($sorteo['fechaHoraProximo']);
		$fechaSorteo=new DateTime($sorteo['fecha']);
	    $tablas.='<td class="hidden" id="fecha_prescripcion">'.$fechaPresc->format("d/m/Y").'</td>';
	    $tablas.='<td class="hidden" id="fecha_proximo">'.$fechaProx->format("d/m/Y").'</td>';
	    $tablas.='<td class="hidden" id="id_juego">'.$sorteo['idJuego'].'</td>';
	    $tablas.='<td class="hidden" id="formato_procesamiento">'.$sorteo['formato_procesamiento'].'</td>';
	    $tablas.='<td class="hidden" id="sorteo">'.$sorteo['nroSorteo'].'</td>';
		$tablas.='<td class="hidden" id="fecha">'.$fechaSorteo->format("Y-m-d").'</td>';
	    $tablas.='</tr>';
	}
		     
		      
	$tablas.='</tbody>';
	$tablas.='</table><br>';
	
    return $tablas;
});

Response::macro('panelResultado',function($mensaje){
	$panel ='<div class="alert alert-danger" role="alert">';
	$panel .='<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>';
	$panel .='<span class="sr-only">Resultado:</span>';
	  $mensaje;
	$panel .='</div>';
	return $panel;
});

Response::macro('panelComisiones',function($datos, $periodo){
	$camposTransaccion="";
	if(strlen($periodo)>6){
		$camposTransaccion.='<div class="col-xs-2 col-sm-7 col-md-12 col-lg-12" align="center"><h2>'.$periodo.'</h2></div>'; 
	}else{
		$camposTransaccion="";
		$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">'; 
			$camposTransaccion.="<label for='periodo' id='lperiodo' class='control-label col-xs-3 col-sm-3 col-md-3 col-lg-3'>Período:</label>";
			$camposTransaccion.='<div class="col-xs-6 col-sm-2 col-lg-6">';
				$camposTransaccion.="<input type='text' name='periodo' id='id_periodo' class='form-control col-xs-3' maxlength='6' data-toggle='tooltip' text-align='right' value='".$periodo."'/>";
			$camposTransaccion.='</div>';				
		$camposTransaccion.='</div>';

		foreach ($datos as $archivoApedir) {			
				$requerido=($archivoApedir['requerido']=="R")?"required":"";
				if(strpos($archivoApedir['nombre'], 'com')!== false){
					$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">';
					$camposTransaccion.="<label for='comisiones_adicionales' id='lcomisiones' class='control-label col-xs-5 col-lg-3'>Comisiones Adicionales:</label>";
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="A00002aamm.zip">';
						}else{
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id=id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="A00002aamm.zip">';
						}
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';	
				}else if(strpos($archivoApedir['nombre'], 'man')!== false){
					$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">';
					$camposTransaccion.="<label for='sellado' id='lsellado' class='control-label col-xs-5 col-lg-3'>Mantenimiento y Sellado:</label>";
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="A00000aamm.zip" >'; 
						}else{
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id=id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].'  data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="A00000aamm.zip">';
						}
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
		}
			
		$camposTransaccion.='<div class="col-xs-5 col-sm-2 col-lg-5">'; 
				$camposTransaccion.="<input type='button' id='btn_procesar' name='btn_procesar' class='col-lg-3 btn btn-primary' value='Procesar'/>";	 			
				$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='col-lg-push-1 col-lg-3 btn btn-primary' value='Cerrar'/>";
		$camposTransaccion.='</div>';
	}
	return $camposTransaccion;
});

Response::macro('panelExcepciones',function($datos){
	//creo las tablas con los sorteos 
	$tablas="";
	$tablas.='<table class="table table-hover" id="tabla_excep">';
	$tablas.="<thead><tr><th>Fecha</th><th>Descripcion</th><th>Accion</th></tr></thead>";
	$tablas.='<tbody id="body_excep">';		
	$i=0;
	foreach($datos as $excepcion){
		$tablas.='<tr id="exc_"'.$i.'>';
		$fecha = new DateTime($excepcion['fecha_exc']);
		$tablas.='<td id="fecha_exc">'.$fecha->format("d/m/Y").'</td>';
		$tablas.='<td id="descripcion_exc">'.$excepcion['descripcion_exc'].'</td>';
		$tablas.='<td id="accion_exc">'.$excepcion['accion_exc'].'</td>';	  
		$tablas.='</tr>';
		$i++;
	}
	   
	$tablas.='</tbody>';
	$tablas.='</table><br>';
	
    return $tablas;
});

Response::macro('panelAdicionalesPendientes',function($datos){
	//creo las tablas con los sorteos 
	$tablas="";
	$tablas.='<table class="table table-hover" id="tabla_excep">';
	$tablas.="<thead><tr><th>Fecha</th><th>Descripcion</th><th>Accion</th></tr></thead>";
	$tablas.='<tbody id="body_excep">';		
	$i=0;
	foreach($datos as $excepcion){
		$tablas.='<tr id="exc_"'.$i.'>';
		$fecha = new DateTime($excepcion['fecha_exc']);
		$tablas.='<td id="fecha_exc">'.$fecha->format("d/m/Y").'</td>';
		$tablas.='<td id="descripcion_exc">'.$excepcion['descripcion_exc'].'</td>';
		$tablas.='<td id="accion_exc">'.$excepcion['accion_exc'].'</td>';	  
		$tablas.='</tr>';
		$i++;
	}
	   
	$tablas.='</tbody>';
	$tablas.='</table><br>';
	
    return $tablas;
});

Response::macro('panelLimites',function($datos){
	$camposTransaccion="";
	
	$camposTransaccion="";

	foreach ($datos as $archivoApedir) {			
			$requerido=($archivoApedir['requerido']=="R")?"required":"";
			if(strpos($archivoApedir['nombre'], 'lv')!== false){
				$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">';
				$camposTransaccion.="<label for='limites venta' id='llimites' class='control-label col-xs-5 col-lg-4'>Archivo límites de ventas diarias:</label>";
				$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					if(strcasecmp($requerido, "required")==0){
						$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="limitevta.txt">';
					}else{
						$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id=id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="limitevta.txt">';
					}
				$camposTransaccion.='</div>';					
				$camposTransaccion.='</div>';	
			} 
	}
		
	$camposTransaccion.='<div class="col-xs-5 col-sm-2 col-lg-5">'; 
			$camposTransaccion.="<input type='button' id='btn_procesar' name='btn_procesar' class='col-lg-3 btn btn-primary' value='Procesar'/>";	 			
			$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='col-lg-push-1 col-lg-3 btn btn-primary' value='Cerrar'/>";
	$camposTransaccion.='</div>';
	
	return $camposTransaccion;
});

Response::macro('recepcionLiquidaciones',function($datos, $secuencia_ant){
	$camposTransaccion="";
		$camposTransaccion="";
		$camposTransaccion.='<div align="center" class="form-group col-xs-12 col-lg-12">'; 
			$camposTransaccion.="<label for='secuencia_ant' id='lperiodo'  class='center control-label col-xs-12 col-sm-12 col-md-12 col-lg-12'><h2>Secuencia esperada ".$secuencia_ant."</h2></label>";
		$camposTransaccion.='</div>';
	

		foreach ($datos as $archivoApedir) {			
				$requerido=($archivoApedir['requerido']=="R")?"required":"";
				if(strpos($archivoApedir['nombre'], 'cas')!== false){
					$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">';
					$camposTransaccion.="<label for='Liquidaciones' id='lliquidaciones' class='control-label col-xs-5 col-lg-3'>Archivo Liquidaciones:</label>";
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="cas.zip">';
						}else{
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="cas.zip">';
						}
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';	
				}
		}

		$camposTransaccion.='<div  class="center col-xs-12 col-sm-12 col-lg-12">'; 
				$camposTransaccion.="<input type='button' id='btn_procesar' name='btn_procesar' class='col-lg-6 btn btn-primary' value='Procesar'/>";	 			
				$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='col-lg-push-1 col-lg-6 btn btn-primary' value='Cerrar'/>";
		$camposTransaccion.='</div>';
	
	return $camposTransaccion;
});



Response::macro('recepcionPrescriptos',function($datos, $secuencia_ant){
	$camposTransaccion="";
		$camposTransaccion="";
		$camposTransaccion.='<div align="center" class="form-group col-xs-12 col-lg-12">'; 
			$camposTransaccion.="<label for='secuencia_ant' id='lperiodo'  class='center control-label col-xs-12 col-sm-12 col-md-12 col-lg-12'><h2>Última Secuencia Procesada<div id='nsecuencia'>".$secuencia_ant."</div></h2></label>";
		$camposTransaccion.='</div>';
	

		foreach ($datos as $archivoApedir) {			
				$requerido=($archivoApedir['requerido']=="R")?"required":"";
				if(strpos($archivoApedir['nombre'], 'A')!== false){
					$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">';
					$camposTransaccion.="<label for='Prescriptos' id='prescriptos' class='control-label col-xs-3 col-lg-5'>Archivo Prescriptos:</label>";
					$camposTransaccion.='<div class="col-xs-7 col-sm-4 col-lg-7">';
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' data-buttonText="Archivo" data-icon="false" >';
						}else{
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' data-buttonText="Archivo" data-icon="false" >';
						}
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';	
				}
		}

		$camposTransaccion.='<div  class="center col-xs-12 col-sm-12 col-lg-12">'; 
				$camposTransaccion.="<input type='button' id='btn_procesar' name='btn_procesar' class='col-lg-6 btn btn-primary' value='Procesar'/>";	 			
				$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='col-lg-push-1 col-lg-6 btn btn-primary' value='Cerrar'/>";
		$camposTransaccion.='</div>';
	
	return $camposTransaccion;
});

Response::macro('recepcionPagosBancos',function($datos, $secuencia_ant){
	$camposTransaccion="";
		$camposTransaccion="";
		$camposTransaccion.='<div align="center" class="form-group col-xs-12 col-lg-12">'; 
			// $camposTransaccion.="<label for='secuencia_ant' id='lperiodo'  class='center control-label col-xs-12 col-sm-12 col-md-12 col-lg-12'><h2>Secuencia esperada ".$secuencia_ant."</h2></label>";
		$camposTransaccion.='</div>';
	

		foreach ($datos as $archivoApedir) {			
				$requerido=($archivoApedir['requerido']=="R")?"required":"";
				if(strpos($archivoApedir['nombre'], 'A')!== false){
					$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">';
					$camposTransaccion.="<label for='Prescriptos' id='prescriptos' class='control-label col-xs-5 col-lg-3'>Archivo Pagos Bancos:</label>";
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$archivoApedir['nombre'].'>';
						}else{
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$archivoApedir['nombre'].'>';
						}
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';	
				}
		}

		$camposTransaccion.='<div  class="center col-xs-12 col-sm-12 col-lg-12">'; 
				$camposTransaccion.="<input type='button' id='btn_procesar' name='btn_procesar' class='col-lg-6 btn btn-primary' value='Procesar'/>";	 			
				$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='col-lg-push-1 col-lg-6 btn btn-primary' value='Cerrar'/>";
		$camposTransaccion.='</div>';
	
	return $camposTransaccion;
});


Response::macro('recepcionDebCredAutomatico',function($datos, $secuencia_ant){
	$camposTransaccion="";
		$camposTransaccion="";
		$camposTransaccion.='<div align="center" class="form-group col-xs-12 col-lg-12">'; 
			// $camposTransaccion.="<label for='secuencia_ant' id='lperiodo'  class='center control-label col-xs-12 col-sm-12 col-md-12 col-lg-12'><h2>Secuencia esperada ".$secuencia_ant."</h2></label>";
		$camposTransaccion.='</div>';
	

		foreach ($datos as $archivoApedir) {			
				$requerido=($archivoApedir['requerido']=="R")?"required":"";
				if(strpos($archivoApedir['nombre'], 'A')!== false){
					$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">';
					$camposTransaccion.="<label for='Prescriptos' id='prescriptos' class='control-label col-xs-5 col-lg-3'>Débito/Crédito Automático:</label>";
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$archivoApedir['nombre'].'>';
						}else{
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$archivoApedir['nombre'].'>';
						}
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';	
				}
		}

		$camposTransaccion.='<div  class="center col-xs-12 col-sm-12 col-lg-12">'; 
				$camposTransaccion.="<input type='button' id='btn_procesar' name='btn_procesar' class='col-lg-6 btn btn-primary' value='Procesar'/>";	 			
				$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='col-lg-push-1 col-lg-6 btn btn-primary' value='Cerrar'/>";
		$camposTransaccion.='</div>';
	
	return $camposTransaccion;
});

//-------------------------------------
/* IR: macro Recepcion premios pagados */
//--------------------------------------
/*
Response::macro('recepcionPrePagados',function($datos, $secuencia_ant){
	$camposTransaccion="";
		$camposTransaccion="";
		$camposTransaccion.='<div align="center" class="form-group col-xs-12 col-lg-12">'; 
			//$camposTransaccion.="<label for='secuencia_ant' id='lperiodo'  class='center control-label col-xs-12 col-sm-12 col-md-12 col-lg-12'><h2>Secuencia esperada ".$secuencia_ant."</h2></label>";
		$camposTransaccion.='</div>';
		foreach ($datos as $archivoApedir) {			
				$requerido=($archivoApedir['requerido']=="R")?"required":"";
				if(strpos($archivoApedir['nombre'], 'A')!== false){
					$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">';
					$camposTransaccion.="<label for='Prescriptos' id='prescriptos' class='control-label col-xs-5 col-lg-3'>Archivo Prescriptos:</label>";
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$archivoApedir['nombre'].'>';
						}else{
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$archivoApedir['nombre'].'>';
						}
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';	
				}
		}
		$camposTransaccion.='<div  class="center col-xs-12 col-sm-12 col-lg-12">'; 
				$camposTransaccion.="<input type='button' id='btn_procesar' name='btn_procesar' class='col-lg-6 btn btn-primary' value='Procesar'/>";	 			
				$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='col-lg-push-1 col-lg-6 btn btn-primary' value='Cerrar'/>";
		$camposTransaccion.='</div>';
	
	return $camposTransaccion;
});
*/

Response::macro('recepcionPrePagados',function($especif_archivo){

	$camposTransaccion="";
	$requerido=($especif_archivo['tipo_requerimiento']=="R")?"required":"";
	$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">';
	$camposTransaccion.="<label for='Prescriptos' id='prescriptos' class='control-label col-xs-5 col-lg-3'>Premios Pagados:</label>";
	$camposTransaccion.='<div class="col-sm-5 col-lg-7">';
	if(strcasecmp($requerido, "required")==0){
		$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id="id_archivo" name="id_archivo" pattern='.$especif_archivo['nombre'].' required = '.$requerido.' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip">';
	}else{
		$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id="id_archivo" name="id_archivo" pattern='.$especif_archivo['nombre'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" >';
	}
	$camposTransaccion.='</div>';					
	$camposTransaccion.='</div>';	

	$camposTransaccion.='<div  class="center col-xs-12 col-sm-12 col-lg-12">'; 
		$camposTransaccion.="<input type='button' id='btn_procesar' name='btn_procesar' class='col-lg-6 btn btn-primary' value='Procesar'/>";	 			
		$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='col-lg-push-1 col-lg-6 btn btn-primary' value='Cerrar'/>";
	$camposTransaccion.='</div>';

	
return $camposTransaccion;
});

/* IR: FIN */


Response::macro('Exportaciones',function($datos,$labels){
	// $camposTransaccion="";
		$camposTransaccion="";
		$camposTransaccion.='<div class="container-fluid"><div class="form-group col-xs-12 col-lg-12">'; 
			//$camposTransaccion.="<label for='secuencia_ant' id='lperiodo'  class='center control-label col-xs-12 col-sm-12 col-md-12 col-lg-12'><h2>Secuencia esperada </h2></label>";
		
	
        for($x=0; $x<count($datos); $x++ ){
				// por cada dato genera un label y un input text readonly
				if(isset($datos[$x]['nombre_exportacion'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="Exportaciones" id="Exportaciones" class="control-label col-xs-5 col-lg-5">'.$labels[$x]['nombre_exportacion'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="nombre_exportacion" name="nombre_exportacion" value='.$datos[$x]['nombre_exportacion'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['nombre_exportacion'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
					$nom_exp = $datos[$x]['nombre_exportacion'];
				}
			/*	
			if($datos[$x]['nombre_exportacion'] == 'ENVIO_AFIP'){
					if(isset($datos[$x]['ult_envio'])){
						$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">'; 
								$camposTransaccion.='<label class="control-label col-xs-5 col-lg-5 col-sm-5 col-md-5">'.$labels[$x]['ult_envio'].':</label>';
							$camposTransaccion.='<div class="col-xs-6 col-sm-2 col-lg-7">';
								$camposTransaccion.="<select id='id_camara' name='id_camara' form='formulario_camaras' class='form-control col-xs-3' maxlength='16' data-toggle='tooltip' text-align='right'>";
								  $camposTransaccion.='<option value='.$datos[$x]['ult_envio'].'>'.$datos[$x]['ult_envio'].'</option>';
								  $camposTransaccion.='<option value='.Date("Ym",strtotime(substr($datos[$x]['ult_envio'],0,4).'-'.substr($datos[$x]['ult_envio'],4,6).'-01 -1 months')).'>'.Date("Ym",strtotime(substr($datos[$x]['ult_envio'],0,4).'-'.substr($datos[$x]['ult_envio'],4,6).'-01 -1 months')).'</option>';
								//  Date("Ym", strtotime($datos[$x]['ult_envio'].'01' -1 Month")
								$camposTransaccion.="</select>";
							$camposTransaccion.='</div>';				
						$camposTransaccion.='</div>';
					}
			}else{
				*/
				if(isset($datos[$x]['ult_envio'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label class="control-label col-xs-5 col-lg-5">'.$labels[$x]['ult_envio'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="ult_envio" name="ult_envio" value='.$datos[$x]['ult_envio'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['ult_envio'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
			//}	
			$camposTransaccion.='<a href="#" id="perciana" name="perciana"> <img src="https://sbxa.loteriasantafe.gov.ar/app/CAS_Procesos/public/images/img_drop_down.png" id="dropdown" title="Expandir" alt="Imagen no encontrada"></a> <div id="content" name="content"> ';       
			
				if(isset($datos[$x]['tipo_paquete'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="tipo_paquete" id="tipo_paquete" class="control-label col-xs-5 col-lg-">'.$labels[$x]['tipo_paquete'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="tipo_paquete" name="tipo_paquete" value='.$datos[$x]['tipo_paquete'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['tipo_paquete'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
				if(isset($datos[$x]['formato_nombre_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="formato_nombre_paq" id="formato_nombre_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['formato_nombre_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="formato_nombre_paq" name="formato_nombre_paq" value='.$datos[$x]['formato_nombre_paq'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['formato_nombre_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
				if(isset($datos[$x]['ruta_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="ruta_paq" id="ruta_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['ruta_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="ruta_paq" name="ruta_paq" value='.$datos[$x]['ruta_paq'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['ruta_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
				if(isset($datos[$x]['mail_destino_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="mail_destino_paq" id="mail_destino_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['mail_destino_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="mail_destino_paq" name="mail_destino_paq" value="'.$datos[$x]['mail_destino_paq'].'" data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['mail_destino_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				if(isset($datos[$x]['mail_remite_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="mail_remite_paq" id="mail_remite_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['mail_remite_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="mail_remite_paq" name="mail_remite_paq" value='.$datos[$x]['mail_remite_paq'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['mail_remite_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				if(isset($datos[$x]['mail_asunto_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="mail_asunto_paq" id="mail_asunto_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['mail_asunto_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="mail_asunto_paq" name="mail_asunto_paq" value="'.$datos[$x]['mail_asunto_paq'].'" data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['mail_asunto_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
				if(isset($datos[$x]['mail_cuerpo_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="mail_cuerpo_paq" id="mail_cuerpo_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['mail_cuerpo_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="mail_cuerpo_paq" name="mail_cuerpo_paq" value="'.$datos[$x]['mail_cuerpo_paq'].'" data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['mail_cuerpo_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				if(isset($datos[$x]['mail_destino_aviso'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="mail_destino_aviso" id="mail_destino_aviso" class="control-label col-xs-5 col-lg-">'.$labels[$x]['mail_destino_aviso'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="mail_destino_aviso" name="mail_destino_aviso" value="'.$datos[$x]['mail_destino_aviso'].'" data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['mail_destino_aviso'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
				if(isset($datos[$x]['cant_archivos'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="cant_archivos" id="cant_archivos" class="control-label col-xs-5 col-lg-">'.$labels[$x]['cant_archivos'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="cant_archivos" name="cant_archivos" value='.$datos[$x]['cant_archivos'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['cant_archivos'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				if(isset($datos[$x]['etapa_audit'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="etapa_audit" id="etapa_audit" class="control-label col-xs-5 col-lg-">'.$labels[$x]['etapa_audit'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id=etapa_audit" name="etapa_audit" value='.$datos[$x]['etapa_audit'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['etapa_audit'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				
					$camposTransaccion.='</div>';
		} 
			/*	foreach ($datos as $archivoApedir) {			
			// por cada dato genera un label y un input text readonly
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="Exportaciones" id="Exportaciones" class="control-label col-xs-5 col-lg-">'.$labels[0]->nombre_exportacion.':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-6" id='.$archivoApedir['nombre_exportacion'].' name='.$archivoApedir['nombre_exportacion'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="cas.zip">';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';	
				}*/
		
		//$camposTransaccion.='</div>';
		
		// seccion para datos de archivos
		
		$camposTransaccion.='<div  id="botonera" class="center col-xs-12 col-sm-12 col-lg-12">'; 
				$camposTransaccion.="<input type='button' id='btn_procesar' name='btn_procesar' class='center col-lg-6 btn btn-primary' value='Generar'/>";	 	
if ($nom_exp === 'RESERVA_LOTERIA'){
	$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='center col-lg-push-1 col-lg-6 btn btn-primary' value='Exportar otro Sorteo'/>";
	
}

				
			//	$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='center col-lg-push-1 col-lg-6 btn btn-primary' value='Cerrar'/>";
				
		$camposTransaccion.='</div>';
	$camposTransaccion.='</div></div>';
	return $camposTransaccion;
	
});



/********************************************************/
/*						exportacion uif					*/
/********************************************************/

Response::macro('ExportacionesUIF',function($datos,$labels){
	// $camposTransaccion="";
		$camposTransaccion="";
		$camposTransaccion.='<div class="container-fluid"><div class="form-group col-xs-12 col-lg-12">'; 
			//$camposTransaccion.="<label for='secuencia_ant' id='lperiodo'  class='center control-label col-xs-12 col-sm-12 col-md-12 col-lg-12'><h2>Secuencia esperada </h2></label>";
		
	
        for($x=0; $x<count($datos); $x++ ){
				// por cada dato genera un label y un input text readonly
				if(isset($datos[$x]['nombre_exportacion'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="Exportaciones" id="Exportaciones" class="control-label col-xs-5 col-lg-">'.$labels[$x]['nombre_exportacion'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="nombre_exportacion" name="nombre_exportacion" value='.$datos[$x]['nombre_exportacion'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['nombre_exportacion'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				
			$camposTransaccion.='<a href="#" id="perciana" name="perciana"> <img src="http://sbx.loteriasantafe.gov.ar/app/CAS_Procesos/public/images/img_drop_down.png" id="dropdown" title="Expandir" alt="Imagen no encontrada"></a> <div id="content" name="content"> ';       
			
				if(isset($datos[$x]['tipo_paquete'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="tipo_paquete" id="tipo_paquete" class="control-label col-xs-5 col-lg-">'.$labels[$x]['tipo_paquete'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="tipo_paquete" name="tipo_paquete" value='.$datos[$x]['tipo_paquete'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['tipo_paquete'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
				if(isset($datos[$x]['formato_nombre_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="formato_nombre_paq" id="formato_nombre_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['formato_nombre_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="formato_nombre_paq" name="formato_nombre_paq" value='.$datos[$x]['formato_nombre_paq'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['formato_nombre_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
				if(isset($datos[$x]['ruta_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="ruta_paq" id="ruta_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['ruta_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="ruta_paq" name="ruta_paq" value='.$datos[$x]['ruta_paq'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['ruta_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
				if(isset($datos[$x]['mail_destino_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="mail_destino_paq" id="mail_destino_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['mail_destino_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="mail_destino_paq" name="mail_destino_paq" value="'.$datos[$x]['mail_destino_paq'].'" data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['mail_destino_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				if(isset($datos[$x]['mail_remite_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="mail_remite_paq" id="mail_remite_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['mail_remite_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="mail_remite_paq" name="mail_remite_paq" value='.$datos[$x]['mail_remite_paq'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['mail_remite_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				if(isset($datos[$x]['mail_asunto_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="mail_asunto_paq" id="mail_asunto_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['mail_asunto_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="mail_asunto_paq" name="mail_asunto_paq" value="'.$datos[$x]['mail_asunto_paq'].'" data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['mail_asunto_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
				if(isset($datos[$x]['mail_cuerpo_paq'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="mail_cuerpo_paq" id="mail_cuerpo_paq" class="control-label col-xs-5 col-lg-">'.$labels[$x]['mail_cuerpo_paq'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="mail_cuerpo_paq" name="mail_cuerpo_paq" value="'.$datos[$x]['mail_cuerpo_paq'].'" data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['mail_cuerpo_paq'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				if(isset($datos[$x]['mail_destino_aviso'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="mail_destino_aviso" id="mail_destino_aviso" class="control-label col-xs-5 col-lg-">'.$labels[$x]['mail_destino_aviso'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="mail_destino_aviso" name="mail_destino_aviso" value="'.$datos[$x]['mail_destino_aviso'].'" data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['mail_destino_aviso'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
				if(isset($datos[$x]['cant_archivos'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="cant_archivos" id="cant_archivos" class="control-label col-xs-5 col-lg-">'.$labels[$x]['cant_archivos'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="cant_archivos" name="cant_archivos" value='.$datos[$x]['cant_archivos'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['cant_archivos'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				if(isset($datos[$x]['etapa_audit'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="etapa_audit" id="etapa_audit" class="control-label col-xs-5 col-lg-">'.$labels[$x]['etapa_audit'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id=etapa_audit" name="etapa_audit" value='.$datos[$x]['etapa_audit'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['etapa_audit'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				if(isset($datos[$x]['ult_envio'])){
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="ult_envio" id="ult_envio" class="control-label col-xs-5 col-lg-">'.$labels[$x]['ult_envio'].':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-10" id="ult_envio" name="ult_envio" value='.$datos[$x]['ult_envio'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title='.$labels[$x]['ult_envio'].' readonly>';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}	
					$camposTransaccion.='</div>';
		} 
			/*	foreach ($datos as $archivoApedir) {			
			// por cada dato genera un label y un input text readonly
					$camposTransaccion.='<div class="center form-group col-xs-12 col-lg-12">';
					$camposTransaccion.='<label for="Exportaciones" id="Exportaciones" class="control-label col-xs-5 col-lg-">'.$labels[0]->nombre_exportacion.':</label>';
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
					$camposTransaccion.='<input type="text" class="filestyle  apply-tooltip col-lg-6" id='.$archivoApedir['nombre_exportacion'].' name='.$archivoApedir['nombre_exportacion'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="cas.zip">';
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';	
				}*/
		
		//$camposTransaccion.='</div>';
		
		// seccion para datos de archivos
		
		$camposTransaccion.='<div  class="center col-xs-12 col-sm-12 col-lg-12">'; 
				$camposTransaccion.="<input type='button' id='btn_procesar' name='btn_procesar' class='center col-lg-6 btn btn-primary' value='Generar'/>";	 			
			//	$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='center col-lg-push-1 col-lg-6 btn btn-primary' value='Cerrar'/>";
				
		$camposTransaccion.='</div>';
	$camposTransaccion.='</div></div>';
	return $camposTransaccion;
	
});


/*******************************************************/
/*			recepcion camaras										*/
/*******************************************************/

Response::macro('panelCamaras',function($datos, $periodo){
	$mes_actual=date("Y").date("m");
	$camposTransaccion="";
//	if(strlen($periodo)>6){
//		$camposTransaccion.='<div class="col-xs-2 col-sm-7 col-md-12 col-lg-12" align="center"><h2>'.$periodo.'</h2></div>'; 
//	}else{
		// inputs hidden para validar x jquery los datos
		

		foreach ($datos as $archivoApedir) {
			
			
		$camposTransaccion.="<input type='hidden' name='idmes' id='idmes' value='".$periodo."'/>";
		$camposTransaccion.="<input type='hidden' name='idcamara' id='idcamara' value='".$archivoApedir['camara']."'/>";
		$camposTransaccion.="<input type='hidden' name='idnombre' id='idnombre' value='".$archivoApedir['nombre']."'/>";

		
		//
		$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">'; 
			$camposTransaccion.="<label for='periodo' id='lperiodo' class='control-label col-xs-3 col-sm-3 col-md-3 col-lg-3'>Mes:</label>";
			$camposTransaccion.='<div class="col-xs-6 col-sm-2 col-lg-6">';
				$camposTransaccion.="<input type='text' name='id_mes' id='id_mes' class='form-control col-xs-3' maxlength='6' data-toggle='tooltip' text-align='right' value='$mes_actual'/>";
			$camposTransaccion.='</div>';				
		$camposTransaccion.='</div>';

		$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">'; 
			$camposTransaccion.="<label for='camara' id='lcamara' class='control-label col-xs-3 col-sm-3 col-md-3 col-lg-3'>Cámara:</label>";
			$camposTransaccion.='<div class="col-xs-6 col-sm-2 col-lg-6">';
			//	$camposTransaccion.="<input type='text' name='id_camara' id='id_camara' class='form-control col-xs-3' maxlength='16' data-toggle='tooltip' text-align='right' value=''/>";
				$camposTransaccion.="<select id='id_camara' name='id_camara' form='formulario_camaras' class='form-control col-xs-3' maxlength='16' data-toggle='tooltip' text-align='right'>";
					  $camposTransaccion.="<option value='CANR'>CANR</option>";
					  $camposTransaccion.="<option value='CACOPLYT'>CACOPLYT</option>";
					$camposTransaccion.="</select>";
			$camposTransaccion.='</div>';				
		$camposTransaccion.='</div>';
		
		$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">'; 
			$camposTransaccion.="<label for='totalafiliados' id='ltotalafiliados' class='control-label col-xs-3 col-sm-3 col-md-3 col-lg-3'>Total Afiliados a Recibir:</label>";
			$camposTransaccion.='<div class="col-xs-6 col-sm-2 col-lg-6">';
				$camposTransaccion.="<input type='text' name='id_totalafiliados' id='id_totalafiliados' class='form-control col-xs-3'  data-toggle='tooltip' text-align='right' value=''/>";
			$camposTransaccion.='</div>';				
		$camposTransaccion.='</div>';
		
		$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">'; 
			$camposTransaccion.="<label for='totalimporte' id='ltotalimporte' class='control-label col-xs-3 col-sm-3 col-md-3 col-lg-3'>Total Importe a Recibir:</label>";
			$camposTransaccion.='<div class="col-xs-6 col-sm-2 col-lg-6">';
				$camposTransaccion.="<input type='text' name='id_totalimporte' id='id_totalimporte' class='form-control col-xs-3'  data-toggle='tooltip' text-align='right' value=''/>";
			$camposTransaccion.='</div>';				
		$camposTransaccion.='</div>';
		
				$requerido=($archivoApedir['requerido']=="R")?"required":"";
				//if(strpos($archivoApedir['nombre'], 'com')!== false){
					$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">';
					$camposTransaccion.="<label for='camaras' id='lcamara' class='control-label col-xs-5 col-lg-3'>Archivo:</label>";
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id="id_archivo" name="id_archivo" pattern='.$archivoApedir['extension'].' required = '.$requerido.' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip">';
						}else{
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id=id="id_archivo" name="id_archivo" pattern='.$archivoApedir['extension'].' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" >';
						}
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';	
				//}
				/*
				else if(strpos($archivoApedir['nombre'], 'man')!== false){
					$camposTransaccion.='<div class="form-group col-xs-12 col-lg-7">';
					$camposTransaccion.="<label for='sellado' id='lsellado' class='control-label col-xs-5 col-lg-3'>Mantenimiento y Sellado:</label>";
					$camposTransaccion.='<div class="col-sm-2 col-lg-7">';
						if(strcasecmp($requerido, "required")==0){
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].' required = '.$requerido.' data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="A00000aamm.zip" >'; 
						}else{
							$camposTransaccion.='<input type="file" class="filestyle  apply-tooltip" id=id='.$archivoApedir['nombre'].' name='.$archivoApedir['nombre'].' pattern='.$archivoApedir['extension'].'  data-buttonText="Archivo" data-icon="false" data-toggle="tooltip" title="A00000aamm.zip">';
						}
					$camposTransaccion.='</div>';					
					$camposTransaccion.='</div>';
				}
				*/
		}
			
		$camposTransaccion.='<div class="col-xs-5 col-sm-2 col-lg-5">'; 
				$camposTransaccion.="<input type='button' id='btn_procesar' name='btn_procesar' class='col-lg-3 btn btn-primary' value='Procesar'/>";	 			
				$camposTransaccion.="<input type='button' id='btn_cerrar' name='btn_cerrar' class='col-lg-push-1 col-lg-3 btn btn-primary' value='Cerrar'/>";
		$camposTransaccion.='</div>';
	//}
	return $camposTransaccion;
});

//RR AGREGA recepcionPrePagOtrProv

Response::macro('recepcionPrePagOtrProv',function($especif_archivo){

	$camposTransaccion = "";
	$requerido = ($especif_archivo['tipo_requerimiento']=="R") ? "required" : "";

	$camposTransaccion .= '<div class="form-group col-xs-12 col-lg-9">';
	$camposTransaccion .= "<label for='archivo' id='archivo' class='control-label col-xs-5 col-lg-3'>Seleccione el archivo a procesar:</label>";
	$camposTransaccion .= '<div class="col-sm-5 col-md-9 col-lg-10">';
	if(strcasecmp($requerido, "required") == 0){
		$camposTransaccion .= '<input type="file" class="filestyle apply-tooltip" id="id_archivo" name="id_archivo" pattern='.$especif_archivo['nombre'].' required='.$requerido.' data-buttonText="&nbsp;&nbsp;Archivo" data-icon="true" data-toggle="Click para elegir archivo" tooltip="kk">';
	}else{
		$camposTransaccion .= '<input type="file" class="filestyle apply-tooltip" id="id_archivo" name="id_archivo" pattern='.$especif_archivo['nombre'].' data-buttonText="&nbsp;&nbsp;Archivo" data-icon="true" data-toggle="Click para elegir archivo">';
	}
	$camposTransaccion .= '</div>';
	$camposTransaccion .= '</div>';

	// Bloque de botones alineados en la misma fila
	$camposTransaccion .= '<div class="form-group col-xs-12 col-lg-9" style="margin-top:15px;">';
	$camposTransaccion .= '<div class="row">';

    // Izquierda: Procesar
    $camposTransaccion .= '<div class="col-xs-4 text-left">';
    $camposTransaccion .= "<input type='button' id='btn_procesar' name='btn_procesar' class='btn btn-primary col-lg-6' value='Procesar' />";
    $camposTransaccion .= '</div>';

    // Centro: Nueva Carga
    $camposTransaccion .= '<div class="col-xs-4 text-center">';
    $camposTransaccion .= "<input type='button' id='btn_nueva_carga' name='btn_nueva_carga' class='btn btn-primary col-lg-6' value='Nueva Carga' />";
    $camposTransaccion .= '</div>';

    // Derecha: Cerrar
    $camposTransaccion .= '<div class="col-xs-4 text-right">';
    $camposTransaccion .= "<input type='button' id='btn_cerrar' name='btn_cerrar' class='btn btn-primary col-lg-6' value='Cerrar'/>";
    $camposTransaccion .= '</div>';

	$camposTransaccion .= '</div>';
	$camposTransaccion .= '</div>';
	
	return $camposTransaccion;
});



?>