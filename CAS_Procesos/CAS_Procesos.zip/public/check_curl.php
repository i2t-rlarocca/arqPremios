<?php
$curl_info = curl_version();
echo "<pre>";
print_r($curl_info);
echo "</pre>";
?>