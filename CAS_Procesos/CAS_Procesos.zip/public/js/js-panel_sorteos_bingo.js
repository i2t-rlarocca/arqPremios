 jQuery.noConflict(); 
jQuery(document).ready(function(){
	


/*var height = jQuery(window).height();
var width = jQuery(window).width();
alert(height);
alert(width);
//refresh on resize
jQuery(window).resize(function() {
  location.reload(true)
});*/

	
     /**Función para iluminar la fila de la tabla seleccionada - sorteos de días anteriores**/
    jQuery('#cuerpo_sda').on('click', 'tr', function () {
        //si hay sorteos del día anterior marcados desmarcar
        jQuery('#cuerpo_sd >tr').each(function(clave, element){
            if(jQuery(element).hasClass('highlighted')){//si está iluminado
                jQuery(element).siblings().removeClass('highlighted');
                jQuery(element).toggleClass('highlighted');
            }   
        });

        jQuery(this).iluminarFila(this);
        
        
    });
    /**Función para iluminar la fila de la tabla seleccionada - sorteos del día**/
    jQuery('#cuerpo_sd').on('click', 'tr', function () {
        //si hay sorteos del día anterior marcados desmarcar
        jQuery('#cuerpo_sda >tr').each(function(clave, element){
            if(jQuery(element).hasClass('highlighted')){//si está iluminado
                jQuery(element).siblings().removeClass('highlighted');
                jQuery(element).toggleClass('highlighted');
            }   
        });

		jQuery(this).iluminarFila(this);
        
    });
		
	 /**Función para iluminar la fila de la tabla seleccionada - sorteos del día**/
    jQuery('#cuerpo_sdf').on('click', 'tr', function () {
        //si hay sorteos del día anterior marcados desmarcar
        jQuery('#cuerpo_sdf >tr').each(function(clave, element){
            if(jQuery(element).hasClass('highlighted')){//si está iluminado
                jQuery(element).siblings().removeClass('highlighted');
                jQuery(element).toggleClass('highlighted');
            }   
        });

		jQuery(this).iluminarFila(this);
        
    });
	
	/******************************************
	* Función que ilumina la fila de la tabla *
	*******************************************/
	jQuery.fn.iluminarFila=function(fila){
		if(!jQuery(fila).hasClass('highlighted')){//si no está iluminado
            jQuery(fila).siblings().removeClass('highlighted');
            jQuery(fila).toggleClass('highlighted');
            document.getElementById('id_seleccionado').value=fila.id;
            document.getElementById('id_juego_seleccionado').value=jQuery(fila).find('#id_juego').text();
            document.getElementById('id_estado_seleccionado').value=jQuery(fila).find('#id_estado').text();
            document.getElementById('id_formato_procesamiento').value=jQuery(fila).find('#formato_procesamiento').text();
            document.getElementById('nro_sorteo').value=jQuery(fila).find('#sorteo').text();
			document.getElementById('fecha_seleccionado').value=jQuery(fila).find('#fecha').text();
            
			jQuery().cargarPanelTransaccion();
        }else{
            jQuery(fila).toggleClass('highlighted');
            jQuery("#datos_juego").empty();
            jQuery("#formulario_archivos").empty();
            jQuery("#panel_error").hide();
            jQuery("#panel_ok").hide();
            jQuery("#panel_btn_publicar").hide();
            jQuery("#panel_btn_diferencias").hide();
			jQuery("#formulario_archivos").show();
            jQuery("<div class='col-xs-2 col-sm-7 col-md-12 col-lg-12'><h1>SELECCIONE UN SORTEO PARA OPERAR...</h1></div>").appendTo('#formulario_archivos');
            jQuery().transaccionActiva(4);
            document.getElementById('id_seleccionado').value="";
            document.getElementById('id_juego_seleccionado').value="";
            document.getElementById('id_estado_seleccionado').value="";
            document.getElementById('id_formato_procesamiento').value="";
            document.getElementById('nro_sorteo').value="";
			document.getElementById('fecha_seleccionado').value="";
        }  
	}


    /******función que carga el panel de transacción según el sorteo*******/
    jQuery.fn.cargarPanelTransaccion = function(){
        jQuery.ajax({
                type:'post',
                url: 'carga-panel-transaccion-bingos',
                data: {'id_seleccionado':jQuery('#id_seleccionado').val(), 'id_estado_seleccionado':jQuery('#id_estado_seleccionado').val(), 'id_juego_seleccionado':jQuery('#id_juego_seleccionado').val(), 'nro_sorteo':jQuery('#nro_sorteo').val()},
                dataType:'json',
     
                success: function (data) {
                    jQuery('#panel_ok').hide();
                    jQuery('#panel_error').hide();
                    jQuery('#panel_btn_publicar').hide();
                    jQuery("#panel_btn_diferencias").hide();
                    //según qué éstado llega permitir o no cargar los archivos
                    jQuery(this).datosSorteo();
                   				
						if(data.datosTransaccion['id_estado']==50){//publicado
							jQuery("#formulario_archivos").show();
							jQuery("#formulario_archivos").empty();
							jQuery(data.datosTransaccion['vista']).appendTo('#formulario_archivos');
						
						}else if(data.datosTransaccion['id_estado']==40){// || data.datosTransaccion['id_estado']==45){
							/*
							jQuery("#formulario_archivos").show();
                            jQuery("#formulario_archivos").empty();
                            jQuery('#panel_btn_publicar').show();
                            jQuery('#btn_publicar').show();
							if(data.mensaje){
								jQuery('#mensaje_ok').text(data.mensaje);
								jQuery('#panel_ok').show();
							}
							*/
							// se ajusta para que en estado 40 al ingresar el usuario luego de hacer click en otro juego-sorteo muestre el boton publicar
							jQuery("#formulario_archivos").show();
							jQuery("#formulario_archivos").empty();
							jQuery('#panel_btn_publicar').show();
                            jQuery('#btn_publicar').show();
						//alert('click');
						//alert(data.datosTransaccion['datos']);
							if(data.datosTransaccion['datos']){
								jQuery('#mensaje_ok').text(data.datosTransaccion['datos']);
								jQuery('#panel_ok').show();
								
							}
							
							jQuery(data.datosTransaccion['vista']).appendTo('#formulario_archivos');
							//anexo de clase filestyle
							if(data.datosTransaccion.nombre_file!=undefined){
								var archivos = data.datosTransaccion.nombre_file;
								for(var i=0; i<archivos.length;i++){
									jQuery('input[name='+archivos[i]['nombre']+']').attr('accept','.zip');	
									jQuery('input[name='+archivos[i]['nombre']+']').filestyle({badge:"false", buttonBefore:"true", buttonText:archivos[i]['buttonText']});  
									//verificar si se puede sacar el atributo value y colocar para mostrarlo
								} 
								jQuery(this).aplicaTooltip();
							}
							
							jQuery('#mensaje_error').text(data.datosTransaccion.datos);
                           // jQuery('#panel_error').show();
							
                        }else{
							jQuery("#formulario_archivos").show();
							jQuery("#formulario_archivos").empty();
							
							jQuery(data.datosTransaccion['vista']).appendTo('#formulario_archivos');
							//anexo de clase filestyle
							if(data.datosTransaccion.nombre_file!=undefined){
								var archivos = data.datosTransaccion.nombre_file;
								for(var i=0; i<archivos.length;i++){
									
									if(archivos[i]['nombre'] == 'totb_1')
									{
										jQuery('input[name='+archivos[i]['nombre']+']').attr('accept','.txt');	
									}else{
										jQuery('input[name='+archivos[i]['nombre']+']').attr('accept','.zip');	
									}
									jQuery('input[name='+archivos[i]['nombre']+']').filestyle({badge:"false", buttonBefore:"true", buttonText:archivos[i]['buttonText']});  
									//verificar si se puede sacar el atributo value y colocar para mostrarlo
								} 
								jQuery(this).aplicaTooltip();
							}
                            
                            if(data.datosTransaccion.datos!=undefined && (data.datosTransaccion['id_estado']==38 || data.datosTransaccion['id_estado']==50)){
                                jQuery('#mensaje_ok').text(data.datosTransaccion.datos);
                                jQuery('#panel_ok').show();
                            }else if(data.datosTransaccion.datos!=undefined && data.datosTransaccion['id_estado']==45){
                                jQuery('#mensaje_error').text(data.datosTransaccion.datos);
                                jQuery('#panel_error').show();
                            }
													
						}
					 jQuery(this).transaccionActiva(data.datosTransaccion.transaccion_activa);
					
                },
                        error(xhr){
							//si estaba el ok lo oculto
							if(jQuery('#panel_ok').css('display') == 'block'){
								jQuery('#panel_ok').hide();
							}
							if(xhr.responseText != null){
								jQuery('#mensaje_error').text(xhr.responseText);
							}else{
								jQuery('#mensaje_error').text("");
							}
                            jQuery('#panel_error').show();
                        }

            });
    };
	
	//tooltip input files
	jQuery.fn.aplicaTooltip = function(){
		jQuery('.apply-tooltip').each(function(){
			jQuery(this).siblings("div").attr("data-toggle", "tooltip");	
			//jQuery(this).siblings("div").attr("data-title", jQuery(this).attr('title'));
                        jQuery(this).next("div").attr("data-title", jQuery(this).attr('title'));
		});  
		jQuery('[data-toggle="tooltip"]').tooltip(); 
	};
    

});//fin document ready



