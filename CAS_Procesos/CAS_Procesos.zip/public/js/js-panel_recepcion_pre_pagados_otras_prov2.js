jQuery.noConflict(); 

function pad (str, max) {
  str = str.toString();
  return str.length < max ? pad("0" + str, max) : str;
}

function div_paquetes(valor){
	 jQuery.ajax({
        url: 'paquetes-prem-otras-prov',
        type: 'post',
		dataType:'json',
		data: {'tipo_exportacion':valor},
		beforeSend: function() {
			jQuery('#cargando').html("<img src='images/cargando.gif' />");
		},
		success: function(data){
			jQuery('#cargando').remove();
			if(data.exito == 1){ // ok
				if (data.mensaje.length !== 0) {
					llenar_tabla(data.mensaje);
				}
			}else{
				if(data.exito == 2){ // warning
					jQuery('#mensaje_warning').empty();
					jQuery('#mensaje_warning').text(data.mensaje);
					jQuery('#panel_warning').show();
				}else{ // error
					jQuery('#btn_procesar').attr('disabled', 'disabled');
					jQuery('#mensaje_error').empty();
					jQuery('#mensaje_error').text(data.mensaje);
					jQuery('#panel_error').show();
				}
				//llenar_tabla_fake();
			}
		},
		error: function(xhr, status, error){
			jQuery('#cargando').remove();
			
			// Mensaje genérico
			jQuery('#mensaje_error').empty();
			jQuery('#mensaje_error').text(
				'Problemas al procesar premios de otras provincias. Contacte a Soporte.'
			);

			// Detalles técnicos del error
			console.log("Estado:", status);          // ej. "error", "timeout"
			console.log("Mensaje de error:", error); // ej. "Internal Server Error"
			console.log("Código HTTP:", xhr.status); // ej. 500, 404
			console.log("Respuesta completa:", xhr.responseText);

			// Si quieres mostrarlo en pantalla:
			jQuery('#mensaje_error').append(
				"<br>Detalles: " + xhr.status + " - " + error + "<br>" + xhr.responseText
			);

			jQuery('#panel_error').show();
			//llenar_tabla_fake();
		}

		/*error(xhr){
					jQuery('#mensaje_error').text('Problemass al procesar premios de otras provincias comuníquese con el administrador.');
                    jQuery('#panel_error').show();
				},*/
      });
}


// ajax para taer div de paquetes

function llenar_tabla(data) {
	
	//var tipo = jQuery("#nombre_exportacion").val();
	var tipo = "PREMIOS_OTRAS_PROV";
	//var envio = jQuery("#ult_envio").val();

	var f = new Date();
	var m = pad(f.getMonth()+1, 2);
	var y = f.getFullYear();
	var fecha = y+m;
/*
		if(tipo == 'ENVIO_UIF' || tipo == 'ENVIO_AFIP'){
				if(parseInt(envio) >= parseInt(fecha)){
					jQuery("#botonera").hide();
				}
		}
*/
	//location.reload();
	// realizar refresh de valor del ultimo envio, ya que no esta reflejando el ultimo luego de procesar
	
	jQuery('#tabla_res tbody').remove();
	jQuery('#cargando').remove();
	codigo_tabla = "<tbody>";
	
	data.length;
    console.log(data);
	jQuery.each( data, function( i, val ) {
			codigo_tabla = codigo_tabla+"<tr>"
			+"<td class='col-lg-4'>"+val.paquete+"</td>"
			+"<td class='col-lg-2'>"+val.fecha+"</td>"
			+"<td class='col-lg-6'><div class='center'><a class='hasTip' title='Descargar' href='"+val.descargar+"' target='_blank'>DESCARGAR</a> &nbsp;&nbsp;&nbsp;&nbsp;"
			+"</div></td></tr>";
	});

	codigo_tabla = codigo_tabla+"</tbody>"
	//jQuery('#id_transaccion').val('algo');
	jQuery("#tabla_res").append(codigo_tabla);
	jQuery("#tabla_res").fadeIn("slow");
}



function llenar_tabla_fake() {
	
	jQuery('#tabla_res tbody').remove();
	jQuery('#cargando').remove();
	codigo_tabla = "<tbody>";

	codigo_tabla = codigo_tabla+"<tr>"
	+"<td class='col-lg-4'>Archivo1</td>"
	+"<td class='col-lg-2'>Fecha1</td>"
	+"<td class='col-lg-6'><div class='center'><a class='hasTip' title='Descargar' href='link_1' target='_blank'>DESCARGAR</a> &nbsp;&nbsp;&nbsp;&nbsp;"
	+"</div></td></tr>";

	codigo_tabla = codigo_tabla+"<tr>"
	+"<td class='col-lg-4'>Archivo2</td>"
	+"<td class='col-lg-2'>Fecha2</td>"
	+"<td class='col-lg-6'><div class='center'><a class='hasTip' title='Descargar' href='link_2' target='_blank'>DESCARGAR</a> &nbsp;&nbsp;&nbsp;&nbsp;"
	+"</div></td></tr>";

	codigo_tabla = codigo_tabla+"<tr>"
	+"<td class='col-lg-4'>Archivo3</td>"
	+"<td class='col-lg-2'>Fecha3</td>"
	+"<td class='col-lg-6'><div class='center'><a class='hasTip' title='Descargar' href='link_3' target='_blank'>DESCARGAR</a> &nbsp;&nbsp;&nbsp;&nbsp;"
	+"</div></td></tr>";

	codigo_tabla = codigo_tabla+"</tbody>"
	//jQuery('#id_transaccion').val('algo');
	jQuery("#tabla_res").append(codigo_tabla);
	jQuery("#tabla_res").fadeIn("slow");
}


jQuery(document).ready(function(){
	
	var llamar = div_paquetes('PREMIOS_OTRAS_PROVINCIAS');
	
   jQuery.validator.addClassRules('filestyle', {
        required: function(){
                jQuery('input[type=file]').filter(function(e){
                     if(jQuery(this).attr('required')!=undefined ){
                        return true;
                     }else{
                        return false;
                     }
                });    
        }       
    });    
	
	//Valida el nombre del archivo
	jQuery.validator.addMethod("nombrearchivo", function(value, element) {
		
		var nombreArchivo = jQuery('input[type=file]').val().replace(/C:\\fakepath\\/i, ''); //elimino el fakepath
		//Levanto la expresion
		var expReg  = new RegExp(jQuery('input[type=file]').attr("pattern"));
		//alert(expReg);
		if (!expReg.test(nombreArchivo)){
		    return false;
		}
		else{
			return true;
		} 
    });
		
	//reglas de validación del formulario
	jQuery("#formulario_recepcion_pre_pagados_otr_prov").validate({
      rules: {
			id_archivo:{nombrearchivo:true}
            },
      messages: {
			id_archivo:{nombrearchivo:"Nombre de archivo no válido"}
            },
      errorElement: "error"
    });

    //controla que se hayan subido todos los archivos
    jQuery.fn.controlArchivosCargados = function(){
        
        var nombresInput=jQuery('input[type=file]').filter(function(e){
			
			var filename = jQuery('input[type=file]').val().replace(/C:\\fakepath\\/i, '');
			//alert(filename);
            return filename;
        });
	
						
        var requeridos = [];
        //cantidad de archivos requeridos
        var cantInputFile = jQuery('input[type=file]').filter(function(){
            requeridos.push(jQuery(this).attr('id'));
            return jQuery(this).attr('required')=='required';
        }).length; 
        //quito los que ya tienen uno previo
        jQuery.each(nombresInput, function(c,v){
            var noSpan='prev_'+jQuery(v).attr('id');
            if(jQuery('#'+noSpan).length){
                cantInputFile--;
            }
        });

        //archivos cargados - los que tienen previo
        var totalFiles= jQuery('input[type=file]').filter(function(){
            var noSpan='prev_'+jQuery.trim(this.id);
            if(jQuery.trim(this.value) != '' && !jQuery('#'+noSpan).length){
                return true;
            }else{
                return false;
            }
                
        }).length;
        var exito=0;

        if(totalFiles>=cantInputFile){//cantidad correcta
            exito=jQuery('input[type=file]').filter(function(){
                
                if(jQuery.trim(this.value) != '' && jQuery.inArray( jQuery(this).attr('id'), requeridos )!=-1 )
                    return true;
                else 
                    return false;
            });
        }

        return exito;
    }


	//btn procesar
	jQuery("#formulario_recepcion_pre_pagados_otr_prov").on('keydown click','input#btn_procesar', function(e){       

        var code = e.keyCode || e.which;
         if((e.type == "click" || code == 13) && code!=32){
			 jQuery('#btn_procesar').attr('disabled', 'disabled');
			 jQuery('#panel_error').hide();
			 jQuery('#panel_ok').hide();
			 jQuery('#panel_warning').hide();

            var hay_archivos = jQuery(this).controlArchivosCargados();
            if(hay_archivos){  
					var form = document.forms.namedItem("formulario_recepcion_pre_pagados_otr_prov"); 
					var formdata = new FormData(form);
                   jQuery.ajax({
                        type:'post',
                        url: 'carga-archivos-prepagados-otr-prov',
                        dataType:'json',
                        contentType: false,
                        processData: false,
                        cache:false,
                        data: formdata,
                        beforeSend: function(){
                            jQuery('#cargandoModal').removeData("modal").modal({backdrop: 'static', keyboard: false});
                            jQuery('#cargandoModal').modal('show');
                        },
                        //complete:function(){
                        //    jQuery('#cargandoModal').modal('hide');
                        //},
						complete:function(){
                            jQuery('#cargandoModal').modal('hide');
							var llamar2 = div_paquetes('PREMIOS_OTRAS_PROVINCIAS');
                        },
                        success: function (data) {
							//si el panel de error/ok estaba activo --> 
							//lo oculto por si el resultado es exitoso/erróneo
							if(jQuery('#panel_error').css('display') == 'block'){
								jQuery('#panel_error').hide();
							}
							if(jQuery('#panel_ok').css('display') == 'block'){
								jQuery('#panel_ok').hide();
							}

                            // se agrega panel_warning RR
                            if(jQuery('#panel_warning').css('display') == 'block'){
								jQuery('#panel_warning').hide();
							} // fin panel_warning 

							if(data['mensaje']==null){
								data['mensaje']= " ";
							}
							if(data.nuevo_id_ejec_proc){
									jQuery("#id_ejec_proc").val(data['nuevo_id_ejec_proc']);
							}
                            if(data.exito === 1){
                                console.log('op-1: ', data.exito);
                                jQuery('#mensaje_ok').text(data['mensaje']);
                                jQuery('#panel_ok').show();
								// aca iria el llamado
                            }
                            else if(data.exito === 2) {
                                console.log('op-2: ', data.exito);
								jQuery('#mensaje_warning').text(data['mensaje']);
                                jQuery('#panel_warning').show();
                            }    
                            else{
                                jQuery('#mensaje_error').text(data['mensaje']);
                                jQuery('#panel_error').show();
                            }                        
                        },
                        error(xhr){
							jQuery('#mensaje_error').text("");
							 var llamar2 = div_paquetes('PREMIOS_OTRAS_PROVINCIAS');
							
							//si estaba el ok lo oculto
							
							if(jQuery('#panel_ok').css('display') == 'block'){
								jQuery('#panel_ok').hide();
							}
							
							if(xhr.responseText != null){
								jQuery('#mensaje_error').text(xhr.responseText);
							}else{
								//jQuery('#mensaje_error').text("");
							}
                            jQuery('#panel_error').show();
                        }
                    });                
            }else{
				var mensaje= "";             				
				 if(!hay_archivos){
					mensaje="Debe subir el archivo.";
					alert(mensaje);
				}
                jQuery('#mensaje_error').text(mensaje);
                jQuery('#panel_error').show();
            }
        }
    });
	
    /**
    * Control de tipo de archivo
    **/
    jQuery.fn.tipoArchivoValido = function()
    {       
    	console.log("Entreo a asdasdas");
            var cantInputFile = jQuery('input[type=file]').length;
            
            var qsoy=jQuery('input[type=file]').filter(function(){
                    var extPedida = jQuery(this).attr('pattern');
                    var archivo = jQuery(this)[0].files[0];
                    var extFile = archivo.name.substring(archivo.name.lastIndexOf('.')+1).toLowerCase();
                    console.log(extPedida);
                    console.log(extFile);
                    console.log(extPedida.match(extFile));
                    return extPedida.match(extFile);                    
            }).length==cantInputFile;
            return qsoy;
    }

    
	//botón cerrar
	jQuery("#formulario_recepcion_pre_pagados_otr_prov").on('keydown click','input#btn_cerrar', function(e){
		window.location = "panel-principal";
	});
    
	//botón nueva carga
	jQuery("#formulario_recepcion_pre_pagados_otr_prov").on('keydown click','input#btn_nueva_carga', function(e){
		window.location = "panel-recepcion-premios-otras-provincias";
	});
	
	//tooltip input files
	 jQuery('.apply-tooltip').each(function(){
        jQuery(this).siblings("div").attr("data-toggle", "tooltip");
        jQuery(this).siblings("div").attr("data-title", jQuery(this).attr('title'));
    });   
    jQuery('[data-toggle="tooltip"]').tooltip(); 
	

});
