jQuery.noConflict(); 



/*
jQuery('div').load('#botonera', function () {
//    $("input[type='text']").val("some text");
//});


});
*/


// jQuery(document).load(function(){
function pad (str, max) {
  str = str.toString();
  return str.length < max ? pad("0" + str, max) : str;
}

function div_paquetes(valor){
	
	
	jQuery.ajax
      ({
          url: '../paquetes-manuales',
          type: 'post',
		  dataType:'json',
		  data: {'tipo_exportacion':valor},
		  beforeSend: function() {
			jQuery('#cargando').html("<img src='../templates/lifestyleoutpost/images/cargando.gif' />");
		  },
		 // afterSend: function() {
			
		  //},
          success: function(data){
					if (data.mensaje.length !== 0) {
						//alert("kk");
						llenar_tabla(data.mensaje);
					}
				},
		error(xhr){
					jQuery('#mensaje_error').text('Problemas al procesar exportación comuníquese con el administrador.');
                    jQuery('#panel_error').show();
				},
		dataType:'json'
      });
}



// ajax para taer div de paquetes

function llenar_tabla(data) {
	
	
var tipo = jQuery("#nombre_exportacion").val();
var envio = jQuery("#ult_envio").val();

	var f = new Date();
	var m = pad(f.getMonth()+1, 2);
	var y = f.getFullYear();
	var fecha = y+m;

		if(tipo == 'ENVIO_UIF' || tipo == 'ENVIO_AFIP'){
				if(parseInt(envio) >= parseInt(fecha)){
					jQuery("#botonera").hide();
				}
		}
	//location.reload();
	// realizar refresh de valor del ultimo envio, ya que no esta reflejando el ultimo luego de procesar
	
	jQuery('#tabla_res tbody').remove();
	jQuery('#cargando').remove();
	
	codigo_tabla = "<tbody>"
	
	data.length;
	jQuery.each( data, function( i, val ) {
	if(tipo == 'ENVIO_UIF' || tipo == 'ENVIO_AFIP'){
		codigo_tabla = codigo_tabla+"<tr>"
		+"<td class='col-lg-4'>"+val.paquete+"</td>"
		+"<td class='col-lg-2'>"+val.fecha+"</td>"
		+"<td class='col-lg-6'><div class='center'><a class='hasTip' title='Descargar' href='"+val.descargar+"' target='_blank'>DESCARGAR</a> &nbsp;&nbsp;&nbsp;&nbsp;"
		+"</div></td></tr>";
	}else{
		codigo_tabla = codigo_tabla+"<tr>"
		+"<td class='col-lg-4'>"+val.paquete+"</td>"
		+"<td class='col-lg-2'>"+val.fecha+"</td>"
		+"<td class='col-lg-6'><div class='center'><a class='hasTip' title='Descargar' href='"+val.descargar+"' target='_blank'>DESCARGAR</a> &nbsp;&nbsp;&nbsp;&nbsp;"
		+" <!-- <a href='../Envio-correo' title='Envío Correo'  target='_blank'>ENVIAR</a> --></div></td></tr>";
	}
	
	
	});
	
	
	codigo_tabla = codigo_tabla+"</tbody>"
	//jQuery('#id_transaccion').val('algo');
	jQuery("#tabla_res").append(codigo_tabla);
	jQuery("#tabla_res").fadeIn("slow");
	
	
	

}


jQuery(document).ready(function(){
	


jQuery("#btn_cerrar").hide();


jQuery("#content").hide();
jQuery("#perciana").click(function(){
	
    jQuery("#content").toggle();
});






var llamar = div_paquetes(jQuery("#nombre_exportacion").val());



	//btn procesar
	jQuery("#formulario_exportacion").on('keydown click','input#btn_procesar', function(e){
		
		
		
        var code = e.keyCode || e.which;
		
         if((e.type == "click" || code == 13) && code!=32){

					var form = document.forms.namedItem("formulario_exportacion"); 
					var formdata = new FormData(form);
					
                   jQuery.ajax({
                        type:'post',
                        url: '../genera-exportacion',
                        dataType:'json',
                        contentType: false,
						processData: false,
                        cache:false,
						data: formdata,
                        beforeSend: function(){
							
                            jQuery('#cargandoModal').removeData("modal").modal({backdrop: 'static', keyboard: false});
                            jQuery('#cargandoModal').modal('show');
                        },
						//afterSend: function() {
							
						//},
                        complete:function(){
                            jQuery('#cargandoModal').modal('hide');
							var llamar2 = div_paquetes(jQuery("#nombre_exportacion").val());
                        },
                        success: function (data) {
							
							//si el panel de error/ok estaba activo --> 
							//lo oculto por si el resultado es exitoso/erróneo
							if(jQuery('#panel_error').css('display') == 'block'){
								jQuery('#panel_error').hide();
							}
							if(jQuery('#panel_ok').css('display') == 'block'){
								jQuery('#panel_ok').hide();
							}
							if(data['mensaje']==null){
								data['mensaje']= " ";
							}
							if(data.envio){
									jQuery("#ult_envio").val(data['envio']);
									if (jQuery("#nombre_exportacion").val() == "RESERVA_LOTERIA"){
										jQuery("#btn_procesar").hide();
										jQuery("#btn_cerrar").show();
									}
									
								}	
							if(data.nuevo_id_ejec_proc){
									jQuery("#id_ejec_proc").val(data['nuevo_id_ejec_proc']);
								}	
                            if(data.exito){
								jQuery('#mensaje_ok').text(data['mensaje']);
                                jQuery('#panel_ok').show();
								
							
									
							}else{
                                jQuery('#mensaje_error').text(data['mensaje']);
                                jQuery('#panel_error').show();
                            }                        
                        },
                        error(xhr){
						//	alert('pasa a eeror');
							 //alert(xhr.responseText);
							 var llamar2 = div_paquetes();
							//si estaba el ok lo oculto
							if(jQuery('#panel_ok').css('display') == 'block'){
								jQuery('#panel_ok').hide();
							}
							if(xhr.responseText != null){
								
								jQuery('#mensaje_error').text(xhr.responseText);
							}else{
								jQuery('#mensaje_error').text("");
							}
                            jQuery('#panel_error').show();
                        }
                    });                
        }
    });
	
  
	//botón cerrar
	jQuery("#formulario_exportacion").on('keydown click','input#btn_cerrar', function(e){
		//alert("kk");
		window.location = "../panel-exportar/reserva-loteria";
	});
    
	//tooltip input files
	 jQuery('.apply-tooltip').each(function(){
        jQuery(this).siblings("div").attr("data-toggle", "tooltip");
        jQuery(this).siblings("div").attr("data-title", jQuery(this).attr('title'));
    });   
    jQuery('[data-toggle="tooltip"]').tooltip(); 
	
	



});


