jQuery.noConflict(); 
jQuery(document).ready(function(){
    //clase para validar los archivos obligatorios
    jQuery.validator.addClassRules('filestyle', {
        required: function(){
                jQuery('input[type=file]').filter(function(e){
                     if(jQuery(this).attr('required')!=undefined ){
                        return true;
                     }else{
                        return false;
                     }
                });    
        }       
    });    

    jQuery("#formulario_archivos").validate({
      errorElement: "error",     
    });

    //controla que se hayan subido todos los archivos
    jQuery.fn.controlArchivosCargados = function(){
        
        var nombresInput=jQuery('input[type=file]').filter(function(e){
            return jQuery(this).attr('name');
        });

        var requeridos = [];
        //cantidad de archivos requeridos
        var cantInputFile = jQuery('input[type=file]').filter(function(){
            requeridos.push(jQuery(this).attr('id'));
            return jQuery(this).attr('required')=='required';
        }).length; 
        //quito los que ya tienen uno previo
        jQuery.each(nombresInput, function(c,v){
            var noSpan='prev_'+jQuery(v).attr('id');
            if(jQuery('#'+noSpan).length){
                cantInputFile--;
            }
        });

        //archivos cargados - los que tienen previo
        var totalFiles= jQuery('input[type=file]').filter(function(){
            var noSpan='prev_'+jQuery.trim(this.id);
            if(jQuery.trim(this.value) != '' && !jQuery('#'+noSpan).length){
                return true;
            }/*else if(jQuery(this).attr('required')==undefined){
                return true;
            }*/else{
                return false;
            }
                
        }).length;
        var exito=0;

        if(totalFiles>=cantInputFile){//cantidad correcta
            exito=jQuery('input[type=file]').filter(function(){
                
                if(jQuery.trim(this.value) != '' && jQuery.inArray( jQuery(this).attr('id'), requeridos )!=-1 )
                    return true;
                else 
                    return false;
            });
        }
        return exito;
    }

    /**
    * Procesar archivos - consolidación
    */
	
    jQuery("#formulario_archivos").on('keydown click','input#btn_procesar', function(e){
        var code = e.keyCode || e.which;

        if((e.type == "click" || code == 13) && code!=32){
            var hay_archivos = jQuery(this).controlArchivosCargados();
            if(hay_archivos){
                var tiposValidos = 1;//jQuery(this).tipoArchivoValido();
                if(tiposValidos){
                    //anexo campos al formulario
                   var formData = new FormData(jQuery("#formulario_archivos")[0]);
                   formData.append('id_juego_seleccionado',jQuery('#id_juego_seleccionado').val());
                   formData.append('id_estado_seleccionado',jQuery('#id_estado_seleccionado').val());
                   formData.append('id_formato_procesamiento',jQuery('#id_formato_procesamiento').val());
                   formData.append('sorteo',jQuery('#nro_sorteo').val());
    			   formData.append('fecha',jQuery('#fecha_seleccionado').val());
                    jQuery.ajax({
                        type:'post',
                        url: 'carga-archivos-transaccion-bingos',
                        dataType:'json',
                        contentType: false,
                        processData: false,
                        cache:false,
                        data: formData,
                        beforeSend: function(){
                            jQuery('#cargandoModal').removeData("modal").modal({backdrop: 'static', keyboard: false});
                            jQuery('#cargandoModal').modal('show');
                        },
                        complete:function(){
                            jQuery('#cargandoModal').modal('hide');
                        },
                        success: function (data) {
                            if(data.exito){
                                if(jQuery('#panel_error').css('display') == 'block'){
                                    jQuery('#panel_error').hide();
                                }
                                jQuery('#mensaje_ok').text(data['mensaje']);
                                jQuery('#panel_ok').show();
                                if(data.estado==38||data.estado==40){//consol
                                    jQuery("#formulario_archivos").show();
                                    jQuery("#formulario_archivos").empty();
                                    jQuery(data.datosTransaccion['vista']).appendTo('#formulario_archivos');
                                   // jQuery('#panel_btn_datos').show();
                                    jQuery('#panel_btn_diferencias').hide();                                
                                }else{
                                    //jQuery('#panel_btn_datos').hide();
                                    jQuery('#formulario_archivos').hide();
                                }
    							
                            }else{
                                if(jQuery('#panel_ok').css('display') == 'block'){
                                    jQuery('#panel_ok').hide();
                                }
                                //jQuery('#panel_btn_datos').hide();
                                jQuery('#mensaje_error').text(data['mensaje']);
                                jQuery('#panel_error').show();
    							if(data.estado==34 || data.estado==36){//Diferencia en Padrón
                                    //jQuery('#panel_btn_diferencias').show();
                                    jQuery("#formulario_archivos").show();
                                    jQuery("#formulario_archivos").empty();
                                    jQuery(data.datosTransaccion['vista']).appendTo('#formulario_archivos');
                                    //anexo de clase filestyle
                                    if(data.datosTransaccion.nombre_file!=undefined){
                                        var archivos = data.datosTransaccion.nombre_file;
                                        for(var i=0; i<archivos.length;i++){
                                            jQuery('input[name='+archivos[i]['nombre']+']').filestyle({placeholder: "No file",badge:"true", buttonBefore:"true", buttonText:archivos[i]['buttonText']});   
											jQuery('input[name='+archivos[i]['nombre']+']').attr('accept','.zip');
                                            //verificar si se puede sacar el atributo value y colocar para mostrarlo
                                        }   
										jQuery(this).aplicaTooltip();										
                                    }
                                }
                                // if(data.estado==38){//consol
                                    // jQuery('#formulario_archivos').hide();
                                    // jQuery('#panel_btn_diferencias').hide();                                
                                    // jQuery('#panel_btn_publicar').show();
                                // }
                            }
    					
    						var fila=jQuery(".highlighted");//obtengo la fila seleccionada
    						jQuery(fila).find('td').eq(3).find('img').attr('src',data.srcImagen);//cambiamos la imagen
    						jQuery(fila).find('td').eq(4).text(data.estado);//cambiamos el estado
    						jQuery(fila).find('td').eq(5).text(data.de_estado);//cambiamos el mensaje del estado
                        },
                        error: function (xhr){
                            jQuery('#mensaje_error').text(xhr.responseText);
                            jQuery('#panel_error').show();
                        }
                    });
                }else{
                    jQuery('#mensaje_error').text("Los tipos de archivos no son válidos.");
                    jQuery('#panel_error').show();               
                }
            }else{
                jQuery('#mensaje_error').text("Debe subir todos los archivos.");
                jQuery('#panel_error').show();
            }
        }
    });
    
    jQuery("#formulario_archivos").on('keydown click','input#btn_caratula', function(e){
        var code = e.keyCode || e.which;
        
        if((e.type == "click" || code == 13) && code!=32){
            var hay_archivos = jQuery(this).controlArchivosCargados();
            if(hay_archivos){
                var tiposValidos = 1;//jQuery(this).tipoArchivoValido();
                if(tiposValidos){
                    //anexo campos al formulario
                   var formData = new FormData(jQuery("#formulario_archivos")[0]);
                   formData.append('id_juego_seleccionado',jQuery('#id_juego_seleccionado').val());
                   formData.append('id_estado_seleccionado',jQuery('#id_estado_seleccionado').val());
                   formData.append('id_formato_procesamiento',jQuery('#id_formato_procesamiento').val());
                   formData.append('sorteo',jQuery('#nro_sorteo').val());
    			   formData.append('fecha',jQuery('#fecha_seleccionado').val());
    			   formData.append('id_seleccionado',jQuery('#id_seleccionado').val());
                    jQuery.ajax({
                        type:'post',
                        url: 'carga-archivos-caratula-bingos',
                        dataType:'json',
                        contentType: false,
                        processData: false,
                        cache:false,
                        data: formData,
                        beforeSend: function(){
                            jQuery('#cargandoModal').removeData("modal").modal({backdrop: 'static', keyboard: false});
                            jQuery('#cargandoModal').modal('show');
                        },
                        complete:function(){
                            jQuery('#cargandoModal').modal('hide');
                        },
                        success: function (data) {
    					
                            if(data.exito){
                                if(jQuery('#panel_error').css('display') == 'block'){
                                    jQuery('#panel_error').hide();
                                }
                                jQuery('#panel_btn_diferencias').hide();
                                jQuery("#formulario_archivos").show();
    							jQuery("#formulario_archivos").empty();
    							
    							//seria->resultados/consolidación según corresponda
    							jQuery(data.datosTransaccion['vista']).appendTo('#formulario_archivos');
    							//anexo de clase filestyle
    							var archivos = data.datosTransaccion.nombre_file;
    							for(var i=0; i<archivos.length;i++){
    								jQuery('input[name='+archivos[i]['nombre']+']').filestyle({badge:"true", buttonBefore:"true", buttonText:archivos[i]['buttonText']}); 
									jQuery('input[name='+archivos[i]['nombre']+']').attr('accept','.zip');									
    							} 
    							jQuery(this).aplicaTooltip();
    							var fila=jQuery(".highlighted");//obtengo la fila seleccionada
    							fila.attr('id',data.idPgm);//colocamos el id
    							jQuery(fila).find('td').eq(3).find('img').attr('src',data.srcImagen);//cambiamos la imagen
    							jQuery(fila).find('td').eq(4).text(data.estado);//cambiamos el estado
    							jQuery(fila).find('td').eq(5).text(data.de_estado);//cambiamos el mensaje del estado
    							jQuery(this).transaccionActiva(data.datosTransaccion.transaccion_activa);//activamos la transacción correspondiente
                            }else{
                                if(jQuery('#panel_ok').css('display') == 'block'){
                                    jQuery('#panel_ok').hide();
                                }							
                                jQuery('#mensaje_error').text(data['mensaje']);
                                jQuery('#panel_error').show();
                               var fila=jQuery(".highlighted");//obtengo la fila seleccionada
                                fila.attr('id',data.idPgm);//colocamos el id
                                jQuery(fila).find('td').eq(3).find('img').attr('src',data.srcImagen);//cambiamos la imagen
                                jQuery(fila).find('td').eq(4).text(data.estado);//cambiamos el estado
                                jQuery(fila).find('td').eq(5).text(data.de_estado);//cambiamos el mensaje del estado
                                //jQuery(this).transaccionActiva(data.datosTransaccion.transaccion_activa);//activamos la transacción correspondiente
                                
                            }
                           
                        },
                        error: function (xhr){
                            jQuery('#mensaje_error').text(xhr.responseText);
                            jQuery('#panel_error').show();
                        }
                    });
                }else{
                    jQuery('#mensaje_error').text("Los tipos de archivos no son válidos.");
                    jQuery('#panel_error').show();                
                }
            }else{
                //console.log(jQuery('#formulario_archivos').validate());
                jQuery('#mensaje_error').text("Debe subir los archivos requeridos.");
                jQuery('#panel_error').show();
            }
        }
    });
	
	jQuery("#formulario_archivos").on('keydown click','input#btn_resultados', function(e){
        var code = e.keyCode || e.which;
        
        if((e.type == "click" || code == 13) && code!=32){
            var hay_archivos = jQuery(this).controlArchivosCargados();
            if(hay_archivos){
                var tiposValidos = 1;//jQuery(this).tipoArchivoValido();
                if(tiposValidos){
                    //anexo campos al formulario
                   var formData = new FormData(jQuery("#formulario_archivos")[0]);
                   formData.append('id_juego_seleccionado',jQuery('#id_juego_seleccionado').val());
                   formData.append('id_estado_seleccionado',jQuery('#id_estado_seleccionado').val());
                   formData.append('id_formato_procesamiento',jQuery('#id_formato_procesamiento').val());
                   formData.append('sorteo',jQuery('#nro_sorteo').val());
    			   formData.append('fecha',jQuery('#fecha_seleccionado').val());
                   jQuery.ajax({
                        type:'post',
                        url: 'carga-archivos-resultados-bingos',
                        dataType:'json',
                        contentType: false,
                        processData: false,
                        cache:false,
                        data: formData,
                        beforeSend: function(){
                            jQuery('#cargandoModal').removeData("modal").modal({backdrop: 'static', keyboard: false});
                            jQuery('#cargandoModal').modal('show');
                        },
                        complete:function(){
                            jQuery('#cargandoModal').modal('hide');
                        },
                        success: function (data) {
    					
                            if(jQuery('#panel_error').css('display') == 'block'){
                                    jQuery('#panel_error').hide();
                                }
                            jQuery('#panel_btn_diferencias').hide();
                            if(data.exito){
								
                                jQuery("#formulario_archivos").show();
    							jQuery("#formulario_archivos").empty();
    							
    							//seria->publicacion
    							jQuery(data.datosTransaccion['vista']).appendTo('#formulario_archivos');
    							//anexo de clase filestyle
    							if(data.datosTransaccion.nombre_file != undefined){
    								var archivos = data.datosTransaccion.nombre_file;
    								for(var i=0; i<archivos.length;i++){
    									jQuery('input[name='+archivos[i]['nombre']+']').filestyle({badge:"true", buttonBefore:"true", buttonText:archivos[i]['buttonText']});                            
										jQuery('input[name='+archivos[i]['nombre']+']').attr('accept','.zip');
    								} 
									jQuery(this).aplicaTooltip();
    							}
    							var fila=jQuery(".highlighted");//obtengo la fila seleccionada
    							fila.attr('id',data.idPgm);//colocamos el id
    							jQuery(fila).find('td').eq(3).find('img').attr('src',data.srcImagen);//cambiamos la imagen
    							jQuery(fila).find('td').eq(4).text(data.estado);//cambiamos el estado
    							jQuery(fila).find('td').eq(5).text(data.de_estado);//cambiamos el mensaje del estado
								//jQuery(fila).find('td').eq(6).text(data.mensaje);
								//jQuery('#mensaje_ok').text(data.mensaje);
								//jQuery('#panel_ok').show();
								if(data.mensaje){
									jQuery('#mensaje_ok').text(data.mensaje);
									jQuery('#panel_ok').show();
								}
								
    							jQuery(this).transaccionActiva(data.datosTransaccion.transaccion_activa);//activamos la transacción correspondiente
                            }else{
                                if(jQuery('#panel_ok').css('display') == 'block'){
                                    jQuery('#panel_ok').hide();
                                }
                                jQuery('#mensaje_error').text(data['mensaje']);
                                jQuery('#panel_error').show();
                                var fila=jQuery(".highlighted");//obtengo la fila seleccionada
                                jQuery(fila).find('td').eq(3).find('img').attr('src',data.srcImagen);//cambiamos la imagen
                              /*  if(data.estado==25){//prob-car
                                    jQuery('#panel_btn_diferencias').show();
                                }*/
                            }                        
                        },
                        error: function(xhr){
                            jQuery('#mensaje_error').text(xhr.responseText);
                            jQuery('#panel_error').show();
                        }
                    });
                }else{
                    alertify.error("Los tipos de archivos no son válidos.", 3);                
                }
            }else{
                //alertify.error("Debe subir todos los archivos.", 3);
                jQuery('#mensaje_error').text("Debe subir todos los archivos.");
                jQuery('#panel_error').show();
            }
        }
    });
	
    /**
    * Control de tipo de archivo
    **/
    jQuery.fn.tipoArchivoValido = function()
    {       
            var cantInputFile = jQuery('input[type=file]').length;
            
            var qsoy=jQuery('input[type=file]').filter(function(){
                    var extPedida = jQuery(this).attr('pattern');
                    var archivo = jQuery(this)[0].files[0];
                    var extFile = archivo.name.substring(archivo.name.lastIndexOf('.')+1).toLowerCase();
                    console.log(extPedida);
                    console.log(extFile);
                    console.log(extPedida.match(extFile));
                    return extPedida.match(extFile);                    
            }).length==cantInputFile;
            return qsoy;
    }

    jQuery.fn.datosSorteo = function(){
        var sorteo = jQuery('#id_seleccionado').val();
        var datosSorteo='';
        jQuery('#cuerpo_sda >tr').each(function(clave,elemento){
            var estado = jQuery(elemento).find('td').eq(4).html();
			var fechaSorteo=jQuery(elemento).find('#fecha').text().split('-');
			var y=fechaSorteo[0], m=fechaSorteo[1],d=fechaSorteo[2];
			
            if(jQuery(elemento).attr('id')==sorteo &&  jQuery(elemento).hasClass('highlighted') && Number(estado)!=50){
                datosSorteo+='<div id="div_nombre_juego" class="text-center col-md-12 col-lg-6"><h3><label id="lnombre_juego">'+jQuery(elemento).find('#nombre_juego').text()+'</label></h3></div>';
                datosSorteo+='<div id="datos" class="col-sm-6 col-md-12 col-lg-5"><h3><label>Nº: </label><label id="lnro_sorteo">&nbsp;'+jQuery(elemento).find('#nro_sorteo').text()+'</label></h3></div>';
                datosSorteo+='<div id="datos_juego_particular" class="col-sm-12 col-md-12 col-lg-12">';
                datosSorteo+='<div id="datos" class="col-sm-6 col-md-12"><h5 id="h5_fecha_sorteo"><label>Sortea: </label><label id="lfecha_sorteo">&nbsp;'+d+"/"+m+"/"+y+'</label></h5></div>';
                datosSorteo+='<div id="datos" class="col-sm-3 col-md-6"><label>Prescribe: </label><label id="lfecha_prescribe">&nbsp;'+jQuery(elemento).find('#fecha_prescripcion').text()+'</label></div>';
                datosSorteo+='<div id="datos" class="col-sm-3 col-md-6"><label>Próximo: </label><label id="lfecha_proximo">&nbsp;'+jQuery(elemento).find('#fecha_proximo').text()+'</label></div>';
                datosSorteo+='</div>';
            }
        });
        if(!datosSorteo.length){
            jQuery('#cuerpo_sd >tr').each(function(clave,elemento){
                var estado = jQuery(elemento).find('td').eq(4).html();
                if(jQuery(elemento).attr('id')==sorteo &&  jQuery(elemento).hasClass('highlighted') && Number(estado)!=50){
                    datosSorteo+='<div id="div_nombre_juego" class="text-center col-md-7 col-lg-6"><h3><label id="lnombre_juego">'+jQuery(elemento).find('#nombre_juego').text()+'</label></h3></div>';
                    datosSorteo+='<div id="datos" class="col-sm-6 col-md-12 col-lg-5"><h3><label id="lnro_sorteo">&nbsp;'+jQuery(elemento).find('#nro_sorteo').text()+'</label></h3></div>';
                    datosSorteo+='<div id="datos_juego_particular" class="col-sm-12 col-md-12 col-lg-12">'; 
                    datosSorteo+='<div id="datos" class="col-sm-6 col-md-12 col-lg-12"><h5 id="h5_fecha_sorteo"><label>Sortea: </label><label id="lfecha_sorteo">&nbsp;'+jQuery(elemento).find('#fecha_sorteo').text()+'</label></h5></div>';
                    datosSorteo+='<div id="datos" class="col-sm-6 col-md-12 col-lg-6"><label>Prescribe: </label><label id="lfecha_prescribe">&nbsp;'+jQuery(elemento).find('#fecha_prescripcion').text()+'</label></div>';
                    datosSorteo+='<div id="datos" class="col-sm-6 col-md-12 col-lg-6"><label>Próximo: </label><label id="lfecha_proximo">&nbsp;'+jQuery(elemento).find('#fecha_proximo').text()+'</label></div>';
                    datosSorteo+='</div>';
                }
            });
            
        }
        jQuery('#datos_juego').empty();
        jQuery('#datos_juego').append(datosSorteo); 
    };

    jQuery.fn.transaccionActiva=function(transaccion){
        jQuery("#div_captacion_apuestas").removeClass("transaccionDesactivada");
        jQuery("#div_resultados_premiados").removeClass("transaccionDesactivada");
        jQuery("#div_liquidacion_ap_com").removeClass("transaccionDesactivada");
		
		jQuery("#div_captacion_apuestas").removeClass("transaccionActiva");
        jQuery("#div_resultados_premiados").removeClass("transaccionActiva");
        jQuery("#div_liquidacion_ap_com").removeClass("transaccionActiva");
		
		jQuery("#div_captacion_apuestas").removeClass("transaccionRealizada");
        jQuery("#div_resultados_premiados").removeClass("transaccionRealizada");
        jQuery("#div_liquidacion_ap_com").removeClass("transaccionRealizada");
		
		jQuery("#div_captacion_apuestas").removeClass("transaccionFaltante");
        jQuery("#div_resultados_premiados").removeClass("transaccionFaltante");
        jQuery("#div_liquidacion_ap_com").removeClass("transaccionFaltante");
		
		jQuery("#div_label_etapa").removeClass("transaccionDesactivada");
		
		jQuery("#im_estado_cap_ap").hide();		
		jQuery("#im_estado_res_prem").hide();		
		jQuery("#im_estado_liq_ap_com").hide();			
		
        if(transaccion==1){//apago 2 y 3 - prendo 1
            jQuery("#div_resultados_premiados").addClass("transaccionFaltante");
            jQuery("#div_liquidacion_ap_com").addClass("transaccionFaltante");
			jQuery("#div_captacion_apuestas").addClass("transaccionActiva");
        }else if(transaccion==2){//apago 1 y 3 - prendo 2
            jQuery("#div_captacion_apuestas").addClass("transaccionRealizada");
			jQuery("#im_estado_cap_ap").show();
            jQuery("#div_liquidacion_ap_com").addClass("transaccionFaltante");
			jQuery("#div_resultados_premiados").addClass("transaccionActiva");
        }else if(transaccion==3){//apago 1 y 2 - prendo 3
            jQuery("#div_captacion_apuestas").addClass("transaccionRealizada");
            jQuery("#div_resultados_premiados").addClass("transaccionRealizada");
			jQuery("#im_estado_cap_ap").show();
			jQuery("#im_estado_res_prem").show();
			jQuery("#div_liquidacion_ap_com").addClass("transaccionActiva");
        }else{
            jQuery("#div_captacion_apuestas").addClass("transaccionDesactivada");
            jQuery("#div_resultados_premiados").addClass("transaccionDesactivada");
            jQuery("#div_liquidacion_ap_com").addClass("transaccionDesactivada");
			jQuery("#div_label_etapa").addClass("transaccionDesactivada");
			jQuery("#im_estado_cap_ap").hide();		
			jQuery("#im_estado_res_prem").hide();		
			jQuery("#im_estado_liq_ap_com").hide();	
        }
		if(jQuery("#no_procesar").length){
            jQuery("#div_captacion_apuestas").addClass("transaccionDesactivada");
            jQuery("#div_resultados_premiados").addClass("transaccionDesactivada");
            jQuery("#div_liquidacion_ap_com").addClass("transaccionDesactivada");
			jQuery("#div_label_etapa").addClass("transaccionDesactivada");
			jQuery("#im_estado_cap_ap").hide();		
			jQuery("#im_estado_res_prem").hide();		
			jQuery("#im_estado_liq_ap_com").hide();	
        }
    };

    //btn - publicar
    jQuery("#formulario_archivos").on('keydown click','input#btn_publicar', function(e){
        var code = e.keyCode || e.which;
        
        if((e.type == "click" || code == 13) && code!=32){
			//var formData = new FormData(jQuery("#formulario_archivos")[0]);
                   //formData.append('id_juego_seleccionado',jQuery('#id_juego_seleccionado').val());
                  // formData.append('id_estado_seleccionado',jQuery('#id_estado_seleccionado').val());
                  // formData.append('id_formato_procesamiento',jQuery('#id_formato_procesamiento').val());
                  // formData.append('sorteo',jQuery('#nro_sorteo').val());
    			   //formData.append('fecha',jQuery('#fecha_seleccionado').val());
			
            jQuery.ajax({
                        type:'post',
                        url: 'publicar-bingos',
                        dataType:'json',
                        data: {'sorteo':jQuery('#nro_sorteo').val(), 'id_juego_seleccionado':jQuery('#id_juego_seleccionado').val(),'id_estado_seleccionado':jQuery('#id_estado_seleccionado').val(),'id_formato_procesamiento':jQuery('#id_formato_procesamiento').val(),'fecha':jQuery('#fecha_seleccionado').val()},
                       // data: formData,
                        beforeSend: function(){
                            jQuery('#cargandoModal').removeData("modal").modal({backdrop: 'static', keyboard: false});
                            jQuery('#cargandoModal').modal('show');
                        },
                        complete:function(){
                            jQuery('#cargandoModal').modal('hide');
                        },
                        success: function (data) {
                            if(data.exito){
                                if(jQuery('#panel_error').css('display') == 'block'){
                                    jQuery('#panel_error').hide();
                                }
                                jQuery('#formulario_archivos').hide();
                                jQuery('#mensaje_ok').text(data['mensaje']);
                                jQuery('#panel_btn_publicar').hide();
                                jQuery('#panel_ok').show();
                                var fila=jQuery(".highlighted");//obtengo la fila seleccionada
                                fila.attr('id',data.idPgm);//colocamos el id
                                jQuery(fila).find('td').eq(4).text(data.estado);//cambiamos el estado
                                jQuery(fila).find('td').eq(5).text(data.de_estado);//cambiamos el mensaje del estado
                                jQuery(this).transaccionActiva(data.datosTransaccion.transaccion_activa);
                            }else{
                                if(jQuery('#panel_ok').css('display') == 'block'){
                                    jQuery('#panel_ok').hide();
                                }
                                jQuery('#mensaje_error').text(data['mensaje']);
                                jQuery('#panel_error').show();
                                if(data['mensaje'].indexOf('Publicación')!=-1){//pte - probl.
                                    jQuery('#formulario_archivos').hide();
                                    jQuery('#panel_btn_publicar').show();
                                }
                            }
                            var fila=jQuery(".highlighted");//obtengo la fila seleccionada
                            jQuery(fila).find('td').eq(3).find('img').attr('src',data.srcImagen);//cambiamos la imagen
                        },
                        error: function(xhr){
                           jQuery('#mensaje_error').text(xhr.responseText);
                            jQuery('#panel_error').show();
                        }
                    });
        }
    });
    
    //btn - publicar
    jQuery("#formulario_archivos").on('keydown click','input#btn_ver_totales', function(e){
        alert("Próximamente reporte");
    });

    //btn - publicar
    jQuery("#formulario_archivos").on('keydown click','input#btn_diferencias', function(e){
        alert("Próximamente reporte");
    });
        
	//tooltip input files
	jQuery.fn.aplicaTooltip = function(){
		jQuery('.apply-tooltip').each(function(){
			jQuery(this).siblings("div").attr("data-toggle", "tooltip");	
			jQuery(this).next("div").attr("data-title", jQuery(this).attr('title')); 
		});  
		jQuery('[data-toggle="tooltip"]').tooltip(); 
	};
    
	
});



