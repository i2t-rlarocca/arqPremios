jQuery.noConflict(); 
jQuery(document).ready(function(){

    //clase para validar los archivos obligatorios
    jQuery.validator.addClassRules('filestyle', {
        required: function(){
                jQuery('input[type=file]').filter(function(e){
                     if(jQuery(this).attr('required')!=undefined ){
                        return true;
                     }else{
                        return false;
                     }
                });    
        }       
    });    
	
	

    //controla que se hayan subido todos los archivos
    jQuery.fn.controlArchivosCargados = function(){
        
        var nombresInput=jQuery('input[type=file]').filter(function(e){
            return jQuery(this).attr('name');
        });

        var requeridos = [];
        //cantidad de archivos requeridos
        var cantInputFile = jQuery('input[type=file]').filter(function(){
            requeridos.push(jQuery(this).attr('id'));
            return jQuery(this).attr('required')=='required';
        }).length; 
        //quito los que ya tienen uno previo
        jQuery.each(nombresInput, function(c,v){
            var noSpan='prev_'+jQuery(v).attr('id');
            if(jQuery('#'+noSpan).length){
                cantInputFile--;
            }
        });

        //archivos cargados - los que tienen previo
        var totalFiles= jQuery('input[type=file]').filter(function(){
            var noSpan='prev_'+jQuery.trim(this.id);
            if(jQuery.trim(this.value) != '' && !jQuery('#'+noSpan).length){
                return true;
            }else{
                return false;
            }
                
        }).length;
        var exito=0;

        if(totalFiles>=cantInputFile){//cantidad correcta
            exito=jQuery('input[type=file]').filter(function(){
                
                if(jQuery.trim(this.value) != '' && jQuery.inArray( jQuery(this).attr('id'), requeridos )!=-1 )
                    return true;
                else 
                    return false;
            });
        }
        return exito;
    }

	//btn procesar
	jQuery("#formulario_limites").on('keydown click','input#btn_procesar', function(e){
        var code = e.keyCode || e.which;
         if((e.type == "click" || code == 13) && code!=32){
            var hay_archivos = jQuery(this).controlArchivosCargados();
			
            if(hay_archivos){   
					var form = document.forms.namedItem("formulario_limites"); 
					var formdata = new FormData(form);
                   jQuery.ajax({
                        type:'post',
                        url: 'carga-archivos-limites',
                        dataType:'json',
                        contentType: false,
                        processData: false,
                        cache:false,
                        data: formdata,
                        beforeSend: function(){
                            jQuery('#cargandoModal').removeData("modal").modal({backdrop: 'static', keyboard: false});
                            jQuery('#cargandoModal').modal('show');
                        },
                        complete:function(){
                            jQuery('#cargandoModal').modal('hide');
                        },
                        success: function (data) {
							//si el panel de error/ok estaba activo --> 
							//lo oculto por si el resultado es exitoso/erróneo
							if(jQuery('#panel_error').css('display') == 'block'){
								jQuery('#panel_error').hide();
							}
							if(jQuery('#panel_ok').css('display') == 'block'){
								jQuery('#panel_ok').hide();
							}
							if(data['mensaje']==null){
								data['mensaje']= " ";
							}
                            if(data.exito){
								jQuery('#mensaje_ok').text(data['mensaje']);
                                jQuery('#panel_ok').show();
                            }else{
                                jQuery('#mensaje_error').text(data['mensaje']);
                                jQuery('#panel_error').show();
                            }             
							reportePDF(data['urlReporte']);
                        },
                        error(xhr){
							//si estaba el ok lo oculto
							if(jQuery('#panel_ok').css('display') == 'block'){
								jQuery('#panel_ok').hide();
							}
							if(xhr.responseText != null){
								jQuery('#mensaje_error').text(xhr.responseText);
							}else{
								jQuery('#mensaje_error').text("");
							}
                            jQuery('#panel_error').show();
                        }
                    });                
            }else{
				var mensaje= "";
                if(!hay_archivos){
					mensaje="Debe subir todos los archivos.";
				}
				
                jQuery('#mensaje_error').text(mensaje);
                jQuery('#panel_error').show();
            }
        }
    });
	
    /**
    * Control de tipo de archivo
    **/
    jQuery.fn.tipoArchivoValido = function()
    {       
            var cantInputFile = jQuery('input[type=file]').length;
            
            var qsoy=jQuery('input[type=file]').filter(function(){
                    var extPedida = jQuery(this).attr('pattern');
                    var archivo = jQuery(this)[0].files[0];
                    var extFile = archivo.name.substring(archivo.name.lastIndexOf('.')+1).toLowerCase();
                    console.log(extPedida);
                    console.log(extFile);
                    console.log(extPedida.match(extFile));
                    return extPedida.match(extFile);                    
            }).length==cantInputFile;
            return qsoy;
    }

    
	//botón cerrar
	jQuery("#formulario_limites").on('keydown click','input#btn_cerrar', function(e){
		window.location = "panel-principal";
	});
    
	//tooltip input files
	 jQuery('.apply-tooltip').each(function(){
        jQuery(this).siblings("div").attr("data-toggle", "tooltip");
        jQuery(this).siblings("div").attr("data-title", jQuery(this).attr('title'));
    });   
    jQuery('[data-toggle="tooltip"]').tooltip(); 
	
});

function reportePDF(url){
 window.open(url, '_blank');
}
