function controlSession(){
	jQuery.ajax({
            type: 'GET',
            url: "control_sesion",   
            dataType:'json',  
            success: function (data) {
				
                if(data['mensaje']=='out'){ 
					clearInterval(intervalo);
					jQuery('#sesionModal').modal({backdrop:'static' });// keyboard: false, 
					var body = '<input type="hidden" id="url_portal" value="'+data['url']+'"/>';
					jQuery('#sesionModal').find('.modal-body').append(body).end();
					jQuery('#sesionModal').modal('show');
                }
               
                
            }
        });
	//para el modal de fin de sesión de las vistas comunes
    jQuery('#sesionModal').on('hidden.bs.modal', function(){
       var url = jQuery('.modal-body #url_portal').val();
       cerrarSesion(url);
    }); 
	
	//para el modal de fin de sesión de las vistas modales
	jQuery('#sesionModal_m').on('hidden.bs.modal', function(){
        var url = jQuery('.modal-body #url_portal').val();
       cerrarSesion(url);
    });
	
	
}
        
//llamada a la función cada 2 segundos         
var intervalo = setInterval('controlSession();', 15000);


function cerrarSesion(url){
    window.location = url;
}