jQuery.noConflict(); 
jQuery(document).ready(function(){
	
	/*
	if (jQuery('#id_seleccionado').val() == ''){
		
	}
	*/
	jQuery('#errores').hide();
	jQuery('#inc_cuad_afec').attr('disabled','disabled');
	
	// recuadro de radios de periodos
	jQuery( "#panel_alertas" ).click(function() {
		jQuery('#errores').hide();
		var estado = jQuery('input:radio[id=periodo]:checked').val();
		var result = estado.split('-');
			estado = result[1]; 
			
			if (estado == 4) // estado OK
			{
				jQuery("#completo_div #a_procesar").prop("checked", true);
				jQuery('#a_partir_fallo_div #a_procesar').attr('disabled','disabled');
				jQuery("#inc_cuad_afec").removeAttr('disabled');
			}
			else if (estado == 3) // estado ER
			{
				jQuery("#a_partir_fallo_div #a_procesar").prop("checked", true);
				jQuery('#a_partir_fallo_div #a_procesar').removeAttr('disabled');
				jQuery("#inc_cuad_afec").prop("checked", false);
				jQuery("#inc_cuad_afec").attr('disabled','disabled');
			}

	});
	
	
	jQuery("#btn_cerrar").on('click', function(e){
		window.location = "panel-principal";
	});
	
		
	// click en "completo"
	jQuery("#completo_div").click(function() {
		var a_procesar = jQuery('input:radio[id=a_procesar]:checked').val(); 
			if( a_procesar == '0'){
				jQuery("#inc_cuad_afec").removeAttr('disabled');
			}
		});
	
	// click en "a partir del fallo"		
	jQuery("#a_partir_fallo_div").click(function() {
			jQuery("#inc_cuad_afec").prop("checked", false);
			jQuery('#inc_cuad_afec').attr('disabled','disabled');
	});
	
	// procesar
	jQuery( "#btn_procesar" ).click(function() {
		var periodo = jQuery('input:radio[id=periodo]:checked').val();
		
		if (periodo == undefined){
			jQuery('input:radio[id=periodo]').focus();
			jQuery('#errores').hide();
			jQuery('#errores').show();
			jQuery('#errores .alert #mensaje_in').html('Ingrese Per&iacute;odo');
			return false;
		}
		
		var estadop = jQuery('input:radio[id=periodo]:checked').val();
		var resultp = estadop.split('-');
			estadop = resultp[1]; 
			periodo = resultp[0]; 
		if (estadop == 4) // estado OK		
		{
			var estado_perido = 'OK';
		}
		else if(estadop == 3){
			var estado_perido = 'ER';
		}
		var a_procesar = jQuery('input:radio[id=a_procesar]:checked').val(); 
		if (a_procesar == 1){
			var a_partir_fallo = '1';
			var completo = '0';
		}else if(a_procesar == 0){
			var a_partir_fallo = '0';
			var completo = '1';
		}
		var inc_cuad_afec = jQuery("#inc_cuad_afec").is(':checked') ? 1 : 0;
		var dif_ejec = jQuery("#dif_ejec").is(':checked') ? 1 : 0;
	
		jQuery.ajax({
                        type:'post',
                        url: 'trata-reproceso-bi',
                        dataType:'json',
                      //  contentType: false,
                       // processData: false,
                        cache:false,
                        data: {'p_periodo':periodo,'p_estado':estado_perido,'p_a_partir_fallo':a_partir_fallo,'p_completo':completo,
						'p_incl_cuad_afec':inc_cuad_afec,'p_dif_ejec':dif_ejec},
                        beforeSend: function(){
                            jQuery('#cargandoModal').removeData("modal").modal({backdrop: 'static', keyboard: false});
                            jQuery('#cargandoModal').modal('show');
                        },
                        complete:function(){
                            jQuery('#cargandoModal').modal('hide');
                        },
                        success: function (data) {
													
							//si el panel de error/ok estaba activo --> 
							//lo oculto por si el resultado es exitoso/erróneo
							if(jQuery('#panel_error').css('display') == 'block'){
								jQuery('#panel_error').hide();
							}
							if(jQuery('#panel_ok').css('display') == 'block'){
								jQuery('#panel_ok').hide();
							}
							
							if(data.mensaje==null){
								//alert(data['mensaje']);
								data['mensaje']= " ";
							}
							//alert(data.exito);
                            if(data.exito == true){
								//alert(data.mensaje[0]);
								jQuery('#mensaje_ok').html(data.mensaje);
                                jQuery('#panel_ok').show();
								jQuery('#btn_procesar').attr('disabled','disabled');
								jQuery('#btn_procesar').css('display','none');
								//window.location = "panel-principal";
								// aca iria el llamado
                            }else{
                                jQuery('#mensaje_error').html(data.mensaje);
                                jQuery('#panel_error').show();
								
                            }    
							
						/*
								setTimeout(function(){
								   window.location.reload(1);
								}, 5000);
						*/
                        },
                        error(xhr){
							//alert(xhr);
							//si estaba el ok lo oculto
							if(jQuery('#panel_ok').css('display') == 'block'){
								jQuery('#panel_ok').hide();
							}
							if(xhr.responseText != null){
								jQuery('#mensaje_error').text(xhr.responseText);
							}else{
								jQuery('#mensaje_error').text("");
							}
                            jQuery('#panel_error').show();
                        }
                    });    
	  
	  

	  
	});
	

/*	
	//tooltip input files
	jQuery.fn.aplicaTooltip = function(){
		jQuery('.apply-tooltip').each(function(){
			jQuery(this).siblings("div").attr("data-toggle", "tooltip");	
			jQuery(this).siblings("div").attr("data-title", jQuery(this).attr('title'));
		});  
		jQuery('[data-toggle="tooltip"]').tooltip(); 
	};
*/    

	//botón cerrar
	

	//reglas de validación del formulario
	jQuery("#formulario_reproceso_bi").validate({
      rules: {
            periodo: {required:true, number:true, min:5}
            },
      messages: {
            periodo: {required:" Debe ingresar un nº de período.", number:" Ingrese solo números", min:"Mínimo de 6 nº"}, 
            },
      errorElement: "error"
    });

});//fin document ready


 



