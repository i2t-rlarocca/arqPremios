jQuery.noConflict(); 
jQuery(document).ready(function(){
	

jQuery("#botonera").hide();
	

jQuery("#content").hide();
jQuery("#perciana").click(function(){
	
jQuery("#content").toggle();
});
// ajax para taer div de paquetes

function llenar_tabla(data) {
	
	jQuery('#tabla_res tbody').remove();
	jQuery('#cargando').remove();
	codigo_tabla = "<tbody>"
	
	data.length;
	jQuery.each( data, function( i, val ) {

		codigo_tabla = codigo_tabla+"<tr>"
		+"<td class='col-lg-4'>"+val.paquete+"</td>"
		+"<td class='col-lg-2'>"+val.fecha+"</td>"
		+"<td class='col-lg-6'><div class='center'><a class='hasTip' title='Descargar' href='"+val.descargar+"' target='_blank'>DESCARGAR</a> &nbsp;&nbsp;&nbsp;&nbsp;"
		+"<a href='../Envio-correo' title='Envío Correo'  target='_blank'>ENVIAR</a> &nbsp;&nbsp;&nbsp;&nbsp;</div></td></tr>";
		
	});
	
	
	codigo_tabla = codigo_tabla+"</tbody>"
	//jQuery('#id_transaccion').val('algo');
	jQuery("#tabla_res").append(codigo_tabla);
	jQuery("#tabla_res").fadeIn("slow");
	
}



function div_paquetes(){
	jQuery.ajax
      ({
          url: '../paquetes-enviouif',
          type: 'post',
		  beforeSend: function() {
			jQuery('#cargando').html("<img src='../templates/lifestyleoutpost/images/cargando.gif' />");
		  },
		 // afterSend: function() {
			
		  //},
          success: function(data){
					if (data.mensaje.length !== 0) {
						llenar_tabla(data.mensaje);
					}
				},
		error(xhr){
				alert(xhr.responseText);
				},
		dataType:'json'
      });
}


var llamar = div_paquetes();


	//btn procesar
	jQuery("#formulario_exportacion").on('keydown click','input#btn_procesar', function(e){
		
        var code = e.keyCode || e.which;
		
         if((e.type == "click" || code == 13) && code!=32){
			 
					var form = document.forms.namedItem("formulario_exportacion"); 
					var formdata = new FormData(form);
					
                   jQuery.ajax({
                        type:'post',
                        url: '../genera-exportacion-uif',
                        dataType:'json',
                        contentType: false,
						processData: false,
                        cache:false,
						data: formdata,
                        beforeSend: function(){
							
                            jQuery('#cargandoModal').removeData("modal").modal({backdrop: 'static', keyboard: false});
                            jQuery('#cargandoModal').modal('show');
                        },
						//afterSend: function() {
							
						//},
                        complete:function(){
                            jQuery('#cargandoModal').modal('hide');
							var llamar2 = div_paquetes();
                        },
                        success: function (data) {
							
							//si el panel de error/ok estaba activo --> 
							//lo oculto por si el resultado es exitoso/erróneo
							if(jQuery('#panel_error').css('display') == 'block'){
								jQuery('#panel_error').hide();
							}
							if(jQuery('#panel_ok').css('display') == 'block'){
								jQuery('#panel_ok').hide();
							}
							if(data['mensaje']==null){
								data['mensaje']= " ";
							}
                            if(data.exito){
								jQuery('#mensaje_ok').text(data['mensaje']);
                                jQuery('#panel_ok').show();
								// aca iria el llamado
                            }else{
                                jQuery('#mensaje_error').text(data['mensaje']);
                                jQuery('#panel_error').show();
                            }                        
                        },
                        error(xhr){
							 alert(xhr.responseText);
							//si estaba el ok lo oculto
							if(jQuery('#panel_ok').css('display') == 'block'){
								jQuery('#panel_ok').hide();
							}
							if(xhr.responseText != null){
								
								jQuery('#mensaje_error').text(xhr.responseText);
							}else{
								jQuery('#mensaje_error').text("");
							}
                            jQuery('#panel_error').show();
                        }
                    });                
        }
    });
	
  
	//botón cerrar
	jQuery("#formulario_exportacion").on('keydown click','input#btn_cerrar', function(e){
		window.location = "panel-principal";
	});
    
	//tooltip input files
	 jQuery('.apply-tooltip').each(function(){
        jQuery(this).siblings("div").attr("data-toggle", "tooltip");
        jQuery(this).siblings("div").attr("data-title", jQuery(this).attr('title'));
    });   
    jQuery('[data-toggle="tooltip"]').tooltip(); 
	
	






});
