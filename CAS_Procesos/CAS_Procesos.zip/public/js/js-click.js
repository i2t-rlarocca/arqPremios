function cierra(){
window.close();
}

function portal(){
	url='portal';
	window.location = url;	
}
