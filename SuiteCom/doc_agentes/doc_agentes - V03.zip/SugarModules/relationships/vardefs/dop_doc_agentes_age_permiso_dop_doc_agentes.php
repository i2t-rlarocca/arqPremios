<?php
// created: 2021-12-23 17:12:11
$dictionary["dop_doc_agentes"]["fields"]["dop_doc_agentes_age_permiso"] = array (
  'name' => 'dop_doc_agentes_age_permiso',
  'type' => 'link',
  'relationship' => 'dop_doc_agentes_age_permiso',
  'source' => 'non-db',
  'module' => 'age_permiso',
  'bean_name' => 'age_permiso',
  'vname' => 'LBL_DOP_DOC_AGENTES_AGE_PERMISO_FROM_AGE_PERMISO_TITLE',
  'id_name' => 'dop_doc_agentes_age_permisoage_permiso_ida',
);
$dictionary["dop_doc_agentes"]["fields"]["dop_doc_agentes_age_permiso_name"] = array (
  'name' => 'dop_doc_agentes_age_permiso_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_DOP_DOC_AGENTES_AGE_PERMISO_FROM_AGE_PERMISO_TITLE',
  'save' => true,
  'id_name' => 'dop_doc_agentes_age_permisoage_permiso_ida',
  'link' => 'dop_doc_agentes_age_permiso',
  'table' => 'age_permiso',
  'module' => 'age_permiso',
  'rname' => 'name',
);
$dictionary["dop_doc_agentes"]["fields"]["dop_doc_agentes_age_permisoage_permiso_ida"] = array (
  'name' => 'dop_doc_agentes_age_permisoage_permiso_ida',
  'type' => 'link',
  'relationship' => 'dop_doc_agentes_age_permiso',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_DOP_DOC_AGENTES_AGE_PERMISO_FROM_DOP_DOC_AGENTES_TITLE',
);
