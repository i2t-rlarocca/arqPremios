<?php
// created: 2021-12-23 17:12:11
$dictionary["age_permiso"]["fields"]["dop_doc_agentes_age_permiso"] = array (
  'name' => 'dop_doc_agentes_age_permiso',
  'type' => 'link',
  'relationship' => 'dop_doc_agentes_age_permiso',
  'source' => 'non-db',
  'module' => 'dop_doc_agentes',
  'bean_name' => 'dop_doc_agentes',
  'side' => 'right',
  'vname' => 'LBL_DOP_DOC_AGENTES_AGE_PERMISO_FROM_DOP_DOC_AGENTES_TITLE',
);
