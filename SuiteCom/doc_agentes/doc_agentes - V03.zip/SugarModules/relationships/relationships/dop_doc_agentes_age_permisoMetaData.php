<?php
// created: 2021-12-23 17:12:11
$dictionary["dop_doc_agentes_age_permiso"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'dop_doc_agentes_age_permiso' => 
    array (
      'lhs_module' => 'age_permiso',
      'lhs_table' => 'age_permiso',
      'lhs_key' => 'id',
      'rhs_module' => 'dop_doc_agentes',
      'rhs_table' => 'dop_doc_agentes',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'dop_doc_agentes_age_permiso_c',
      'join_key_lhs' => 'dop_doc_agentes_age_permisoage_permiso_ida',
      'join_key_rhs' => 'dop_doc_agentes_age_permisodop_doc_agentes_idb',
    ),
  ),
  'table' => 'dop_doc_agentes_age_permiso_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'dop_doc_agentes_age_permisoage_permiso_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'dop_doc_agentes_age_permisodop_doc_agentes_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'dop_doc_agentes_age_permisospk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'dop_doc_agentes_age_permiso_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'dop_doc_agentes_age_permisoage_permiso_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'dop_doc_agentes_age_permiso_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'dop_doc_agentes_age_permisodop_doc_agentes_idb',
      ),
    ),
  ),
);