<?php
 // created: 2021-12-23 17:12:11
$layout_defs["age_permiso"]["subpanel_setup"]['dop_doc_agentes_age_permiso'] = array (
  'order' => 100,
  'module' => 'dop_doc_agentes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_DOP_DOC_AGENTES_AGE_PERMISO_FROM_DOP_DOC_AGENTES_TITLE',
  'get_subpanel_data' => 'dop_doc_agentes_age_permiso',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
