<?php
$module_name = 'dop_doc_agentes';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'dop_doc_agentes_age_permiso_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_DOP_DOC_AGENTES_AGE_PERMISO_FROM_AGE_PERMISO_TITLE',
        'id' => 'DOP_DOC_AGENTES_AGE_PERMISOAGE_PERMISO_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'dop_doc_agentes_age_permiso_name',
      ),
      'tipodocumento' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_TIPODOCUMENTO',
        'id' => 'DOP_DOC_TIPODOCUMENTOS_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'tipodocumento',
      ),
      'fecha' => 
      array (
        'type' => 'date',
        'label' => 'LBL_FECHA',
        'width' => '10%',
        'default' => true,
        'name' => 'fecha',
      ),
      'verificado' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_VERIFICADO',
        'width' => '10%',
        'name' => 'verificado',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
