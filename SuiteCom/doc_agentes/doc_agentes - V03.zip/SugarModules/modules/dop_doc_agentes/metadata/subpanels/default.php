<?php
$module_name='dop_doc_agentes';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'dop_doc_agentes',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '20%',
      'default' => true,
    ),
    'fecha' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_FECHA',
      'width' => '10%',
      'default' => true,
    ),
    'url' => 
    array (
      'type' => 'url',
      'vname' => 'LBL_URL',
      'width' => '30%',
      'default' => true,
    ),
    'verificado' => 
    array (
      'type' => 'bool',
      'default' => true,
      'vname' => 'LBL_VERIFICADO',
      'width' => '10%',
    ),
    'edit_button' => 
    array (
      'vname' => 'LBL_EDIT_BUTTON',
      'widget_class' => 'SubPanelEditButton',
      'module' => 'dop_doc_agentes',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'vname' => 'LBL_REMOVE',
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'dop_doc_agentes',
      'width' => '5%',
      'default' => true,
    ),
  ),
);