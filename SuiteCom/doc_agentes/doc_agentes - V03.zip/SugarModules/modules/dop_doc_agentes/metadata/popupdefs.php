<?php
$popupMeta = array (
    'moduleMain' => 'dop_doc_agentes',
    'varName' => 'dop_doc_agentes',
    'orderBy' => 'dop_doc_agentes.name',
    'whereClauses' => array (
  'name' => 'dop_doc_agentes.name',
  'fecha' => 'dop_doc_agentes.fecha',
  'dop_doc_agentes_age_permiso_name' => 'dop_doc_agentes.dop_doc_agentes_age_permiso_name',
  'verificado' => 'dop_doc_agentes.verificado',
  'tipodocumento' => 'dop_doc_agentes.tipodocumento',
),
    'searchInputs' => array (
  1 => 'name',
  5 => 'fecha',
  6 => 'dop_doc_agentes_age_permiso_name',
  7 => 'verificado',
  8 => 'tipodocumento',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'dop_doc_agentes_age_permiso_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_DOP_DOC_AGENTES_AGE_PERMISO_FROM_AGE_PERMISO_TITLE',
    'id' => 'DOP_DOC_AGENTES_AGE_PERMISOAGE_PERMISO_IDA',
    'width' => '10%',
    'name' => 'dop_doc_agentes_age_permiso_name',
  ),
  'tipodocumento' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_TIPODOCUMENTO',
    'id' => 'DOP_DOC_TIPODOCUMENTOS_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'tipodocumento',
  ),
  'fecha' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA',
    'width' => '10%',
    'name' => 'fecha',
  ),
  'verificado' => 
  array (
    'type' => 'bool',
    'label' => 'LBL_VERIFICADO',
    'width' => '10%',
    'name' => 'verificado',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
    'name' => 'name',
  ),
  'DOP_DOC_AGENTES_AGE_PERMISO_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_DOP_DOC_AGENTES_AGE_PERMISO_FROM_AGE_PERMISO_TITLE',
    'id' => 'DOP_DOC_AGENTES_AGE_PERMISOAGE_PERMISO_IDA',
    'width' => '10%',
    'default' => true,
    'name' => 'dop_doc_agentes_age_permiso_name',
  ),
  'TIPODOCUMENTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_TIPODOCUMENTO',
    'id' => 'DOP_DOC_TIPODOCUMENTOS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'FECHA' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA',
    'width' => '10%',
    'default' => true,
    'name' => 'fecha',
  ),
  'URL' => 
  array (
    'type' => 'url',
    'label' => 'LBL_URL',
    'width' => '10%',
    'default' => true,
    'name' => 'url',
  ),
  'VERIFICADO' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_VERIFICADO',
    'width' => '10%',
    'name' => 'verificado',
  ),
),
);
