<?php
$module_name = 'dop_doc_agentes';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '20%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'DOP_DOC_AGENTES_AGE_PERMISO_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_DOP_DOC_AGENTES_AGE_PERMISO_FROM_AGE_PERMISO_TITLE',
    'id' => 'DOP_DOC_AGENTES_AGE_PERMISOAGE_PERMISO_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'TIPODOCUMENTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_TIPODOCUMENTO',
    'id' => 'DOP_DOC_TIPODOCUMENTOS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'FECHA' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA',
    'width' => '10%',
    'default' => true,
  ),
  'URL' => 
  array (
    'type' => 'url',
    'label' => 'LBL_URL',
    'width' => '30%',
    'default' => true,
  ),
  'VERIFICADO' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_VERIFICADO',
    'width' => '10%',
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
);
?>
