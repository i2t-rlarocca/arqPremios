<?php
$popupMeta = array (
    'moduleMain' => 'dop_doc_tipodocumentos',
    'varName' => 'dop_doc_tipodocumentos',
    'orderBy' => 'dop_doc_tipodocumentos.name',
    'whereClauses' => array (
  'name' => 'dop_doc_tipodocumentos.name',
),
    'searchInputs' => array (
  1 => 'name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'PREFIJO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PREFIJO',
    'width' => '10%',
    'default' => true,
  ),
),
);
