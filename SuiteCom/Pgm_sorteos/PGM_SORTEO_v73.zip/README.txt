V73 - Desabilitada la accion de "Republicar" Modulo SOR_pgmsorteo - reporte alea fcomun
V72 - LM - custom fcomun para sorteos de ALEA ALEA
V71 - LM - modulo de fcomun para sorteos de ALEA, genera cuenta corriente provincias. Version simplificada como esta en as400
---
v5 HG - se agrega el siguiente funcionamiento al versionado
Los cambios en acciones,anuncios y dia modelo vuelkven a tras el estado si estubiese confirmado , agrega una auditoria de cambio de estado(definitivo a provisorio) y una auditoria del cambio
El cambio de version se da unicamente cuando se confirma el anuncio,y genera una audtoria de cambio de versio y cambia de estado (de provisorio a definitivo)
Tambien se agrega los campos mes y a o al modulo de acciones par afacilitar las busquedas
v17 - v21. RL. Surge de nivelar e integrar varios cambios que se fueron dando sin mantener sincronizados los ambientes/paquetes/cloude. En el post-install se completan listas y agregan nuevas listas, y se agrega una funcion de reconstruccion de las listas desplegables de suite incorporadas en el post-install para que luego de instalar no sea necesario ir una por una y editar+guardar para hacer la actualizaci n.
v30 - v31. RL. Ajustes a vistas de detalle, de lista, popups, busqueda, etc de modalidades y productos.
-- --------------------------------------------------------------------------------------
v43. RL. PgmSorteos. LogicHook. Si es bingo lo agrego al envio que corresponda.
         Modalidades.LogicHook. Si es raspadita la agrego a los envios habilitados y genero los correspondientes pedidos.
-- --------------------------------------------------------------------------------------
v46. AE. Se agregan modulos requeridos para ALEA, se modifica SOR_MODALIDADES
V47. AE. Se agrega datos para calculo de captura y ajustan vistas. Se incorpora validacion de acciones
V48. AE. Se agrega anexos para procesamiento y para captura
V49. AE. Se agrega modificaciones caso 113084 - conexion sw sala de sorteo con calendario permanente. 
SOR_MODALIDAD -> El cambio de valor de apuesta y pozo asegurado de q6, br, pf ponen en provisorio el mes (SOR_ANUNCIOS)
SOR_MODALIDAD_EXT -> Se incorpora modulo para tener inicializada VA / PA a futuro
V50. AE. Se agrega customizaciones de SOR_MODALIDAD_EXT
V51. AE. Se agregan modulos para calculo de alea (sor_alea_hst_*)
V52. AE. Se campos a sor_alea_hst_sorteo_pcia_mod y se modifican datos decimales con tama o incorrecto
V53. AE. Se incorporan campos a hst_sorteo, hst_sorteo_pcia y hst_sorteo_pcia_mod
V54. AE. Se incorporan campos a hst_sorteo
V55. AE. Se ajustan dise o de interfases
V56. AE. Se customiza hst_sorteo
V57. AE. Se incorporan relaciones del modulo ALEA: SORTEO->PROVINCIAS / SORTEO->MODALIDADES
V58. AE. Se incorpora para EXTRACTOS DIGITALES (SORTEOS): autoridades y se modifica sor_parametros
V59. AE. Se incorpora cargos 
V60. AE. Se incorpora modelo de extractos, se modifica en sor_pgmsorteos el dato sorteados para que sea una lista!
V61. LA. Se incorpora premios programados; pozos del sorteo, loterias (jurisdicciones), Premios y Modalidades del sorteo.
V62. LA. Se incorpora Modelo de Extraccion por Modalidad, Extracciones del Sorteo, Pozos Sugeridos del Sorteo y Autoridades del Sorteo.Se cambio el nombre de premios_sorteo por pgmsorteo_premios.
V63. LA. Se modificaron las views de edici n. 
V64. AE. Se ajusta modulo de pozos del sorteo.
V65. AE. Se agrega modelo de extractos y de autoridades planificadas por sorteo
V66. AE. Se agrega estado de loteria x sorteo.
V67. AE. Se incorpora MALETINES, ACTAS DEL SORTEO, MALETINES DEL SORTEO Y BIT CORAS DEL SORTEO. Se modifica EXTRACTOS, se agrega estado_numero y EXTRACTOS_OPERADOR, se agrega estado_numero, estado_posicion y estado_ingreso
V68. AE. Se elimina PRODUCTO de cargos y cargos x sorteo. Se incorpora EVALUACI N DE BIT CORAS.
V69. AE. Se agrega el acta modelo x producto.
V70. AE. Se agrega en cargos x sorteo el producto.
