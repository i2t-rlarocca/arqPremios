<?php
// created: 2020-09-11 14:04:14
$dictionary["sor_alea_hst_sorteo_sor_alea_hst_sorteo_mod"] = array (
  'true_relationship_type' => 'many-to-many',
  'relationships' => 
  array (
    'sor_alea_hst_sorteo_sor_alea_hst_sorteo_mod' => 
    array (
      'lhs_module' => 'SOR_alea_hst_sorteo',
      'lhs_table' => 'sor_alea_hst_sorteo',
      'lhs_key' => 'id',
      'rhs_module' => 'SOR_alea_hst_sorteo_mod',
      'rhs_table' => 'sor_alea_hst_sorteo_mod',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'sor_alea_hst_sorteo_sor_alea_hst_sorteo_mod_c',
      'join_key_lhs' => 'sor_alea_h01fd_sorteo_ida',
      'join_key_rhs' => 'sor_alea_h1c79teo_mod_idb',
    ),
  ),
  'table' => 'sor_alea_hst_sorteo_sor_alea_hst_sorteo_mod_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'sor_alea_h01fd_sorteo_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'sor_alea_h1c79teo_mod_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'sor_alea_hst_sorteo_sor_alea_hst_sorteo_modspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'sor_alea_hst_sorteo_sor_alea_hst_sorteo_mod_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'sor_alea_h01fd_sorteo_ida',
        1 => 'sor_alea_h1c79teo_mod_idb',
      ),
    ),
  ),
);