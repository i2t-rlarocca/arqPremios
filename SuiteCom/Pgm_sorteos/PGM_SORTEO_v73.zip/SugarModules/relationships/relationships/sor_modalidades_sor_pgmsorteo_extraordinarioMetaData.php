<?php
// created: 2020-09-07 12:55:46
$dictionary["sor_modalidades_sor_pgmsorteo_extraordinario"] = array (
  'true_relationship_type' => 'many-to-many',
  'relationships' => 
  array (
    'sor_modalidades_sor_pgmsorteo_extraordinario' => 
    array (
      'lhs_module' => 'SOR_MODALIDADES',
      'lhs_table' => 'sor_modalidades',
      'lhs_key' => 'id',
      'rhs_module' => 'SOR_pgmsorteo_extraordinario',
      'rhs_table' => 'sor_pgmsorteo_extraordinario',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'sor_modalidades_sor_pgmsorteo_extraordinario_c',
      'join_key_lhs' => 'sor_modalidades_sor_pgmsorteo_extraordinariosor_modalidades_ida',
      'join_key_rhs' => 'sor_modali47dcdinario_idb',
    ),
  ),
  'table' => 'sor_modalidades_sor_pgmsorteo_extraordinario_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'sor_modalidades_sor_pgmsorteo_extraordinariosor_modalidades_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'sor_modali47dcdinario_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'sor_modalidades_sor_pgmsorteo_extraordinariospk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'sor_modalidades_sor_pgmsorteo_extraordinario_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'sor_modalidades_sor_pgmsorteo_extraordinariosor_modalidades_ida',
        1 => 'sor_modali47dcdinario_idb',
      ),
    ),
  ),
);