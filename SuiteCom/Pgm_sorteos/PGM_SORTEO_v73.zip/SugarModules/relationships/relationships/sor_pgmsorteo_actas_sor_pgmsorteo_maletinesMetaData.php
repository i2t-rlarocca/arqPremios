<?php
// created: 2022-04-20 17:54:42
$dictionary["sor_pgmsorteo_actas_sor_pgmsorteo_maletines"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'sor_pgmsorteo_actas_sor_pgmsorteo_maletines' => 
    array (
      'lhs_module' => 'SOR_pgmsorteo_actas',
      'lhs_table' => 'sor_pgmsorteo_actas',
      'lhs_key' => 'id',
      'rhs_module' => 'SOR_pgmsorteo_maletines',
      'rhs_table' => 'sor_pgmsorteo_maletines',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines_c',
      'join_key_lhs' => 'sor_pgmsor4d44o_actas_ida',
      'join_key_rhs' => 'sor_pgmsor20b8letines_idb',
    ),
  ),
  'table' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'sor_pgmsor4d44o_actas_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'sor_pgmsor20b8letines_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletinesspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'sor_pgmsor4d44o_actas_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'sor_pgmsor20b8letines_idb',
      ),
    ),
  ),
);