<?php
// created: 2022-04-21 12:52:27
$dictionary["sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras' => 
    array (
      'lhs_module' => 'SOR_pgmsorteo_evaluacion_bitacoras',
      'lhs_table' => 'sor_pgmsorteo_evaluacion_bitacoras',
      'lhs_key' => 'id',
      'rhs_module' => 'SOR_pgmsorteo_bitacoras',
      'rhs_table' => 'sor_pgmsorteo_bitacoras',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras_c',
      'join_key_lhs' => 'sor_pgmsor0601tacoras_ida',
      'join_key_rhs' => 'sor_pgmsor0dcftacoras_idb',
    ),
  ),
  'table' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'sor_pgmsor0601tacoras_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'sor_pgmsor0dcftacoras_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacorasspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'sor_pgmsor0601tacoras_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'sor_pgmsor0dcftacoras_idb',
      ),
    ),
  ),
);