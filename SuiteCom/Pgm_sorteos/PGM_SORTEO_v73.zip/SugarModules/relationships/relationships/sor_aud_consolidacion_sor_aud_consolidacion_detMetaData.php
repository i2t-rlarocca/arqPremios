<?php
// created: 2020-09-07 12:55:48
$dictionary["sor_aud_consolidacion_sor_aud_consolidacion_det"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'sor_aud_consolidacion_sor_aud_consolidacion_det' => 
    array (
      'lhs_module' => 'SOR_aud_consolidacion',
      'lhs_table' => 'sor_aud_consolidacion',
      'lhs_key' => 'id',
      'rhs_module' => 'SOR_aud_consolidacion_det',
      'rhs_table' => 'sor_aud_consolidacion_det',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'sor_aud_consolidacion_sor_aud_consolidacion_det_c',
      'join_key_lhs' => 'sor_aud_co1aadidacion_ida',
      'join_key_rhs' => 'sor_aud_coe6f4ion_det_idb',
    ),
  ),
  'table' => 'sor_aud_consolidacion_sor_aud_consolidacion_det_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'sor_aud_co1aadidacion_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'sor_aud_coe6f4ion_det_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'sor_aud_consolidacion_sor_aud_consolidacion_detspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'sor_aud_consolidacion_sor_aud_consolidacion_det_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'sor_aud_co1aadidacion_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'sor_aud_consolidacion_sor_aud_consolidacion_det_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'sor_aud_coe6f4ion_det_idb',
      ),
    ),
  ),
);