<?php
// created: 2023-01-19 11:12:55
$dictionary["sor_alea_fcomun_det_sor_alea_fcomun_cab"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'sor_alea_fcomun_det_sor_alea_fcomun_cab' => 
    array (
      'lhs_module' => 'SOR_alea_fcomun_cab',
      'lhs_table' => 'sor_alea_fcomun_cab',
      'lhs_key' => 'id',
      'rhs_module' => 'SOR_alea_fcomun_det',
      'rhs_table' => 'sor_alea_fcomun_det',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab_c',
      'join_key_lhs' => 'sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_cab_ida',
      'join_key_rhs' => 'sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_det_idb',
    ),
  ),
  'table' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_cab_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_det_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cabspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_cab_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_det_idb',
      ),
    ),
  ),
);