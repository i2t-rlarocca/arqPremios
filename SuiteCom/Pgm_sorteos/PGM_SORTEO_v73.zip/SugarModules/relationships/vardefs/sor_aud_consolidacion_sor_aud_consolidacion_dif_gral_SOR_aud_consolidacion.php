<?php
// created: 2020-09-07 12:55:48
$dictionary["SOR_aud_consolidacion"]["fields"]["sor_aud_consolidacion_sor_aud_consolidacion_dif_gral"] = array (
  'name' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif_gral',
  'type' => 'link',
  'relationship' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif_gral',
  'source' => 'non-db',
  'module' => 'SOR_aud_consolidacion_dif_gral',
  'bean_name' => 'SOR_aud_consolidacion_dif_gral',
  'side' => 'right',
  'vname' => 'LBL_SOR_AUD_CONSOLIDACION_SOR_AUD_CONSOLIDACION_DIF_GRAL_FROM_SOR_AUD_CONSOLIDACION_DIF_GRAL_TITLE',
);
