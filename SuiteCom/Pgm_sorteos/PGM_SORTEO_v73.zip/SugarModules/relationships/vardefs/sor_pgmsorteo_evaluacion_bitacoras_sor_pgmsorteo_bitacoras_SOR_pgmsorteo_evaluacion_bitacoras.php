<?php
// created: 2022-04-21 12:52:27
$dictionary["SOR_pgmsorteo_evaluacion_bitacoras"]["fields"]["sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras"] = array (
  'name' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras',
  'type' => 'link',
  'relationship' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras',
  'source' => 'non-db',
  'module' => 'SOR_pgmsorteo_bitacoras',
  'bean_name' => 'SOR_pgmsorteo_bitacoras',
  'side' => 'right',
  'vname' => 'LBL_SOR_PGMSORTEO_EVALUACION_BITACORAS_SOR_PGMSORTEO_BITACORAS_FROM_SOR_PGMSORTEO_BITACORAS_TITLE',
);
