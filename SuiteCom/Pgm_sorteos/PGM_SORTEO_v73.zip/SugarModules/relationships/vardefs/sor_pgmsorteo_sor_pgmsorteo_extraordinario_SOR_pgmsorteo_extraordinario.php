<?php
// created: 2020-09-07 12:55:47
$dictionary["SOR_pgmsorteo_extraordinario"]["fields"]["sor_pgmsorteo_sor_pgmsorteo_extraordinario"] = array (
  'name' => 'sor_pgmsorteo_sor_pgmsorteo_extraordinario',
  'type' => 'link',
  'relationship' => 'sor_pgmsorteo_sor_pgmsorteo_extraordinario',
  'source' => 'non-db',
  'module' => 'SOR_pgmsorteo',
  'bean_name' => 'SOR_pgmsorteo',
  'vname' => 'LBL_SOR_PGMSORTEO_SOR_PGMSORTEO_EXTRAORDINARIO_FROM_SOR_PGMSORTEO_TITLE',
);
