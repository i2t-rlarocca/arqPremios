<?php
// created: 2020-09-07 12:55:47
$dictionary["SOR_PRODUCTO"]["fields"]["sor_modalidades_sor_producto"] = array (
  'name' => 'sor_modalidades_sor_producto',
  'type' => 'link',
  'relationship' => 'sor_modalidades_sor_producto',
  'source' => 'non-db',
  'module' => 'SOR_MODALIDADES',
  'bean_name' => 'SOR_MODALIDADES',
  'side' => 'right',
  'vname' => 'LBL_SOR_MODALIDADES_SOR_PRODUCTO_FROM_SOR_MODALIDADES_TITLE',
);
