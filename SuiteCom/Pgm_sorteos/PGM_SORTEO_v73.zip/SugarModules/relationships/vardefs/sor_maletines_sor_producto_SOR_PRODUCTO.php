<?php
// created: 2022-04-20 08:03:56
$dictionary["SOR_PRODUCTO"]["fields"]["sor_maletines_sor_producto"] = array (
  'name' => 'sor_maletines_sor_producto',
  'type' => 'link',
  'relationship' => 'sor_maletines_sor_producto',
  'source' => 'non-db',
  'module' => 'SOR_maletines',
  'bean_name' => false,
  'vname' => 'LBL_SOR_MALETINES_SOR_PRODUCTO_FROM_SOR_MALETINES_TITLE',
  'id_name' => 'sor_maletines_sor_productosor_maletines_ida',
);
$dictionary["SOR_PRODUCTO"]["fields"]["sor_maletines_sor_producto_name"] = array (
  'name' => 'sor_maletines_sor_producto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SOR_MALETINES_SOR_PRODUCTO_FROM_SOR_MALETINES_TITLE',
  'save' => true,
  'id_name' => 'sor_maletines_sor_productosor_maletines_ida',
  'link' => 'sor_maletines_sor_producto',
  'table' => 'sor_maletines',
  'module' => 'SOR_maletines',
  'rname' => 'name',
);
$dictionary["SOR_PRODUCTO"]["fields"]["sor_maletines_sor_productosor_maletines_ida"] = array (
  'name' => 'sor_maletines_sor_productosor_maletines_ida',
  'type' => 'link',
  'relationship' => 'sor_maletines_sor_producto',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SOR_MALETINES_SOR_PRODUCTO_FROM_SOR_PRODUCTO_TITLE',
);
