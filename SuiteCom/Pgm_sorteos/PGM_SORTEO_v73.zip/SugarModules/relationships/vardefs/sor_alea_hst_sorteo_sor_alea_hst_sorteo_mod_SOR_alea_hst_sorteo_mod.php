<?php
// created: 2020-09-11 14:04:14
$dictionary["SOR_alea_hst_sorteo_mod"]["fields"]["sor_alea_hst_sorteo_sor_alea_hst_sorteo_mod"] = array (
  'name' => 'sor_alea_hst_sorteo_sor_alea_hst_sorteo_mod',
  'type' => 'link',
  'relationship' => 'sor_alea_hst_sorteo_sor_alea_hst_sorteo_mod',
  'source' => 'non-db',
  'module' => 'SOR_alea_hst_sorteo',
  'bean_name' => 'SOR_alea_hst_sorteo',
  'vname' => 'LBL_SOR_ALEA_HST_SORTEO_SOR_ALEA_HST_SORTEO_MOD_FROM_SOR_ALEA_HST_SORTEO_TITLE',
);
