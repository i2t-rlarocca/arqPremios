<?php
// created: 2020-09-07 12:55:48
$dictionary["SOR_aud_consolidacion_dif_gral"]["fields"]["sor_aud_consolidacion_sor_aud_consolidacion_dif_gral"] = array (
  'name' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif_gral',
  'type' => 'link',
  'relationship' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif_gral',
  'source' => 'non-db',
  'module' => 'SOR_aud_consolidacion',
  'bean_name' => 'SOR_aud_consolidacion',
  'vname' => 'LBL_SOR_AUD_CONSOLIDACION_SOR_AUD_CONSOLIDACION_DIF_GRAL_FROM_SOR_AUD_CONSOLIDACION_TITLE',
  'id_name' => 'sor_aud_co93e3idacion_ida',
);
$dictionary["SOR_aud_consolidacion_dif_gral"]["fields"]["sor_aud_consolidacion_sor_aud_consolidacion_dif_gral_name"] = array (
  'name' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif_gral_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SOR_AUD_CONSOLIDACION_SOR_AUD_CONSOLIDACION_DIF_GRAL_FROM_SOR_AUD_CONSOLIDACION_TITLE',
  'save' => true,
  'id_name' => 'sor_aud_co93e3idacion_ida',
  'link' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif_gral',
  'table' => 'sor_aud_consolidacion',
  'module' => 'SOR_aud_consolidacion',
  'rname' => 'name',
);
$dictionary["SOR_aud_consolidacion_dif_gral"]["fields"]["sor_aud_co93e3idacion_ida"] = array (
  'name' => 'sor_aud_co93e3idacion_ida',
  'type' => 'link',
  'relationship' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif_gral',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SOR_AUD_CONSOLIDACION_SOR_AUD_CONSOLIDACION_DIF_GRAL_FROM_SOR_AUD_CONSOLIDACION_DIF_GRAL_TITLE',
);
