<?php
// created: 2022-04-21 12:52:27
$dictionary["SOR_pgmsorteo_bitacoras"]["fields"]["sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras"] = array (
  'name' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras',
  'type' => 'link',
  'relationship' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras',
  'source' => 'non-db',
  'module' => 'SOR_pgmsorteo_evaluacion_bitacoras',
  'bean_name' => 'SOR_pgmsorteo_evaluacion_bitacoras',
  'vname' => 'LBL_SOR_PGMSORTEO_EVALUACION_BITACORAS_SOR_PGMSORTEO_BITACORAS_FROM_SOR_PGMSORTEO_EVALUACION_BITACORAS_TITLE',
  'id_name' => 'sor_pgmsor0601tacoras_ida',
);
$dictionary["SOR_pgmsorteo_bitacoras"]["fields"]["sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras_name"] = array (
  'name' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SOR_PGMSORTEO_EVALUACION_BITACORAS_SOR_PGMSORTEO_BITACORAS_FROM_SOR_PGMSORTEO_EVALUACION_BITACORAS_TITLE',
  'save' => true,
  'id_name' => 'sor_pgmsor0601tacoras_ida',
  'link' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras',
  'table' => 'sor_pgmsorteo_evaluacion_bitacoras',
  'module' => 'SOR_pgmsorteo_evaluacion_bitacoras',
  'rname' => 'name',
);
$dictionary["SOR_pgmsorteo_bitacoras"]["fields"]["sor_pgmsor0601tacoras_ida"] = array (
  'name' => 'sor_pgmsor0601tacoras_ida',
  'type' => 'link',
  'relationship' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SOR_PGMSORTEO_EVALUACION_BITACORAS_SOR_PGMSORTEO_BITACORAS_FROM_SOR_PGMSORTEO_BITACORAS_TITLE',
);
