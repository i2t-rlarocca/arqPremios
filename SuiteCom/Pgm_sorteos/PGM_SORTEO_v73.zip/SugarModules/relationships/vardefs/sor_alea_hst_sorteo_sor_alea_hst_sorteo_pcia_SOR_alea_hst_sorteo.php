<?php
// created: 2020-09-11 14:04:14
$dictionary["SOR_alea_hst_sorteo"]["fields"]["sor_alea_hst_sorteo_sor_alea_hst_sorteo_pcia"] = array (
  'name' => 'sor_alea_hst_sorteo_sor_alea_hst_sorteo_pcia',
  'type' => 'link',
  'relationship' => 'sor_alea_hst_sorteo_sor_alea_hst_sorteo_pcia',
  'source' => 'non-db',
  'module' => 'SOR_alea_hst_sorteo_pcia',
  'bean_name' => 'SOR_alea_hst_sorteo_pcia',
  'vname' => 'LBL_SOR_ALEA_HST_SORTEO_SOR_ALEA_HST_SORTEO_PCIA_FROM_SOR_ALEA_HST_SORTEO_PCIA_TITLE',
);
