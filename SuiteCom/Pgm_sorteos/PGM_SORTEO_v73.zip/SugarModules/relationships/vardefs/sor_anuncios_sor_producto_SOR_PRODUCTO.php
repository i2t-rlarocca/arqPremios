<?php
// created: 2015-04-06 18:11:12
$dictionary["SOR_PRODUCTO"]["fields"]["sor_anuncios_sor_producto"] = array (
  'name' => 'sor_anuncios_sor_producto',
  'type' => 'link',
  'relationship' => 'sor_anuncios_sor_producto',
  'source' => 'non-db',
  'module' => 'SOR_ANUNCIOS',
  'bean_name' => 'SOR_ANUNCIOS',
  'side' => 'right',
  'vname' => 'LBL_SOR_ANUNCIOS_SOR_PRODUCTO_FROM_SOR_ANUNCIOS_TITLE',
);
