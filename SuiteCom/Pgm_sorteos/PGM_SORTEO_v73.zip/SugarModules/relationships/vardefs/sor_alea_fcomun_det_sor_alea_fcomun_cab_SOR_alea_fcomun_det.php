<?php
// created: 2023-01-19 11:12:55
$dictionary["SOR_alea_fcomun_det"]["fields"]["sor_alea_fcomun_det_sor_alea_fcomun_cab"] = array (
  'name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab',
  'type' => 'link',
  'relationship' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab',
  'source' => 'non-db',
  'module' => 'SOR_alea_fcomun_cab',
  'bean_name' => false,
  'vname' => 'LBL_SOR_ALEA_FCOMUN_DET_SOR_ALEA_FCOMUN_CAB_FROM_SOR_ALEA_FCOMUN_CAB_TITLE',
  'id_name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_cab_ida',
);
$dictionary["SOR_alea_fcomun_det"]["fields"]["sor_alea_fcomun_det_sor_alea_fcomun_cab_name"] = array (
  'name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SOR_ALEA_FCOMUN_DET_SOR_ALEA_FCOMUN_CAB_FROM_SOR_ALEA_FCOMUN_CAB_TITLE',
  'save' => true,
  'id_name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_cab_ida',
  'link' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab',
  'table' => 'sor_alea_fcomun_cab',
  'module' => 'SOR_alea_fcomun_cab',
  'rname' => 'name',
);
$dictionary["SOR_alea_fcomun_det"]["fields"]["sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_cab_ida"] = array (
  'name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_cab_ida',
  'type' => 'link',
  'relationship' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SOR_ALEA_FCOMUN_DET_SOR_ALEA_FCOMUN_CAB_FROM_SOR_ALEA_FCOMUN_DET_TITLE',
);
