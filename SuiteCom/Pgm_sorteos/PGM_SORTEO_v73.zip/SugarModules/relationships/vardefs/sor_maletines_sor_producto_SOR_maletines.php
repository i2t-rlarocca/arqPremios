<?php
// created: 2022-04-20 08:03:56
$dictionary["SOR_maletines"]["fields"]["sor_maletines_sor_producto"] = array (
  'name' => 'sor_maletines_sor_producto',
  'type' => 'link',
  'relationship' => 'sor_maletines_sor_producto',
  'source' => 'non-db',
  'module' => 'SOR_PRODUCTO',
  'bean_name' => 'SOR_PRODUCTO',
  'side' => 'right',
  'vname' => 'LBL_SOR_MALETINES_SOR_PRODUCTO_FROM_SOR_PRODUCTO_TITLE',
);
