<?php
// created: 2020-09-07 12:55:47
$dictionary["SOR_pgmsorteo_extraordinario"]["fields"]["sor_producto_sor_pgmsorteo_extraordinario"] = array (
  'name' => 'sor_producto_sor_pgmsorteo_extraordinario',
  'type' => 'link',
  'relationship' => 'sor_producto_sor_pgmsorteo_extraordinario',
  'source' => 'non-db',
  'module' => 'SOR_PRODUCTO',
  'bean_name' => 'SOR_PRODUCTO',
  'vname' => 'LBL_SOR_PRODUCTO_SOR_PGMSORTEO_EXTRAORDINARIO_FROM_SOR_PRODUCTO_TITLE',
);
