<?php
// created: 2020-09-07 12:55:47
$dictionary["SOR_pgmsorteo_extraordinario"]["fields"]["sor_modalidades_sor_pgmsorteo_extraordinario"] = array (
  'name' => 'sor_modalidades_sor_pgmsorteo_extraordinario',
  'type' => 'link',
  'relationship' => 'sor_modalidades_sor_pgmsorteo_extraordinario',
  'source' => 'non-db',
  'module' => 'SOR_MODALIDADES',
  'bean_name' => 'SOR_MODALIDADES',
  'vname' => 'LBL_SOR_MODALIDADES_SOR_PGMSORTEO_EXTRAORDINARIO_FROM_SOR_MODALIDADES_TITLE',
);
