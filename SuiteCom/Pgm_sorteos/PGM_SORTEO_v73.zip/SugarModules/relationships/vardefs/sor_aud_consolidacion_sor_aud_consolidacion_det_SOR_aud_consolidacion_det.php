<?php
// created: 2020-09-07 12:55:48
$dictionary["SOR_aud_consolidacion_det"]["fields"]["sor_aud_consolidacion_sor_aud_consolidacion_det"] = array (
  'name' => 'sor_aud_consolidacion_sor_aud_consolidacion_det',
  'type' => 'link',
  'relationship' => 'sor_aud_consolidacion_sor_aud_consolidacion_det',
  'source' => 'non-db',
  'module' => 'SOR_aud_consolidacion',
  'bean_name' => 'SOR_aud_consolidacion',
  'vname' => 'LBL_SOR_AUD_CONSOLIDACION_SOR_AUD_CONSOLIDACION_DET_FROM_SOR_AUD_CONSOLIDACION_TITLE',
  'id_name' => 'sor_aud_co1aadidacion_ida',
);
$dictionary["SOR_aud_consolidacion_det"]["fields"]["sor_aud_consolidacion_sor_aud_consolidacion_det_name"] = array (
  'name' => 'sor_aud_consolidacion_sor_aud_consolidacion_det_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SOR_AUD_CONSOLIDACION_SOR_AUD_CONSOLIDACION_DET_FROM_SOR_AUD_CONSOLIDACION_TITLE',
  'save' => true,
  'id_name' => 'sor_aud_co1aadidacion_ida',
  'link' => 'sor_aud_consolidacion_sor_aud_consolidacion_det',
  'table' => 'sor_aud_consolidacion',
  'module' => 'SOR_aud_consolidacion',
  'rname' => 'name',
);
$dictionary["SOR_aud_consolidacion_det"]["fields"]["sor_aud_co1aadidacion_ida"] = array (
  'name' => 'sor_aud_co1aadidacion_ida',
  'type' => 'link',
  'relationship' => 'sor_aud_consolidacion_sor_aud_consolidacion_det',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SOR_AUD_CONSOLIDACION_SOR_AUD_CONSOLIDACION_DET_FROM_SOR_AUD_CONSOLIDACION_DET_TITLE',
);
