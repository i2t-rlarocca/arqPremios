<?php
// created: 2022-04-20 17:54:42
$dictionary["SOR_pgmsorteo_maletines"]["fields"]["sor_pgmsorteo_actas_sor_pgmsorteo_maletines"] = array (
  'name' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines',
  'type' => 'link',
  'relationship' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines',
  'source' => 'non-db',
  'module' => 'SOR_pgmsorteo_actas',
  'bean_name' => 'SOR_pgmsorteo_actas',
  'vname' => 'LBL_SOR_PGMSORTEO_ACTAS_SOR_PGMSORTEO_MALETINES_FROM_SOR_PGMSORTEO_ACTAS_TITLE',
  'id_name' => 'sor_pgmsor4d44o_actas_ida',
);
$dictionary["SOR_pgmsorteo_maletines"]["fields"]["sor_pgmsorteo_actas_sor_pgmsorteo_maletines_name"] = array (
  'name' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SOR_PGMSORTEO_ACTAS_SOR_PGMSORTEO_MALETINES_FROM_SOR_PGMSORTEO_ACTAS_TITLE',
  'save' => true,
  'id_name' => 'sor_pgmsor4d44o_actas_ida',
  'link' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines',
  'table' => 'sor_pgmsorteo_actas',
  'module' => 'SOR_pgmsorteo_actas',
  'rname' => 'name',
);
$dictionary["SOR_pgmsorteo_maletines"]["fields"]["sor_pgmsor4d44o_actas_ida"] = array (
  'name' => 'sor_pgmsor4d44o_actas_ida',
  'type' => 'link',
  'relationship' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SOR_PGMSORTEO_ACTAS_SOR_PGMSORTEO_MALETINES_FROM_SOR_PGMSORTEO_MALETINES_TITLE',
);
