<?php
// created: 2020-09-07 12:55:47
$dictionary["SOR_MODALIDADES"]["fields"]["sor_modalidades_sor_producto"] = array (
  'name' => 'sor_modalidades_sor_producto',
  'type' => 'link',
  'relationship' => 'sor_modalidades_sor_producto',
  'source' => 'non-db',
  'module' => 'SOR_PRODUCTO',
  'bean_name' => 'SOR_PRODUCTO',
  'vname' => 'LBL_SOR_MODALIDADES_SOR_PRODUCTO_FROM_SOR_PRODUCTO_TITLE',
  'id_name' => 'sor_modalidades_sor_productosor_producto_ida',
);
$dictionary["SOR_MODALIDADES"]["fields"]["sor_modalidades_sor_producto_name"] = array (
  'name' => 'sor_modalidades_sor_producto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SOR_MODALIDADES_SOR_PRODUCTO_FROM_SOR_PRODUCTO_TITLE',
  'save' => true,
  'id_name' => 'sor_modalidades_sor_productosor_producto_ida',
  'link' => 'sor_modalidades_sor_producto',
  'table' => 'sor_producto',
  'module' => 'SOR_PRODUCTO',
  'rname' => 'name',
);
$dictionary["SOR_MODALIDADES"]["fields"]["sor_modalidades_sor_productosor_producto_ida"] = array (
  'name' => 'sor_modalidades_sor_productosor_producto_ida',
  'type' => 'link',
  'relationship' => 'sor_modalidades_sor_producto',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SOR_MODALIDADES_SOR_PRODUCTO_FROM_SOR_MODALIDADES_TITLE',
);
