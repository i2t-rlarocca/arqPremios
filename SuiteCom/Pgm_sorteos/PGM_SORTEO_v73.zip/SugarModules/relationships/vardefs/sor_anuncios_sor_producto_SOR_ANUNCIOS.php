<?php
// created: 2015-04-06 18:11:12
$dictionary["SOR_ANUNCIOS"]["fields"]["sor_anuncios_sor_producto"] = array (
  'name' => 'sor_anuncios_sor_producto',
  'type' => 'link',
  'relationship' => 'sor_anuncios_sor_producto',
  'source' => 'non-db',
  'module' => 'SOR_PRODUCTO',
  'bean_name' => 'SOR_PRODUCTO',
  'vname' => 'LBL_SOR_ANUNCIOS_SOR_PRODUCTO_FROM_SOR_PRODUCTO_TITLE',
  'id_name' => 'sor_anuncios_sor_productosor_producto_ida',
);
$dictionary["SOR_ANUNCIOS"]["fields"]["sor_anuncios_sor_producto_name"] = array (
  'name' => 'sor_anuncios_sor_producto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SOR_ANUNCIOS_SOR_PRODUCTO_FROM_SOR_PRODUCTO_TITLE',
  'save' => true,
  'id_name' => 'sor_anuncios_sor_productosor_producto_ida',
  'link' => 'sor_anuncios_sor_producto',
  'table' => 'sor_producto',
  'module' => 'SOR_PRODUCTO',
  'rname' => 'name',
);
$dictionary["SOR_ANUNCIOS"]["fields"]["sor_anuncios_sor_productosor_producto_ida"] = array (
  'name' => 'sor_anuncios_sor_productosor_producto_ida',
  'type' => 'link',
  'relationship' => 'sor_anuncios_sor_producto',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SOR_ANUNCIOS_SOR_PRODUCTO_FROM_SOR_ANUNCIOS_TITLE',
);
