<?php
// created: 2020-09-07 12:55:48
$dictionary["SOR_aud_consolidacion"]["fields"]["sor_aud_consolidacion_sor_aud_consolidacion_dif"] = array (
  'name' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif',
  'type' => 'link',
  'relationship' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif',
  'source' => 'non-db',
  'module' => 'SOR_aud_consolidacion_dif',
  'bean_name' => 'SOR_aud_consolidacion_dif',
  'side' => 'right',
  'vname' => 'LBL_SOR_AUD_CONSOLIDACION_SOR_AUD_CONSOLIDACION_DIF_FROM_SOR_AUD_CONSOLIDACION_DIF_TITLE',
);
