<?php
// created: 2022-04-20 17:54:42
$dictionary["SOR_pgmsorteo_actas"]["fields"]["sor_pgmsorteo_actas_sor_pgmsorteo_maletines"] = array (
  'name' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines',
  'type' => 'link',
  'relationship' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines',
  'source' => 'non-db',
  'module' => 'SOR_pgmsorteo_maletines',
  'bean_name' => 'SOR_pgmsorteo_maletines',
  'side' => 'right',
  'vname' => 'LBL_SOR_PGMSORTEO_ACTAS_SOR_PGMSORTEO_MALETINES_FROM_SOR_PGMSORTEO_MALETINES_TITLE',
);
