<?php
 // created: 2020-09-07 12:55:46
$layout_defs["SOR_PRODUCTO"]["subpanel_setup"]['sor_modalidades_sor_producto'] = array (
  'order' => 100,
  'module' => 'SOR_MODALIDADES',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SOR_MODALIDADES_SOR_PRODUCTO_FROM_SOR_MODALIDADES_TITLE',
  'get_subpanel_data' => 'sor_modalidades_sor_producto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
