<?php
 // created: 2020-09-07 12:55:48
$layout_defs["SOR_aud_consolidacion"]["subpanel_setup"]['sor_aud_consolidacion_sor_aud_consolidacion_dif'] = array (
  'order' => 100,
  'module' => 'SOR_aud_consolidacion_dif',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SOR_AUD_CONSOLIDACION_SOR_AUD_CONSOLIDACION_DIF_FROM_SOR_AUD_CONSOLIDACION_DIF_TITLE',
  'get_subpanel_data' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
