<?php
 // created: 2022-04-20 17:54:42
$layout_defs["SOR_pgmsorteo_actas"]["subpanel_setup"]['sor_pgmsorteo_actas_sor_pgmsorteo_maletines'] = array (
  'order' => 100,
  'module' => 'SOR_pgmsorteo_maletines',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SOR_PGMSORTEO_ACTAS_SOR_PGMSORTEO_MALETINES_FROM_SOR_PGMSORTEO_MALETINES_TITLE',
  'get_subpanel_data' => 'sor_pgmsorteo_actas_sor_pgmsorteo_maletines',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
