<?php
 // created: 2022-04-21 12:52:27
$layout_defs["SOR_pgmsorteo_evaluacion_bitacoras"]["subpanel_setup"]['sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras'] = array (
  'order' => 100,
  'module' => 'SOR_pgmsorteo_bitacoras',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SOR_PGMSORTEO_EVALUACION_BITACORAS_SOR_PGMSORTEO_BITACORAS_FROM_SOR_PGMSORTEO_BITACORAS_TITLE',
  'get_subpanel_data' => 'sor_pgmsorteo_evaluacion_bitacoras_sor_pgmsorteo_bitacoras',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
