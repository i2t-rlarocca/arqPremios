<?php
 // created: 2022-04-20 08:03:56
$layout_defs["SOR_maletines"]["subpanel_setup"]['sor_maletines_sor_producto'] = array (
  'order' => 100,
  'module' => 'SOR_PRODUCTO',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SOR_MALETINES_SOR_PRODUCTO_FROM_SOR_PRODUCTO_TITLE',
  'get_subpanel_data' => 'sor_maletines_sor_producto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
