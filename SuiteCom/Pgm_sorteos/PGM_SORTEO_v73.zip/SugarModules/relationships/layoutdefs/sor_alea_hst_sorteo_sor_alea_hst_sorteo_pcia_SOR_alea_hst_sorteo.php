<?php
 // created: 2020-09-11 14:04:14
$layout_defs["SOR_alea_hst_sorteo"]["subpanel_setup"]['sor_alea_hst_sorteo_sor_alea_hst_sorteo_pcia'] = array (
  'order' => 100,
  'module' => 'SOR_alea_hst_sorteo_pcia',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SOR_ALEA_HST_SORTEO_SOR_ALEA_HST_SORTEO_PCIA_FROM_SOR_ALEA_HST_SORTEO_PCIA_TITLE',
  'get_subpanel_data' => 'sor_alea_hst_sorteo_sor_alea_hst_sorteo_pcia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
