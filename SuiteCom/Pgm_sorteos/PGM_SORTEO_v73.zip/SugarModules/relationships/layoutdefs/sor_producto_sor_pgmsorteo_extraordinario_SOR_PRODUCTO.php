<?php
 // created: 2020-09-07 12:55:47
$layout_defs["SOR_PRODUCTO"]["subpanel_setup"]['sor_producto_sor_pgmsorteo_extraordinario'] = array (
  'order' => 100,
  'module' => 'SOR_pgmsorteo_extraordinario',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SOR_PRODUCTO_SOR_PGMSORTEO_EXTRAORDINARIO_FROM_SOR_PGMSORTEO_EXTRAORDINARIO_TITLE',
  'get_subpanel_data' => 'sor_producto_sor_pgmsorteo_extraordinario',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
