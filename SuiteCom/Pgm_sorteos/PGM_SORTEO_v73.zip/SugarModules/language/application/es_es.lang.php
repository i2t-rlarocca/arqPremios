<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.

 * SuiteCRM is an extension to SugarCRM Community Edition developed by Salesagility Ltd.
 * Copyright (C) 2011 - 2014 Salesagility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for  technical reasons, the Appropriate Legal Notices must
 * display the words  "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 ********************************************************************************/


$app_list_strings['moduleList']['SOR_PRODUCTO'] = 'PGM - Productos';
$app_list_strings['moduleList']['SOR_PRD_AGRUPACION'] = 'PGM - Agrupación de Productos';
$app_list_strings['moduleList']['SOR_DIAS'] = 'PGM - Días';
$app_list_strings['moduleList']['SOR_FER_PERMANENTES'] = 'PGM - Feriados Permanentes';
$app_list_strings['moduleList']['SOR_LOTERIAS'] = 'PGM - Loterías';
$app_list_strings['moduleList']['SOR_MODALIDADES'] = 'PGM - Modalidades de Productos';
$app_list_strings['moduleList']['SOR_DIA_MODELO'] = 'PGM - Día Modelo';
$app_list_strings['moduleList']['SOR_ANUNCIOS'] = 'PGM - Anuncios';
$app_list_strings['moduleList']['SOR_FERIADOS'] = 'PGM - Feriados';
$app_list_strings['moduleList']['SOR_ACCIONES'] = 'PGM - Acciones';
$app_list_strings['moduleList']['SOR_categoria_juego'] = 'PGM_CATEGORIA_JUEGO';
$app_list_strings['moduleList']['SOR_pgmsorteo'] = 'PGM - Pgmsorteo';
$app_list_strings['moduleList']['SOR_aud_consolidacion'] = 'PGM - Auditoria Cabecera';
$app_list_strings['moduleList']['SOR_aud_evento'] = 'PGM - eventos';
$app_list_strings['moduleList']['SOR_aud_consolidacion_det'] = 'PGM - Auditoria Detalle';
$app_list_strings['moduleList']['SOR_aud_consolidacion_dif'] = 'PGM - Auditoria Diferencias';
$app_list_strings['moduleList']['SOR_aud_consolidacion_dif_gral'] = 'PGM - Auditoria Diferencias Grales';
$app_list_strings['moduleList']['SOR_estado_pgmsorteo'] = 'PGM - Estado Sorteo';
$app_list_strings['moduleList']['SOR_aud_etapas'] = 'PGM - Etapas proceso';
$app_list_strings['moduleList']['SOR_pgmsorteo_extraordinario'] = 'PGM - Sorteos Extraordinarios BINGOS';
$app_list_strings['moduleList']['SOR_parametros'] = 'ALEA - Parámetros';
$app_list_strings['moduleList']['SOR_parametros_provincias'] = 'ALEA - Parámetros por provincias';
$app_list_strings['moduleList']['SOR_alea_ddjj_provincias_sorteos'] = 'ALEA - DDJJ por Provincias';
$app_list_strings['moduleList']['SOR_alea_hst_sorteo_pcia_mod'] = 'ALEA - Provincias/Modalidades';
$app_list_strings['moduleList']['SOR_alea_hst_sorteo_mod'] = 'ALEA - Modalidades';
$app_list_strings['moduleList']['SOR_MODALIDADES_EXT'] = 'PGM - Modalidades de Productos EXT';
$app_list_strings['moduleList']['SOR_alea_hst_sorteo'] = 'ALEA - Sorteos';
$app_list_strings['moduleList']['SOR_alea_hst_sorteo_pcia'] = 'ALEA - Provincias';
$app_list_strings['moduleList']['SOR_Autoridades'] = 'SOR - Autoridades';
$app_list_strings['moduleList']['SOR_Cargos'] = 'SOR - Cargos';
$app_list_strings['moduleList']['SOR_Modelo_Extraccion'] = 'PGM - Modelo de Extracción';
$app_list_strings['moduleList']['SOR_pgmsorteo_pozos'] = 'SOR - Pozos del Sorteo';
$app_list_strings['moduleList']['SOR_premio'] = 'PGM - Premios Programados';
$app_list_strings['moduleList']['SOR_pgmsorteo_loteria'] = 'SOR - Loterías del Sorteo';
$app_list_strings['moduleList']['SOR_premios_sorteos'] = 'SOR - Premios del sorteo';
$app_list_strings['moduleList']['SOR_pgmsorteo_modalidades'] = 'SOR - Modalidades del Sorteo';
$app_list_strings['moduleList']['SOR_Modelo_Extraccion_Modalidad'] = 'PGM - Modelo Extracción - Modalidad';
$app_list_strings['moduleList']['SOR_pgmsorteo_extracciones'] = 'SOR - Extracciones del Sorteo';
$app_list_strings['moduleList']['SOR_pgmsorteo_pozos_sugeridos'] = 'SOR - Pozos Sugeridos del Sorteo';
$app_list_strings['moduleList']['SOR_pgmsorteo_autcargos'] = 'SOR - Autoridades del Sorteo';
$app_list_strings['moduleList']['SOR_pgmsorteo_premios'] = 'SOR - Premios del sorteo';
$app_list_strings['moduleList']['SOR_pgmsorteo_extracto'] = 'SOR - Extracto';
$app_list_strings['moduleList']['SOR_pgmsorteo_extracto_operador'] = 'SOR - Extracto por Operador';
$app_list_strings['moduleList']['SOR_Cargos_Por_Sorteo'] = 'PGM - Cargos por Sorteo';
$app_list_strings['moduleList']['SOR_maletines'] = 'PGM - Maletines';
$app_list_strings['moduleList']['SOR_pgmsorteo_actas'] = 'SOR - Actas de sorteos';
$app_list_strings['moduleList']['SOR_pgmsorteo_bitacoras'] = 'SOR - Bitácoras del Sorteo';
$app_list_strings['moduleList']['SOR_pgmsorteo_maletines'] = 'SOR - Maletines del sorteo';
$app_list_strings['moduleList']['SOR_pgmsorteo_evaluacion_bitacoras'] = 'SOR - Evaluación de Bitácoras';
$app_list_strings['moduleList']['SOR_acta_modelo'] = 'SOR - Acta Modelo';
$app_list_strings['moduleList']['SOR_alea_fcomun_cab'] = 'ALEA - Fondo Comun - Cabecera';
$app_list_strings['moduleList']['SOR_alea_fcomun_det'] = 'ALEA - Fondo Comun - Detalle';
$app_list_strings['tipo_producto_list']['Bancado'] = 'Bancado';
$app_list_strings['tipo_producto_list']['Poceado'] = 'Poceado';
$app_list_strings['tipo_accion_list']['AT'] = 'Anula Todos los Sorteos';
$app_list_strings['tipo_accion_list']['AP'] = 'Anula los sorteos de un producto';
$app_list_strings['tipo_accion_list']['IP'] = 'Incorpora sorteo de un producto';

$app_list_strings['pgm_tipo_accion']['AT'] = 'Anular Todos los Sorteos';
$app_list_strings['pgm_tipo_accion']['IP'] = 'Incorpora sorteo de un producto';
$app_list_strings['pgm_tipo_accion']['AP'] = 'Anula los sorteos de un producto';
$app_list_strings['pgm_tipo_accion']['CAT1'] = 'Agrega Modalidad Adicional 1er y 2do premio';
$app_list_strings['pgm_tipo_accion']['CAT2'] = 'Agrega Modalidad Adicional Siempre Sale';
$app_list_strings['pgm_tipo_accion']['RP'] = 'Replanifica Horario de los Sorteos de un Producto';
$app_list_strings['pgm_tipo_accion']['RSL'] = 'Replanifica Horario de los Sorteos de un Producto Quiniela';
$app_list_strings['pgm_tipo_accion']['ASL'] = 'Anula sorteo de un Producto Quiniela';
$app_list_strings['pgm_tipo_accion']['ALEA'] = 'Sorteo de ALEA';

$app_list_strings['pgm_modalidad_tipo_adicional']['0'] = 'No es adicional';
$app_list_strings['pgm_modalidad_tipo_adicional']['1'] = 'Adicional Tipo 1er y 2do Premio';
$app_list_strings['pgm_modalidad_tipo_adicional']['2'] = 'Adicional tipo S.S';
$app_list_strings['cc_modo_liquidacion_prod_list']['C'] = 'Comprobante';
$app_list_strings['cc_modo_liquidacion_prod_list']['S'] = 'Sorteo';
$app_list_strings['cc_modo_acred_premios_prod_list']['A'] = 'Anticipado';
$app_list_strings['cc_modo_acred_premios_prod_list']['R'] = 'Reintegro';
$app_list_strings['pgm_tck_gan_volcados_list']['0'] = 'No';
$app_list_strings['pgm_tck_gan_volcados_list']['1'] = 'Si';
$app_list_strings['alea_valor_base_list']['recaudacion_total'] = 'Recaudación Total';
$app_list_strings['alea_valor_base_list']['venta_nominal'] = 'Venta Nominal';
$app_list_strings['alea_anexo_list']['II'] = 'ANEXO II';
$app_list_strings['alea_anexo_list']['III'] = 'ANEXO III';
$app_list_strings['alea_anexo_list']['IV'] = 'ANEXO IV';
$app_list_strings['alea_anexo_list']['V'] = 'ANEXO V';
$app_list_strings['alea_anexo_list']['VI'] = 'ANEXO VI';
$app_list_strings['alea_anexo_list']['VII'] = 'ANEXO VII';
$app_list_strings['alea_anexo_list']['VIII'] = 'ANEXO VIII';
$app_list_strings['alea_anexo_list']['IX'] = 'ANEXO IX';
$app_list_strings['alea_anexo_list']['X'] = 'ANEXO X';
$app_list_strings['cab_estado_cnt_list']['P'] = 'Pendiente de Contabilizar';
$app_list_strings['cab_estado_cnt_list']['C'] = 'Contabilizado';
$app_list_strings['cab_estado_cnt_list']['V'] = 'Contabilizado Provisorio';
$app_list_strings['cargo_list']['A'] = 'Autoridad';
$app_list_strings['cargo_list']['AN'] = 'Área Notarial';
$app_list_strings['cargo_list']['JS'] = 'Jefe de Sorteo';
$app_list_strings['motivo_baja_list']['0'] = 'Activo';
$app_list_strings['motivo_baja_list']['1'] = 'Denuncia';
$app_list_strings['motivo_baja_list']['2'] = 'Baja Producci&oacute;n';
$app_list_strings['motivo_baja_list']['3'] = 'Cambio Titular';
$app_list_strings['motivo_baja_list']['4'] = 'Cambio Domicilio';
$app_list_strings['motivo_baja_list']['5'] = 'Revocaci&oacute;n Permiso';
$app_list_strings['motivo_baja_list']['6'] = 'Renuncia';
$app_list_strings['motivo_baja_list']['7'] = 'Fallecimiento';
$app_list_strings['motivo_baja_list']['8'] = 'Cambio de Agente';
$app_list_strings['motivo_baja_list']['10'] = 'Cambio Domicilio Manual';
$app_list_strings['motivo_baja_list']['11'] = 'Cambio Domicilio';
$app_list_strings['motivo_baja_list']['12'] = 'Fin Permiso Temporal';
$app_list_strings['motivo_baja_list']['66'] = 'Reasignaci&oacute;n';
$app_list_strings['motivo_baja_list']['88'] = 'Reestructuraci&oacute;n.Redes';
$app_list_strings['motivo_baja_list']['95'] = 'Incorporaci&oacute;n Co-Titular';
$app_list_strings['motivo_baja_list']['96'] = 'Renuncia Co-Titular';
$app_list_strings['motivo_baja_list']['97'] = 'Baja por Error';
$app_list_strings['motivo_baja_list']['98'] = 'Reiteraci&oacute;n de faltas';
$app_list_strings['motivo_baja_list']['99'] = 'Cambio de Categor&iacute;a';
$app_list_strings['modalidad_extraccion_list']['F'] = 'Fija';
$app_list_strings['modalidad_extraccion_list']['V'] = 'Variable';
$app_list_strings['sino_list']['N'] = 'No';
$app_list_strings['sino_list']['S'] = 'Si';
$app_list_strings['proveedor_extracto_list']['0'] = 'No';
$app_list_strings['proveedor_extracto_list']['1'] = 'Si, en 1er orden';
$app_list_strings['proveedor_extracto_list']['2'] = 'Si, en 2do orden';
$app_list_strings['proveedor_extracto_list']['3'] = 'Si, en 3er orden';
$app_list_strings['modo_ingreso_list']['A'] = 'Archivo';
$app_list_strings['modo_ingreso_list']['B'] = 'Bolillero';
$app_list_strings['modo_ingreso_list']['E'] = 'Otro Extracto';
$app_list_strings['modo_ingreso_list']['M'] = 'Manual';
$app_list_strings['sorteado_list']['0'] = 'Pendiente';
$app_list_strings['sorteado_list']['1'] = 'En Configuración';
$app_list_strings['sorteado_list']['2'] = 'En Curso';
$app_list_strings['sorteado_list']['3'] = 'Sorteado';
$app_list_strings['estado_extraccion_list']['0'] = 'Pendiente';
$app_list_strings['estado_extraccion_list']['1'] = 'En Curso';
$app_list_strings['estado_extraccion_list']['2'] = 'Ingresado';
$app_list_strings['estado_extraccion_list']['3'] = 'Confirmado';
$app_list_strings['estado_loteria_list']['0'] = 'Pendiente';
$app_list_strings['estado_ingreso_manual_list']['0'] = 'Pendiente';
$app_list_strings['estado_ingreso_manual_list']['1'] = 'En Curso';
$app_list_strings['estado_ingreso_manual_list']['2'] = 'Confirmado';
$app_list_strings['prb_tecnico_list']['X'] = 'A Relevar';
$app_list_strings['prb_sistema_list']['X'] = 'A Relevar';
$app_list_strings['prb_personal_list']['X'] = 'A Relevar';
$app_list_strings['estado_bitacora_list']['C'] = 'Confirmada';
$app_list_strings['estado_bitacora_list']['P'] = 'Pendiente';
$app_list_strings['estado_evaluacion_list']['0'] = 'Elija Uno';
$app_list_strings['estado_evaluacion_list']['1'] = 'Oportunidad';
$app_list_strings['estado_evaluacion_list']['2'] = 'Datos Insuficientes';
$app_list_strings['estado_evaluacion_list']['3'] = 'Interrogación';
$app_list_strings['estado_evaluacion_list']['4'] = 'No Recomendable';
$app_list_strings['estado_evaluacion_list']['E'] = 'Evaluada';
$app_list_strings['estado_evaluacion_list']['P'] = 'Pendiente de Evaluación';
$app_list_strings['estado_evaluacion_bitacora_list']['E'] = 'Evaluada';
$app_list_strings['estado_evaluacion_bitacora_list']['P'] = 'Pendiente de Evaluación';
$app_list_strings['uso_maletin_list']['C'] = 'Centena';
$app_list_strings['uso_maletin_list']['D'] = 'Decena';
$app_list_strings['uso_maletin_list']['E'] = 'Decena de Mil';
$app_list_strings['uso_maletin_list']['M'] = 'Unidad de Mil';
$app_list_strings['uso_maletin_list']['N'] = 'Unidad';
$app_list_strings['uso_maletin_list']['U'] = 'Ubicación';
