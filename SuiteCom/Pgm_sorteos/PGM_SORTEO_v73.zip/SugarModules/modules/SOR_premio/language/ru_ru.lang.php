<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.

 * SuiteCRM is an extension to SugarCRM Community Edition developed by Salesagility Ltd.
 * Copyright (C) 2011 - 2014 Salesagility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for  technical reasons, the Appropriate Legal Notices must
 * display the words  "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 ********************************************************************************/

$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Ответственный(ая)',
  'LBL_ASSIGNED_TO_NAME' => 'Ответственный(ая)',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Дата создания',
  'LBL_DATE_MODIFIED' => 'Дата изменения',
  'LBL_MODIFIED' => 'Изменено',
  'LBL_MODIFIED_ID' => 'Изменено(ID)',
  'LBL_MODIFIED_NAME' => 'Изменено',
  'LBL_CREATED' => 'Создано',
  'LBL_CREATED_ID' => 'Создано(ID)',
  'LBL_DESCRIPTION' => 'Описание',
  'LBL_DELETED' => 'Удалено',
  'LBL_NAME' => 'Название',
  'LBL_CREATED_USER' => 'Создано',
  'LBL_MODIFIED_USER' => 'Изменено',
  'LBL_LIST_NAME' => 'Название',
  'LBL_EDIT_BUTTON' => 'Править',
  'LBL_REMOVE' => 'Удалить',
  'LBL_LIST_FORM_TITLE' => 'PGM - Premios Programados Список',
  'LBL_MODULE_NAME' => 'PGM - Premios Programados',
  'LBL_MODULE_TITLE' => 'PGM - Premios Programados',
  'LBL_HOMEPAGE_TITLE' => 'Мой PGM - Premios Programados',
  'LNK_NEW_RECORD' => 'Создать PGM - Premios Programados',
  'LNK_LIST' => 'View PGM - Premios Programados',
  'LNK_IMPORT_SOR_SOR_PREMIO' => 'Importar SOR-Premio',
  'LBL_SEARCH_FORM_TITLE' => 'Поиск PGM - Premios Programados',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Просмотр истории',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Мероприятия',
  'LBL_SOR_SOR_PREMIO_SUBPANEL_TITLE' => 'SOR-Premio',
  'LBL_NEW_FORM_TITLE' => 'Новый PGM - Premios Programados',
  'LBL_PRODUCTO' => 'Producto',
  'LNK_IMPORT_SOR_PREMIOSPGM' => 'Importar SOR-Premios Programados',
  'LBL_SOR_PREMIOSPGM_SUBPANEL_TITLE' => 'SOR-Premios Programados',
  'LBL_PRODUCTO_AOS_PRODUCTS_ID' => 'Producto (relacionado  ID)',
  'LBL_IDPREMIO' => 'ID Premio',
  'LBL_DE_PREMIO' => 'Descripcion de Premio',
  'LBL_IDJUEGO' => 'ID Juego',
  'LBL_ORDEN' => 'Orden',
  'LBL_HABILITADO' => 'Habilitado',
  'LBL_REQUIERE_ACIERTOS' => 'Requiere Aciertos',
  'LBL_ACIERTOS_POR_DEF' => 'aciertos por def',
  'LBL_CARGA_POZO' => 'Carga Pozo',
  'LBL_DESTINO_WEB_POZO' => 'destino web pozo',
  'LBL_DESTINO_WEB_ACIERTOS' => 'destino web aciertos',
  'LBL_DESTINO_WEB_GANADORES' => 'destino web ganadores',
  'LBL_DESTINO_WEB_PREMIO' => 'destino web premio',
  'LNK_IMPORT_SOR_PREMIO' => 'Importar PGM - Premios Programados',
  'LBL_SOR_PREMIO_SUBPANEL_TITLE' => 'PGM - Premios Programados',
  'LBL_PRODUCTO_SOR_PRODUCTO_ID' => 'Producto (relacionado  ID)',
  'LBL_MODALIDADES_SOR_MODALIDADES_ID' => 'Modalidad (relacionado  ID)',
  'LBL_MODALIDADES' => 'Modalidad',
);