<?php
$module_name = 'SOR_premio';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '20%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'PRODUCTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO',
    'id' => 'SOR_PRODUCTO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'MODALIDADES' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_MODALIDADES',
    'id' => 'SOR_MODALIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'ORDEN' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ORDEN',
    'width' => '10%',
    'default' => true,
  ),
  'HABILITADO' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_HABILITADO',
    'width' => '10%',
  ),
  'REQUIERE_ACIERTOS' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_REQUIERE_ACIERTOS',
    'width' => '10%',
  ),
  'CARGA_POZO' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_CARGA_POZO',
    'width' => '10%',
  ),
  'DESTINO_WEB_PREMIO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DESTINO_WEB_PREMIO',
    'width' => '10%',
    'default' => false,
  ),
  'DESTINO_WEB_GANADORES' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DESTINO_WEB_GANADORES',
    'width' => '10%',
    'default' => false,
  ),
  'DESTINO_WEB_ACIERTOS' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DESTINO_WEB_ACIERTOS',
    'width' => '10%',
    'default' => false,
  ),
  'DESTINO_WEB_POZO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DESTINO_WEB_POZO',
    'width' => '10%',
    'default' => false,
  ),
);
?>
