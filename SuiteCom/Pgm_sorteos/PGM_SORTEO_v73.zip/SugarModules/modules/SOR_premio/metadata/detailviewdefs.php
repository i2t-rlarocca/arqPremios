<?php
$module_name = 'SOR_premio';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'producto',
            'studio' => 'visible',
            'label' => 'LBL_PRODUCTO',
          ),
          1 => 
          array (
            'name' => 'modalidades',
            'studio' => 'visible',
            'label' => 'LBL_MODALIDADES',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'orden',
            'label' => 'LBL_ORDEN',
          ),
          1 => 
          array (
            'name' => 'habilitado',
            'studio' => 'visible',
            'label' => 'LBL_HABILITADO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'carga_pozo',
            'studio' => 'visible',
            'label' => 'LBL_CARGA_POZO',
          ),
          1 => 
          array (
            'name' => 'aciertos_por_def',
            'label' => 'LBL_ACIERTOS_POR_DEF',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'destino_web_aciertos',
            'label' => 'LBL_DESTINO_WEB_ACIERTOS',
          ),
          1 => 
          array (
            'name' => 'destino_web_ganadores',
            'label' => 'LBL_DESTINO_WEB_GANADORES',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'destino_web_premio',
            'label' => 'LBL_DESTINO_WEB_PREMIO',
          ),
          1 => 
          array (
            'name' => 'destino_web_pozo',
            'label' => 'LBL_DESTINO_WEB_POZO',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'requiere_aciertos',
            'studio' => 'visible',
            'label' => 'LBL_REQUIERE_ACIERTOS',
          ),
        ),
      ),
    ),
  ),
);
?>
