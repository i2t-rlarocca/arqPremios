<?php
$module_name = 'SOR_LOTERIAS';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'ID_LOTERIA' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ID_LOTERIA',
    'width' => '10%',
    'default' => true,
  ),
);
?>
