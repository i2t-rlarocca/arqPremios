<?php
$module_name = 'SOR_LOTERIAS';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'id_loteria',
            'label' => 'LBL_ID_LOTERIA',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'letra_loteria',
            'label' => 'LBL_LETRA_LOTERIA',
          ),
          1 => 'description',
        ),
      ),
    ),
  ),
);
?>
