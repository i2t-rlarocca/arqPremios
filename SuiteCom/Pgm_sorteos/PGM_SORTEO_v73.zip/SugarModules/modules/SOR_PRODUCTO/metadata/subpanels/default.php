<?php
$module_name='SOR_PRODUCTO';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SOR_PRODUCTO',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'dias_prescripcion' => 
    array (
      'type' => 'int',
      'default' => true,
      'vname' => 'LBL_DIAS_PRESCRIPCION',
      'width' => '10%',
    ),
    'dias_rendicion' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_DIAS_RENDICION',
      'width' => '10%',
      'default' => true,
    ),
    'modo_liquidacion' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'vname' => 'LBL_MODO_LIQUIDACION',
      'width' => '10%',
    ),
    'modo_acred_premios' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'vname' => 'LBL_MODO_ACRED_PREMIOS',
      'width' => '10%',
    ),
    'codigo_afip' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_CODIGO_AFIP',
      'width' => '10%',
      'default' => true,
    ),
    'min_neto_env_uif' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_MIN_NETO_ENV_UIF',
      'width' => '10%',
      'default' => true,
    ),
    'min_bruto_reg_uif' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_MIN_BRUTO_REG_UIF',
      'width' => '10%',
      'default' => true,
    ),
    'id_categoria' => 
    array (
      'type' => 'relate',
      'studio' => 'visible',
      'vname' => 'LBL_ID_CATEGORIA',
      'id' => 'SOR_CATEGORIA_JUEGO_ID_C',
      'link' => true,
      'width' => '10%',
      'default' => true,
      'widget_class' => 'SubPanelDetailViewLink',
      'target_module' => 'SOR_categoria_juego',
      'target_record_key' => 'sor_categoria_juego_id_c',
    ),
    'fin_operacion' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_FIN_OPERACION',
      'width' => '10%',
      'default' => true,
    ),
    'habilitado' => 
    array (
      'type' => 'bool',
      'default' => true,
      'vname' => 'LBL_HABILITADO',
      'width' => '10%',
    ),
  ),
);