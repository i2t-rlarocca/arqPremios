<?php
$module_name = 'SOR_PRODUCTO';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'DIAS_PRESCRIPCION' => 
  array (
    'type' => 'int',
    'default' => true,
    'label' => 'LBL_DIAS_PRESCRIPCION',
    'width' => '10%',
  ),
  'DIAS_RENDICION' => 
  array (
    'type' => 'int',
    'label' => 'LBL_DIAS_RENDICION',
    'width' => '10%',
    'default' => true,
  ),
  'CODIGO_AFIP' => 
  array (
    'type' => 'int',
    'label' => 'LBL_CODIGO_AFIP',
    'width' => '10%',
    'default' => true,
  ),
  'ID_JUEGO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ID_JUEGO',
    'width' => '10%',
    'default' => true,
  ),
  'ID_AS400' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ID_AS400',
    'width' => '10%',
    'default' => true,
  ),
  'MODO_LIQUIDACION' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_MODO_LIQUIDACION',
    'width' => '10%',
  ),
  'MODO_ACRED_PREMIOS' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_MODO_ACRED_PREMIOS',
    'width' => '10%',
  ),
  'ID_CATEGORIA' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_ID_CATEGORIA',
    'id' => 'SOR_CATEGORIA_JUEGO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'ULTIMA_EMISION' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ULTIMA_EMISION',
    'width' => '10%',
    'default' => true,
  ),
  'FIN_OPERACION' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FIN_OPERACION',
    'width' => '10%',
    'default' => true,
  ),
  'INICIO_OPERACION' => 
  array (
    'type' => 'date',
    'label' => 'LBL_INICIO_OPERACION',
    'width' => '10%',
    'default' => false,
  ),
  'PREFIJO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PREFIJO',
    'width' => '10%',
    'default' => false,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'REQUIERE_CAR' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_REQUIERE_CAR',
    'width' => '10%',
  ),
  'REQUIERE_RES' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_REQUIERE_RES',
    'width' => '10%',
  ),
  'REQUIERE_SUE' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_REQUIERE_SUE',
    'width' => '10%',
  ),
  'TIPO' => 
  array (
    'type' => 'enum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_TIPO',
    'width' => '10%',
  ),
  'REQUIERE_PRE_AGE' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_REQUIERE_PRE_AGE',
    'width' => '10%',
  ),
  'REQUIERE_CONS' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_REQUIERE_CONS',
    'width' => '10%',
  ),
  'REQUIERE_APU' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_REQUIERE_APU',
    'width' => '10%',
  ),
  'JU_DESC_CORTA' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_JU_DESC_CORTA',
    'width' => '10%',
    'default' => false,
  ),
  'HABILITADO' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_HABILITADO',
    'width' => '10%',
  ),
  'MIN_BRUTO_REG_UIF' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_MIN_BRUTO_REG_UIF',
    'width' => '10%',
    'default' => false,
  ),
  'MIN_NETO_ENV_UIF' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_MIN_NETO_ENV_UIF',
    'width' => '10%',
    'default' => false,
  ),
  'DIAS_ESPERA_CIERRE_EMISION' => 
  array (
    'type' => 'int',
    'default' => false,
    'label' => 'LBL_DIAS_ESPERA_CIERRE_EMISION',
    'width' => '10%',
  ),
);
?>
