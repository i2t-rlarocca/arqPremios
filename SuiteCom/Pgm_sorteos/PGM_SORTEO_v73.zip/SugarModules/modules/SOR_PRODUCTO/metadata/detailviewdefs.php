<?php
$module_name = 'SOR_PRODUCTO';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'prefijo',
            'label' => 'LBL_PREFIJO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'dias_rendicion',
            'label' => 'LBL_DIAS_RENDICION',
          ),
          1 => 
          array (
            'name' => 'dias_prescripcion',
            'label' => 'LBL_DIAS_PRESCRIPCION',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'inicio_operacion',
            'label' => 'LBL_INICIO_OPERACION',
          ),
          1 => 
          array (
            'name' => 'fin_operacion',
            'label' => 'LBL_FIN_OPERACION',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'id_juego',
            'label' => 'LBL_ID_JUEGO',
          ),
          1 => 
          array (
            'name' => 'id_as400',
            'label' => 'LBL_ID_AS400',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'agrupacion',
            'studio' => 'visible',
            'label' => 'LBL_AGRUPACION',
          ),
          1 => 
          array (
            'name' => 'id_categoria',
            'studio' => 'visible',
            'label' => 'LBL_ID_CATEGORIA',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'ultima_emision',
            'label' => 'LBL_ULTIMA_EMISION',
          ),
          1 => 
          array (
            'name' => 'tipo',
            'studio' => 'visible',
            'label' => 'LBL_TIPO',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'codigo_afip',
            'label' => 'LBL_CODIGO_AFIP',
          ),
          1 => 
          array (
            'name' => 'ju_desc_corta',
            'label' => 'LBL_JU_DESC_CORTA',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'sor_maletines_sor_producto_name',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'requiere_car',
            'label' => 'LBL_REQUIERE_CAR',
          ),
          1 => 
          array (
            'name' => 'requiere_apu',
            'label' => 'LBL_REQUIERE_APU',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'requiere_res',
            'label' => 'LBL_REQUIERE_RES',
          ),
          1 => 
          array (
            'name' => 'requiere_sue',
            'label' => 'LBL_REQUIERE_SUE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'requiere_cons',
            'label' => 'LBL_REQUIERE_CONS',
          ),
          1 => 
          array (
            'name' => 'requiere_pre_age',
            'label' => 'LBL_REQUIERE_PRE_AGE',
          ),
        ),
      ),
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'min_bruto_reg_uif',
            'label' => 'LBL_MIN_BRUTO_REG_UIF',
          ),
          1 => 
          array (
            'name' => 'min_neto_env_uif',
            'label' => 'LBL_MIN_NETO_ENV_UIF',
          ),
        ),
      ),
    ),
  ),
);
?>
