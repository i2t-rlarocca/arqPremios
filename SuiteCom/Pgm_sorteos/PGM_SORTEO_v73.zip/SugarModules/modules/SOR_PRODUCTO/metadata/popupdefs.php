<?php
$popupMeta = array (
    'moduleMain' => 'SOR_PRODUCTO',
    'varName' => 'SOR_PRODUCTO',
    'orderBy' => 'sor_producto.name',
    'whereClauses' => array (
  'name' => 'sor_producto.name',
  'id_categoria' => 'sor_producto.id_categoria',
  'codigo_afip' => 'sor_producto.codigo_afip',
  'modo_liquidacion' => 'sor_producto.modo_liquidacion',
  'modo_acred_premios' => 'sor_producto.modo_acred_premios',
  'habilitado' => 'sor_producto.habilitado',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'id_categoria',
  5 => 'codigo_afip',
  6 => 'modo_liquidacion',
  7 => 'modo_acred_premios',
  8 => 'habilitado',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'id_categoria' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_ID_CATEGORIA',
    'id' => 'SOR_CATEGORIA_JUEGO_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'id_categoria',
  ),
  'codigo_afip' => 
  array (
    'type' => 'int',
    'label' => 'LBL_CODIGO_AFIP',
    'width' => '10%',
    'name' => 'codigo_afip',
  ),
  'modo_liquidacion' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_MODO_LIQUIDACION',
    'width' => '10%',
    'name' => 'modo_liquidacion',
  ),
  'modo_acred_premios' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_MODO_ACRED_PREMIOS',
    'width' => '10%',
    'name' => 'modo_acred_premios',
  ),
  'habilitado' => 
  array (
    'type' => 'bool',
    'label' => 'LBL_HABILITADO',
    'width' => '10%',
    'name' => 'habilitado',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
    'name' => 'name',
  ),
  'ID_CATEGORIA' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_ID_CATEGORIA',
    'id' => 'SOR_CATEGORIA_JUEGO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'id_categoria',
  ),
  'DIAS_PRESCRIPCION' => 
  array (
    'type' => 'int',
    'default' => true,
    'label' => 'LBL_DIAS_PRESCRIPCION',
    'width' => '10%',
    'name' => 'dias_prescripcion',
  ),
  'DIAS_RENDICION' => 
  array (
    'type' => 'int',
    'label' => 'LBL_DIAS_RENDICION',
    'width' => '10%',
    'default' => true,
    'name' => 'dias_rendicion',
  ),
  'CODIGO_AFIP' => 
  array (
    'type' => 'int',
    'label' => 'LBL_CODIGO_AFIP',
    'width' => '10%',
    'default' => true,
    'name' => 'codigo_afip',
  ),
  'MODO_LIQUIDACION' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_MODO_LIQUIDACION',
    'width' => '10%',
  ),
  'MODO_ACRED_PREMIOS' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_MODO_ACRED_PREMIOS',
    'width' => '10%',
  ),
  'FIN_OPERACION' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FIN_OPERACION',
    'width' => '10%',
    'default' => true,
    'name' => 'fin_operacion',
  ),
  'HABILITADO' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_HABILITADO',
    'width' => '10%',
    'name' => 'habilitado',
  ),
),
);
