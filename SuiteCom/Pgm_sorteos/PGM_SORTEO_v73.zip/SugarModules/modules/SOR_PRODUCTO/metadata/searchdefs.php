<?php
$module_name = 'SOR_PRODUCTO';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'id_categoria' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_ID_CATEGORIA',
        'id' => 'SOR_CATEGORIA_JUEGO_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'id_categoria',
      ),
      'habilitado' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_HABILITADO',
        'width' => '10%',
        'name' => 'habilitado',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'id_categoria' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_ID_CATEGORIA',
        'id' => 'SOR_CATEGORIA_JUEGO_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'id_categoria',
      ),
      'habilitado' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_HABILITADO',
        'width' => '10%',
        'name' => 'habilitado',
      ),
      'codigo_afip' => 
      array (
        'type' => 'int',
        'label' => 'LBL_CODIGO_AFIP',
        'width' => '10%',
        'default' => true,
        'name' => 'codigo_afip',
      ),
      'id_juego' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ID_JUEGO',
        'width' => '10%',
        'default' => true,
        'name' => 'id_juego',
      ),
      'id_as400' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ID_AS400',
        'width' => '10%',
        'default' => true,
        'name' => 'id_as400',
      ),
      'modo_acred_premios' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_MODO_ACRED_PREMIOS',
        'width' => '10%',
        'name' => 'modo_acred_premios',
      ),
      'modo_liquidacion' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_MODO_LIQUIDACION',
        'width' => '10%',
        'name' => 'modo_liquidacion',
      ),
      'requiere_car' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_REQUIERE_CAR',
        'width' => '10%',
        'name' => 'requiere_car',
      ),
      'requiere_res' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_REQUIERE_RES',
        'width' => '10%',
        'name' => 'requiere_res',
      ),
      'requiere_apu' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_REQUIERE_APU',
        'width' => '10%',
        'name' => 'requiere_apu',
      ),
      'requiere_cons' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_REQUIERE_CONS',
        'width' => '10%',
        'name' => 'requiere_cons',
      ),
      'requiere_sue' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_REQUIERE_SUE',
        'width' => '10%',
        'name' => 'requiere_sue',
      ),
      'requiere_pre_age' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_REQUIERE_PRE_AGE',
        'width' => '10%',
        'name' => 'requiere_pre_age',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
