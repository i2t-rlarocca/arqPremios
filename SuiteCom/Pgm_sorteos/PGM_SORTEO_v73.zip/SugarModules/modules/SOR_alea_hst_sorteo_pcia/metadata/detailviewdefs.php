<?php
$module_name = 'SOR_alea_hst_sorteo_pcia';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL3' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'sorteo',
            'studio' => 'visible',
            'label' => 'LBL_SORTEO',
          ),
          1 => 
          array (
            'name' => 'provincia',
            'studio' => 'visible',
            'label' => 'LBL_PROVINCIA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'sp_recaudacion_total',
            'label' => 'LBL_SP_RECAUDACION_TOTAL',
          ),
          1 => 
          array (
            'name' => 'sp_valor_nominal',
            'label' => 'LBL_SP_VALOR_NOMINAL',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'sp_total_arancel',
            'label' => 'LBL_SP_TOTAL_ARANCEL',
          ),
          1 => 
          array (
            'name' => 'sp_total_fondo_comun',
            'label' => 'LBL_SP_TOTAL_FONDO_COMUN',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'sp_total_pozo_premios',
            'label' => 'LBL_SP_TOTAL_POZO_PREMIOS',
          ),
          1 => 
          array (
            'name' => 'sp_total_premios',
            'label' => 'LBL_SP_TOTAL_PREMIOS',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'sp_comisiones',
            'label' => 'LBL_SP_COMISIONES',
          ),
          1 => 
          array (
            'name' => 'sp_utilidad_calculada',
            'label' => 'LBL_SP_UTILIDAD_CALCULADA',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'sp_porc_iva',
            'label' => 'LBL_SP_PORC_IVA',
          ),
          1 => 
          array (
            'name' => 'sp_iva',
            'label' => 'LBL_SP_IVA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'sp_base_gto_captura',
            'studio' => 'visible',
            'label' => 'LBL_SP_BASE_GTO_CAPTURA',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'sp_gtocapt',
            'label' => 'LBL_SP_GTOCAPT',
          ),
          1 => 
          array (
            'name' => 'sp_gtocapt_total',
            'label' => 'LBL_SP_GTOCAPT_TOTAL',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'sp_base_gto_sop_proc',
            'studio' => 'visible',
            'label' => 'LBL_SP_BASE_GTO_SOP_PROC',
          ),
          1 => 
          array (
            'name' => 'sp_gtoprc',
            'label' => 'LBL_SP_GTOPRC',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'sp_gtoprc_total',
            'label' => 'LBL_SP_GTOPRC_TOTAL',
          ),
          1 => 
          array (
            'name' => 'sp_descuento',
            'label' => 'LBL_SP_DESCUENTO',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'sp_neto',
            'label' => 'LBL_SP_NETO',
          ),
        ),
      ),
      'lbl_editview_panel3' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'sp_utilidad_partes_iguales',
            'label' => 'LBL_SP_UTILIDAD_PARTES_IGUALES',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'sp_utilidad_ventas',
            'label' => 'LBL_SP_UTILIDAD_VENTAS',
          ),
          1 => 
          array (
            'name' => 'sp_porc_sobre_ventas',
            'label' => 'LBL_SP_PORC_SOBRE_VENTAS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'sp_para_ente',
            'label' => 'LBL_SP_PARA_ENTE',
          ),
          1 => 
          array (
            'name' => 'sp_para_cas',
            'label' => 'LBL_SP_PARA_CAS',
          ),
        ),
      ),
    ),
  ),
);
?>
