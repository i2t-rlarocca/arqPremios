<?php
$module_name='SOR_alea_hst_sorteo_pcia';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SOR_alea_hst_sorteo_pcia',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '5%',
      'default' => true,
    ),
    'sp_recaudacion_total' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_RECAUDACION_TOTAL',
      'width' => '5%',
      'default' => true,
    ),
    'sp_total_arancel' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_TOTAL_ARANCEL',
      'width' => '5%',
      'default' => true,
    ),
    'sp_total_fondo_comun' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_TOTAL_FONDO_COMUN',
      'width' => '5%',
      'default' => true,
    ),
    'sp_valor_nominal' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_VALOR_NOMINAL',
      'width' => '5%',
      'default' => true,
    ),
    'sp_comisiones' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_COMISIONES',
      'width' => '5%',
      'default' => true,
    ),
    'sp_utilidad_calculada' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_UTILIDAD_CALCULADA',
      'width' => '5%',
      'default' => true,
    ),
    'sp_base_gto_sop_proc' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'vname' => 'LBL_SP_BASE_GTO_SOP_PROC',
      'width' => '5%',
    ),
    'sp_gtoprc' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_GTOPRC',
      'width' => '5%',
      'default' => true,
    ),
    'sp_gtoprc_total' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_GTOPRC_TOTAL',
      'width' => '5%',
      'default' => true,
    ),
    'sp_base_gto_captura' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'vname' => 'LBL_SP_BASE_GTO_CAPTURA',
      'width' => '5%',
    ),
    'sp_gtocapt' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_GTOCAPT',
      'width' => '5%',
      'default' => true,
    ),
    'sp_gtocapt_total' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_GTOCAPT_TOTAL',
      'width' => '5%',
      'default' => true,
    ),
    'sp_descuento' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_DESCUENTO',
      'width' => '5%',
      'default' => true,
    ),
    'sp_utilidad_partes_iguales' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_UTILIDAD_PARTES_IGUALES',
      'width' => '5%',
      'default' => true,
    ),
    'sp_porc_sobre_ventas' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_PORC_SOBRE_VENTAS',
      'width' => '5%',
      'default' => true,
    ),
    'sp_utilidad_ventas' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_UTILIDAD_VENTAS',
      'width' => '5%',
      'default' => true,
    ),
    'sp_para_cas' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_PARA_CAS',
      'width' => '5%',
      'default' => true,
    ),
    'sp_para_ente' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SP_PARA_ENTE',
      'width' => '5%',
      'default' => true,
    ),
  ),
);