<?php
$module_name = 'SOR_alea_hst_sorteo_pcia';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'SP_RECAUDACION_TOTAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
  ),
  'SP_TOTAL_ARANCEL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_TOTAL_ARANCEL',
    'width' => '10%',
    'default' => true,
  ),
  'SP_TOTAL_FONDO_COMUN' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_TOTAL_FONDO_COMUN',
    'width' => '10%',
    'default' => true,
  ),
  'SP_VALOR_NOMINAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_VALOR_NOMINAL',
    'width' => '10%',
    'default' => true,
  ),
  'SP_COMISIONES' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_COMISIONES',
    'width' => '10%',
    'default' => true,
  ),
  'SP_UTILIDAD_CALCULADA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_UTILIDAD_CALCULADA',
    'width' => '10%',
    'default' => true,
  ),
  'SP_GTOPRC_TOTAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_GTOPRC_TOTAL',
    'width' => '10%',
    'default' => true,
  ),
  'SP_GTOCAPT_TOTAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_GTOCAPT_TOTAL',
    'width' => '10%',
    'default' => true,
  ),
  'SP_DESCUENTO' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_DESCUENTO',
    'width' => '10%',
    'default' => true,
  ),
  'SP_NETO' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_NETO',
    'width' => '10%',
    'default' => true,
  ),
  'SP_TOTAL_POZO_PREMIOS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_TOTAL_POZO_PREMIOS',
    'width' => '10%',
    'default' => true,
  ),
  'SP_TOTAL_PREMIOS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_TOTAL_PREMIOS',
    'width' => '10%',
    'default' => true,
  ),
  'SP_UTILIDAD_PARTES_IGUALES' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_UTILIDAD_PARTES_IGUALES',
    'width' => '10%',
    'default' => true,
  ),
  'SP_UTILIDAD_VENTAS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_UTILIDAD_VENTAS',
    'width' => '10%',
    'default' => true,
  ),
  'SP_PARA_ENTE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_PARA_ENTE',
    'width' => '10%',
    'default' => true,
  ),
  'SP_PARA_CAS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_PARA_CAS',
    'width' => '10%',
    'default' => true,
  ),
  'SORTEO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
  'PROVINCIA' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PROVINCIA',
    'id' => 'TBL_PROVINCIAS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
  'SP_BASE_GTO_SOP_PROC' => 
  array (
    'type' => 'enum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_SP_BASE_GTO_SOP_PROC',
    'width' => '10%',
  ),
  'SP_GTOPRC' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_GTOPRC',
    'width' => '10%',
    'default' => false,
  ),
  'SP_BASE_GTO_CAPTURA' => 
  array (
    'type' => 'enum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_SP_BASE_GTO_CAPTURA',
    'width' => '10%',
  ),
  'SP_GTOCAPT' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_GTOCAPT',
    'width' => '10%',
    'default' => false,
  ),
  'SP_PORC_IVA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_PORC_IVA',
    'width' => '10%',
    'default' => false,
  ),
  'SP_IVA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_IVA',
    'width' => '10%',
    'default' => false,
  ),
  'SP_PORC_SOBRE_VENTAS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_PORC_SOBRE_VENTAS',
    'width' => '10%',
    'default' => false,
  ),
  'SP_TOTAL_RETENCIONES' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_TOTAL_RETENCIONES',
    'width' => '10%',
    'default' => false,
  ),
);
?>
