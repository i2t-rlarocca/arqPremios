<?php
$dashletData['SOR_alea_hst_sorteo_pciaDashlet']['searchFields'] = array (
  'provincia' => 
  array (
    'default' => '',
  ),
  'sorteo' => 
  array (
    'default' => '',
  ),
);
$dashletData['SOR_alea_hst_sorteo_pciaDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'sp_recaudacion_total' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
  ),
  'sp_total_fondo_comun' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_TOTAL_FONDO_COMUN',
    'width' => '10%',
    'default' => true,
  ),
  'sp_total_arancel' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_TOTAL_ARANCEL',
    'width' => '10%',
    'default' => true,
  ),
  'sp_valor_nominal' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_VALOR_NOMINAL',
    'width' => '10%',
    'default' => true,
  ),
  'sp_para_cas' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_PARA_CAS',
    'width' => '10%',
    'default' => false,
  ),
  'sp_para_ente' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_PARA_ENTE',
    'width' => '10%',
    'default' => false,
  ),
);
