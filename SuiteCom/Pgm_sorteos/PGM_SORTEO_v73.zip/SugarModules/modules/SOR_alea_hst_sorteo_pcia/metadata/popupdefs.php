<?php
$popupMeta = array (
    'moduleMain' => 'SOR_alea_hst_sorteo_pcia',
    'varName' => 'SOR_alea_hst_sorteo_pcia',
    'orderBy' => 'sor_alea_hst_sorteo_pcia.name',
    'whereClauses' => array (
  'name' => 'sor_alea_hst_sorteo_pcia.name',
),
    'searchInputs' => array (
  0 => 'sor_alea_hst_sorteo_pcia_number',
  1 => 'name',
  2 => 'priority',
  3 => 'status',
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'SP_RECAUDACION_TOTAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
  ),
  'SP_TOTAL_FONDO_COMUN' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_TOTAL_FONDO_COMUN',
    'width' => '10%',
    'default' => true,
  ),
  'SP_TOTAL_ARANCEL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_TOTAL_ARANCEL',
    'width' => '10%',
    'default' => true,
  ),
  'SP_PARA_ENTE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_PARA_ENTE',
    'width' => '10%',
    'default' => true,
  ),
  'SP_PARA_CAS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SP_PARA_CAS',
    'width' => '10%',
    'default' => true,
  ),
),
);
