<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.

 * SuiteCRM is an extension to SugarCRM Community Edition developed by Salesagility Ltd.
 * Copyright (C) 2011 - 2014 Salesagility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for  technical reasons, the Appropriate Legal Notices must
 * display the words  "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 ********************************************************************************/

$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Ответственный(ая)',
  'LBL_ASSIGNED_TO_NAME' => 'Ответственный(ая)',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Дата создания',
  'LBL_DATE_MODIFIED' => 'Дата изменения',
  'LBL_MODIFIED' => 'Изменено',
  'LBL_MODIFIED_ID' => 'Изменено(ID)',
  'LBL_MODIFIED_NAME' => 'Изменено',
  'LBL_CREATED' => 'Создано',
  'LBL_CREATED_ID' => 'Создано(ID)',
  'LBL_DESCRIPTION' => 'Описание',
  'LBL_DELETED' => 'Удалено',
  'LBL_NAME' => 'Название',
  'LBL_CREATED_USER' => 'Создано',
  'LBL_MODIFIED_USER' => 'Изменено',
  'LBL_LIST_NAME' => 'Название',
  'LBL_EDIT_BUTTON' => 'Править',
  'LBL_REMOVE' => 'Удалить',
  'LBL_LIST_FORM_TITLE' => 'ALEA - Provincias Список',
  'LBL_MODULE_NAME' => 'ALEA - Provincias',
  'LBL_MODULE_TITLE' => 'ALEA - Provincias',
  'LBL_HOMEPAGE_TITLE' => 'Мой ALEA - Provincias',
  'LNK_NEW_RECORD' => 'Создать ALEA - Provincias',
  'LNK_LIST' => 'View ALEA - Provincias',
  'LNK_IMPORT_SOR_ALEA_HST_SORTEO_PCIA' => 'Importar ALEA - Provincias',
  'LBL_SEARCH_FORM_TITLE' => 'Поиск ALEA - Provincias',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Просмотр истории',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Мероприятия',
  'LBL_SOR_ALEA_HST_SORTEO_PCIA_SUBPANEL_TITLE' => 'ALEA - Provincias',
  'LBL_NEW_FORM_TITLE' => 'Новый ALEA - Provincias',
  'LBL_SORTEO_SOR_PGMSORTEO_ID' => 'Sorteo (relacionado  ID)',
  'LBL_SORTEO' => 'Sorteo',
  'LBL_PROVINCIA_TBL_PROVINCIAS_ID' => 'Provincia (relacionado  ID)',
  'LBL_PROVINCIA' => 'Provincia',
  'LBL_SP_GTOPRC' => '% Gastos de Procesamiento',
  'LBL_SP_BASE_GTO_SOP_PROC' => 'Base Gasto de Procesamiento',
  'LBL_SP_NETO' => 'Neto',
  'LBL_SP_IVA' => 'Iva',
  'LBL_SP_PORC_IVA' => '% IVA',
  'LBL_SP_GTOPRC_TOTAL' => 'Gastos de Procesamiento',
  'LBL_SP_DESCUENTO' => 'Descuento',
  'LBL_SP_VALOR_NOMINAL' => 'Valor Nominal',
  'LBL_SP_COMISIONES' => 'Comisiones',
  'LBL_SP_UTILIDAD_CALCULADA' => 'Utilidad Calculada (VN - COMISION)',
  'LBL_SP_UTILIDAD_PARTES_IGUALES' => 'Utilidad Partes Iguales',
  'LBL_SP_UTILIDAD_VENTAS' => 'Utilidad por Ventas',
  'LBL_SP_PORC_SOBRE_VENTAS' => '% sobre Ventas',
  'LBL_SP_TOTAL_PREMIOS' => 'Premios',
  'LBL_SP_TOTAL_RETENCIONES' => 'Total Retenciones',
  'LBL_SP_PARA_CAS' => 'Transferencia a la CAS',
  'LBL_SP_TOTAL_FONDO_COMUN' => 'Fondo Comun',
  'LBL_SP_TOTAL_ARANCEL' => 'Arancel',
  'LBL_SP_PARA_ENTE' => 'Para el ENTE',
  'LBL_SP_BASE_GTO_CAPTURA' => 'Base Gtos Captura',
  'LBL_SP_GTOCAPT' => '% Gastos Captura',
  'LBL_SP_GTOCAPT_TOTAL' => 'Gastos Captura',
  'LBL_SP_RECAUDACION_TOTAL' => 'Recaudación Total',
  'LBL_SP_TOTAL_POZO_PREMIOS' => 'Pozo premios',
);