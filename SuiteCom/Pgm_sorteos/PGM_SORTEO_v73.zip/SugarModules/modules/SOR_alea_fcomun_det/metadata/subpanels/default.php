<?php
$module_name='SOR_alea_fcomun_det';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SOR_alea_fcomun_det',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '20%',
      'default' => true,
    ),
    'aporte_premios' => 
    array (
      'type' => 'currency',
      'vname' => 'LBL_APORTE_PREMIOS',
      'currency_format' => true,
      'width' => '10%',
      'default' => true,
    ),
    'fondo_comun' => 
    array (
      'type' => 'currency',
      'vname' => 'LBL_FONDO_COMUN',
      'currency_format' => true,
      'width' => '10%',
      'default' => true,
    ),
    'premios' => 
    array (
      'type' => 'currency',
      'vname' => 'LBL_PREMIOS',
      'currency_format' => true,
      'width' => '10%',
      'default' => true,
    ),
    'edit_button' => 
    array (
      'vname' => 'LBL_EDIT_BUTTON',
      'widget_class' => 'SubPanelEditButton',
      'module' => 'SOR_alea_fcomun_det',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'vname' => 'LBL_REMOVE',
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'SOR_alea_fcomun_det',
      'width' => '5%',
      'default' => true,
    ),
  ),
);