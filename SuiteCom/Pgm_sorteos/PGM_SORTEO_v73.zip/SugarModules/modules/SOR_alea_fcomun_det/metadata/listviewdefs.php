<?php
$module_name = 'SOR_alea_fcomun_det';
$listViewDefs [$module_name] = 
array (
  'SOR_ALEA_FCOMUN_DET_SOR_ALEA_FCOMUN_CAB_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_SOR_ALEA_FCOMUN_DET_SOR_ALEA_FCOMUN_CAB_FROM_SOR_ALEA_FCOMUN_CAB_TITLE',
    'id' => 'SOR_ALEA_FCOMUN_DET_SOR_ALEA_FCOMUN_CABSOR_ALEA_FCOMUN_CAB_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'APORTE_PREMIOS' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_APORTE_PREMIOS',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'FONDO_COMUN' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_FONDO_COMUN',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'PREMIOS' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_PREMIOS',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'PROVINCIA' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PROVINCIA',
    'id' => 'AGE_RED_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
);
?>
