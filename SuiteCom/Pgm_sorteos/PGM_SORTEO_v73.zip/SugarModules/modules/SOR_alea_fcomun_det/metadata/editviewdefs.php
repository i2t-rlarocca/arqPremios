<?php
$module_name = 'SOR_alea_fcomun_det';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => false,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'provincia',
            'studio' => 'visible',
            'label' => 'LBL_PROVINCIA',
          ),
          1 => '',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'aporte_premios',
            'label' => 'LBL_APORTE_PREMIOS',
          ),
          1 => 
          array (
            'name' => 'premios',
            'label' => 'LBL_PREMIOS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'fondo_comun',
            'label' => 'LBL_FONDO_COMUN',
          ),
          1 => 
          array (
            'name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab_name',
            'label' => 'LBL_SOR_ALEA_FCOMUN_DET_SOR_ALEA_FCOMUN_CAB_FROM_SOR_ALEA_FCOMUN_CAB_TITLE',
          ),
        ),
      ),
    ),
  ),
);
?>
