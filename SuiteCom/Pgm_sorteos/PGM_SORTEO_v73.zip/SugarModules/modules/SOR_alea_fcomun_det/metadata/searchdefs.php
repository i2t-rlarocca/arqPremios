<?php
$module_name = 'SOR_alea_fcomun_det';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
    ),
    'advanced_search' => 
    array (
      'sor_alea_fcomun_det_sor_alea_fcomun_cab_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_SOR_ALEA_FCOMUN_DET_SOR_ALEA_FCOMUN_CAB_FROM_SOR_ALEA_FCOMUN_CAB_TITLE',
        'id' => 'SOR_ALEA_FCOMUN_DET_SOR_ALEA_FCOMUN_CABSOR_ALEA_FCOMUN_CAB_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab_name',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'provincia' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PROVINCIA',
        'id' => 'AGE_RED_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'provincia',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
