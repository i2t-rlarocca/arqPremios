<?php
$module_name = 'SOR_pgmsorteo';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'PRODUCTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO',
    'id' => 'SOR_PRODUCTO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'NROSORTEO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_NROSORTEO',
    'width' => '10%',
    'default' => true,
  ),
  'FECHA' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA',
    'width' => '10%',
    'default' => true,
  ),
  'HORA' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_HORA',
    'width' => '10%',
    'default' => true,
  ),
  'ESTADO_SORTEO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_ESTADO_SORTEO',
    'id' => 'SOR_ESTADO_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'POZOESTIMADOPROXIMO' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_POZOESTIMADOPROXIMO',
    'width' => '10%',
    'default' => false,
  ),
  'FECHAHORAPROXIMO' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_FECHAHORAPROXIMO',
    'width' => '10%',
    'default' => false,
  ),
  'APU_AFE' => 
  array (
    'type' => 'int',
    'label' => 'LBL_APU_AFE',
    'width' => '10%',
    'default' => false,
  ),
  'FECHAHORA_AFE' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_FECHAHORA_AFE',
    'width' => '10%',
    'default' => false,
  ),
  'TIENE_ADIC' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_TIENE_ADIC',
    'width' => '10%',
  ),
  'TCK_AFE' => 
  array (
    'type' => 'int',
    'label' => 'LBL_TCK_AFE',
    'width' => '10%',
    'default' => false,
  ),
  'NET_AFE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_NET_AFE',
    'width' => '10%',
    'default' => false,
  ),
  'PRE_PV0' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_PRE_PV0',
    'width' => '10%',
    'default' => false,
  ),
  'PRE_AGE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_PRE_AGE',
    'width' => '10%',
    'default' => false,
  ),
  'TCK_APU' => 
  array (
    'type' => 'int',
    'label' => 'LBL_TCK_APU',
    'width' => '10%',
    'default' => false,
  ),
  'APUESTAS' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_APUESTAS',
    'width' => '10%',
  ),
  'APU_APU' => 
  array (
    'type' => 'int',
    'label' => 'LBL_APU_APU',
    'width' => '10%',
    'default' => false,
  ),
  'RET_AFE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_RET_AFE',
    'width' => '10%',
    'default' => false,
  ),
  'PRE_RES' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_PRE_RES',
    'width' => '10%',
    'default' => false,
  ),
  'COMPV_AFE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_COMPV_AFE',
    'width' => '10%',
    'default' => false,
  ),
  'RET_PV0' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_RET_PV0',
    'width' => '10%',
    'default' => false,
  ),
  'COMRED_AFE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_COMRED_AFE',
    'width' => '10%',
    'default' => false,
  ),
  'NET_PV0' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_NET_PV0',
    'width' => '10%',
    'default' => false,
  ),
  'NET_AGE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_NET_AGE',
    'width' => '10%',
    'default' => false,
  ),
  'REC_APU' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_REC_APU',
    'width' => '10%',
    'default' => false,
  ),
  'RET_AGE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_RET_AGE',
    'width' => '10%',
    'default' => false,
  ),
  'FECHAHORA_RES' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_FECHAHORA_RES',
    'width' => '10%',
    'default' => false,
  ),
  'FECHAHORA_CAR' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_FECHAHORA_CAR',
    'width' => '10%',
    'default' => false,
  ),
  'PRE_AFE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_PRE_AFE',
    'width' => '10%',
    'default' => false,
  ),
  'REC_AFE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_REC_AFE',
    'width' => '10%',
    'default' => false,
  ),
  'TCK_CAR' => 
  array (
    'type' => 'int',
    'label' => 'LBL_TCK_CAR',
    'width' => '10%',
    'default' => false,
  ),
  'APU_CAR' => 
  array (
    'type' => 'int',
    'label' => 'LBL_APU_CAR',
    'width' => '10%',
    'default' => false,
  ),
  'PRODUCTO_PADRE' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO_PADRE',
    'id' => 'SOR_PRODUCTO_ID1_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
  'REC_CAR' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_REC_CAR',
    'width' => '10%',
    'default' => false,
  ),
);
?>
