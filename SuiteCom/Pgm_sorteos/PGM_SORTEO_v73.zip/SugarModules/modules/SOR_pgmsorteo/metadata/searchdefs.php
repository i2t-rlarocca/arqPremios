<?php
$module_name = 'SOR_pgmsorteo';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'producto' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PRODUCTO',
        'id' => 'SOR_PRODUCTO_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'producto',
      ),
      'nrosorteo' => 
      array (
        'type' => 'int',
        'label' => 'LBL_NROSORTEO',
        'width' => '10%',
        'default' => true,
        'name' => 'nrosorteo',
      ),
      'fecha' => 
      array (
        'type' => 'date',
        'label' => 'LBL_FECHA',
        'width' => '10%',
        'default' => true,
        'name' => 'fecha',
      ),
      'hora' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_HORA',
        'width' => '10%',
        'default' => true,
        'name' => 'hora',
      ),
      'estado_sorteo' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_ESTADO_SORTEO',
        'id' => 'SOR_ESTADO_PGMSORTEO_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'estado_sorteo',
      ),
    ),
    'advanced_search' => 
    array (
      'producto' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PRODUCTO',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'SOR_PRODUCTO_ID_C',
        'name' => 'producto',
      ),
      'nrosorteo' => 
      array (
        'type' => 'int',
        'label' => 'LBL_NROSORTEO',
        'width' => '10%',
        'default' => true,
        'name' => 'nrosorteo',
      ),
      'fecha' => 
      array (
        'type' => 'date',
        'label' => 'LBL_FECHA',
        'width' => '10%',
        'default' => true,
        'name' => 'fecha',
      ),
      'hora' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_HORA',
        'width' => '10%',
        'default' => true,
        'name' => 'hora',
      ),
      'producto_padre' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PRODUCTO_PADRE',
        'id' => 'SOR_PRODUCTO_ID1_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'producto_padre',
      ),
      'estado_sorteo' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_ESTADO_SORTEO',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'SOR_ESTADO_PGMSORTEO_ID_C',
        'name' => 'estado_sorteo',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
