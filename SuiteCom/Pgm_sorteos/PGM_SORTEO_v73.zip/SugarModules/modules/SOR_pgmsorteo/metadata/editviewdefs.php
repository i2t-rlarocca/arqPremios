<?php
$module_name = 'SOR_pgmsorteo';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => false,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'producto',
            'studio' => 'visible',
            'label' => 'LBL_PRODUCTO',
          ),
          1 => 
          array (
            'name' => 'nrosorteo',
            'label' => 'LBL_NROSORTEO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'fecha',
            'label' => 'LBL_FECHA',
          ),
          1 => 
          array (
            'name' => 'hora',
            'label' => 'LBL_HORA',
          ),
        ),
        2 => 
        array (
          1 => 
          array (
            'name' => 'fechahoraproximo',
            'label' => 'LBL_FECHAHORAPROXIMO',
          ),
        ),
      ),
    ),
  ),
);
?>
