<?php
$module_name = 'SOR_pgmsorteo';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'producto',
            'studio' => 'visible',
            'label' => 'LBL_PRODUCTO',
          ),
          1 => 
          array (
            'name' => 'nrosorteo',
            'label' => 'LBL_NROSORTEO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'fecha',
            'label' => 'LBL_FECHA',
          ),
          1 => 
          array (
            'name' => 'hora',
            'label' => 'LBL_HORA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'estado_sorteo',
            'studio' => 'visible',
            'label' => 'LBL_ESTADO_SORTEO',
          ),
          1 => 
          array (
            'name' => 'fechahoraproximo',
            'label' => 'LBL_FECHAHORAPROXIMO',
          ),
        ),
        3 => 
        array (
          1 => 
          array (
            'name' => 'fecha_prescripcion',
            'label' => 'LBL_FECHA_PRESCRIPCION',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'tck_afe',
            'label' => 'LBL_TCK_AFE',
          ),
          1 => 
          array (
            'name' => 'apu_afe',
            'label' => 'LBL_APU_AFE',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'rec_afe',
            'label' => 'LBL_REC_AFE',
          ),
          1 => 
          array (
            'name' => 'pre_afe',
            'label' => 'LBL_PRE_AFE',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'compv_afe',
            'label' => 'LBL_COMPV_AFE',
          ),
          1 => 
          array (
            'name' => 'comred_afe',
            'label' => 'LBL_COMRED_AFE',
          ),
        ),
      ),
    ),
  ),
);
?>
