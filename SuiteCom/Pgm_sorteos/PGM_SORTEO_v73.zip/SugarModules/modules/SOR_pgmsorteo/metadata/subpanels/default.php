<?php
$module_name='SOR_pgmsorteo';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SOR_pgmsorteo',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'fecha' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_FECHA',
      'width' => '10%',
      'default' => true,
    ),
    'fechahoraproximo' => 
    array (
      'type' => 'datetimecombo',
      'vname' => 'LBL_FECHAHORAPROXIMO',
      'width' => '10%',
      'default' => true,
    ),
    'fecha_prescripcion' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_FECHA_PRESCRIPCION',
      'width' => '10%',
      'default' => true,
    ),
    'estado_sorteo' => 
    array (
      'type' => 'relate',
      'studio' => 'visible',
      'vname' => 'LBL_ESTADO_SORTEO',
      'id' => 'SOR_ESTADO_PGMSORTEO_ID_C',
      'link' => true,
      'width' => '10%',
      'default' => true,
      'widget_class' => 'SubPanelDetailViewLink',
      'target_module' => 'SOR_estado_pgmsorteo',
      'target_record_key' => 'sor_estado_pgmsorteo_id_c',
    ),
  ),
);