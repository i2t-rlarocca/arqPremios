<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.

 * SuiteCRM is an extension to SugarCRM Community Edition developed by Salesagility Ltd.
 * Copyright (C) 2011 - 2014 Salesagility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for  technical reasons, the Appropriate Legal Notices must
 * display the words  "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 ********************************************************************************/

$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Ответственный(ая)',
  'LBL_ASSIGNED_TO_NAME' => 'Ответственный(ая)',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Дата создания',
  'LBL_DATE_MODIFIED' => 'Дата изменения',
  'LBL_MODIFIED' => 'Изменено',
  'LBL_MODIFIED_ID' => 'Изменено(ID)',
  'LBL_MODIFIED_NAME' => 'Изменено',
  'LBL_CREATED' => 'Создано',
  'LBL_CREATED_ID' => 'Создано(ID)',
  'LBL_DESCRIPTION' => 'Описание',
  'LBL_DELETED' => 'Удалено',
  'LBL_NAME' => 'Название',
  'LBL_CREATED_USER' => 'Создано',
  'LBL_MODIFIED_USER' => 'Изменено',
  'LBL_LIST_NAME' => 'Название',
  'LBL_EDIT_BUTTON' => 'Править',
  'LBL_REMOVE' => 'Удалить',
  'LBL_LIST_FORM_TITLE' => 'PGM - Pgmsorteo Список',
  'LBL_MODULE_NAME' => 'PGM - Pgmsorteo',
  'LBL_MODULE_TITLE' => 'PGM - Pgmsorteo',
  'LBL_HOMEPAGE_TITLE' => 'Мой PGM - Pgmsorteo',
  'LNK_NEW_RECORD' => 'Создать PGM - Pgmsorteo',
  'LNK_LIST' => 'View PGM - Pgmsorteo',
  'LNK_IMPORT_SOR_PGMSORTEO' => 'Importar PGM - Pgmsorteo',
  'LBL_SEARCH_FORM_TITLE' => 'Поиск PGM - Pgmsorteo',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Просмотр истории',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Мероприятия',
  'LBL_SOR_PGMSORTEO_SUBPANEL_TITLE' => 'PGM - Pgmsorteo',
  'LBL_NEW_FORM_TITLE' => 'Новый PGM - Pgmsorteo',
  'LBL_IDPGMSORTEO' => 'idPgmSorteo',
  'LBL_IDJUEGO' => 'Juego',
  'LBL_NROSORTEO' => 'nroSorteo',
  'LBL_IDJUEGO_EXTRACTO_DE' => 'Juego Rector',
  'LBL_IDESTADO' => 'Estado',
  'LBL_FECHA' => 'fecha',
  'LBL_HORA' => 'Hora',
  'LBL_FECHAHORAPRESCRIPCION' => 'fechaHoraPrescripcion',
  'LBL_FECHAHORAPROXIMO' => 'fechaHoraProximo',
  'LBL_POZOESTIMADOPROXIMO' => 'PozoEstimadoProximo',
  'LBL_LOCALIDAD' => 'localidad',
  'LBL_TIENE_ADIC' => 'Tiene adicional',
  'LBL_FECHAHORA_CAR' => 'Fecha Hora caratula',
  'LBL_FECHAHORA_RES' => 'Fecha Hora resultado',
  'LBL_FECHAHORA_AFE' => 'Fecha Hora afectaciones',
  'LBL_APUESTAS' => 'apuestas',
  'LBL_TCK_CAR' => 'tck car',
  'LBL_APU_CAR' => 'apu car',
  'LBL_REC_CAR' => 'rec car',
  'LBL_TCK_APU' => 'tck apu',
  'LBL_APU_APU' => 'apuestas apuesta',
  'LBL_REC_APU' => 'rec apu',
  'LBL_TCK_AFE' => 'tck afe',
  'LBL_APU_AFE' => 'apu afe',
  'LBL_REC_AFE' => 'rec afe',
  'LBL_PRE_AFE' => 'pre afe',
  'LBL_PRE_PRE' => 'pre pre',
  'LBL_PRE_RES' => 'pre res',
  'LBL_APU_PAIS_CAR' => 'apu pais car',
  'LBL_PRE_RET' => 'pre ret',
  'LBL_PRE_NET' => 'pre net',
  'LBL_SORTEADO' => 'sorteado',
  'LBL_PRODUCTO_SOR_PRODUCTO_ID' => 'Producto (relacionado  ID)',
  'LBL_PRODUCTO' => 'Producto',
  'LBL_ESTADO_SORTEO_SOR_ESTADO_PGMSORTEO_ID' => 'Estado Sorteo (relacionado  ID)',
  'LBL_ESTADO_SORTEO' => 'Estado Sorteo',
  'LBL_PRODUCTO_PADRE_SOR_PRODUCTO_ID' => 'Producto Rector (relacionado  ID)',
  'LBL_PRODUCTO_PADRE' => 'Producto Rector',
  'LBL_FECHA_PRESCRIPCION' => 'Fecha Prescripcion',
  'LBL_NET_AFE' => 'neto afe',
  'LBL_RET_AFE' => 'Retenciones',
  'LBL_NET_PRE' => 'Neto premios',
  'LBL_RET_PRE' => 'ret pre',
  'LBL_PRE_AGE' => 'premios  agencia',
  'LBL_NET_AGE' => 'Premios Neto Agencias',
  'LBL_RET_AGE' => 'Ret Premios Agencias',
  'LBL_PRE_PV0' => 'Premios Premios',
  'LBL_NET_PV0' => 'Neto premios',
  'LBL_RET_PV0' => 'Retenciones Premios',
  'LBL_COMPV_AFE' => 'Comisiones P.V',
  'LBL_COMRED_AFE' => 'Comisiones Red',
  'LBL_ESTADO_CONTROL_CONTAB' => 'Estado control contabilidad',
  'LBL_VALOR_EN_CNT' => 'Valor en Contabilidad',
  'LBL_SOR_EMISION_CERRADA' => 'Emisión Cerrada',
  'LBL_SOR_PRESC_RECIBIDA' => 'Prescripción Pr. Ag. Recibida',
  'LBL_SOR_PRESC_CONTABILIZADA' => 'Prescripción Contabilizada',
  'LBL_SOR_FECHOR_EMISION_CERRADA' => 'Fecha de Cierre de emisión',
  'LBL_SOR_FECHOR_PRESC_RECIBIDA' => 'Fecha que se recibió prescripción pr. ag.',
  'LBL_SOR_FECHOR_PRESC_CONTABILIZADA' => 'Fecha contabilización de la prescripción',
  'LBL_TCK_GAN_VOLCADOS' => 'Tickets Ganadores Volcados?',
  'LBL_SOR_VTASACUM' => 'Ventas Acumuladas',
);