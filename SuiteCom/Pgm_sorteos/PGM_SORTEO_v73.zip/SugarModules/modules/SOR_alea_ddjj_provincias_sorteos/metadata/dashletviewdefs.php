<?php
$dashletData['SOR_alea_ddjj_provincias_sorteosDashlet']['searchFields'] = array (
  'ddjj_sorteo' => 
  array (
    'default' => '',
  ),
  'ddjj_provincia' => 
  array (
    'default' => '',
  ),
);
$dashletData['SOR_alea_ddjj_provincias_sorteosDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '10%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'ddjj_comisiones' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_DDJJ_COMISIONES',
    'width' => '10%',
    'default' => true,
    'name' => 'ddjj_comisiones',
  ),
  'ddjj_porc_costo_captura' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_DDJJ_PORC_COSTO_CAPTURA',
    'width' => '10%',
    'default' => true,
    'name' => 'ddjj_porc_costo_captura',
  ),
  'ddjj_descuento' => 
  array (
    'type' => 'decimal',
    'default' => true,
    'label' => 'LBL_DDJJ_DESCUENTO',
    'width' => '10%',
    'name' => 'ddjj_descuento',
  ),
  'ddjj_sorteo' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DDJJ_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
    'name' => 'ddjj_sorteo',
  ),
  'ddjj_provincia' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DDJJ_PROVINCIA',
    'id' => 'TBL_PROVINCIAS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
    'name' => 'ddjj_provincia',
  ),
);
