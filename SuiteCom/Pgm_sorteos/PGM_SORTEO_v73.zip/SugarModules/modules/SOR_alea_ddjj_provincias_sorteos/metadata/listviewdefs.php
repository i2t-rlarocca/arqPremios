<?php
$module_name = 'SOR_alea_ddjj_provincias_sorteos';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'DDJJ_COMISIONES' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_DDJJ_COMISIONES',
    'width' => '10%',
    'default' => true,
  ),
  'DDJJ_PORC_COSTO_CAPTURA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_DDJJ_PORC_COSTO_CAPTURA',
    'width' => '10%',
    'default' => true,
  ),
  'DDJJ_DESCUENTO' => 
  array (
    'type' => 'decimal',
    'default' => true,
    'label' => 'LBL_DDJJ_DESCUENTO',
    'width' => '10%',
  ),
  'DDJJ_SORTEO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DDJJ_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
  'DDJJ_PROVINCIA' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DDJJ_PROVINCIA',
    'id' => 'TBL_PROVINCIAS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
);
?>
