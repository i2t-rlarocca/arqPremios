<?php
$popupMeta = array (
    'moduleMain' => 'SOR_alea_ddjj_provincias_sorteos',
    'varName' => 'SOR_alea_ddjj_provincias_sorteos',
    'orderBy' => 'sor_alea_ddjj_provincias_sorteos.name',
    'whereClauses' => array (
  'ddjj_sorteo' => 'sor_alea_ddjj_provincias_sorteos.ddjj_sorteo',
  'ddjj_provincia' => 'sor_alea_ddjj_provincias_sorteos.ddjj_provincia',
),
    'searchInputs' => array (
  4 => 'ddjj_sorteo',
  5 => 'ddjj_provincia',
),
    'searchdefs' => array (
  'ddjj_sorteo' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DDJJ_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'ddjj_sorteo',
  ),
  'ddjj_provincia' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DDJJ_PROVINCIA',
    'id' => 'TBL_PROVINCIAS_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'ddjj_provincia',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
    'name' => 'name',
  ),
  'DDJJ_SORTEO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DDJJ_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'ddjj_sorteo',
  ),
  'DDJJ_PROVINCIA' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DDJJ_PROVINCIA',
    'id' => 'TBL_PROVINCIAS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'ddjj_provincia',
  ),
  'DDJJ_COMISIONES' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_DDJJ_COMISIONES',
    'width' => '10%',
    'default' => true,
    'name' => 'ddjj_comisiones',
  ),
  'DDJJ_PORC_COSTO_CAPTURA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_DDJJ_PORC_COSTO_CAPTURA',
    'width' => '10%',
    'default' => true,
    'name' => 'ddjj_porc_costo_captura',
  ),
  'DDJJ_DESCUENTO' => 
  array (
    'type' => 'decimal',
    'default' => true,
    'label' => 'LBL_DDJJ_DESCUENTO',
    'width' => '10%',
    'name' => 'ddjj_descuento',
  ),
),
);
