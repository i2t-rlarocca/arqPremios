<?php
$module_name = 'SOR_alea_ddjj_provincias_sorteos';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'ddjj_sorteo',
            'studio' => 'visible',
            'label' => 'LBL_DDJJ_SORTEO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'ddjj_provincia',
            'studio' => 'visible',
            'label' => 'LBL_DDJJ_PROVINCIA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'ddjj_comisiones',
            'label' => 'LBL_DDJJ_COMISIONES',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'ddjj_porc_costo_captura',
            'label' => 'LBL_DDJJ_PORC_COSTO_CAPTURA',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'ddjj_descuento',
            'label' => 'LBL_DDJJ_DESCUENTO',
          ),
        ),
      ),
    ),
  ),
);
?>
