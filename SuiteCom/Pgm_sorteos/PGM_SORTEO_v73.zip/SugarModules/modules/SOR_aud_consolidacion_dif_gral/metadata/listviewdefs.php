<?php
$module_name = 'SOR_aud_consolidacion_dif_gral';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'ID_PERMISO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ID_PERMISO',
    'width' => '10%',
    'default' => true,
  ),
  'NUMERO_AGENTE' => 
  array (
    'type' => 'int',
    'label' => 'LBL_NUMERO_AGENTE',
    'width' => '10%',
    'default' => true,
  ),
  'PUNTO_VENTA_NUMERO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_PUNTO_VENTA_NUMERO',
    'width' => '10%',
    'default' => true,
  ),
  'ENCONTRADO_ARCHIVO_AFECTACION' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_ENCONTRADO_ARCHIVO_AFECTACION',
    'width' => '10%',
  ),
  'ENCONTRADO_ARCHIVO_APUESTAS' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_ENCONTRADO_ARCHIVO_APUESTAS',
    'width' => '10%',
  ),
  'ENCONTRADO_ARCHIVO_PREMIOS' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_ENCONTRADO_ARCHIVO_PREMIOS',
    'width' => '10%',
  ),
  'CUIT_SUITE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CUIT_SUITE',
    'width' => '10%',
    'default' => false,
  ),
  'CUIT_ARCHIVO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CUIT_ARCHIVO',
    'width' => '10%',
    'default' => false,
  ),
);
?>
