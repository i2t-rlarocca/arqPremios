<?php
$module_name = 'SOR_aud_consolidacion_dif_gral';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'id_permiso',
            'label' => 'LBL_ID_PERMISO',
          ),
          1 => 
          array (
            'name' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif_gral_name',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'numero_agente',
            'label' => 'LBL_NUMERO_AGENTE',
          ),
          1 => 
          array (
            'name' => 'punto_venta_numero',
            'label' => 'LBL_PUNTO_VENTA_NUMERO',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'cuit_archivo',
            'label' => 'LBL_CUIT_ARCHIVO',
          ),
          1 => 
          array (
            'name' => 'cuit_suite',
            'label' => 'LBL_CUIT_SUITE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'encontrado_archivo_afectacion',
            'label' => 'LBL_ENCONTRADO_ARCHIVO_AFECTACION',
          ),
          1 => 
          array (
            'name' => 'encontrado_archivo_apuestas',
            'label' => 'LBL_ENCONTRADO_ARCHIVO_APUESTAS',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'encontrado_archivo_premios',
            'label' => 'LBL_ENCONTRADO_ARCHIVO_PREMIOS',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
?>
