<?php
$module_name='SOR_aud_consolidacion_dif_gral';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SOR_aud_consolidacion_dif_gral',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'numero_agente' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_NUMERO_AGENTE',
      'width' => '10%',
      'default' => true,
    ),
    'punto_venta_numero' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_PUNTO_VENTA_NUMERO',
      'width' => '10%',
      'default' => true,
    ),
    'id_permiso' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_ID_PERMISO',
      'width' => '10%',
      'default' => true,
    ),
    'cuit_archivo' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_CUIT_ARCHIVO',
      'width' => '10%',
      'default' => true,
    ),
    'cuit_suite' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_CUIT_SUITE',
      'width' => '10%',
      'default' => true,
    ),
    'encontrado_archivo_afectacion' => 
    array (
      'type' => 'bool',
      'default' => true,
      'vname' => 'LBL_ENCONTRADO_ARCHIVO_AFECTACION',
      'width' => '10%',
    ),
    'encontrado_archivo_apuestas' => 
    array (
      'type' => 'bool',
      'default' => true,
      'vname' => 'LBL_ENCONTRADO_ARCHIVO_APUESTAS',
      'width' => '10%',
    ),
    'encontrado_archivo_premios' => 
    array (
      'type' => 'bool',
      'default' => true,
      'vname' => 'LBL_ENCONTRADO_ARCHIVO_PREMIOS',
      'width' => '10%',
    ),
  ),
);