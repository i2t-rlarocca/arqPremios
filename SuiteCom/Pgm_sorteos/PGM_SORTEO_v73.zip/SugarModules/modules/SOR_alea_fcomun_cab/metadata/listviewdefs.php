<?php
$module_name = 'SOR_alea_fcomun_cab';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'APORTE_PREMIOS' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_APORTE_PREMIOS',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'FONDO_COMUN' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_FONDO_COMUN',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'PREMIOS' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_PREMIOS',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'PROCESADO' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_PROCESADO',
    'width' => '10%',
  ),
  'SORTEO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
);
?>
