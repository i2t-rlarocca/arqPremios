<?php
$module_name='SOR_alea_fcomun_cab';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SOR_alea_fcomun_cab',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'aporte_premios' => 
    array (
      'type' => 'currency',
      'vname' => 'LBL_APORTE_PREMIOS',
      'currency_format' => true,
      'width' => '10%',
      'default' => true,
    ),
    'premios' => 
    array (
      'type' => 'currency',
      'vname' => 'LBL_PREMIOS',
      'currency_format' => true,
      'width' => '10%',
      'default' => true,
    ),
    'fondo_comun' => 
    array (
      'type' => 'currency',
      'vname' => 'LBL_FONDO_COMUN',
      'currency_format' => true,
      'width' => '10%',
      'default' => true,
    ),
    'procesado' => 
    array (
      'type' => 'bool',
      'default' => true,
      'vname' => 'LBL_PROCESADO',
      'width' => '10%',
    ),
    'edit_button' => 
    array (
      'vname' => 'LBL_EDIT_BUTTON',
      'widget_class' => 'SubPanelEditButton',
      'module' => 'SOR_alea_fcomun_cab',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'vname' => 'LBL_REMOVE',
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'SOR_alea_fcomun_cab',
      'width' => '5%',
      'default' => true,
    ),
  ),
);