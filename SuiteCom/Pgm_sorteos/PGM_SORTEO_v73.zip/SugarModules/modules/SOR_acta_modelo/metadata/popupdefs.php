<?php
$popupMeta = array (
    'moduleMain' => 'SOR_acta_modelo',
    'varName' => 'SOR_acta_modelo',
    'orderBy' => 'sor_acta_modelo.name',
    'whereClauses' => array (
  'name' => 'sor_acta_modelo.name',
  'producto' => 'sor_acta_modelo.producto',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'producto',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'producto' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO',
    'id' => 'SOR_PRODUCTO_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'producto',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'PRODUCTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO',
    'id' => 'SOR_PRODUCTO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
),
);
