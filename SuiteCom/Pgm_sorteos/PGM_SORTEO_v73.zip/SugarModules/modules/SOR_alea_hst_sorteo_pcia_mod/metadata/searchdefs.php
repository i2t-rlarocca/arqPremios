<?php
$module_name = 'SOR_alea_hst_sorteo_pcia_mod';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'sorteo' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_SORTEO',
        'id' => 'SOR_PGMSORTEO_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'sorteo',
      ),
      'name' => 
      array (
        'type' => 'name',
        'link' => true,
        'label' => 'LBL_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'name',
      ),
    ),
    'advanced_search' => 
    array (
      'sorteo' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_SORTEO',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'SOR_PGMSORTEO_ID_C',
        'name' => 'sorteo',
      ),
      'modalidad' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_MODALIDAD',
        'id' => 'SOR_MODALIDADES_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'modalidad',
      ),
      'provincia' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PROVINCIA',
        'id' => 'TBL_PROVINCIAS_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'provincia',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
