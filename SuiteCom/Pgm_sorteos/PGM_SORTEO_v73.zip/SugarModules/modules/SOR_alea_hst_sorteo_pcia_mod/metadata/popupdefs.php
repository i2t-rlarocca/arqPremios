<?php
$popupMeta = array (
    'moduleMain' => 'SOR_alea_hst_sorteo_pcia_mod',
    'varName' => 'SOR_alea_hst_sorteo_pcia_mod',
    'orderBy' => 'sor_alea_hst_sorteo_pcia_mod.name',
    'whereClauses' => array (
  'sorteo' => 'sor_alea_hst_sorteo_pcia_mod.sorteo',
  'modalidad' => 'sor_alea_hst_sorteo_pcia_mod.modalidad',
  'provincia' => 'sor_alea_hst_sorteo_pcia_mod.provincia',
),
    'searchInputs' => array (
  4 => 'sorteo',
  5 => 'modalidad',
  6 => 'provincia',
),
    'searchdefs' => array (
  'sorteo' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'sorteo',
  ),
  'modalidad' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_MODALIDAD',
    'id' => 'SOR_MODALIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'modalidad',
  ),
  'provincia' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PROVINCIA',
    'id' => 'TBL_PROVINCIAS_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'provincia',
  ),
),
    'listviewdefs' => array (
  'SORTEO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'MODALIDAD' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_MODALIDAD',
    'id' => 'SOR_MODALIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'PROVINCIA' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PROVINCIA',
    'id' => 'TBL_PROVINCIAS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'SPM_RECAUDACION_TOTAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
  ),
  'SPM_TOTAL_ARANCEL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_TOTAL_ARANCEL',
    'width' => '10%',
    'default' => true,
  ),
  'SPM_TOTAL_FONDO_COMUN' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_TOTAL_FONDO_COMUN',
    'width' => '10%',
    'default' => true,
  ),
),
);
