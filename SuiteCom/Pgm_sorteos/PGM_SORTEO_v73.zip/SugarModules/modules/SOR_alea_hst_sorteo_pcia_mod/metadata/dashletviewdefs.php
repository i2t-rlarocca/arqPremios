<?php
$dashletData['SOR_alea_hst_sorteo_pcia_modDashlet']['searchFields'] = array (
  'sorteo' => 
  array (
    'default' => '',
  ),
  'provincia' => 
  array (
    'default' => '',
  ),
  'modalidad' => 
  array (
    'default' => '',
  ),
);
$dashletData['SOR_alea_hst_sorteo_pcia_modDashlet']['columns'] = array (
  'sorteo' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'sorteo',
  ),
  'modalidad' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_MODALIDAD',
    'id' => 'SOR_MODALIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'modalidad',
  ),
  'provincia' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PROVINCIA',
    'id' => 'TBL_PROVINCIAS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'provincia',
  ),
  'spm_recaudacion_total' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
    'name' => 'spm_recaudacion_total',
  ),
  'spm_total_arancel' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_TOTAL_ARANCEL',
    'width' => '10%',
    'default' => true,
    'name' => 'spm_total_arancel',
  ),
  'spm_total_fondo_comun' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_TOTAL_FONDO_COMUN',
    'width' => '10%',
    'default' => true,
    'name' => 'spm_total_fondo_comun',
  ),
  'spm_apuestas' => 
  array (
    'type' => 'int',
    'label' => 'LBL_SPM_APUESTAS',
    'width' => '10%',
    'default' => false,
    'name' => 'spm_apuestas',
  ),
  'spm_valor_apuesta' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_VALOR_APUESTA',
    'width' => '10%',
    'default' => false,
    'name' => 'spm_valor_apuesta',
  ),
  'spm_porc_arancel' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_PORC_ARANCEL',
    'width' => '10%',
    'default' => false,
    'name' => 'spm_porc_arancel',
  ),
  'spm_porc_fondo_comun' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_PORC_FONDO_COMUN',
    'width' => '10%',
    'default' => false,
    'name' => 'spm_porc_fondo_comun',
  ),
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => false,
    'name' => 'name',
  ),
);
