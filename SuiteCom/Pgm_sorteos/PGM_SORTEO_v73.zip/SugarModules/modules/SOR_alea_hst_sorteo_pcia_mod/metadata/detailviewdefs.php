<?php
$module_name = 'SOR_alea_hst_sorteo_pcia_mod';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'sorteo',
            'studio' => 'visible',
            'label' => 'LBL_SORTEO',
          ),
          1 => 
          array (
            'name' => 'modalidad',
            'studio' => 'visible',
            'label' => 'LBL_MODALIDAD',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'provincia',
            'studio' => 'visible',
            'label' => 'LBL_PROVINCIA',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'spm_apuestas',
            'label' => 'LBL_SPM_APUESTAS',
          ),
          1 => 
          array (
            'name' => 'spm_valor_apuesta',
            'label' => 'LBL_SPM_VALOR_APUESTA',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'spm_recaudacion_total',
            'label' => 'LBL_SPM_RECAUDACION_TOTAL',
          ),
          1 => 
          array (
            'name' => 'spm_valor_nominal',
            'label' => 'LBL_SPM_VALOR_NOMINAL',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'spm_porc_arancel',
            'label' => 'LBL_SPM_PORC_ARANCEL',
          ),
          1 => 
          array (
            'name' => 'spm_total_arancel',
            'label' => 'LBL_SPM_TOTAL_ARANCEL',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'spm_porc_fondo_comun',
            'label' => 'LBL_SPM_PORC_FONDO_COMUN',
          ),
          1 => 
          array (
            'name' => 'spm_total_fondo_comun',
            'label' => 'LBL_SPM_TOTAL_FONDO_COMUN',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'spm_porc_fondo_premios',
            'label' => 'LBL_SPM_PORC_FONDO_PREMIOS',
          ),
          1 => 
          array (
            'name' => 'spm_fondo_pozo_premios',
            'label' => 'LBL_SPM_FONDO_POZO_PREMIOS',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'spm_porc_fondo_premios_esp',
            'label' => 'LBL_SPM_PORC_FONDO_PREMIOS_ESP',
          ),
          1 => 
          array (
            'name' => 'spm_fondo_pozo_premios_esp',
            'label' => 'LBL_SPM_FONDO_POZO_PREMIOS_ESP',
          ),
        ),
      ),
    ),
  ),
);
?>
