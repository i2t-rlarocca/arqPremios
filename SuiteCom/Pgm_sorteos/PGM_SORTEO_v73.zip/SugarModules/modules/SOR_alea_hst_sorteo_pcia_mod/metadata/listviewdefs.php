<?php
$module_name = 'SOR_alea_hst_sorteo_pcia_mod';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'PROVINCIA' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PROVINCIA',
    'id' => 'TBL_PROVINCIAS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'SORTEO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'MODALIDAD' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_MODALIDAD',
    'id' => 'SOR_MODALIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'SPM_APUESTAS' => 
  array (
    'type' => 'int',
    'label' => 'LBL_SPM_APUESTAS',
    'width' => '10%',
    'default' => true,
  ),
  'SPM_VALOR_APUESTA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_VALOR_APUESTA',
    'width' => '10%',
    'default' => true,
  ),
  'SPM_RECAUDACION_TOTAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
  ),
  'SPM_TOTAL_ARANCEL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_TOTAL_ARANCEL',
    'width' => '10%',
    'default' => true,
  ),
  'SPM_TOTAL_FONDO_COMUN' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_TOTAL_FONDO_COMUN',
    'width' => '10%',
    'default' => true,
  ),
  'SPM_VALOR_NOMINAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_VALOR_NOMINAL',
    'width' => '10%',
    'default' => true,
  ),
  'SPM_FONDO_POZO_PREMIOS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_FONDO_POZO_PREMIOS',
    'width' => '10%',
    'default' => true,
  ),
  'SPM_FONDO_POZO_PREMIOS_ESP' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_FONDO_POZO_PREMIOS_ESP',
    'width' => '10%',
    'default' => true,
  ),
  'SPM_PORC_ARANCEL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_PORC_ARANCEL',
    'width' => '10%',
    'default' => false,
  ),
  'SPM_PORC_FONDO_COMUN' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_PORC_FONDO_COMUN',
    'width' => '10%',
    'default' => false,
  ),
  'SPM_PORC_FONDO_PREMIOS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_PORC_FONDO_PREMIOS',
    'width' => '10%',
    'default' => false,
  ),
  'SPM_PORC_FONDO_PREMIOS_ESP' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SPM_PORC_FONDO_PREMIOS_ESP',
    'width' => '10%',
    'default' => false,
  ),
);
?>
