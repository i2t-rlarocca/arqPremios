<?php
$module_name = 'SOR_alea_hst_sorteo_mod';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'sorteo' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_SORTEO',
        'id' => 'SOR_PGMSORTEO_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'sorteo',
      ),
      'modalidad' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_MODALIDAD',
        'id' => 'SOR_MODALIDADES_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'modalidad',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
