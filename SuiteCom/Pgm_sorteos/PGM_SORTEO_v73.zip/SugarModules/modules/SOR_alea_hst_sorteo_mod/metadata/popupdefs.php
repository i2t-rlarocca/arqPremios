<?php
$popupMeta = array (
    'moduleMain' => 'SOR_alea_hst_sorteo_mod',
    'varName' => 'SOR_alea_hst_sorteo_mod',
    'orderBy' => 'sor_alea_hst_sorteo_mod.name',
    'whereClauses' => array (
  'sorteo' => 'sor_alea_hst_sorteo_mod.sorteo',
  'modalidad' => 'sor_alea_hst_sorteo_mod.modalidad',
),
    'searchInputs' => array (
  4 => 'sorteo',
  5 => 'modalidad',
),
    'searchdefs' => array (
  'sorteo' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'sorteo',
  ),
  'modalidad' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_MODALIDAD',
    'id' => 'SOR_MODALIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'modalidad',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'SM_APUESTAS' => 
  array (
    'type' => 'int',
    'label' => 'LBL_SM_APUESTAS',
    'width' => '10%',
    'default' => true,
  ),
  'SM_VALOR_APUESTA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_VALOR_APUESTA',
    'width' => '10%',
    'default' => true,
  ),
  'SM_RECAUDACION_TOTAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
  ),
  'SM_TOTAL_VALOR_NOMINAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_TOTAL_VALOR_NOMINAL',
    'width' => '10%',
    'default' => true,
  ),
  'SM_FONDO_POZO_PREMIOS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_FONDO_POZO_PREMIOS',
    'width' => '10%',
    'default' => true,
  ),
  'SM_FONDO_POZO_PREMIOS_ESP' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_FONDO_POZO_PREMIOS_ESP',
    'width' => '10%',
    'default' => true,
  ),
),
);
