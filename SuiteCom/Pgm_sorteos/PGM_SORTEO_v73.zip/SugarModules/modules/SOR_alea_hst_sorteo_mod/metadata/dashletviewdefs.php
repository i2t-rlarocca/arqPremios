<?php
$dashletData['SOR_alea_hst_sorteo_modDashlet']['searchFields'] = array (
  'sorteo' => 
  array (
    'default' => '',
  ),
  'modalidad' => 
  array (
    'default' => '',
  ),
);
$dashletData['SOR_alea_hst_sorteo_modDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '20%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'sm_apuestas' => 
  array (
    'type' => 'int',
    'label' => 'LBL_SM_APUESTAS',
    'width' => '10%',
    'default' => true,
    'name' => 'sm_apuestas',
  ),
  'sm_valor_apuesta' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_VALOR_APUESTA',
    'width' => '10%',
    'default' => true,
    'name' => 'sm_valor_apuesta',
  ),
  'sm_recaudacion_total' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
    'name' => 'sm_recaudacion_total',
  ),
  'sm_fondo_pozo_premios' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_FONDO_POZO_PREMIOS',
    'width' => '10%',
    'default' => true,
    'name' => 'sm_fondo_pozo_premios',
  ),
  'sm_fondo_pozo_premios_esp' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_FONDO_POZO_PREMIOS_ESP',
    'width' => '10%',
    'default' => true,
    'name' => 'sm_fondo_pozo_premios_esp',
  ),
  'sorteo' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
    'name' => 'sorteo',
  ),
  'modalidad' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_MODALIDAD',
    'id' => 'SOR_MODALIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
    'name' => 'modalidad',
  ),
  'sm_total_arancel' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_TOTAL_ARANCEL',
    'width' => '10%',
    'default' => false,
    'name' => 'sm_total_arancel',
  ),
  'sm_total_fondo_comun' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_TOTAL_FONDO_COMUN',
    'width' => '10%',
    'default' => false,
    'name' => 'sm_total_fondo_comun',
  ),
  'sm_porc_fondo_premios' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_PORC_FONDO_PREMIOS',
    'width' => '10%',
    'default' => false,
    'name' => 'sm_porc_fondo_premios',
  ),
  'sm_porc_fondo_premios_esp' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_PORC_FONDO_PREMIOS_ESP',
    'width' => '10%',
    'default' => false,
    'name' => 'sm_porc_fondo_premios_esp',
  ),
);
