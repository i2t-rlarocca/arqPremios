<?php
$module_name = 'SOR_alea_hst_sorteo_mod';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'SM_APUESTAS' => 
  array (
    'type' => 'int',
    'label' => 'LBL_SM_APUESTAS',
    'width' => '10%',
    'default' => true,
  ),
  'SM_VALOR_APUESTA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_VALOR_APUESTA',
    'width' => '10%',
    'default' => true,
  ),
  'SM_RECAUDACION_TOTAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
  ),
  'SM_TOTAL_ARANCEL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_TOTAL_ARANCEL',
    'width' => '10%',
    'default' => true,
  ),
  'SM_TOTAL_FONDO_COMUN' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_TOTAL_FONDO_COMUN',
    'width' => '10%',
    'default' => true,
  ),
  'SM_TOTAL_VALOR_NOMINAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_TOTAL_VALOR_NOMINAL',
    'width' => '10%',
    'default' => true,
  ),
  'SM_PORC_FONDO_PREMIOS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_PORC_FONDO_PREMIOS',
    'width' => '10%',
    'default' => true,
  ),
  'SM_FONDO_POZO_PREMIOS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_FONDO_POZO_PREMIOS',
    'width' => '10%',
    'default' => true,
  ),
  'SM_PORC_FONDO_PREMIOS_ESP' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_PORC_FONDO_PREMIOS_ESP',
    'width' => '10%',
    'default' => true,
  ),
  'SM_FONDO_POZO_PREMIOS_ESP' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SM_FONDO_POZO_PREMIOS_ESP',
    'width' => '10%',
    'default' => true,
  ),
  'SORTEO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
  'MODALIDAD' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_MODALIDAD',
    'id' => 'SOR_MODALIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
);
?>
