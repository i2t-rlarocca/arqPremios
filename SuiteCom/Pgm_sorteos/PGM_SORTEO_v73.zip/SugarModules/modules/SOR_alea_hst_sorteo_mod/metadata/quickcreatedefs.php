<?php
$module_name = 'SOR_alea_hst_sorteo_mod';
$viewdefs [$module_name] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'collapsed',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'sorteo',
            'studio' => 'visible',
            'label' => 'LBL_SORTEO',
          ),
          1 => 
          array (
            'name' => 'modalidad',
            'studio' => 'visible',
            'label' => 'LBL_MODALIDAD',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'sm_apuestas',
            'label' => 'LBL_SM_APUESTAS',
          ),
          1 => 
          array (
            'name' => 'sm_valor_apuesta',
            'label' => 'LBL_SM_VALOR_APUESTA',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'sm_recaudacion_total',
            'label' => 'LBL_SM_RECAUDACION_TOTAL',
          ),
          1 => 
          array (
            'name' => 'sm_total_valor_nominal',
            'label' => 'LBL_SM_TOTAL_VALOR_NOMINAL',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'sm_total_arancel',
            'label' => 'LBL_SM_TOTAL_ARANCEL',
          ),
          1 => 
          array (
            'name' => 'sm_total_fondo_comun',
            'label' => 'LBL_SM_TOTAL_FONDO_COMUN',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'sm_porc_fondo_premios',
            'label' => 'LBL_SM_PORC_FONDO_PREMIOS',
          ),
          1 => 
          array (
            'name' => 'sm_fondo_pozo_premios',
            'label' => 'LBL_SM_FONDO_POZO_PREMIOS',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'sm_porc_fondo_premios_esp',
            'label' => 'LBL_SM_PORC_FONDO_PREMIOS_ESP',
          ),
          1 => 
          array (
            'name' => 'sm_fondo_pozo_premios_esp',
            'label' => 'LBL_SM_FONDO_POZO_PREMIOS_ESP',
          ),
        ),
      ),
    ),
  ),
);
?>
