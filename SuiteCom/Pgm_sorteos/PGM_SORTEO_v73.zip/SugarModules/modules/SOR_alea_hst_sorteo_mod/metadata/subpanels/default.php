<?php
$module_name='SOR_alea_hst_sorteo_mod';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SOR_alea_hst_sorteo_mod',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'sm_valor_apuesta' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SM_VALOR_APUESTA',
      'width' => '10%',
      'default' => true,
    ),
    'sm_apuestas' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_SM_APUESTAS',
      'width' => '10%',
      'default' => true,
    ),
    'sm_recaudacion_total' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SM_RECAUDACION_TOTAL',
      'width' => '10%',
      'default' => true,
    ),
    'sm_total_arancel' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SM_TOTAL_ARANCEL',
      'width' => '10%',
      'default' => true,
    ),
    'sm_total_fondo_comun' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SM_TOTAL_FONDO_COMUN',
      'width' => '10%',
      'default' => true,
    ),
    'sm_total_valor_nominal' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SM_TOTAL_VALOR_NOMINAL',
      'width' => '10%',
      'default' => true,
    ),
    'sm_porc_fondo_premios' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SM_PORC_FONDO_PREMIOS',
      'width' => '10%',
      'default' => true,
    ),
    'sm_fondo_pozo_premios' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SM_FONDO_POZO_PREMIOS',
      'width' => '10%',
      'default' => true,
    ),
    'sm_porc_fondo_premios_esp' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SM_PORC_FONDO_PREMIOS_ESP',
      'width' => '10%',
      'default' => true,
    ),
    'sm_fondo_pozo_premios_esp' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SM_FONDO_POZO_PREMIOS_ESP',
      'width' => '10%',
      'default' => true,
    ),
  ),
);