<?php
$module_name = 'SOR_aud_evento';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'TIPO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TIPO',
    'width' => '10%',
    'default' => true,
  ),
  'ETAPA' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_ETAPA',
    'id' => 'SOR_AUD_ETAPAS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
);
?>
