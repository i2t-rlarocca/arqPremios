<?php
$module_name = 'SOR_DIAS';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'codigo' => 
      array (
        'type' => 'int',
        'label' => 'LBL_CODIGO',
        'width' => '10%',
        'default' => true,
        'name' => 'codigo',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'codigo' => 
      array (
        'type' => 'int',
        'label' => 'LBL_CODIGO',
        'width' => '10%',
        'default' => true,
        'name' => 'codigo',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
