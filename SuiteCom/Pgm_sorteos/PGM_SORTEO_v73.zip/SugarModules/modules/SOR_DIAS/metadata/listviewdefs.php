<?php
$module_name = 'SOR_DIAS';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'CODIGO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_CODIGO',
    'width' => '10%',
    'default' => true,
  ),
  'HABIL' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_HABIL',
    'width' => '10%',
  ),
);
?>
