<?php
$module_name = 'SOR_alea_hst_sorteo';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'sorteo' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_SORTEO',
        'id' => 'SOR_PGMSORTEO_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'sorteo',
      ),
      'hs_estado' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HS_ESTADO',
        'width' => '10%',
        'name' => 'hs_estado',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
