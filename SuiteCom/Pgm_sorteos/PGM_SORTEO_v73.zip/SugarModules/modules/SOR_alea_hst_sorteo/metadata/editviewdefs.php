<?php
$module_name = 'SOR_alea_hst_sorteo';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'hs_estado',
            'studio' => 'visible',
            'label' => 'LBL_HS_ESTADO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'hs_recaudacion_total',
            'label' => 'LBL_HS_RECAUDACION_TOTAL',
          ),
          1 => 
          array (
            'name' => 'hs_valor_nominal',
            'label' => 'LBL_HS_VALOR_NOMINAL',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'hs_total_arancel',
            'label' => 'LBL_HS_TOTAL_ARANCEL',
          ),
          1 => 
          array (
            'name' => 'hs_total_fondo_comun',
            'label' => 'LBL_HS_TOTAL_FONDO_COMUN',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'hs_pozo_premios',
            'label' => 'LBL_HS_POZO_PREMIOS',
          ),
          1 => 
          array (
            'name' => 'hs_comisiones',
            'label' => 'LBL_HS_COMISIONES',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'hs_total_sop_y_prc',
            'label' => 'LBL_HS_TOTAL_SOP_Y_PRC',
          ),
          1 => 
          array (
            'name' => 'hs_utilidad_neta',
            'label' => 'LBL_HS_UTILIDAD_NETA',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'hs_porc_alea',
            'label' => 'LBL_HS_PORC_ALEA',
          ),
          1 => 
          array (
            'name' => 'hs_total_alea',
            'label' => 'LBL_HS_TOTAL_ALEA',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'hs_porc_ente',
            'label' => 'LBL_HS_PORC_ENTE',
          ),
          1 => 
          array (
            'name' => 'hs_aporte_ente',
            'label' => 'LBL_HS_APORTE_ENTE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'hs_valor_base_calculo_ente',
            'studio' => 'visible',
            'label' => 'LBL_HS_VALOR_BASE_CALCULO_ENTE',
          ),
        ),
      ),
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'hs_utilidad_a_distribuir',
            'label' => 'LBL_HS_UTILIDAD_A_DISTRIBUIR',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'hs_utilidad_segun_vtas',
            'label' => 'LBL_HS_UTILIDAD_SEGUN_VTAS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'hs_utilidad_en_partes_iguales',
            'label' => 'LBL_HS_UTILIDAD_EN_PARTES_IGUALES',
          ),
          1 => 
          array (
            'name' => 'hs_utilidad_en_pi_unidad',
            'label' => 'LBL_HS_UTILIDAD_EN_PI_UNIDAD',
          ),
        ),
      ),
    ),
  ),
);
?>
