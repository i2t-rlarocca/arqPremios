<?php
$popupMeta = array (
    'moduleMain' => 'SOR_alea_hst_sorteo',
    'varName' => 'SOR_alea_hst_sorteo',
    'orderBy' => 'sor_alea_hst_sorteo.name',
    'whereClauses' => array (
  'name' => 'sor_alea_hst_sorteo.name',
  'sorteo' => 'sor_alea_hst_sorteo.sorteo',
  'hs_estado' => 'sor_alea_hst_sorteo.hs_estado',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'sorteo',
  5 => 'hs_estado',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'sorteo' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'sorteo',
  ),
  'hs_estado' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_HS_ESTADO',
    'width' => '10%',
    'name' => 'hs_estado',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
    'name' => 'name',
  ),
  'HS_RECAUDACION_TOTAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
    'name' => 'hs_recaudacion_total',
  ),
  'HS_APORTE_ENTE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_APORTE_ENTE',
    'width' => '10%',
    'default' => true,
    'name' => 'hs_aporte_ente',
  ),
  'HS_TOTAL_ALEA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_TOTAL_ALEA',
    'width' => '10%',
    'default' => true,
  ),
  'HS_ESTADO' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_HS_ESTADO',
    'width' => '10%',
  ),
),
);
