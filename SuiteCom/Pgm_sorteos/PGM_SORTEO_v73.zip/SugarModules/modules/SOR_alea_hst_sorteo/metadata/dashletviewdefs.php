<?php
$dashletData['SOR_alea_hst_sorteoDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'hs_estado' => 
  array (
    'default' => '',
  ),
);
$dashletData['SOR_alea_hst_sorteoDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'hs_recaudacion_total' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
    'name' => 'hs_recaudacion_total',
  ),
  'hs_total_arancel' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_TOTAL_ARANCEL',
    'width' => '10%',
    'default' => true,
    'name' => 'hs_total_arancel',
  ),
  'hs_total_fondo_comun' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_TOTAL_FONDO_COMUN',
    'width' => '10%',
    'default' => true,
    'name' => 'hs_total_fondo_comun',
  ),
  'hs_valor_nominal' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_VALOR_NOMINAL',
    'width' => '10%',
    'default' => true,
    'name' => 'hs_valor_nominal',
  ),
  'hs_estado' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_HS_ESTADO',
    'width' => '10%',
    'name' => 'hs_estado',
  ),
  'sorteo' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_SORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
    'name' => 'sorteo',
  ),
  'hs_utilidad_neta' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_UTILIDAD_NETA',
    'width' => '10%',
    'default' => false,
    'name' => 'hs_utilidad_neta',
  ),
  'hs_valor_base_calculo_ente' => 
  array (
    'type' => 'enum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_HS_VALOR_BASE_CALCULO_ENTE',
    'width' => '10%',
    'name' => 'hs_valor_base_calculo_ente',
  ),
  'hs_porc_ente' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_PORC_ENTE',
    'width' => '10%',
    'default' => false,
    'name' => 'hs_porc_ente',
  ),
  'hs_aporte_ente' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_APORTE_ENTE',
    'width' => '10%',
    'default' => false,
    'name' => 'hs_aporte_ente',
  ),
  'hs_comisiones' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_COMISIONES',
    'width' => '10%',
    'default' => false,
    'name' => 'hs_comisiones',
  ),
  'hs_porc_alea' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_PORC_ALEA',
    'width' => '10%',
    'default' => false,
    'name' => 'hs_porc_alea',
  ),
  'hs_total_alea' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_TOTAL_ALEA',
    'width' => '10%',
    'default' => false,
    'name' => 'hs_total_alea',
  ),
  'hs_utilidad_a_distribuir' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_UTILIDAD_A_DISTRIBUIR',
    'width' => '10%',
    'default' => false,
  ),
  'hs_pozo_premios' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_POZO_PREMIOS',
    'width' => '10%',
    'default' => false,
    'name' => 'hs_pozo_premios',
  ),
);
