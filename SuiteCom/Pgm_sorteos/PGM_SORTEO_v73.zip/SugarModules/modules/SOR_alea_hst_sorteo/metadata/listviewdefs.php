<?php
$module_name = 'SOR_alea_hst_sorteo';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'HS_RECAUDACION_TOTAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_RECAUDACION_TOTAL',
    'width' => '10%',
    'default' => true,
  ),
  'HS_TOTAL_ARANCEL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_TOTAL_ARANCEL',
    'width' => '10%',
    'default' => true,
  ),
  'HS_TOTAL_FONDO_COMUN' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_TOTAL_FONDO_COMUN',
    'width' => '10%',
    'default' => true,
  ),
  'HS_VALOR_NOMINAL' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_VALOR_NOMINAL',
    'width' => '10%',
    'default' => true,
  ),
  'HS_COMISIONES' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_COMISIONES',
    'width' => '10%',
    'default' => true,
  ),
  'HS_POZO_PREMIOS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_POZO_PREMIOS',
    'width' => '10%',
    'default' => true,
  ),
  'HS_UTILIDAD_NETA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_UTILIDAD_NETA',
    'width' => '10%',
    'default' => true,
  ),
  'HS_APORTE_ENTE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_APORTE_ENTE',
    'width' => '10%',
    'default' => true,
  ),
  'HS_TOTAL_SOP_Y_PRC' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_TOTAL_SOP_Y_PRC',
    'width' => '10%',
    'default' => true,
  ),
  'HS_PORC_ALEA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_PORC_ALEA',
    'width' => '10%',
    'default' => true,
  ),
  'HS_TOTAL_ALEA' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_TOTAL_ALEA',
    'width' => '10%',
    'default' => true,
  ),
  'HS_UTILIDAD_A_DISTRIBUIR' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_UTILIDAD_A_DISTRIBUIR',
    'width' => '10%',
    'default' => true,
  ),
  'HS_UTILIDAD_EN_PARTES_IGUALES' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_UTILIDAD_EN_PARTES_IGUALES',
    'width' => '10%',
    'default' => true,
  ),
  'HS_UTILIDAD_SEGUN_VTAS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_UTILIDAD_SEGUN_VTAS',
    'width' => '10%',
    'default' => true,
  ),
  'HS_ESTADO' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_HS_ESTADO',
    'width' => '10%',
  ),
  'HS_VALOR_BASE_CALCULO_ENTE' => 
  array (
    'type' => 'enum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_HS_VALOR_BASE_CALCULO_ENTE',
    'width' => '10%',
  ),
  'HS_PORC_ENTE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_PORC_ENTE',
    'width' => '10%',
    'default' => false,
  ),
  'HS_UTILIDAD_EN_PI_UNIDAD' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_HS_UTILIDAD_EN_PI_UNIDAD',
    'width' => '10%',
    'default' => false,
  ),
);
?>
