<?php
$module_name='SOR_aud_consolidacion_det';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SOR_aud_consolidacion_det',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'etapa' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_ETAPA',
      'width' => '10%',
      'default' => true,
    ),
    'id_aud_evento' => 
    array (
      'type' => 'relate',
      'studio' => 'visible',
      'vname' => 'LBL_ID_AUD_EVENTO',
      'id' => 'SOR_AUD_EVENTO_ID_C',
      'link' => true,
      'width' => '10%',
      'default' => true,
      'widget_class' => 'SubPanelDetailViewLink',
      'target_module' => 'SOR_aud_evento',
      'target_record_key' => 'sor_aud_evento_id_c',
    ),
    'fechahora' => 
    array (
      'type' => 'datetimecombo',
      'vname' => 'LBL_FECHAHORA',
      'width' => '10%',
      'default' => true,
    ),
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'estado_posterior' => 
    array (
      'type' => 'relate',
      'studio' => 'visible',
      'vname' => 'LBL_ESTADO_POSTERIOR',
      'id' => 'SOR_ESTADO_PGMSORTEO_ID1_C',
      'link' => true,
      'width' => '10%',
      'default' => true,
      'widget_class' => 'SubPanelDetailViewLink',
      'target_module' => 'SOR_estado_pgmsorteo',
      'target_record_key' => 'sor_estado_pgmsorteo_id1_c',
    ),
    'operador' => 
    array (
      'type' => 'relate',
      'studio' => 'visible',
      'vname' => 'LBL_OPERADOR',
      'id' => 'USER_ID_C',
      'link' => true,
      'width' => '10%',
      'default' => true,
      'widget_class' => 'SubPanelDetailViewLink',
      'target_module' => 'Users',
      'target_record_key' => 'user_id_c',
    ),
  ),
);