<?php
$module_name = 'SOR_aud_consolidacion_det';
$listViewDefs [$module_name] = 
array (
  'ETAPA' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ETAPA',
    'width' => '10%',
    'default' => true,
  ),
  'ID_AUD_EVENTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_ID_AUD_EVENTO',
    'id' => 'SOR_AUD_EVENTO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'FECHAHORA' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_FECHAHORA',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'ESTADO_POSTERIOR' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_ESTADO_POSTERIOR',
    'id' => 'SOR_ESTADO_PGMSORTEO_ID1_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'OPERADOR' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_OPERADOR',
    'id' => 'USER_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
);
?>
