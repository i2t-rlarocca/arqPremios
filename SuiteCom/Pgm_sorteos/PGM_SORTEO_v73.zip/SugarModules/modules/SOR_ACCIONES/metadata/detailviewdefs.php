<?php
$module_name = 'SOR_ACCIONES';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL4' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'fecha',
            'label' => 'LBL_FECHA',
          ),
          1 => 
          array (
            'name' => 'tipo_accion',
            'studio' => 'visible',
            'label' => 'LBL_TIPO_ACCION',
          ),
        ),
        1 => 
        array (
          0 => 'description',
        ),
      ),
      'lbl_editview_panel4' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'producto',
            'studio' => 'visible',
            'label' => 'LBL_PRODUCTO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'loteria',
            'studio' => 'visible',
            'label' => 'LBL_LOTERIA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'hora_sorteo',
            'label' => 'LBL_HORA_SORTEO',
          ),
          1 => 
          array (
            'name' => 'minuto_sorteo',
            'label' => 'LBL_MINUTO_SORTEO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'producto_vinculado',
            'studio' => 'visible',
            'label' => 'LBL_PRODUCTO_VINCULADO',
          ),
        ),
      ),
    ),
  ),
);
?>
