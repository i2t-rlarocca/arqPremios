<?php
$module_name = 'SOR_ACCIONES';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'mes' => 
      array (
        'type' => 'int',
        'label' => 'LBL_MES',
        'width' => '10%',
        'default' => true,
        'name' => 'mes',
      ),
      'anio' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ANIO',
        'width' => '10%',
        'default' => true,
        'name' => 'anio',
      ),
    ),
    'advanced_search' => 
    array (
      'fecha' => 
      array (
        'type' => 'date',
        'label' => 'LBL_FECHA',
        'width' => '10%',
        'default' => true,
        'name' => 'fecha',
      ),
      'tipo_accion' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_TIPO_ACCION',
        'width' => '10%',
        'name' => 'tipo_accion',
      ),
      'producto' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PRODUCTO',
        'id' => 'SOR_PRODUCTO_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'producto',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
