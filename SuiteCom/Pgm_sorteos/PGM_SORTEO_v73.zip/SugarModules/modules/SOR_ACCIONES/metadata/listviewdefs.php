<?php
$module_name = 'SOR_ACCIONES';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'DIA' => 
  array (
    'type' => 'int',
    'label' => 'LBL_DIA',
    'width' => '10%',
    'default' => true,
  ),
  'MES' => 
  array (
    'type' => 'int',
    'label' => 'LBL_MES',
    'width' => '10%',
    'default' => true,
  ),
  'ANIO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ANIO',
    'width' => '10%',
    'default' => true,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'TIPO_ACCION' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_TIPO_ACCION',
    'width' => '5%',
  ),
  'PRODUCTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO',
    'id' => 'SOR_PRODUCTO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'LOTERIA' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_LOTERIA',
    'id' => 'SOR_LOTERIAS_ID_C',
    'link' => true,
    'width' => '5%',
    'default' => true,
  ),
  'HORA_SORTEO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_HORA_SORTEO',
    'width' => '5%',
    'default' => true,
  ),
  'MINUTO_SORTEO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_MINUTO_SORTEO',
    'width' => '5%',
    'default' => true,
  ),
  'PRODUCTO_VINCULADO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO_VINCULADO',
    'id' => 'SOR_PRODUCTO_ID1_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
);
?>
