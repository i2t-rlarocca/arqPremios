<?php
$module_name = 'SOR_aud_consolidacion_dif';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'idpgmsorteo' => 
      array (
        'type' => 'int',
        'label' => 'LBL_IDPGMSORTEO',
        'width' => '10%',
        'default' => true,
        'name' => 'idpgmsorteo',
      ),
      'id_permiso' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ID_PERMISO',
        'width' => '10%',
        'default' => true,
        'name' => 'id_permiso',
      ),
      'punto_venta_numero' => 
      array (
        'type' => 'int',
        'label' => 'LBL_PUNTO_VENTA_NUMERO',
        'width' => '10%',
        'default' => true,
        'name' => 'punto_venta_numero',
      ),
      'numero_agente' => 
      array (
        'type' => 'int',
        'label' => 'LBL_NUMERO_AGENTE',
        'width' => '10%',
        'default' => true,
        'name' => 'numero_agente',
      ),
      'concepto' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_CONCEPTO',
        'id' => 'CAS02_CC_CONCEPTOS_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'concepto',
      ),
    ),
    'advanced_search' => 
    array (
      'idpgmsorteo' => 
      array (
        'type' => 'int',
        'label' => 'LBL_IDPGMSORTEO',
        'width' => '10%',
        'default' => true,
        'name' => 'idpgmsorteo',
      ),
      'id_permiso' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ID_PERMISO',
        'width' => '10%',
        'default' => true,
        'name' => 'id_permiso',
      ),
      'numero_agente' => 
      array (
        'type' => 'int',
        'label' => 'LBL_NUMERO_AGENTE',
        'width' => '10%',
        'default' => true,
        'name' => 'numero_agente',
      ),
      'punto_venta_numero' => 
      array (
        'type' => 'int',
        'label' => 'LBL_PUNTO_VENTA_NUMERO',
        'width' => '10%',
        'default' => true,
        'name' => 'punto_venta_numero',
      ),
      'concepto' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_CONCEPTO',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'CAS02_CC_CONCEPTOS_ID_C',
        'name' => 'concepto',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
