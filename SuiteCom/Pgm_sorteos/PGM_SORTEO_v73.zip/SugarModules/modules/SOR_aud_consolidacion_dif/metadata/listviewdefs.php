<?php
$module_name = 'SOR_aud_consolidacion_dif';
$listViewDefs [$module_name] = 
array (
  'CONCEPTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_CONCEPTO',
    'id' => 'CAS02_CC_CONCEPTOS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'NUMERO_AGENTE' => 
  array (
    'type' => 'int',
    'label' => 'LBL_NUMERO_AGENTE',
    'width' => '10%',
    'default' => true,
  ),
  'PUNTO_VENTA_NUMERO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_PUNTO_VENTA_NUMERO',
    'width' => '10%',
    'default' => true,
  ),
  'ID_PERMISO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ID_PERMISO',
    'width' => '10%',
    'default' => true,
  ),
  'VALOR_AFE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_VALOR_AFE',
    'width' => '10%',
    'default' => true,
  ),
  'VALOR_APU' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_VALOR_APU',
    'width' => '10%',
    'default' => true,
  ),
  'VALOR_PRE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_VALOR_PRE',
    'width' => '10%',
    'default' => true,
  ),
  'IDPGMSORTEO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_IDPGMSORTEO',
    'width' => '10%',
    'default' => false,
  ),
);
?>
