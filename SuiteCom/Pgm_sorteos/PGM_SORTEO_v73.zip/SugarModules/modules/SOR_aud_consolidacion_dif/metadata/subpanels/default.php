<?php
$module_name='SOR_aud_consolidacion_dif';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SOR_aud_consolidacion_dif',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'concepto' => 
    array (
      'type' => 'relate',
      'studio' => 'visible',
      'vname' => 'LBL_CONCEPTO',
      'id' => 'CAS02_CC_CONCEPTOS_ID_C',
      'link' => true,
      'width' => '10%',
      'default' => true,
      'widget_class' => 'SubPanelDetailViewLink',
      'target_module' => 'cas02_CC_Conceptos',
      'target_record_key' => 'cas02_cc_conceptos_id_c',
    ),
    'numero_agente' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_NUMERO_AGENTE',
      'width' => '10%',
      'default' => true,
    ),
    'punto_venta_numero' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_PUNTO_VENTA_NUMERO',
      'width' => '10%',
      'default' => true,
    ),
    'valor_apu' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_VALOR_APU',
      'width' => '10%',
      'default' => true,
    ),
    'valor_afe' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_VALOR_AFE',
      'width' => '10%',
      'default' => true,
    ),
    'valor_pre' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_VALOR_PRE',
      'width' => '10%',
      'default' => true,
    ),
  ),
);