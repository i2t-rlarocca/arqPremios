<?php
$module_name = 'SOR_aud_consolidacion_dif';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'sor_aud_consolidacion_sor_aud_consolidacion_dif_name',
          ),
          1 => 
          array (
            'name' => 'idpgmsorteo',
            'label' => 'LBL_IDPGMSORTEO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'numero_agente',
            'label' => 'LBL_NUMERO_AGENTE',
          ),
          1 => 
          array (
            'name' => 'punto_venta_numero',
            'label' => 'LBL_PUNTO_VENTA_NUMERO',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'concepto',
            'studio' => 'visible',
            'label' => 'LBL_CONCEPTO',
          ),
          1 => 
          array (
            'name' => 'id_permiso',
            'label' => 'LBL_ID_PERMISO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'valor_afe',
            'label' => 'LBL_VALOR_AFE',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'valor_apu',
            'label' => 'LBL_VALOR_APU',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'valor_pre',
            'label' => 'LBL_VALOR_PRE',
          ),
        ),
      ),
    ),
  ),
);
?>
