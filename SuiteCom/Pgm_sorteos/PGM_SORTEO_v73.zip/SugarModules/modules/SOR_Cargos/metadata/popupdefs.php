<?php
$popupMeta = array (
    'moduleMain' => 'SOR_Cargos',
    'varName' => 'SOR_Cargos',
    'orderBy' => 'sor_cargos.name',
    'whereClauses' => array (
  'autoridad' => 'sor_cargos.autoridad',
  'car_cargo' => 'sor_cargos.car_cargo',
),
    'searchInputs' => array (
  5 => 'autoridad',
  6 => 'car_cargo',
),
    'searchdefs' => array (
  'autoridad' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_AUTORIDAD',
    'id' => 'SOR_AUTORIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'autoridad',
  ),
  'car_cargo' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CAR_CARGO',
    'width' => '10%',
    'name' => 'car_cargo',
  ),
),
    'listviewdefs' => array (
  'AUTORIDAD' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_AUTORIDAD',
    'id' => 'SOR_AUTORIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'autoridad',
  ),
  'CAR_CARGO' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_CAR_CARGO',
    'width' => '10%',
    'name' => 'car_cargo',
  ),
  'CAR_ORDEN' => 
  array (
    'type' => 'int',
    'label' => 'LBL_CAR_ORDEN',
    'width' => '10%',
    'default' => true,
    'name' => 'car_orden',
  ),
),
);
