<?php
$dashletData['SOR_CargosDashlet']['searchFields'] = array (
  'producto' => 
  array (
    'default' => '',
  ),
  'autoridad' => 
  array (
    'default' => '',
  ),
  'car_cargo' => 
  array (
    'default' => '',
  ),
);
$dashletData['SOR_CargosDashlet']['columns'] = array (
  'autoridad' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_AUTORIDAD',
    'id' => 'SOR_AUTORIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'autoridad',
  ),
  'car_cargo' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_CAR_CARGO',
    'width' => '10%',
    'name' => 'car_cargo',
  ),
  'car_orden' => 
  array (
    'type' => 'int',
    'label' => 'LBL_CAR_ORDEN',
    'width' => '10%',
    'default' => true,
    'name' => 'car_orden',
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
    'name' => 'date_entered',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
);
