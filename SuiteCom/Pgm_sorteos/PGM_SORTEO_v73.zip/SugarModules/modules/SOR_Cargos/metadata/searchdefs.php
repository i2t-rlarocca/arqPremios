<?php
$module_name = 'SOR_Cargos';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'type' => 'name',
        'link' => true,
        'label' => 'LBL_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'name',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'autoridad' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_AUTORIDAD',
        'id' => 'SOR_AUTORIDADES_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'autoridad',
      ),
      'car_cargo' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_CAR_CARGO',
        'width' => '10%',
        'name' => 'car_cargo',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
