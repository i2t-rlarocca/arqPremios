<?php
$module_name = 'SOR_Cargos';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '20%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'AUTORIDAD' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_AUTORIDAD',
    'id' => 'SOR_AUTORIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'CAR_CARGO' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_CAR_CARGO',
    'width' => '10%',
  ),
  'CAR_ORDEN' => 
  array (
    'type' => 'int',
    'label' => 'LBL_CAR_ORDEN',
    'width' => '10%',
    'default' => true,
  ),
);
?>
