<?php
$module_name = 'SOR_Cargos_Por_Sorteo';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'CAR_FECHA' => 
  array (
    'type' => 'date',
    'label' => 'LBL_CAR_FECHA',
    'width' => '10%',
    'default' => true,
  ),
  'PRODUCTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO',
    'id' => 'SOR_PRODUCTO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'CAR_CARGOLST' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_CAR_CARGOLST',
    'width' => '10%',
  ),
  'CAR_ORDEN' => 
  array (
    'type' => 'int',
    'default' => true,
    'label' => 'LBL_CAR_ORDEN',
    'width' => '10%',
  ),
  'AUTORIDAD' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_AUTORIDAD',
    'id' => 'SOR_AUTORIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'link' => true,
    'type' => 'relate',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'id' => 'ASSIGNED_USER_ID',
    'width' => '10%',
    'default' => true,
  ),
);
?>
