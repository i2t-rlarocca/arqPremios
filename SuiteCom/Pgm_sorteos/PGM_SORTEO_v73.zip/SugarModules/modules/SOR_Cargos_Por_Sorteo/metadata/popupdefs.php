<?php
$popupMeta = array (
    'moduleMain' => 'SOR_Cargos',
    'varName' => 'SOR_Cargos',
    'orderBy' => 'sor_cargos.name',
    'whereClauses' => array (
  'producto' => 'sor_cargos.producto',
  'autoridad' => 'sor_cargos.autoridad',
  'car_fecha' => 'sor_cargos_por_sorteo.car_fecha',
  'car_cargolst' => 'sor_cargos_por_sorteo.car_cargolst',
),
    'searchInputs' => array (
  4 => 'producto',
  5 => 'autoridad',
  7 => 'car_fecha',
  8 => 'car_cargolst',
),
    'searchdefs' => array (
  'car_fecha' => 
  array (
    'type' => 'date',
    'label' => 'LBL_CAR_FECHA',
    'width' => '10%',
    'name' => 'car_fecha',
  ),
  'producto' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO',
    'id' => 'SOR_PRODUCTO_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'producto',
  ),
  'car_cargolst' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CAR_CARGOLST',
    'width' => '10%',
    'name' => 'car_cargolst',
  ),
  'autoridad' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_AUTORIDAD',
    'id' => 'SOR_AUTORIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'autoridad',
  ),
),
    'listviewdefs' => array (
  'CAR_FECHA' => 
  array (
    'type' => 'date',
    'label' => 'LBL_CAR_FECHA',
    'width' => '10%',
    'default' => true,
    'name' => 'car_fecha',
  ),
  'PRODUCTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO',
    'id' => 'SOR_PRODUCTO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'producto',
  ),
  'CAR_CARGOLST' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_CAR_CARGOLST',
    'width' => '10%',
    'name' => 'car_cargolst',
  ),
  'CAR_ORDEN' => 
  array (
    'type' => 'int',
    'default' => true,
    'label' => 'LBL_CAR_ORDEN',
    'width' => '10%',
  ),
  'AUTORIDAD' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_AUTORIDAD',
    'id' => 'SOR_AUTORIDADES_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'autoridad',
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'link' => true,
    'type' => 'relate',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'id' => 'ASSIGNED_USER_ID',
    'width' => '10%',
    'default' => true,
    'name' => 'assigned_user_name',
  ),
),
);
