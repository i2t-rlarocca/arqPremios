<?php
$module_name = 'SOR_Cargos_Por_Sorteo';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'car_fecha' => 
      array (
        'type' => 'date',
        'label' => 'LBL_CAR_FECHA',
        'width' => '10%',
        'default' => true,
        'name' => 'car_fecha',
      ),
    ),
    'advanced_search' => 
    array (
      'car_fecha' => 
      array (
        'type' => 'date',
        'label' => 'LBL_CAR_FECHA',
        'width' => '10%',
        'default' => true,
        'name' => 'car_fecha',
      ),
      'producto' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PRODUCTO',
        'id' => 'SOR_PRODUCTO_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'producto',
      ),
      'autoridad' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_AUTORIDAD',
        'id' => 'SOR_AUTORIDADES_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'autoridad',
      ),
      'car_cargolst' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_CAR_CARGOLST',
        'width' => '10%',
        'name' => 'car_cargolst',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
