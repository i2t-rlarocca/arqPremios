<?php
$module_name = 'SOR_pgmsorteo_pozos';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'PGMSORTEO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PGMSORTEO',
    'id' => 'SOR_PGMSORTEO_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'IMPORTE_POZO' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_IMPORTE_POZO',
    'width' => '10%',
    'default' => true,
  ),
  'APUESTAS' => 
  array (
    'type' => 'int',
    'label' => 'LBL_APUESTAS',
    'width' => '10%',
    'default' => true,
  ),
  'IMPORTE_POZO_REC' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_IMPORTE_POZO_REC',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
);
?>
