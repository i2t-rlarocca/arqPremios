<?php
$module_name = 'SOR_pgmsorteo_loteria';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'pgmsorteo',
            'studio' => 'visible',
            'label' => 'LBL_PGMSORTEO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'loteria',
            'studio' => 'visible',
            'label' => 'LBL_LOTERIA',
          ),
          1 => 
          array (
            'name' => 'letra_loteria',
            'label' => 'LBL_LETRA_LOTERIA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'fechaloteria',
            'label' => 'LBL_FECHALOTERIA',
          ),
          1 => 
          array (
            'name' => 'horaloteria',
            'label' => 'LBL_HORALOTERIA',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'nrosorteoloteria',
            'label' => 'LBL_NROSORTEOLOTERIA',
          ),
          1 => 
          array (
            'name' => 'estado',
            'studio' => 'visible',
            'label' => 'LBL_ESTADO',
          ),
        ),
      ),
    ),
  ),
);
?>
