<?php
$dashletData['SOR_AutoridadesDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'aut_codigo' => 
  array (
    'default' => '',
  ),
);
$dashletData['SOR_AutoridadesDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'aut_codigo' => 
  array (
    'type' => 'int',
    'label' => 'LBL_AUT_CODIGO',
    'width' => '10%',
    'default' => true,
  ),
);
