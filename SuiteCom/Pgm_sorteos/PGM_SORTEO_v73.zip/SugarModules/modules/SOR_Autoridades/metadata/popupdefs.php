<?php
$popupMeta = array (
    'moduleMain' => 'SOR_Autoridades',
    'varName' => 'SOR_Autoridades',
    'orderBy' => 'sor_autoridades.name',
    'whereClauses' => array (
  'name' => 'sor_autoridades.name',
  'aut_codigo' => 'sor_autoridades.aut_codigo',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'aut_codigo',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'aut_codigo' => 
  array (
    'type' => 'int',
    'label' => 'LBL_AUT_CODIGO',
    'width' => '10%',
    'name' => 'aut_codigo',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'AUT_CODIGO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_AUT_CODIGO',
    'width' => '10%',
    'default' => true,
  ),
),
);
