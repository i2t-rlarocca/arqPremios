<?php
$module_name = 'SOR_pgmsorteo_premios';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'pgmsorteo',
            'studio' => 'visible',
            'label' => 'LBL_PGMSORTEO',
          ),
          1 => 
          array (
            'name' => 'premio',
            'studio' => 'visible',
            'label' => 'LBL_PREMIO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'importe_pozo',
            'label' => 'LBL_IMPORTE_POZO',
          ),
          1 => 
          array (
            'name' => 'cant_aciertos',
            'label' => 'LBL_CANT_ACIERTOS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'cant_ganadores',
            'label' => 'LBL_CANT_GANADORES',
          ),
          1 => 
          array (
            'name' => 'importe_premio',
            'label' => 'LBL_IMPORTE_PREMIO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'vacante',
            'label' => 'LBL_VACANTE',
          ),
          1 => 
          array (
            'name' => 'secuencia',
            'label' => 'LBL_SECUENCIA',
          ),
        ),
      ),
    ),
  ),
);
?>
