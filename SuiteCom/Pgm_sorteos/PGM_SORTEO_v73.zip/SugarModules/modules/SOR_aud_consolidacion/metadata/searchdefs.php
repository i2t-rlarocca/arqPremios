<?php
$module_name = 'SOR_aud_consolidacion';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
	 'id_pro_consolidacion' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ID_PRO_CONSOLIDACION',
        'width' => '10%',
        'default' => true,
        'name' => 'id_pro_consolidacion',
      ),
      'producto' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PRODUCTO',
        'id' => 'SOR_PRODUCTO_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'producto',
      ),
      'nrosorteo' => 
      array (
        'type' => 'int',
        'label' => 'LBL_NROSORTEO',
        'width' => '10%',
        'default' => true,
        'name' => 'nrosorteo',
      ),
      'operador' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_OPERADOR',
        'id' => 'USER_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'operador',
      ),
    ),
    'advanced_search' => 
	  array (
	  'id_pro_consolidacion' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ID_PRO_CONSOLIDACION',
        'width' => '10%',
        'default' => true,
        'name' => 'id_pro_consolidacion',
      ),
      'producto' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PRODUCTO',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'SOR_PRODUCTO_ID_C',
        'name' => 'producto',
      ),
      'nrosorteo' => 
      array (
        'type' => 'int',
        'label' => 'LBL_NROSORTEO',
        'width' => '10%',
        'default' => true,
        'name' => 'nrosorteo',
      ),
      'operador' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_OPERADOR',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'USER_ID_C',
        'name' => 'operador',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
