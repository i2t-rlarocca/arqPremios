<?php
$module_name = 'SOR_aud_consolidacion';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'PRODUCTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO',
    'id' => 'SOR_PRODUCTO_ID_C',
    'link' => false,
    'width' => '10%',
    'default' => true,
  ),
  'NROSORTEO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_NROSORTEO',
    'width' => '10%',
    'default' => true,
  ),
  'OPERADOR' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_OPERADOR',
    'id' => 'USER_ID_C',
    'link' => false,
    'width' => '10%',
    'default' => true,
  ),
);
?>
