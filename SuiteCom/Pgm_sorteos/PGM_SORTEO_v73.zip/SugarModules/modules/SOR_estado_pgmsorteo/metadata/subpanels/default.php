<?php
$module_name='SOR_estado_pgmsorteo';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SOR_estado_pgmsorteo',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'idestado' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_IDESTADO',
      'width' => '10%',
      'default' => true,
    ),
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
  ),
);