<?php
$module_name = 'SOR_ANUNCIOS';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'ANIO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ANIO',
    'width' => '5%',
    'default' => true,
  ),
  'MES' => 
  array (
    'type' => 'int',
    'label' => 'LBL_MES',
    'width' => '5%',
    'default' => true,
  ),
  'CONFIRMADO' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_CONFIRMADO',
    'width' => '10%',
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '70%',
    'default' => true,
  ),
  'ID_VERSION' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ID_VERSION',
    'width' => '10%',
    'default' => true,
  ),
  'FECHA_HORA_CONFIRMACION' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_FECHA_HORA_CONFIRMACION',
    'width' => '10%',
    'default' => true,
  ),
);
?>
