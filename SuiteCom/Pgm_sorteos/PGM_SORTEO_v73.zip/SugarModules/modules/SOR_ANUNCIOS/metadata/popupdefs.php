<?php
$popupMeta = array (
    'moduleMain' => 'SOR_ANUNCIOS',
    'varName' => 'SOR_ANUNCIOS',
    'orderBy' => 'sor_anuncios.name',
    'whereClauses' => array (
  'anio' => 'sor_anuncios.anio',
  'mes' => 'sor_anuncios.mes',
  'description' => 'sor_anuncios.description',
),
    'searchInputs' => array (
  4 => 'anio',
  5 => 'mes',
  6 => 'description',
),
    'searchdefs' => array (
  'anio' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ANIO',
    'width' => '10%',
    'name' => 'anio',
  ),
  'mes' => 
  array (
    'type' => 'int',
    'label' => 'LBL_MES',
    'width' => '10%',
    'name' => 'mes',
  ),
  'description' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'name' => 'description',
  ),
),
    'listviewdefs' => array (
  'ANIO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ANIO',
    'width' => '10%',
    'default' => true,
  ),
  'MES' => 
  array (
    'type' => 'int',
    'label' => 'LBL_MES',
    'width' => '10%',
    'default' => true,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
),
);
