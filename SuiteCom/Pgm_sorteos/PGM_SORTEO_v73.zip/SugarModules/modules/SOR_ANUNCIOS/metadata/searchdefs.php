<?php
$module_name = 'SOR_ANUNCIOS';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'anio' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ANIO',
        'width' => '10%',
        'default' => true,
        'name' => 'anio',
      ),
      'mes' => 
      array (
        'type' => 'int',
        'label' => 'LBL_MES',
        'width' => '10%',
        'default' => true,
        'name' => 'mes',
      ),
    ),
    'advanced_search' => 
    array (
      'anio' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ANIO',
        'width' => '10%',
        'default' => true,
        'name' => 'anio',
      ),
      'mes' => 
      array (
        'type' => 'int',
        'label' => 'LBL_MES',
        'width' => '10%',
        'default' => true,
        'name' => 'mes',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
