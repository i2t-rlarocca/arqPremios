<?php
$module_name = 'SOR_ANUNCIOS';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'anio',
            'label' => 'LBL_ANIO',
          ),
          1 => 
          array (
            'name' => 'mes',
            'label' => 'LBL_MES',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'id_version',
            'label' => 'LBL_ID_VERSION',
          ),
          1 => 
          array (
            'name' => 'confirmado',
            'label' => 'LBL_CONFIRMADO',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'usuario_confirmacion',
            'label' => 'LBL_USUARIO_CONFIRMACION',
          ),
          1 => 
          array (
            'name' => 'fecha_hora_confirmacion',
            'label' => 'LBL_FECHA_HORA_CONFIRMACION',
          ),
        ),
        3 => 
        array (
          0 => 'description',
        ),
      ),
    ),
  ),
);
?>
