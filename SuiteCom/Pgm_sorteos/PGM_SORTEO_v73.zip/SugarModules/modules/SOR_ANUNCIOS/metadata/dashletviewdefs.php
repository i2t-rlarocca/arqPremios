<?php
$dashletData['SOR_ANUNCIOSDashlet']['searchFields'] = array (
  'anio' => 
  array (
    'default' => '',
  ),
  'mes' => 
  array (
    'default' => '',
  ),
);
$dashletData['SOR_ANUNCIOSDashlet']['columns'] = array (
  'anio' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ANIO',
    'width' => '10%',
    'default' => true,
  ),
  'mes' => 
  array (
    'type' => 'int',
    'label' => 'LBL_MES',
    'width' => '10%',
    'default' => true,
  ),
  'description' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
);
