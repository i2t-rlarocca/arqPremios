<?php
// require_once('verifica_funcion.php'); 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

require_once('include/MVC/View/views/view.detail.php');

class SOR_alea_hst_sorteoViewDetail extends ViewDetail {


 	function SOR_alea_hst_sorteoViewDetail(){
 		parent::ViewDetail();
 	}
	
  public function display() {
		if(file_exists("cache/modules/SOR_alea_hst_sorteo/DetailView.tpl")) {
			unlink("cache/modules/SOR_alea_hst_sorteo/DetailView.tpl");  
		}	  
		global $current_user;
 
		$idusuario=$current_user->id;
		// determina se puede contabilizar
		$id = $_REQUEST['record'];
		// $GLOBALS['log']->debug("SOR_alea_hst_sorteo id : $id");
		$bean = BeanFactory::getBean('SOR_alea_hst_sorteo', $id);	

		/*
		$app_list_strings['cab_estado_cnt_list']['P'] = 'Pendiente de Contabilizar';
		$app_list_strings['cab_estado_cnt_list']['C'] = 'Contabilizado';
		$app_list_strings['cab_estado_cnt_list']['V'] = 'Contabilizado Provisorio';
		*/		

		$estado = 'P'; // por defecto, pendiente!
		$estado = $bean->hs_estado;
		// $GLOBALS['log']->debug("validacion-SOR_alea_hst_sorteo - id: $bean->id, $bean->hs_estado");
		
		// botones: 0-Editar, 1-Duplicar, 2-Borrar, 3-Buscar duplicados, 4-Procesar, 5-Imprimir
		unset($this->dv->defs['templateMeta']['form']['buttons'][1]); // NO SE PUEDE DUPLICAR
		unset($this->dv->defs['templateMeta']['form']['buttons'][2]); // NO SE PUEDE BORRAR
		unset($this->dv->defs['templateMeta']['form']['buttons'][3]); // NO SE PUEDE BUSCAR DUPLICADOS
		
		if ($estado=='C') { 
			unset($this->dv->defs['templateMeta']['form']['buttons'][0]); // Si ya est� procesado. NO SE PUEDE EDITAR
			unset($this->dv->defs['templateMeta']['form']['buttons'][4]); // Si ya est� procesado. NO SE REPROCESAR
		}
		
		if ($estado=='P') {
			unset($this->dv->defs['templateMeta']['form']['buttons'][5]); // No se puede IMPRIMIR (la impresion lo pasa a V!
		}

		parent::display(); 
  }	
	
}

?>
