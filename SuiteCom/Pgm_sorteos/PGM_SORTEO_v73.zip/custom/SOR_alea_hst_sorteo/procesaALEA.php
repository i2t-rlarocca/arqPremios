<?php
	require_once('include/MVC/SugarApplication.php');
	require_once('data/BeanFactory.php');  

	include('parametros_app.php');

	$msg = "";

	$id		= $_REQUEST['record'];
	$offset	= $_REQUEST['offset'];
//	$stamp	= $_REQUEST['stamp'];
	$url	= "index.php?module=SOR_alea_hst_sorteo&rnd=".time()."&action=DetailView&record=".$id;

	// $GLOBALS['log']->debug("validacion-SOR_alea_hst_sorteo - url: $url");
	
	$bean = BeanFactory::getBean('SOR_alea_hst_sorteo', $id);	

	// $GLOBALS['log']->debug("validacion-SOR_alea_hst_sorteo - id: $bean->id, $bean->sor_pgmsorteo_id_c");
	
	$id_pgmsorteo = $bean->sor_pgmsorteo_id_c;

	$GLOBALS['log']->fatal("validacion-SOR_alea_hst_sorteo -  idenprc: $id_pgmsorteo servidor: $servidor_crm - usuario: $usuario_crm - db: $bd_crm");
	
	$conexion2 = mysqli_connect($servidor_crm, $usuario_crm, $password_crm, $bd_crm) or die("Problemas con la conexion");
	$q2 = "SELECT COUNT(*) AS cnt
				FROM sor_alea_ddjj_provincias_sorteos ddjj
				WHERE ddjj.sor_pgmsorteo_id_c = @id_pgmsorteo AND ddjj.ddjj_comisiones = 0;";
		
	$GLOBALS['log']->debug("validacion-SOR_alea_hst_sorteo - SQL: $q2");
		
	$res2=mysqli_query($conexion2, $q2);
	$row2 = mysqli_fetch_array($res2);

	$cnt = $row2['cnt'];
		
	mysqli_close($conexion2);
	if ($nt > 0) {
		$msg = "Existen comisiones sin informar...";
	}

	// Actualizo 	

	$UserId=0;
	$UserId=$GLOBALS['current_user']->id;
	
	$mysqli = NEW mysqli($servidor_crm, $usuario_crm, $password_crm, $bd_crm);
	// verificar conexi�n 
	if (mysqli_connect_errno()) {
		$msg = "Falla en la conexion: " . mysqli_connect_error();
	}

	if ($msg == "") {
		$stmt = $mysqli->stmt_init();
//		$stmt->prepare("CALL sor_contabiliza_minutas('$id', '$UserId', @RCode, @RTxt, @RId, @RSQLErrNo, @RSQLErrtxt)");
		$GLOBALS['log']->fatal("validacion-SOR_alea_hst_sorteo - ejecuto sor_contabiliza_minutas - query:" . print_r($stmt, true));
		$stmt->execute();
			
		$resultado = $mysqli->query('SELECT @RCode as Rcode, @RTxt as RTxt, @RId as RId, @RSQLErrNo as RSQLErrNo, @RSQLErrtxt as RSQLErrtxt');
		$fila = $resultado->fetch_assoc();
		$RCode = $fila['RCode'];
		$RTxt = $fila['RTxt'];

		$GLOBALS['log']->fatal("validacion-SOR_alea_hst_sorteo - ejecuto sor_contabiliza_minutas - RCode: $RCode - RTxt: $RTxt - query:" . print_r($stmt, true));
		
		mysqli_free_result($resultado);
		mysqli_stmt_close($stmt);		

		if($Rcode != 0){
			// mysqli_close($conexion);
			$msg = "Ocurri� un problema al actualizar: $RTxt" ;
			//$_SESSION['MyBean']=$bean;
			//~ $GLOBALS['log']->fatal(Date("Y-m-d H:i:s") .__FILE__.":".__LINE__."bean aries_Edificios ----->>> ".print_r($bean,true), 0);
		}
	}
	
	$GLOBALS['log']->fatal("validacion-SOR_alea_hst_sorteo - fin - mensaje: $msg");
	if ($msg != "") {
		SugarApplication::appendErrorMessage($msg);
		$params = array(
				'module'=> 'cas02_cc_cntpoc_grp',
				'action'=>'DetailView', 
				'record' => $id,
				);
		//$_SESSION['MyBean']=$bean;
		SugarApplication::redirect('index.php?' . http_build_query($params));
		return false;		
	} else {
		echo ("<h2> Procesando... </h2>");
		sleep(5);
		header("Refresh:1; $url");
		exit;
	}

	
?>


