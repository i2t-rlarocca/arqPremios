
function RecorrerForm()
{
	var sAux="";
	var frm = document.getElementById("EditView");
	
	$('#grp_fecprc_trigger').hide();
	
	for (i=0;i<frm.elements.length;i++)
	{
		if (frm.elements[i].type!="hidden") {
			if (frm.elements[i].id!="btn_view_change_log"){
				frm.elements[i].disabled=true;
			}
			
		}
	}
	$('#grp_feccon').removeAttr('disabled');
	$('#grp_feccon_trigger').removeAttr('disabled');
	$('#SAVE_HEADER').removeAttr('disabled');
	$('#CANCEL_HEADER').removeAttr('disabled');
	$('#CANCEL_FOOTER').removeAttr('disabled');
	$('#SAVE_FOOTER').removeAttr('disabled');
	

}
$(document).ready( function () {
	RecorrerForm();	
			
});
 
