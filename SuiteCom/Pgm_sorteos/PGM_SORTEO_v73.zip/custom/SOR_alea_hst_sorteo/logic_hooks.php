<?php
$hook_version = 1; 
$hook_array = Array(); 
$hook_array['after_ui_frame'] = Array(); 
$hook_array['after_ui_frame'][] = Array(1, 'Customizar', 'custom/modules/SOR_alea_hst_sorteo/logichookSOR_alea_hst_sorteo.php', 'logichookSOR_alea_hst_sorteo', 'customizar'); 

?>
