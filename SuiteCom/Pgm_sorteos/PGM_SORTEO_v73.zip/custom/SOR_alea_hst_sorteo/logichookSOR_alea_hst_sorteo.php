<?php
class logichookSOR_alea_hst_sorteo{

function customizar() {
		if ($_REQUEST['action'] == 'EditView') {
			echo "<script src=custom/modules/SOR_alea_hst_sorteo/Desabilita_todo.js?var=".rand()."></script>";          
				
		}	
	}
}
?>
