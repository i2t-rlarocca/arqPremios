<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


require_once('include/MVC/View/views/view.edit.php');

class SOR_Cargos_Por_SorteoViewEdit extends ViewEdit {

    public function preDisplay() {   
          //this displays errors among other things 
        $this->errors[]=$_SESSION['myError']; 
        unset($_SESSION['myError']); 
        parent::preDisplay(); 
    } 

  public function display() { 
  
  // para mostrar errores personalizados
    if(isset($_SESSION['MyBean'])) { //an error must have occurred bean is in session 
        $sessionBean=$_SESSION['MyBean'];                 
        $fieldKeys=array_keys($_SESSION['MyBean']->field_defs); 
        foreach($fieldKeys as $key) {  //get each field the user typed and set them into the current bean 
            if($sessionBean->field_defs[$key]['type']=="date") { 
        //dates get formated into YYYY-MM-DD and on next submit they throw an error for me 
                $this->bean->{$key} =  
                date_format(date_create($_SESSION['MyBean']->{$key}),"d/m/Y"); 
            } else { 
                $this->bean->{$key} = $_SESSION['MyBean']->{$key}; 
            } 
        } 
        unset($_SESSION['MyBean']); 
    } 
    parent::display(); 
  }	
	
}

?>