<?php
class logichookCargosPorSorteo{
function controla ($bean, $event, $arguments)
{
	$resultado=$this->realiza_controles($bean,$mensaje);
	if(!($resultado)){
		$this->mostrar_msg($bean, $event, $arguments,$mensaje);
	}
	
}
function grab_dump($var)
		{
			ob_start();
			var_dump($var);
			return ob_get_clean();
		}
function realiza_controles($bean,&$msj)	{

	$GLOBALS['log']->fatal("[Guardar Cargo por Sorteo]  sor_cargos_id_c :$bean->sor_cargos_id_c ");
		$bCargo = BeanFactory::getBean("SOR_Cargos", $bean->sor_cargos_id_c);

//		$bean->sor_producto_id_c=$bCargo->sor_producto_id_c;
		$bean->sor_autoridades_id_c=$bCargo->sor_autoridades_id_c;
		$bean->car_cargolst=$bCargo->car_cargo;
		$bean->assigned_user_id=$bCargo->assigned_user_id;
		$GLOBALS['log']->fatal("[Guardar Cargo por Sorteo] autoridad: $bean->sor_autoridades_id_c - cargo: $bean->car_cargolst - assig_usr: $bean->assigned_user_id");
	   
//		$bProd = BeanFactory::getBean("SOR_PRODUCTO", $bean->sor_producto_id_c);
//		$GLOBALS['log']->fatal("[Guardar Cargo] toma producto - bProd: $bProd->prefijo - fin_operacion: $bProd->fin_operacion");
		
		if($bean->car_fecha < date("Y-m-d")){
			$GLOBALS['log']->fatal("Sorteo expirado");
			$msj="No se pueden actualizar sorteos en el pasado";
			return false;
		}

		$fecha = date( "d/m/Y", strtotime($bean->car_fecha) );
		$GLOBALS['log']->fatal("[Guardar Cargo por Sorteo]  fecha:$fecha");
		$nameCargo = $bCargo->name;
		$bean->name=$fecha."-".$nameCargo;
		

		
		$db = $GLOBALS['db'];
		
		$sql="SELECT COUNT(*) AS cantidad";
		$sql.=" FROM sor_cargos_por_sorteo a  ";
		$sql.=" WHERE a.deleted=0 AND a.id<>'$bean->id' AND a.sor_cargos_id_c='$bCargo->id' AND a.car_fecha='$bean->car_fecha' ";
		$results = $db->query($sql, true);
		$row = $db->fetchByAssoc($results);
		if ($row['cantidad'] >0)
			{
				$msj="La autoridad ya se encuentra registrada para este sorteo";
				return false;
			}
		

		return true;
	}

	
	function mostrar_msg($bean, $event, $arguments,$mensaje)
	{	 
		 $_SESSION['myError']=$mensaje; 
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$action="&action=EditView"; //we need to have EditView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['return_module']; 
		 
		$offset=$_REQUEST['offset']; 
		if($offset=="") { 
		} else { 
			$offset="&offset=$offset"; 
		} 
		 
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="") { 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
			 
		if($recordId=="") { 
			$returnAction="&return_action=detailView"; 
		} else { 
			$recordId="&record=".$recordId; 
		} 
		 
		$url="index.php?module=".$module.$offset.$stamp.$action.$returnModule.$returnAction.$recordId; 
		header("Location: $url"); 
		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 
		exit;   //goto the location contained in header 
	}
}
?>