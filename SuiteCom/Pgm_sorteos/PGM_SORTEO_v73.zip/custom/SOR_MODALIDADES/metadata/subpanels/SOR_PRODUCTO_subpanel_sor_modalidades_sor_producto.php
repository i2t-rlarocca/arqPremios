<?php
// created: 2016-02-04 17:13:14
$subpanel_layout['list_fields'] = array (
  'name' => 
  array (
    'vname' => 'LBL_NAME',
    'widget_class' => 'SubPanelDetailViewLink',
    'width' => '45%',
    'default' => true,
  ),
  'inicio_operaciones' => 
  array (
    'type' => 'date',
    'vname' => 'LBL_INICIO_OPERACIONES',
    'width' => '10%',
    'default' => true,
  ),
  'fin_operaciones' => 
  array (
    'type' => 'date',
    'vname' => 'LBL_FIN_OPERACIONES',
    'width' => '10%',
    'default' => true,
  ),
  'valor_apuesta' => 
  array (
    'type' => 'decimal',
    'vname' => 'LBL_VALOR_APUESTA',
    'width' => '10%',
    'default' => true,
  ),
  'asegurado_minimo' => 
  array (
    'type' => 'decimal',
    'vname' => 'LBL_ASEGURADO_MINIMO',
    'width' => '10%',
    'default' => true,
  ),
);