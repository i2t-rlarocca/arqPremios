<?php
class logichookModalidad{
	
	function controla (&$bean, $event, $arguments){
		// $GLOBALS['log']->fatal("Sor_Modalidades - controla - inicio - event->".$event);
		
		$ajusta_estado = false;
		$resultado=$this->realiza_controles($bean,$ajusta_estado,$mensaje);

		// $GLOBALS['log']->fatal("Sor_Modalidades - controla - fin controles - ajusta_estado->".$ajusta_estado);

		if(!($resultado)){
			$this->mostrar_msg($bean, $event, $arguments,$mensaje);
		} else {
			// Si todo fue bien 
			// si (juego es q6 / br / pf) y cambio (valor apuesta o pozo asegurado)
			//       paso a provisorio la confirmación del mes en curso
			
			if ($ajusta_estado) {
				$this->ajusto_estado_sor_anuncios();
			}
			
		}
	}

	function grab_dump(&$var){
		ob_start();
		var_dump($var);
		return ob_get_clean();
	}

	function ajusto_estado_sor_anuncios()	{
		// Ajusto el estado del mes en curso
		$db = $GLOBALS['db'];
		
		$sql="UPDATE sor_anuncios SET confirmado = false, fecha_hora_confirmacion='1900/01/01' WHERE anio = YEAR(CURDATE()) AND mes = MONTH(CURDATE())";
		$GLOBALS['log']->fatal("Sor_Modalidades - el periodo actual ha sido pasado a provisorio ->".$sql);
		$db->query($sql, true);
		
	}
	function realiza_controles(&$bean,&$ajusta_estado,&$msj)	{
		$db = $GLOBALS['db'];
		$where="";
		//el proudcto es obligatorio
		if(trim($bean->producto)==""){
			$msj="Ingrese PRODUCTO";
			return false;
		}
		// controla fechas hasta y desde
		if ((trim($bean->fin_operaciones)!="")&&($bean->fin_operaciones<$bean->inicio_operaciones)){
			$msj="La fecha DESDE debe ser menor la fecha HASTA";
			return false;
		}
		// controlar que si esta activa la fecha hasta sea  mayor a la actual
		if ((trim($bean->activa)!="")&&(trim($bean->fin_operaciones)!="")){
			require_once "include/TimeDate.php";
			$curdate = TimeDate::getNow();
			$date = date("Y-m-d", strtotime($curdate));
			$parts = explode(" ", $curdate);
			$CurrenrDateTime = $date . " " . $parts[4];
			
			if($CurrenrDateTime >($bean->fin_operaciones)){
				$msj="La fecha HASTA es menor a la fecha actual y el estado es Activa";
				return false;
				
			}
		}
		//$prefijo=$this->obtener_prefijo($bean->sor_modalidades_sor_productosor_producto_ida);
		$prefijo=$this->obtener_prefijo($bean->producto);
		// controlar valores apuestas para brinco modalid 1,PF modaliad 1 y quini6 modalidad 1,3,7
		// controlar minimos asegurados para brinco y quini

		// $ae = ($ajusta_estado) ? "V" : "F"; 
		// $GLOBALS['log']->fatal("Sor_Modalidades - realiza_controles - ajusta_estado->" . $ae . " - prefijo->".$prefijo);
		
		switch ($prefijo){
			case "BR":
					// Dejo expresado si hay que pasar el pgm de sorteo a provisorio
					if ($bean->codigo_modalidad == 1 
						&& ($bean->valor_apuesta != $bean->fetched_row['valor_apuesta']
						     || $bean->asegurado_minimo != $bean->fetched_row['asegurado_minimo'])) {
								 
							$ajusta_estado = true;
							
						}
			
			case "PF":
					if (($bean->codigo_modalidad==1)&&((trim($bean->valor_apuesta)=="")||trim($bean->valor_apuesta==0))){
							$msj="La modalidad seleccionada requiere el ingreso de un VALOR APUESTA mayor a cero";
							return false;					
					}
					if (($bean->codigo_modalidad==1)&&(trim($bean->asegurado_minimo)=="" ||trim($bean->asegurado_minimo)==0)){
							$msj="La modalidad seleccionada requiere el ingreso de un POZO MINIMO ASEGURADO";
							return false;					
					}
					// Dejo expresado si hay que pasar el pgm de sorteo a provisorio
					if ($bean->codigo_modalidad == 1 
						&& ($bean->valor_apuesta != $bean->fetched_row['valor_apuesta']
						     || $bean->asegurado_minimo != $bean->fetched_row['asegurado_minimo'])) {
								 
							$ajusta_estado = true;
							
						}
					

				   break;
			case "Q6":
					
					if ((($bean->codigo_modalidad==1)||($bean->codigo_modalidad==3)||($bean->codigo_modalidad==7))
							&&(trim($bean->valor_apuesta)==""||$bean->valor_apuesta==0))
					{
							$msj="La modalidad seleccionada requiere el ingreso de un VALOR APUESTA mayor a cero";
							return false;					
					}
					if ((($bean->codigo_modalidad==1)||($bean->codigo_modalidad==3))
							&&(trim($bean->asegurado_minimo)=="" ||trim($bean->asegurado_minimo)==0))
					{
							$msj="La modalidad seleccionada requiere el ingreso de un POZO MINIMO ASEGURADO";
							return false;					
					
					}

					// Dejo expresado si hay que pasar el pgm de sorteo a provisorio
					if (($bean->codigo_modalidad == 1 || $bean->codigo_modalidad == 3 || $bean->codigo_modalidad == 7 )
						&& ($bean->valor_apuesta != $bean->fetched_row['valor_apuesta']
						     || $bean->asegurado_minimo != $bean->fetched_row['asegurado_minimo'])) {
								 
							$ajusta_estado = true;
							
						}

					break;
		}
		
		if ($this->controla_repetidos($bean)){
				$msj="Ya existe una Modalidad con los datos ingresado";
				return false;
		}

		//verifico existencia de relacion
		$sql = "";
		$sql.= "SELECT COALESCE(COUNT(*), 0) AS existe FROM sor_modalidades_sor_producto_c rel ";
		$sql.= "where rel.sor_modalidades_sor_productosor_modalidades_idb = '$bean->id' ";
		$sql.= "AND rel.deleted = 0;";
		$results = $db->query($sql, true);
		$row = $db->fetchByAssoc($results);

		if($row['existe'] == 0){
				//Todo ok agrego la relación
				$sq = "";
				$sq.= "INSERT INTO sor_modalidades_sor_producto_c ";
				$sq.= "values (UUID(),NOW(),FALSE, ";
				$sq.= "'$bean->sor_producto_id_c','$bean->id');";
		
				$db->query($sq, true);
		}
		return true;
	}

	function actualiza_periodo(&$bean, $event, $arguments){
		include("parametros_app.php");
		// Raspadita LAS VENGAS
		if ($bean->sor_producto_id_c == '26') {
			try {
				$mysqli2 = NEW mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm);

				$q = "call dis_habilitar_mod('".$bean->id."',@msgRet)";
				$GLOBALS['log']->fatal("Sor_Modalidades - After_save - actualiza_periodo - llama al stored ->$q<-");
				
				$contMod = 0;
				$res2 = mysqli_query($mysqli2, $q); 
				while ($row2 = $res2->fetch_assoc()){
					if(isset($row2['msgRet'])) {
						$arrMod[$contMod][0] = $row2['msgRet'];
					}
					if(isset($row2['msgret'])) {
						$arrMod[$contMod][0] = $row2['msgret'];
					}
					$GLOBALS['log']->fatal("Sor_PgmSorteo - After Save - Inserta bingo en Periodo -  cont: ->$contMod<-,  - row2[msgret] ->".$arrMod[$contMod][0],"<-");
					$contMod = $contMod + 1;
				}
				try {
					mysqli_free_result($res2);
				} catch (Exception $e) {}
			} catch (Exception $e) {
				$GLOBALS['log']->fatal("Sor_Modalidades - After_save - actualiza_periodo - Ejecucion del stored con ERROR. Mensaje: ".$e->getMessage());
				return false;
			}		
			$GLOBALS['log']->fatal("Sor_Modalidades - After_save - actualiza_periodo - Ejecucion OK del stored.");
		}
		return true;
	}
	
	function obtener_prefijo($idproducto){
		$prefijo="";
		$db = $GLOBALS['db'];
		$sql="SELECT prefijo FROM sor_producto WHERE name='$idproducto'";
		$results = $db->query($sql, true);
		// $GLOBALS['log']->fatal("Sor_Modalidades - actualiza_periodo - sql->" . $sql ); 
		$row = $db->fetchByAssoc($results);
		$prefijo=$row['prefijo'];
		// $GLOBALS['log']->fatal("Sor_Modalidades - actualiza_periodo - prefijo->" . $prefijo);
		return  $prefijo;
	}

	function controla_repetidos(&$bean){
		$db = $GLOBALS['db'];
		if (($bean->codigo_modalidad!= $bean->fetched_row['codigo_modalidad']) || ($bean->inicio_operaciones!= $bean->fetched_row['inicio_operaciones']) ){
			$sql="SELECT COUNT(*) AS cantidad,COALESCE(a.id,-1) AS idmodalidad ";
			$sql.=" FROM sor_modalidades  a  ";
			$sql.=" INNER JOIN sor_modalidades_sor_producto_c b ON a.id=b.sor_modalidades_sor_productosor_modalidades_idb  AND  b.deleted=0 ";
			$sql.=" INNER JOIN sor_producto c ON c.id=b.sor_modalidades_sor_productosor_producto_ida  AND  c.deleted=0 ";
			$sql.=" WHERE a.deleted=0 and a.codigo_modalidad=$bean->codigo_modalidad and c.id='$bean->sor_producto_id_c' and a.inicio_operaciones='$bean->inicio_operaciones'";

			$results = $db->query($sql, true);
			$row = $db->fetchByAssoc($results);
			if ($row['cantidad'] >0){
				return true;
			}
		}		
		return false;
	}
	
	function mostrar_msg(&$bean, $event, $arguments,$mensaje){	 
		 $_SESSION['myError']=$mensaje; 
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$action="&action=EditView"; //we need to have EditView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['return_module']; 
		 
		$offset=$_REQUEST['offset']; 
		if($offset=="") { 
		} else { 
			$offset="&offset=$offset"; 
		} 
		 
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="") { 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
			 
		if($recordId=="") { 
			$returnAction="&return_action=detailView"; 
		} else { 
			$recordId="&record=".$recordId; 
		} 
		 
		$url="index.php?module=".$module.$offset.$stamp.$action.$returnModule.$returnAction.$recordId; 
		header("Location: $url"); 
		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 
		exit;   //goto the location contained in header 
	}
}
?>