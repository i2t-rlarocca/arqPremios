<?php
include('parametros_app.php');
global $current_user;


$db = $GLOBALS['db'];//conexion a la base de datos de SUGAR	
$idoperacion=$_REQUEST['idoperacion'];
$offset = $_REQUEST['offset'];
$stamp = $_REQUEST['stamp'];

$url ="Refresh:5; url=http://$url_crm/index.php?module=SOR_ANUNCIOS&offset=$offset&stamp=$stamp&return_module=SOR_ANUNCIOS&action=DetailView&record=$idoperacion";

	//Valido si existe la operacion y el tipo de operacion.
	$sql = "";
	$sql= "SELECT confirmado,mes,anio,COALESCE(id_version,0) AS id_version,coalesce(id,0) id FROM sor_anuncios";
	$sql.= " WHERE id='$idoperacion'";
	$GLOBALS['log']->fatal("anuncios - select operacion ->$sql<-");
	$result=$db->query($sql);
	$cant_reg = 0;
	$tipo_new = '';
	// Es un while pero en realidad hay un unico registro o ninguno. Se deja el while para mantener la manera estandar de recorrer el $result
	while ($row = $db->fetchByAssoc($result)) {
		$cant_reg = $cant_reg + 1;
		$id=$row['id'];
		$confirmado= 0;
		$confirmado =$row['confirmado'];
		$mes =$row['mes'];
		$anio =$row['anio'];
		$id_version =$row['id_version'];
			} 
	
	if ($cant_reg == 0) {
		$msg="No existe anuncios para el periodo ingresado. Volviendo a anuncios. Aguarde unos instantes...";
		echo "<h1>".$msg."</h1>";
	}
	else {
		if ($confirmado > 0) {	
			$msg="Periodo ya confirmado. Volviendo a anuncios. Aguarde unos instantes...";
			echo "<h1>".$msg."</h1>";
		}
		else {
			// Si todo esta ok actualizo el tipo de operacion nuevo,aumento la version
			$id_version_nueva=$id_version+1;
			
			$sql = "";	
			$sql= "UPDATE sor_anuncios ";
			$sql.= "SET confirmado = 1,id_version=$id_version_nueva, fecha_hora_confirmacion=now(),usuario_confirmacion='".$current_user->name."'";
			$sql.= " WHERE id='$idoperacion'; ";

			$GLOBALS['log']->fatal("Confirmacion->".$sql);

			$db->query($sql);
			
			// RL 23/01/2018. EVITAR EL MENSAJE "PROBLEMA DE BASE DE DATOS" AL FINAL DEL PROCESO...
			$msj=$id_version_nueva." Confirma Anuncio.";

			// auditoria de cambia de estado
			$conexion=mysqli_connect($servidor_crm,$usuario_crm ,$password_crm,$bd_crm) or die("Problemas con la conexion");
            $q2 = " INSERT into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id',now(),'text','PROVISORIO','CONFIRMADO','Estado',$current_user->id); ";
			$GLOBALS['log']->fatal("INSERT into sor_anuncios_audit: auditoria de cambia de estado: ".$q2);
            $res2=mysqli_query($conexion,$q2);
			
			// auditoria de cambio de version
			$conexion=mysqli_connect($servidor_crm,$usuario_crm ,$password_crm,$bd_crm) or die("Problemas con la conexion");
            $q3 = " INSERT into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id',now(),'text','$id_version','$msj','Version',$current_user->id); ";
			$GLOBALS['log']->fatal("INSERT into sor_anuncios_audit: auditoria de cambio de version: ".$q3);
            $res3=mysqli_query($conexion,$q3);
			
			$GLOBALS['log']->fatal("Fin Confirmacion ANUNCIO Anio-mes: $anio-$mes - version: $id_version_nueva");
			/*
			// auditoria de cambia de estado
			$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id',now(),'text','PROVISORIO','CONFIRMADO','Estado',$current_user->id)";
			$db->query($sql, true);
			
			// auditoria de cambio de version
			$msj=$id_version_nueva." Confirma Anuncio.";
			$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id',now(),'text','$id_version','$msj','Version',$current_user->id)";
			$db->query($sql, true);
			*/
			// FIN RL 23/01/2018. EVITAR EL MENSAJE "PROBLEMA DE BASE DE DATOS" AL FINAL DEL PROCESO...
			
			$url ="Refresh:2; url=http://$url_crm/index.php?module=SOR_ANUNCIOS&offset=$offset&stamp=$stamp&return_module=SOR_ANUNCIOS&action=DetailView&record=$idoperacion";
			$msg="El periodo se est� actualizando...";
			echo "<h1>".$msg."</h1>";

		}
	}
header($url);
?>
<html>
    <head>
        <title></title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <link href="css/style.css" rel="stylesheet" type="text/css" /> 
		<link href="css/print.css" rel="stylesheet" type="text/css" /> 
		<link href="css/chart.css" rel="stylesheet" type="text/css" /> 
		<link href="css/wizard.css" rel="stylesheet" type="text/css" /> 
		<link href="css/yui.css" rel="stylesheet" type="text/css" /> 
    </head>

</html>
