
$(document).ready( function () {
	$('#anio').attr('readonly', 'readonly');
	$('#mes').attr('readonly', 'readonly');
	
			
});