<?php
require_once("include/SugarTinyMCE.php");
$tiny = new SugarTinyMCE();
$tiny->defaultConfig['cleanup_on_startup']=true;
$tinyHtml = $tiny->getInstance('description');

$module_name = 'SOR_ANUNCIOS';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'anio',
            'label' => 'LBL_ANIO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'mes',
            'label' => 'LBL_MES',
          ),
        ),
        2 => 
        array (
          0 => 
		  array(
		  'name'=>'description',
		  'customCode' => '<textarea id="description"  name="description">{$fields.description.value}</textarea>{literal}'. $tinyHtml .  '<script>focus_obj = document.getElementById("description");</script>{/literal}',
		  ),
        ),
      ),
    ),
  ),
);
?>
