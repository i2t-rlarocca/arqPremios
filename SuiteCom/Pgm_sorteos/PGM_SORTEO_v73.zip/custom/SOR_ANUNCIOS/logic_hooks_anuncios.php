<?php
  
     //require_once('replace_char.php');

     class logic_hooks_anuncios 
     { 
	 
		function acuerdos_list (&$bean, $event, $arguments)
           {
            // muestra una extracto del encabezado en listviewdef	

            $bean->description   = html_entity_decode($bean->description);
            
           }	
		   
		   function repetidos_list (&$bean, $event, $arguments)
           {
		   $db=$GLOBALS['db'];
		   global $current_user;
				$fecha=date("d/m/Y");
			
            if ($bean->id!= $bean->fetched_row['id'])
					{
				// es un ingreso
					$resultado=$this->realiza_controles($bean,$mensaje);
					if(!($resultado)){
						$this->mostrar_msg($bean, $event, $arguments,$mensaje);
					}
					// la version inicial es cero
					$bean->id_version=0;
				
				}else{
				// si cambio anio y mes, significaque el mes no esta confirmado porque si esta confirmado estos daytos no se pueden modificar
				
					
					if(($bean->anio!= $bean->fetched_row['anio']) ||($bean->mes!= $bean->fetched_row['mes']))
					{
						
						$resultado=$this->realiza_controles($bean,$mensaje);
						if(!($resultado)){
							$this->mostrar_msg($bean, $event, $arguments,$mensaje);
						}
						
					}
					// hubo cambios en la descripcion,inserta auditoria y vuelve a tras la confirmacion si es necesario
						if ($bean-> description!= $bean->fetched_row['description'])
						{
							$idversionNueva=$bean->id_version+1;	
							if ($bean->confirmado==1){// si esta confirmado vuelve atras el estado 
								$bean->confirmado=0;
								$bean->fecha_hora_confirmacion='1900/01/01';								
								// inserto auditoria de cambio de estado
								$msj=" PROVISORIO  Cambio descripcion DIA MODELO Fecha:".$fecha;
								$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$bean->id',now(),'text','CONFIRMADO','$msj','Estado','$current_user->id')	";
								$GLOBALS['log']->fatal("UPDATE:".$sql);
								$db->query($sql, true);
							}
						  // inserto auditoria de cambio de version
							$msj=$bean->id_version." Cambio descripcion DIA MODELO Fecha:".$fecha;
							$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$bean->id',now(),'text','$bean->id_version','$msj','Cambios','$current_user->id')	";
							$db->query($sql, true);
						}
				}
				
				$bean->name=$bean->anio.str_pad($bean->mes,2,'0', STR_PAD_LEFT);
            
           }	
		   
		   
		   
		   
function realiza_controles($bean,&$msj)	{
	
		$db = $GLOBALS['db'];
		//controla repetidos
		$mes=$bean->mes;
		$ani=$bean->anio;
		    
        $sql="select count(*) as cantidad from sor_anuncios where deleted=0 and  anio=".$ani." and mes=".$mes;
	
		$results = $db->query($sql, true);
		$row = $db->fetchByAssoc($results);
		if ($row['cantidad'] >0)
            {
				$msj="Ya existe un Anuncio para Mes:".$mes." y A&ntilde;o:".$ani;
				return false;
            }
			
	return true;
	}
	
	
	function mostrar_msg($bean, $event, $arguments,$mensaje)
	{	 
		 $_SESSION['myError']=$mensaje; 
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$action="&action=EditView"; //we need to have EditView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['return_module']; 
		 
		$offset=$_REQUEST['offset']; 
		if($offset=="") { 
		} else { 
			$offset="&offset=$offset"; 
		} 
		 
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="") { 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
			 
		if($recordId=="") { 
			$returnAction="&return_action=detailView"; 
		} else { 
			$recordId="&record=".$recordId; 
		} 
		 
		$url="index.php?module=".$module.$offset.$stamp.$action.$returnModule.$returnAction.$recordId; 
		header("Location: $url"); 
		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 
		exit;   //goto the location contained in header 
	}
   function customizar() {

$id=$_REQUEST['record'];

    if ($_REQUEST['action'] == 'EditView') {
	  $db = $GLOBALS['db'];
	   // $id=$this->bean->id;
	   $confirmado=-1;
	   $q="select coalesce(confirmado,0) confirmado,id_version from sor_anuncios where id='$id'";
	   $GLOBALS['log']->fatal("anuncios - confirmado->$q<-");
		    $result = $db->query($q);
            while ($row = $db->fetchByAssoc($result)){
				$confirmado=$row['confirmado'];
				$id_version=$row['id_version'];
				
			} 
			$GLOBALS['log']->fatal("anuncios - confirmado->$confirmado<- version->$id_version");
			if (($confirmado==1) || ($id_version>0)){
			$GLOBALS['log']->fatal("anuncios - entra");
			echo "<script src=custom/modules/SOR_ANUNCIOS/Deshabilitaperiodo.js></script>";
				
			}

		
	

     }

  }   
          
    }
?>

