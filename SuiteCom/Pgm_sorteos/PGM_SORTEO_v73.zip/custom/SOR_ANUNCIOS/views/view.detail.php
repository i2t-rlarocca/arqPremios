<?php
require_once('include/MVC/View/views/view.detail.php');

class SOR_ANUNCIOSViewDetail extends ViewDetail 
{
 
 
 

 	function SOR_ANUNCIOSViewDetail()
 	{
		parent::ViewDetail();
       }

	function display()
       {
	   
	   
	   
	   $db = $GLOBALS['db'];
	   $id=$this->bean->id;
	   $confirmado=-1;
	   $q="select coalesce(confirmado,0) confirmado from sor_anuncios where id='$id'";
	   //$GLOBALS['log']->fatal("anuncios - confirmado->$q<-");
		    $result = $db->query($q);
            while ($row = $db->fetchByAssoc($result)){
				$confirmado=$row['confirmado'];
				
			} 
			//$GLOBALS['log']->fatal("anuncios - confirmado->$confirmado<-");
			if ($confirmado==1){
			//$GLOBALS['log']->fatal("anuncios - entra");
			
				unset($this->dv->defs['templateMeta']['form']['buttons'][3]);
			}
	   
	   if(file_exists("cache/modules/SOR_ANUNCIOS/DetailView.tpl"))
         unlink("cache/modules/SOR_ANUNCIOS/DetailView.tpl");
              $this->ss->assign("description", from_html($this->bean->description));
              
		parent::display();
	}
}