<?php
$hook_version = 1; 
$hook_array = Array(); 
$hook_array['after_ui_frame'] = Array(); 
$hook_array['after_ui_frame'][] = Array(1, 'Customizar', 'custom/modules/SOR_ANUNCIOS/logic_hooks_anuncios.php', 'logic_hooks_anuncios', 'customizar'); 
$hook_array['process_record'] = Array(); 
$hook_array['process_record'][] = Array(2, 'acuerdos02', 'custom/modules/SOR_ANUNCIOS/logic_hooks_anuncios.php', 'logic_hooks_anuncios', 'acuerdos_list'); 
$hook_array['before_save'] = Array(); 
$hook_array['before_save'][] = Array(1, 'control', 'custom/modules/SOR_ANUNCIOS/logic_hooks_anuncios.php', 'logic_hooks_anuncios', 'repetidos_list'); 

?>