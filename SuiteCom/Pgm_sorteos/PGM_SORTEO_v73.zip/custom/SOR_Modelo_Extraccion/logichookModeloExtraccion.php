<?php
class logichookCargos{
function controla ($bean, $event, $arguments)
{
	$resultado=$this->realiza_controles($bean,$mensaje);
	if(!($resultado)){
		$this->mostrar_msg($bean, $event, $arguments,$mensaje);
	}
	
}
function grab_dump($var)
		{
			ob_start();
			var_dump($var);
			return ob_get_clean();
		}
function realiza_controles($bean,&$msj)	{
	    // $bean->name = "armar esto";
		
		$db = $GLOBALS['db'];
		if  ($bean->car_orden!=$bean->fetched_row['car_orden']){
			$sql="SELECT COUNT(*) AS cantidad";
		    $sql.=" FROM sor_cargos a  ";
			$sql.=" WHERE a.deleted=0 and a.car_orden=$bean->car_orden AND a.id<>'$bean->id'";
			$results = $db->query($sql, true);
			$row = $db->fetchByAssoc($results);
			if ($row['cantidad'] >0)
				{
					$msj="Ya existe un CARGO con orden: ".$bean->car_orden;
					return false;
				}
		}
	
		return true;
	}
	function graba_nombre($bean, $event, $arguments){

		$bCargo = $bean->car_cargo;
		$GLOBALS['log']->fatal("[Guardar Cargo] toma cargo - bCargo: $bCargo - beanCargo: $bean->car_cargo");
		// var_dump($bMedio);
		$bNombre = BeanFactory::getBean("SOR_Autoridades", $bean->name);
		$GLOBALS['log']->fatal("[Guardar Cargo] toma nombre - bCargo: $bNombre");
		$bProd = BeanFactory::getBean("SOR_PRODUCTOS", $bean->description); 
		$GLOBALS['log']->fatal("[Guardar Cargo] toma producto - bProd: $bProd");
		// var_dump($bProveedor);
		$bean->name = trim($bProd->description).' - '.trim($bCargo->car_cargo).' - '.trim($bNombre->name);
		$GLOBALS['log']->fatal("[Guardar Cargo] nombre completo de cargo - bean: $bean->name");


	}
	
	
	function mostrar_msg($bean, $event, $arguments,$mensaje)
	{	 
		 $_SESSION['myError']=$mensaje; 
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$action="&action=EditView"; //we need to have EditView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['return_module']; 
		 
		$offset=$_REQUEST['offset']; 
		if($offset=="") { 
		} else { 
			$offset="&offset=$offset"; 
		} 
		 
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="") { 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
			 
		if($recordId=="") { 
			$returnAction="&return_action=detailView"; 
		} else { 
			$recordId="&record=".$recordId; 
		} 
		 
		$url="index.php?module=".$module.$offset.$stamp.$action.$returnModule.$returnAction.$recordId; 
		header("Location: $url"); 
		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 
		exit;   //goto the location contained in header 
	}
}
?>