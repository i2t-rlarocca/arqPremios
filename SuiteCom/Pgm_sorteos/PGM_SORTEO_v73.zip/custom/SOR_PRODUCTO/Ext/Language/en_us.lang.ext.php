<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_SOR_MODALIDADES_SOR_PRODUCTO_FROM_SOR_MODALIDADES_TITLE'] = 'Producto';
$mod_strings['LBL_SOR_ANUNCIOS_SOR_PRODUCTO_FROM_SOR_ANUNCIOS_TITLE'] = 'Anuncios';

?>