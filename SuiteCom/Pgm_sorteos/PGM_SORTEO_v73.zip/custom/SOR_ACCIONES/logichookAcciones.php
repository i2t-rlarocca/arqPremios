<?php
class logichookAcciones{


	function listar_nombre (&$bean, $event, $arguments){
// muestra una extracto del encabezado en listviewdef	

	$bean->description  = html_entity_decode($bean->description);

}	

	function asigna_nombre ($bean, $event, $arguments){
 
	$db = $GLOBALS['db'];
	$actualiza=false;
	$a�o = substr($bean->fecha,0,4); //2013
	$mes = substr($bean->fecha,5,2); //
	$dias = substr($bean->fecha,8,2);
	$fecha = $dias."/".$mes."/".$a�o;
	$bean->dia=$dias;
	$bean->mes=$mes;
	$bean->anio=$a�o;
	$fechaaccion=$a�o.$mes;
	$fecha_actual=date("Ym");
	$fecha_pos = new DateTime(date("Y-m-d"));
	$intervalo = new DateInterval('P1M');
	$fecha_pos->add($intervalo);
	$fecha_pos=$fecha_pos->format("Ym");
	global $current_user;
	//$GLOBALS['log']->fatal("fechas->".$fechaaccion.' -- '.$fecha_actual.' -- '.$fecha_pos);
	// controla que la fecha de la accion este entre el mes actual o el siguiente
	if  (($fechaaccion >=$fecha_actual) && ($fechaaccion <=$fecha_pos)){
		$actualiza=true;
	}
	//$GLOBALS['log']->fatal("Actualiza?->".$actualiza);
	if ($actualiza) {
		$sql="select coalesce(id,0) id,id_version,confirmado from  sor_anuncios ";
		$sql.=" WHERE mes=$mes AND anio=$a�o";
		$results = $db->query($sql, true);
		$row = $db->fetchByAssoc($results);
		$id=$row['id'];
		$id_version=$row['id_version'];
		$confirmado=$row['confirmado'];
		$desconfirma=false;
		//$GLOBALS['log']->fatal("ID anuncios SQL->".$id." version:".$id_version);
	}
	//si esta confirmado,desconfirma el mes actual y proximo mes
	if ($confirmado==1){
		$confirmado=0;
		$desconfirma=true;
	}
	if ($bean->id!= $bean->fetched_row['id'])
	{
	
	// es un ingreso
		$resultado=$this->realiza_controles($bean,$mensaje);
		if(!($resultado)){
			$this->mostrar_msg($bean, $event, $arguments,$mensaje);
		}
		if ($actualiza) {
					
			if ($desconfirma){
				$sql="UPDATE  sor_anuncios SET	confirmado=$confirmado, fecha_hora_confirmacion='1900/01/01' ";
				$sql.=" WHERE  (anio*100+mes)=$fechaaccion";
				$GLOBALS['log']->fatal("actualiza SQL->".$sql);
				$db->query($sql, true);
				
				$msj=" PROVISORIO  Alta ACCION de tipo:".strtoupper($bean->tipo_accion)." Fecha:".$fecha;
			//$GLOBALS['log']->fatal("alta accion SQL->".$sql);
				if (trim($bean->producto)!=""){
					$msj.=" Juego:".$bean->producto;
				}
				if (trim($bean->loteria)!=""){
					$msj.=" Loteria:".$bean->loteria;
				}
				$msj.=" e ID:".$bean->id;
				
				$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id',now(),'text','CONFIRMADO','$msj','Estado','$current_user->id')	";
				$db->query($sql, true);
			}
			
			
			// inserta auditoria cuando la versiones mayor a cero, es decir que el anuncio ya fue confirmado al menos una vez
			if ($id_version>0){
			
				$msj=$id_version." Alta ACCION de tipo:".strtoupper($bean->tipo_accion)." Fecha:".$fecha;
				if (trim($bean->producto)!=""){
					$msj.=" Juego:".$bean->producto;
				}
				if (trim($bean->loteria)!=""){
					$msj.=" Loteria:".$bean->loteria;
				}
				
				$msj.=" e ID:".$bean->id;
				$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id',now(),'text','$id_version','$msj','Cambios','$current_user->id')	";
				
				$db->query($sql, true);
				//$GLOBALS['log']->fatal("actualiza SQL->".$sql);
			}
		}
		
		
	}else{
	
		$hubo_cambios=false;
			
		switch($bean->tipo_accion){
			case "AT": // anula todos los sorteos de un dia
				if ($bean->fecha!= $bean->fetched_row['fecha']){
					$hubo_cambios=true;
				}		 
				break;
			case "IP":// incorpora un sorteo a un producto
				if (($bean->fecha!= $bean->fetched_row['fecha'])||($bean->sor_producto_id_c!= $bean->fetched_row['sor_producto_id_c']) || ($bean->sor_loterias_id_c!= $bean->fetched_row['sor_loterias_id_c']) ||  ($bean->hora_sorteo!= $bean->fetched_row['hora_sorteo']) || ($bean->minuto_sorteo!= $bean->fetched_row['minuto_sorteo']) ){
					$hubo_cambios=true;
				}		 
				
				break;
			case "AP": // anula los sorteos de un producto
				if (($bean->fecha!= $bean->fetched_row['fecha'])||($bean->sor_producto_id_c!= $bean->fetched_row['sor_producto_id_c']))
				{
					$hubo_cambios=true;
				}
				break;
			case "ASL": // anula una jurisdiccion
				if (($bean->fecha!= $bean->fetched_row['fecha'])||($bean->sor_producto_id_c!= $bean->fetched_row['sor_producto_id_c'])|| ($bean->sor_loterias_id_c!= $bean->fetched_row['sor_loterias_id_c']))
				{
					$hubo_cambios=true;
				} 
				
				break;
			case "CAT1": // agrega adicional tipo 1
				if (($bean->fecha!= $bean->fetched_row['fecha'])||($bean->sor_producto_id_c!= $bean->fetched_row['sor_producto_id_c']))
				{
					$hubo_cambios=true;
				} 
				break ;
			case "CAT2":// agrega adicional tipo 2
				if (($bean->fecha!= $bean->fetched_row['fecha'])||($bean->sor_producto_id_c!= $bean->fetched_row['sor_producto_id_c']))
				{
					$hubo_cambios=true;
				}
				break;

			case "RP":// agrega adicional tipo 2
				if (($bean->fecha!= $bean->fetched_row['fecha'])||($bean->sor_producto_id_c!= $bean->fetched_row['sor_producto_id_c'])||  ($bean->hora_sorteo!= $bean->fetched_row['hora_sorteo']) || ($bean->minuto_sorteo!= $bean->fetched_row['minuto_sorteo']))
				{
					$hubo_cambios=true;
				}
				break;
			case "RSL":// agrega adicional tipo 2
				if (($bean->fecha!= $bean->fetched_row['fecha'])||($bean->sor_producto_id_c!= $bean->fetched_row['sor_producto_id_c'])|| ($bean->sor_loterias_id_c!= $bean->fetched_row['sor_loterias_id_c'])||  ($bean->hora_sorteo!= $bean->fetched_row['hora_sorteo']) || ($bean->minuto_sorteo!= $bean->fetched_row['minuto_sorteo']))
				{
					$hubo_cambios=true;
				}
				break;				
		}
		// solo si hubo cambios realiza controles
		if ($hubo_cambios){
			$resultado=$this->realiza_controles($bean,$mensaje);
			if(!($resultado)){
				$this->mostrar_msg($bean, $event, $arguments,$mensaje);
			}
			
			if ($actualiza) {
			
				
				
				$msj="PROVISORIO Modificacion ACCION de tipo:".STRTOUPPER($bean->tipo_accion)." Fecha:".$fecha;
				if ($desconfirma){
					$sql="UPDATE  sor_anuncios SET	confirmado=$confirmado, fecha_hora_confirmacion='1900/01/01'";
					$sql.=" WHERE  (anio*100+mes)=$fechaaccion";
					$GLOBALS['log']->fatal("actualiza SQL->".$sql);
					$db->query($sql, true);
				
					if (trim($bean->producto)!=""){
						$msj.=" Juego:".$bean->producto;
					}
					if (trim($bean->loteria)!=""){
						$msj.=" Loteria:".$bean->loteria;
					}
					$msj.=" e ID:".$bean->id;
					
					$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id',now(),'text','CONFIRMADO','$msj','Estado','$current_user->id')	";
					$db->query($sql, true);
				}
			   
				if ($id_version>0){
					$msj=$id_version." Modificacion ACCION de tipo:".strtoupper($bean->tipo_accion)." Fecha:".$fecha;
					if (trim($bean->producto)!=""){
						$msj.=" Juego:".$bean->producto;
					}
					if (trim($bean->loteria)!=""){
						$msj.=" Loteria:".$bean->loteria;
					}
					$msj.=" e ID:".$bean->id;
					$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id',now(),'text','$id_version','$msj','Cambios','$current_user->id')	";
					$db->query($sql, true);
				//$GLOBALS['log']->fatal("modifica accion SQL->".$sql);
				}
				
			}
			
		}
	
	}
	// limpia los campos que no se usan segun la accion
		$tipo_accion=$bean->tipo_accion;
		
		
		switch($tipo_accion){
			case "AT": // anula todos los sorteos de un dia
					$bean->sor_producto_id_c="";
					$bean->producto="";
					$bean->loteria="";
					$bean->hora_sorteo="";
					$bean->minuto_sorteo="";
					$bean->producto_vinculado="";
					
					$bean->sor_loterias_id_c="";
					$bean->sor_producto_id1_c="";
					
										
				break;
				case "IP":// incorpora un sorteo a un producto
					
					break;
			case "AP": // anula los sorteos de un producto
					$bean->loteria="";
					$bean->hora_sorteo="";
					$bean->minuto_sorteo="";
					$bean->producto_vinculado="";
					$bean->sor_loterias_id_c="";
					$bean->sor_producto_id1_c="";
				break;
			case "ASL": // anula una jurisdiccion
			
						break;
			}
	
	
	// asigna la fecha al name
	
	$a�o = substr($bean->fecha,0,4); //2013
	$mes = substr($bean->fecha,5,2); //
	$dias = substr($bean->fecha,8,2);
	$fecha = $dias."/".$mes."/".$a�o;
	$bean->name=$fecha;
	$codigo=date("w",strtotime($bean->fecha));
	$bean->codigo=$codigo+1;
	
	
	
}

	function controla_modalidad_adicional( $bean){
   
	$db = $GLOBALS['db'];
	if ($bean->tipo_accion=="CAT1"){
			$tipo_adicional=1;
		}else{
			$tipo_adicional=2;
		}
	//busca si existe la modalidad para ese producto ,si no existe la crea y arma la relacionc on le poruducto
	
	$sql="SELECT count(*) as cantidad,COALESCE(a.id,-1) AS idmodalidad FROM sor_modalidades  a ";
	$sql.=" INNER JOIN sor_modalidades_sor_producto_c b ON a.id=b.sor_modalidades_sor_productosor_modalidades_idb  AND  b.deleted=0";
	$sql.=" INNER JOIN sor_producto c ON c.id=b.sor_modalidades_sor_productosor_producto_ida  AND  c.deleted=0";
	$sql.=" WHERE a.tipo_adicional=$tipo_adicional AND c.id='$bean->sor_producto_id_c'  AND  a.deleted=0";
	//$GLOBALS['log']->fatal("verifica SQL->".$sql);
	$results = $db->query($sql, true);
	$row = $db->fetchByAssoc($results);
	$cantidad=$row['cantidad'];
	$id_adicional=$row['idmodalidad'];
	if ($cantidad ==0)
		{
		return false;
		}
	return true;
}

	function realiza_controles($bean,&$msj)	{
	
		$db = $GLOBALS['db'];
		$where="";
		
		//if (($bean->id)!=($bean->fetched_row['id'])){
			if ($this->controla_repetidos($bean))
			{
				$msj="Ya existe un registro con los datos ingresado";
				return false;
			}
		//}
		
		
		//controla repetidos
		$fecha=$bean->fecha;
		$tipo_accion=$bean->tipo_accion;
		$GLOBALS['log']->fatal(" tipo de accion->".$tipo_accion);
		
		switch($tipo_accion){
			case "AT": // anula todos los sorteos de un dia
				if(trim($bean->fecha)==""){
					$msj="Para el tipo de acci&oacute;n seleccionada debe completar FECHA";
					return false;
				}		 
				break;
			case "ALEA": // defini un sorteo de tipo ALEA -> tiene 
				if(trim($bean->fecha)==""){
					$msj="Para el tipo de acci&oacute;n seleccionada debe completar FECHA";
					return false;
				}		 
				setlocale(LC_ALL,"es_ES");
				$GLOBALS['log']->fatal(" comparacion de fechas fecha ingresada -> " . trim($bean->fecha) 
											. " fecha del dia -> " . date("Y-m-d")
											. " resultado de la comparacion -> " . (trim($bean->fecha) < date("Y-m-d")));
				if(trim($bean->fecha) < date("Y-m-d")){
					$msj="Para el tipo de acci&oacute;n debe seleccionar una fecha igual o mayor a la del d&iacute;a";
					return false;
				}		 
				break;
			case "IP":// incorpora un sorteo a un producto
				if((trim($bean->fecha)=="") ||(trim($bean->sor_producto_id_c)=="")||(trim($bean->sor_loterias_id_c)=="") ||(trim($bean->hora_sorteo)=="") ||(trim($bean->minuto_sorteo)=="")){
					$msj="Para el tipo de acci&oacute;n seleccionada debe completar FECHA,PRODUCTO,LOTERIA,HORA Y MINUTO DE SORTEO. ";
					return false;
				}
				break;
			case "AP": // anula los sorteos de un producto
				if((trim($bean->fecha)=="") ||(trim($bean->sor_producto_id_c)=="") )
				{
					$msj="Para el tipo de acci&oacute;n seleccionada debe completar FECHA y PRODUCTO";
					return false;
					}
						// controla que los juegos dependientes estan anulados
					$sql= " SELECT p.id_juego AS id_juego,	CASE WHEN p.id_juego=30 AND MONTH(da.sor_fecha) % 2 = 0 THEN 'Entre R�os' ELSE l.name END AS localidad,	p.name AS juegodesc ";
					$sql.=" FROM sor_dia_modelo dm ";
					$sql.=" JOIN sor_dias d ON d.id = dm.sor_dias_id_c AND d.deleted = 0";
					$sql.=" JOIN sor_producto p ON p.id = dm.sor_producto_id_c AND p.deleted = 0";
					$sql.=" JOIN sor_loterias l ON l.id = dm.sor_loterias_id_c AND l.deleted = 0 AND (l.id_loteria=3 OR dm.hora_sorteo=0)";
					$sql.=" JOIN sor_diasanio da ON da.sor_codigo = d.codigo";
					$sql.=" LEFT JOIN sor_producto jr ON jr.deleted=0 AND  jr.id = dm.sor_producto_id1_c ";
					$sql.=" LEFT JOIN (SELECT dm3.*,l2.id_loteria FROM sor_dia_modelo dm3 INNER JOIN sor_loterias l2 ON l2.deleted = 0 AND l2.id = dm3.sor_loterias_id_c ";
					$sql.=" ) dm2 ";
					$sql.=" ON dm2.deleted=0 AND dm2.sor_dias_id_c = d.id AND dm2.sor_producto_id_c = jr.id ";
					$sql.=" WHERE   da.sor_fecha  BETWEEN '$bean->fecha' AND '$bean->fecha' AND COALESCE(jr.id,0)='$bean->sor_producto_id_c' AND  ";
					$sql.=" ((COALESCE(dm2.id_loteria,0) = CASE WHEN p.id_juego=30 AND MONTH(da.sor_fecha) % 2 = 0 AND COALESCE(dm2.sor_dias_id_c,0) = 4 THEN 5 ELSE 3 END) OR (dm2.id_loteria IS NULL)) ";
					$sql.=" AND dm.deleted=0 ";
					$sql.=" ORDER BY localidad ";
					//$GLOBALS['log']->fatal(" dependientes SQL->".$sql);
					$results = $db->query($sql, true);
					while($row = $db->fetchByAssoc($results)){
						if (STRTOUPPER($row['localidad'])=='SANTA FE'){
							 $juegos_dependientes=$juegos_dependientes.$row['juegodesc'].",";
							//busca si hay una excpecion para el juego y fecha
							$sqlaux="SELECT  COUNT(*) cantidad ";
							$sqlaux.= " FROM sor_acciones a   ";
							$sqlaux.= " JOIN tbl_listas_desplegables b ON a.tipo_accion = b.codigo AND b.deleted = 0 ";
							$sqlaux.= " INNER JOIN sor_producto p ON p.id = a.sor_producto_id_c AND p.deleted = 0 ";
							$sqlaux.= " AND p.id_juego=".$row['id_juego']." and a.fecha='$bean->fecha' ";
					//	$GLOBALS['log']->fatal(" juego SQL->".$sqlaux);
							$resultsaux = $db->query($sqlaux, true);
							$rowaux = $db->fetchByAssoc($resultsaux);
							$cantidad =$rowaux['cantidad'];
							if ($cantidad ==0)
							{
								$juego_no_encontrado=true;
							}
						}
					}
					// existe algun juego dependiente que no tiene una exepcion ingresada,informa
					if ($juego_no_encontrado==true){
						$juegos_dependientes=trim($juegos_dependientes,",");
						$msj="Para anular el producto,primero debe anular los juegos:".$juegos_dependientes. " que dependen de el";
						return false;						
					}
				break;
			case "ASL": // anula una jurisdiccion
				if((trim($bean->fecha)=="") ||(trim($bean->sor_producto_id_c)=="")||(trim($bean->sor_loterias_id_c)=="")){
					$msj="Para el tipo de acci&oacute;n seleccionada debe completar FECHA,PRODUCTO y LOTERIA";
					return false;
				}
				$sql="SELECT COUNT(*) as cantidad FROM sor_producto WHERE  prefijo IN('QN','QM','QV','QA') AND id='$bean->sor_producto_id_c'";
				
		
				$db->query($sql, true);
				$results = $db->query($sql, true);
				$row = $db->fetchByAssoc($results);
				if ($row['cantidad'] ==0)
					{
						$msj="Para el tipo de acci&oacute;n seleccionada el PRODUCTO debe ser de tipo Quiniela";
						return false;
					}
				break;
			case "CAT1":
			case "CAT2": // agrega adicional tipo 1 solo para quini o brinco
				
				if((trim($bean->fecha)=="") ||(trim($bean->sor_producto_id_c)=="")){
					$msj="Para el tipo de acci&oacute;n seleccionada debe completar FECHA y PRODUCTO";
					return false;
				}	
				$sql="SELECT COUNT(*) as cantidad FROM sor_producto WHERE  prefijo IN('Q6','BR') AND id='$bean->sor_producto_id_c'";
				$db->query($sql, true);
				$results = $db->query($sql, true);
				$row = $db->fetchByAssoc($results);
				if ($row['cantidad'] ==0)
					{
						$msj="Para el tipo de acci&oacute;n seleccionada el PRODUCTO debe ser de tipo QUINI6 O BRINCO";
						return false;
					}
					if (!$this->controla_modalidad_adicional( $bean)){
						$msj="No existe la modalidad que se quiere incorporar para el producto seleccionado.Por favor revise el modulode MODALIDADES";
						return false;
					}
								
				break ;
		/*Agregado nuevas acciones*/
				case "RSL":// cambia la hora de un producto loteria(otras jurisdicciones-> BS AS ,Nacional,etc)
					if((trim($bean->fecha)=="") ||(trim($bean->sor_producto_id_c)=="")||(trim($bean->sor_loterias_id_c)=="") ||(trim($bean->hora_sorteo)=="") ||(trim($bean->minuto_sorteo)=="")){
						$msj="Para el tipo de acci&oacute;n seleccionada debe completar FECHA,PRODUCTO,LOTERIA,HORA Y MINUTO DE SORTEO. ";
						return false;
					}
					$juego=0;
					$loteria=0;
					$sql="SELECT COUNT(*) as cantidad,id_juego FROM sor_producto WHERE  prefijo IN('QN','QM','QV','QA') AND id='$bean->sor_producto_id_c'";
					
					$db->query($sql, true);
					$results = $db->query($sql, true);
					$row = $db->fetchByAssoc($results);
					if ($row['cantidad'] ==0)
					{
						$msj="Para el tipo de acci&oacute;n seleccionada el PRODUCTO debe ser de tipo Quiniela";
						return false;
					}
					$juego=$row['id_juego'];
					
					$sql="SELECT id_loteria FROM sor_loterias WHERE  id='$bean->sor_loterias_id_c'";
					
					$db->query($sql, true);
					$results = $db->query($sql, true);
					$row = $db->fetchByAssoc($results);
					
					$loteria=$row['id_loteria'];
					if(!($this->controla_dia($bean->fecha,$juego,$loteria))){
						$msj="No se encontr&oacute; un dia modelo para la fecha , producto y loter&iacute;a ingresados";
						return false;
					}
				
				break;
			case "RP": // cambia la hora de un producto(Matutina,quini6,etc)
					if((trim($bean->fecha)=="") ||(trim($bean->sor_producto_id_c)=="") ||(trim($bean->hora_sorteo)=="") ||(trim($bean->minuto_sorteo)==""))
					{
						$msj="Para el tipo de acci&oacute;n seleccionada debe completar FECHA ,PRODUCTO,HORA Y MINUTO DE SORTEO.";
						return false;
					}
					$sql="SELECT id_juego FROM sor_producto WHERE  id='$bean->sor_producto_id_c'";
					$juego=0;
					$db->query($sql, true);
					$results = $db->query($sql, true);
					$row = $db->fetchByAssoc($results);
					$juego=$row['id_juego'];
					$loteria="";
					if(!($this->controla_dia($bean->fecha,$juego,$loteria))){
						$msj="No se encontr&oacute; un dia modelo para la fecha  y producto ingresados";
						return false;
					}
		/*Fin agregado*/
		}
		return true;
	
	}

	function controla_repetidos($bean){
		$db = $GLOBALS['db'];
		$tipo_accion=$bean->tipo_accion;
		$where="";
		$GLOBALS['log']->fatal(" tipo de accion->".$tipo_accion);
		
		switch($tipo_accion){
			case "AT": // anula todos los sorteos de un dia
				$where=" fecha='$bean->fecha' and tipo_accion='AT'";		 
				break;
			case "ALEA": // define un sorteo q6 tipo alea
				$where=" fecha='$bean->fecha' and tipo_accion='ALEA'";		 
				break;
			case "IP":// incorpora un sorteo a un producto
				$where=" fecha='$bean->fecha' and tipo_accion='IP' and sor_producto_id_c='$bean->sor_producto_id_c' and sor_loterias_id_c='$bean->sor_loterias_id_c' and sor_producto_id1_c='$bean->sor_producto_id1_c' and hora_sorteo=$bean->hora_sorteo and minuto_sorteo=$bean->minuto_sorteo";		 
				break;
			case "AP": // anula los sorteos de un producto
				$where=" fecha='$bean->fecha' and tipo_accion='AP' and sor_producto_id_c='$bean->sor_producto_id_c' ";		 
				break;
			case "ASL": // anula una jurisdiccion
				$where=" fecha='$bean->fecha' and tipo_accion='ASL' and sor_producto_id_c='$bean->sor_producto_id_c' and sor_loterias_id_c='$bean->sor_loterias_id_c' and sor_producto_id1_c='$bean->sor_producto_id1_c' and hora_sorteo=$bean->hora_sorteo and minuto_sorteo=$bean->minuto_sorteo";		 
				break;
			case "CAT1":
			case "CAT2": // agrega adicional tipo 1 o 2
				$where=" fecha='$bean->fecha' and tipo_accion='$tipo_accion' and sor_producto_id_c='$bean->sor_producto_id_c' ";		 
				break ;
			case "RP":// agrega adicional tipo 2
				$where=" fecha='$bean->fecha' and tipo_accion='$tipo_accion' and sor_producto_id_c='$bean->sor_producto_id_c' and hora_sorteo=$bean->hora_sorteo and minuto_sorteo=$bean->minuto_sorteo";		 
				break;
				case "RSL":// agrega adicional tipo 2
				$where=" fecha='$bean->fecha' and tipo_accion='$tipo_accion' and sor_producto_id_c='$bean->sor_producto_id_c' and sor_loterias_id_c='$bean->sor_loterias_id_c' and hora_sorteo=$bean->hora_sorteo and minuto_sorteo=$bean->minuto_sorteo";		 
				break;
						
		}
		$sql="select count(*) as cantidad from sor_acciones where deleted=0 and ".$where;
		$GLOBALS['log']->fatal(" CONTROLA ACCIONES SQL->".$sql);
		$results = $db->query($sql, true);
		$row = $db->fetchByAssoc($results);
		if ($row['cantidad'] >0)
            {
				//$msj="Ya existe un registro con los datos ingresado";
				return true;
            }
			
        return false;
		
		
	}

	function controla_dia($fecha,$juego,$loteria){
	//funciona para controlar que cuando se realiza una cambio de horario el producto debe existir en el dia modelo para la fecha ingresada
	//la fecha y el producto son obligatorios,la loteria es opcional
	$db = $GLOBALS['db'];
	$where=" da.sor_fecha  = '$fecha'   AND p.id_juego=$juego";
	if (trim($loteria)!=""){
		$where=$where." AND l.id_loteria=$loteria";
	}
				// controla que exista el dia modelo para la fecha seleccionada
					$sql= " SELECT count(*) as cantidad";
					$sql.=" FROM sor_dia_modelo dm ";
					$sql.=" JOIN sor_dias d ON d.id = dm.sor_dias_id_c AND d.deleted = 0";
					$sql.=" JOIN sor_producto p ON p.id = dm.sor_producto_id_c AND p.deleted = 0";
					$sql.=" JOIN sor_loterias l ON l.id = dm.sor_loterias_id_c AND l.deleted = 0 ";
					$sql.=" JOIN sor_diasanio da ON da.sor_codigo = d.codigo";
					$sql.=" LEFT JOIN sor_producto jr ON jr.deleted=0 AND  jr.id = dm.sor_producto_id1_c ";
					$sql.=" LEFT JOIN (SELECT dm3.*,l2.id_loteria FROM sor_dia_modelo dm3 INNER JOIN sor_loterias l2 ON l2.deleted = 0 AND l2.id = dm3.sor_loterias_id_c ";
					$sql.=" ) dm2 ";
					$sql.=" ON dm2.deleted=0 AND dm2.sor_dias_id_c = d.id AND dm2.sor_producto_id_c = jr.id ";
					$sql.=" WHERE    $where  ";
					$sql.=" AND ((COALESCE(dm2.id_loteria,0) = CASE WHEN p.id_juego=30 AND MONTH(da.sor_fecha) % 2 = 0 AND COALESCE(dm2.sor_dias_id_c,0) = 4 THEN 5 ELSE 3 END) OR (dm2.id_loteria IS NULL)) ";
					$sql.=" AND dm.deleted=0 ";
					
					//$GLOBALS['log']->fatal(" CONTROLA DIA MODELO SQL->".$sql);
					
					$db->query($sql, true);
					$results = $db->query($sql, true);
					$row = $db->fetchByAssoc($results);
					if ($row['cantidad'] ==0){
							return false;
					}
					return true;
	}
	
	function mostrar_msg($bean, $event, $arguments,$mensaje){	 
		 $_SESSION['myError']=$mensaje; 
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$action="&action=EditView"; //we need to have EditView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['return_module']; 
		 
		$offset=$_REQUEST['offset']; 
		if($offset=="") { 
		} else { 
			$offset="&offset=$offset"; 
		} 
		 
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="") { 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
			 
		if($recordId=="") { 
			$returnAction="&return_action=detailView"; 
		} else { 
			$recordId="&record=".$recordId; 
		} 
		 
		$url="index.php?module=".$module.$offset.$stamp.$action.$returnModule.$returnAction.$recordId; 
		
		header("Location: $url"); 
		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 
		exit;   //goto the location contained in header 
	}
}
?>