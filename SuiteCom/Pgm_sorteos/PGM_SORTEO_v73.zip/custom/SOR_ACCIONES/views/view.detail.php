<?php
require_once('include/MVC/View/views/view.detail.php');

class SOR_ACCIONESViewDetail extends ViewDetail 
{
 
 
 

 	function SOR_ACCIONESViewDetail()
 	{
		parent::ViewDetail();
       }

	function display()
       {
              $this->ss->assign("description", from_html($this->bean->description));
              
		parent::display();
	}
}