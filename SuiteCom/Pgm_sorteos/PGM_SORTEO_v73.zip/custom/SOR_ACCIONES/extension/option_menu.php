<?php 
global $module_menu;
$module_menu[] = array (
                       'index.php?module=SOR_ACCIONES&action=InformeAcciones&id_reporte=1&modulo_act='.$_REQUEST['module'],
                        'Informe Excepciones',
                        'ActivitiesReports',
                        'SOR_ACCIONES'
                       );
$module_menu[] = array (
                       'index.php?module=SOR_ACCIONES&action=InformeAcciones&id_reporte=2&modulo_act='.$_REQUEST['module'],
                        'Informe Programa Sorteo',
                        'ActivitiesReports',
                        'SOR_ACCIONES'
                       );
$module_menu[] = array (
                       'index.php?module=SOR_ACCIONES&action=InformeAcciones&id_reporte=4&modulo_act='.$_REQUEST['module'],
                        'Informe PGM Sorteo numerado',
                        'ActivitiesReports',
                        'SOR_ACCIONES'
                       );
$module_menu[] = array (
                       'index.php?module=SOR_ACCIONES&action=InformeAcciones&id_reporte=3&modulo_act='.$_REQUEST['module'],
                        'Informe Dia Modelo',
                        'ActivitiesReports',
                        'SOR_ACCIONES'
                       );
?>
