<?php
// Do not store anything in this file that is not part of the array or the hook version.  This file will	
// be automatically rebuilt in the future. 
 $hook_version = 1; 
$hook_array = Array(); 

$hook_array['process_record'] = Array(); 
$hook_array['process_record'][] = Array(1, 'listar_nombre', 'custom/modules/SOR_ACCIONES/logichookAcciones.php','logichookAcciones', 'listar_nombre'); 
$hook_array['before_save'] = Array(); 
$hook_array['before_save'][] = Array(1, 'asigna_nombre', 'custom/modules/SOR_ACCIONES/logichookAcciones.php','logichookAcciones', 'asigna_nombre'); 




?>