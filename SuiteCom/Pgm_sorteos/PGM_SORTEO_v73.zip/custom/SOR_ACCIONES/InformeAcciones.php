<?php
include('parametros_app.php');
$reporte=$_REQUEST['id_reporte'];
$url = "http://$servidor_jasper/cas/pgm_sorteos/informeAcciones.php?id_reporte=".$reporte;
echo "<script language=\"javascript\">window.open(\"$url\",\"_blank\");</script>";

$url2 = "Refresh: 0; url= http://$url_crm/index.php?module=".$_REQUEST['modulo_act'];
header($url2, true, 303);

exit; 

?>
