<?php
// include_once('parametros_app.php');
include('parametros_app.php');
$module_name = 'SOR_pgmsorteo';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
		  4 => 
          array (
            'customCode' => '<input class="button"  onclick="window.open(\''.$protocolo.$servidor_jasper.'/Ejecutar_Reportes2.php?ruta_reporte=/'.$carpeta_reports.'/CAS/pgm_sorteos/resumen_de_sorteo&formato=PDF&param_idjuego=0&param_sorteo=0&param_opc=0&param_id='.$_REQUEST['record'].'\');this.form.action.value=\'DetailView\';"  name="button"  value="Ver Sorteo Resumido"  type="submit">',
          ),
          5 => 
          array (
            'customCode' => '<input class="button"  onclick="window.open(\''.$protocolo.$servidor_jasper.'/Ejecutar_Reportes2.php?ruta_reporte=/'.$carpeta_reports.'/CAS/pgm_sorteos/resumen_de_sorteo&formato=PDF&param_idjuego=0&param_sorteo=0&param_opc=1&param_id='.$_REQUEST['record'].'\');this.form.action.value=\'DetailView\';"  name="button"  value="Ver Sorteo Detallado"  type="submit">',
          ),
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'producto',
            'studio' => 'visible',
            'label' => 'LBL_PRODUCTO',
          ),
          1 => 
          array (
            'name' => 'nrosorteo',
            'label' => 'LBL_NROSORTEO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'fecha',
            'label' => 'LBL_FECHA',
          ),
          1 => 
          array (
            'name' => 'hora',
            'label' => 'LBL_HORA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'estado_sorteo',
            'studio' => 'visible',
            'label' => 'LBL_ESTADO_SORTEO',
          ),
          1 => 
          array (
            'name' => 'fechahoraproximo',
            'label' => 'LBL_FECHAHORAPROXIMO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'sorteado',
            'label' => 'LBL_SORTEADO',
          ),
          1 => 
          array (
            'name' => 'fecha_prescripcion',
            'label' => 'LBL_FECHA_PRESCRIPCION',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'tck_afe',
            'label' => 'LBL_TCK_AFE',
          ),
          1 => 
          array (
            'name' => 'apu_afe',
            'label' => 'LBL_APU_AFE',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'rec_afe',
            'label' => 'LBL_REC_AFE',
          ),
          1 => 
          array (
            'name' => 'pre_afe',
            'label' => 'LBL_PRE_AFE',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'compv_afe',
            'label' => 'LBL_COMPV_AFE',
          ),
          1 => 
          array (
            'name' => 'comred_afe',
            'label' => 'LBL_COMRED_AFE',
          ),
        ),
      ),
    ),
  ),
);
?>
