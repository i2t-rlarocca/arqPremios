<?php
$module_name = 'SOR_pgmsorteo';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '1%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'PRODUCTO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRODUCTO',
    'id' => 'SOR_PRODUCTO_ID_C',
    'link' => false,
    'width' => '1%',
    'default' => true,
  ),
  'NROSORTEO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_NROSORTEO',
    'width' => '1%',
    'default' => true,
  ),
  'FECHA' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA',
    'width' => '1%',
    'default' => true,
  ),
  'HORA' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_HORA',
    'width' => '1%',
    'default' => true,
  ),
  'ESTADO_SORTEO' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_ESTADO_SORTEO',
    'id' => 'SOR_ESTADO_PGMSORTEO_ID_C',
    'link' => false,
    'width' => '1%',
    'default' => false,
  ),
  'SOR_PRESC_RECIBIDA' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_SOR_PRESC_RECIBIDA',
    'width' => '1%',
  ),
  'SOR_EMISION_CERRADA' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_SOR_EMISION_CERRADA',
    'width' => '1%',
  ),
  'SOR_PRESC_CONTABILIZADA' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_SOR_PRESC_CONTABILIZADA',
    'width' => '1%',
  ),
  'LOCALIDAD' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LOCALIDAD',
    'width' => '1%',
    'default' => false,
  ),
  'FECHA_PRESCRIPCION' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA_PRESCRIPCION',
    'width' => '1%',
    'default' => false,
  ),
  'SOR_FECHOR_PRESC_RECIBIDA' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_SOR_FECHOR_PRESC_RECIBIDA',
    'width' => '1%',
    'default' => false,
  ),
  'SOR_FECHOR_EMISION_CERRADA' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_SOR_FECHOR_EMISION_CERRADA',
    'width' => '1%',
    'default' => false,
  ),
  'SOR_FECHOR_PRESC_CONTABILIZADA' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_SOR_FECHOR_PRESC_CONTABILIZADA',
    'width' => '1%',
    'default' => false,
  ),
  'ESTADO_CONTROL_CONTAB' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ESTADO_CONTROL_CONTAB',
    'width' => '1%',
    'default' => false,
  ),
  'POZOESTIMADOPROXIMO' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_POZOESTIMADOPROXIMO',
    'width' => '1%',
    'default' => false,
  ),
  'FECHAHORAPROXIMO' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_FECHAHORAPROXIMO',
    'width' => '1%',
    'default' => false,
  ),
  'TIENE_ADIC' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_TIENE_ADIC',
    'width' => '1%',
  ),
);
?>
