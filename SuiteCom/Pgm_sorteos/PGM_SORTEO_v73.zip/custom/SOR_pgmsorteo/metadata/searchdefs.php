<?php
$module_name = 'SOR_pgmsorteo';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
	array (
      'name' => 
      array (
        'type' => 'name',
        'link' => true,
        'label' => 'LBL_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'name',
      ),
      'producto' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PRODUCTO',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'SOR_PRODUCTO_ID_C',
        'name' => 'producto',
      ),
      'nrosorteo' => 
      array (
        'type' => 'int',
        'label' => 'LBL_NROSORTEO',
        'width' => '10%',
        'default' => true,
        'name' => 'nrosorteo',
      ),
      'localidad' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LOCALIDAD',
        'width' => '10%',
        'default' => true,
        'name' => 'localidad',
      ),
      'tiene_adic' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_TIENE_ADIC',
        'width' => '10%',
        'name' => 'tiene_adic',
      ),
      'estado_sorteo' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_ESTADO_SORTEO',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'SOR_ESTADO_PGMSORTEO_ID_C',
        'name' => 'estado_sorteo',
      ),
      'sor_presc_recibida' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_SOR_PRESC_RECIBIDA',
        'width' => '10%',
        'name' => 'sor_presc_recibida',
      ),
      'sor_emision_cerrada' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_SOR_EMISION_CERRADA',
        'width' => '10%',
        'name' => 'sor_emision_cerrada',
      ),
      'sor_presc_contabilizada' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_SOR_PRESC_CONTABILIZADA',
        'width' => '10%',
        'name' => 'sor_presc_contabilizada',
      ),
      'estado_control_contab' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ESTADO_CONTROL_CONTAB',
        'width' => '10%',
        'default' => true,
        'name' => 'estado_control_contab',
      ),
      'fecha' => 
      array (
        'type' => 'date',
        'label' => 'LBL_FECHA',
        'width' => '10%',
        'default' => true,
        'name' => 'fecha',
      ),
      'fecha_prescripcion' => 
      array (
        'type' => 'date',
        'label' => 'LBL_FECHA_PRESCRIPCION',
        'width' => '10%',
        'default' => true,
        'name' => 'fecha_prescripcion',
      ),
      'sor_fechor_presc_recibida' => 
      array (
        'type' => 'datetimecombo',
        'label' => 'LBL_SOR_FECHOR_PRESC_RECIBIDA',
        'width' => '10%',
        'default' => true,
        'name' => 'sor_fechor_presc_recibida',
      ),
      'sor_fechor_emision_cerrada' => 
      array (
        'type' => 'datetimecombo',
        'label' => 'LBL_SOR_FECHOR_EMISION_CERRADA',
        'width' => '10%',
        'default' => true,
        'name' => 'sor_fechor_emision_cerrada',
      ),
      'sor_fechor_presc_contabilizada' => 
      array (
        'type' => 'datetimecombo',
        'label' => 'LBL_SOR_FECHOR_PRESC_CONTABILIZADA',
        'width' => '10%',
        'default' => true,
        'name' => 'sor_fechor_presc_contabilizada',
      ),
	 ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'type' => 'name',
        'link' => true,
        'label' => 'LBL_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'name',
      ),
      'producto' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PRODUCTO',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'SOR_PRODUCTO_ID_C',
        'name' => 'producto',
      ),
      'nrosorteo' => 
      array (
        'type' => 'int',
        'label' => 'LBL_NROSORTEO',
        'width' => '10%',
        'default' => true,
        'name' => 'nrosorteo',
      ),
      'localidad' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LOCALIDAD',
        'width' => '10%',
        'default' => true,
        'name' => 'localidad',
      ),
      'tiene_adic' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_TIENE_ADIC',
        'width' => '10%',
        'name' => 'tiene_adic',
      ),
      'estado_sorteo' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_ESTADO_SORTEO',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'SOR_ESTADO_PGMSORTEO_ID_C',
        'name' => 'estado_sorteo',
      ),
      'sor_presc_recibida' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_SOR_PRESC_RECIBIDA',
        'width' => '10%',
        'name' => 'sor_presc_recibida',
      ),
      'sor_emision_cerrada' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_SOR_EMISION_CERRADA',
        'width' => '10%',
        'name' => 'sor_emision_cerrada',
      ),
      'sor_presc_contabilizada' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_SOR_PRESC_CONTABILIZADA',
        'width' => '10%',
        'name' => 'sor_presc_contabilizada',
      ),
      'estado_control_contab' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ESTADO_CONTROL_CONTAB',
        'width' => '10%',
        'default' => true,
        'name' => 'estado_control_contab',
      ),
      'fecha' => 
      array (
        'type' => 'date',
        'label' => 'LBL_FECHA',
        'width' => '10%',
        'default' => true,
        'name' => 'fecha',
      ),
      'fecha_prescripcion' => 
      array (
        'type' => 'date',
        'label' => 'LBL_FECHA_PRESCRIPCION',
        'width' => '10%',
        'default' => true,
        'name' => 'fecha_prescripcion',
      ),
      'sor_fechor_presc_recibida' => 
      array (
        'type' => 'datetimecombo',
        'label' => 'LBL_SOR_FECHOR_PRESC_RECIBIDA',
        'width' => '10%',
        'default' => true,
        'name' => 'sor_fechor_presc_recibida',
      ),
      'sor_fechor_emision_cerrada' => 
      array (
        'type' => 'datetimecombo',
        'label' => 'LBL_SOR_FECHOR_EMISION_CERRADA',
        'width' => '10%',
        'default' => true,
        'name' => 'sor_fechor_emision_cerrada',
      ),
      'sor_fechor_presc_contabilizada' => 
      array (
        'type' => 'datetimecombo',
        'label' => 'LBL_SOR_FECHOR_PRESC_CONTABILIZADA',
        'width' => '10%',
        'default' => true,
        'name' => 'sor_fechor_presc_contabilizada',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '2',
    'maxColumnsBasic' => '2',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
