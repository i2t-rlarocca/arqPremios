<?php
require_once('verifica_funcion.php'); 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

require_once('include/MVC/View/views/view.list.php');

class SOR_pgmsorteoViewList extends ViewList 
{

    /**
     * @see ViewList::preDisplay()
     */
    public function preDisplay()
    {
        parent::preDisplay();
			$this->lv->actionsMenuExtraItems[] = $this->buildMyMenuItem();
	}
    /**
     * @return string HTML
     */
    protected function buildMyMenuItem()
    {
        global $app_strings;
		include("parametros_app.php");
		
		global $current_user;
        $user_name=$current_user->user_name;

		$strHtml= "";
		$strHtml=$strHtml.<<<EOHTML
			<a class="menuItem" style="width: 150px;" href="#" onmouseover='hiliteItem(this,"yes");' 
			onmouseout='unhiliteItem(this);' 
			onclick="sugarListView.get_checks();
			if(sugarListView.get_checks_count() &lt; 1) {
				alert('{$app_strings['LBL_LISTVIEW_NO_SELECTED']}');
				return false;
			}
			document.MassUpdate.action.value='seguimiento';
			document.MassUpdate.submit();">Reporte Resumen Emisi&oacute;n</a>
EOHTML;
		// Agrego opc Cerrar Premios sólo si el usuario tiene permiso.
		$rol = "";
		$funcion = "PRE_001"; // PRE_001 = Cerrar Emisión en Premios. Solo usuario Premios
		$estado = 0;
        $estado = verifica_tg_funcion($user_name, $rol, $funcion);
        if ($estado!=0) {
			$strHtml=$strHtml.<<<EOHTML
			<a class="menuItem" style="width: 150px;" href="#" onmouseover='hiliteItem(this,"yes");' 
			onmouseout='unhiliteItem(this);' 
			onclick="sugarListView.get_checks();
			if(sugarListView.get_checks_count() &lt; 1) {
				alert('{$app_strings['LBL_LISTVIEW_NO_SELECTED']}');
				return false;
			}
			document.MassUpdate.action.value='cerrar_premios';
			document.MassUpdate.submit();">Cerrar Premios de la Emisi&oacute;n</a>
EOHTML;
		}	
		// Agrego opc Prescribir Emisión sólo si el usuario tiene permiso.
		$rol = "";
		$funcion = "P007"; // P007 = Prescribir Emisión. Solo usuarios Entes Adherentes
		$estado = 0;
        $estado = verifica_tg_funcion($user_name, $rol, $funcion);
        if ($estado!=0) {
			$strHtml=$strHtml.<<<EOHTML
			<a class="menuItem" style="width: 150px;" href="#" onmouseover='hiliteItem(this,"yes");' 
			onmouseout='unhiliteItem(this);' 
			onclick="sugarListView.get_checks();
			if(sugarListView.get_checks_count() &lt; 1) {
				alert('{$app_strings['LBL_LISTVIEW_NO_SELECTED']}');
				return false;
			}
			document.MassUpdate.action.value='cerrar_ctasctes_pcias';
			document.MassUpdate.submit();">Generar NC Pcias y Minutas</a>
EOHTML;
		}
		return $strHtml;
	}
}