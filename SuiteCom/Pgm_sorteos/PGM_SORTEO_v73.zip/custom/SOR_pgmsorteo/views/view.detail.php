<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
 
//Points to 'modules/Accounts/views/view.detail.php' instead of 'include/MVC/View/views/view.detail.php' since accounts already overrides the stock view
require_once('include/MVC/View/views/view.detail.php');
//require_once('modules/uif_Operaciones/views/view.detail.php');
 
class SOR_pgmsorteoViewDetail extends ViewDetail
{
 
    function SOR_pgmsorteoViewDetail()
    {
        parent::ViewDetail();
    }
 
    /**
     * Override - Called from process(). This method will display subpanels.
     */
	 
    	
	function display(){
	
	if(file_exists("cache/modules/SOR_pgmsorteo/DetailView.tpl"))
         unlink("cache/modules/SOR_pgmsorteo/DetailView.tpl");
		
		// muestra la vista
		parent::display();
	}
	
}
?>