<?php
require_once('modules/SOR_pgmsorteo/SOR_pgmsorteo.php');


class logic_hooks_impl {


	
	function mensajes_list (&$bean, $event, $arguments) {
 	       
		//custom campos nrosorteo producto	
		$bean->name = strtoupper($bean->producto)."_".$bean->nrosorteo;

		$db = $GLOBALS['db'];
		
		$q = "SELECT p.id_juego AS idJuego, p.dias_prescripcion AS dias FROM sor_producto p ";
		$q.= "WHERE p.id = '$bean->sor_producto_id_c' AND p.`deleted` = 0;";		

		$results = $bean->db->query($q, true);
		$row = $bean->db->fetchByAssoc($results);
		$bean->idjuego = $row['idJuego'];
		// La fecha de prescripción queda en null: corresponde a la fecha de sorteo + cantidad de dias para prescripción del producto.
		$date = $bean->fecha;
		//Incrementando 2 dias
		$dias = $row['dias'];
		$mod_date = strtotime($date." + ".$dias." days");

		$bean->fecha_prescripcion = date("Y-m-d",$mod_date);

		$bean->tck_car = 0;
		$bean->apu_car = 0;
		$bean->rec_car = 0;
		$bean->pre_pre = 0;
		$bean->apu_pais_car = 0;
		$bean->pre_ret = 0;
		$bean->pre_net = 0;
		$bean->net_afe = 0;
		$bean->ret_afe = 0;
		$bean->pre_age = 0;
		$bean->net_age = 0;
		$bean->ret_age = 0;
		$bean->pre_pv0 = 0;
		$bean->net_pv0 = 0;
		$bean->ret_pv0 = 0;
		$bean->compv_afe = 0;
		$bean->comred_afe = 0;


		// inferimos el año de la fecha	

		$mensaje="";
		$result=$this->realiza_controles($bean,$mensaje);
		if ($result){

		}else{
			$this->mostrar_msg($bean, $event, $arguments,$mensaje);
		}
			
		$GLOBALS['log']->fatal("sale funcion:"); 


				
	}
		   
		   //*********agregado hg ************
	function realiza_controles($bean,&$msj)	{

			$db = $GLOBALS['db'];

			//delete preventivo, borro todo lo anulado logicamente en Suite de pgmsorteo
			$q = "";
			$q = "delete from sor_pgmsorteo WHERE deleted = 1";	

			$results = $bean->db->query($q, true);
			$bean->db->fetchByAssoc($results);
		
			$q = "";
			$q = "SELECT coalesce(sp.id, '') AS existe FROM sor_pgmsorteo sp  WHERE sp.idjuego = '$bean->idjuego' AND ";
			$q.= "sp.nrosorteo = '$bean->nrosorteo' AND sp.deleted = 0";	

			$results = $bean->db->query($q, true);
			$row = $bean->db->fetchByAssoc($results);
			
			$valorid = 	$row['existe'];

			if ($valorid != $bean->id && $valorid != "")
            {
                $msj="El Juego Sorteo ya existe.";

				return false;
            }
            else{
            	$q = "";
				$q = "SELECT es.id as estado FROM sor_estado_pgmsorteo es ";
				$q.= "WHERE es.`idestado` = 10; ";
				$results1 = $bean->db->query($q, true);
				$row1 = $bean->db->fetchByAssoc($results1);
				$idestado = $row1['estado'];

	            $q = "";
				$q = "SELECT 'UPD' AS tipo FROM sor_pgmsorteo sor ";
				$q.= "WHERE sor.id = '$bean->id'";		
				$results2 = $bean->db->query($q, true);
				$row2 = $bean->db->fetchByAssoc($results2);
				//Si es nuevo
				if($row2['tipo'] != 'UPD'){
	            	$bean->sor_estado_pgmsorteo_id_c = $idestado;
					$bean->idestado = 10;	
	            	$bean->sorteado = 0;
	            	$bean->pozoestimadoproximo = 0;
	            	$bean->tck_afe = 0;
	            	$bean->rec_afe = 0;
	            	$bean->tck_apu = 0;
	            	$bean->rec_apu = 0;
	            	$bean->pre_res = 0;
	            	$bean->fechahora_car_date = null;
	            	$bean->fechahora_afe_date = null;
	            	$bean->sor_producto_id1_c = '';
	            	$bean->apu_afe = 0;
	            	$bean->pre_afe = 0;
	            	$bean->apu_apu = 0;
	            	$bean->fechahora_res_date = null;			
					$bean->estado_control_contab = 0;	
					$bean->valor_en_cnt = 0.0;	
					$bean->sor_emision_cerrada = 0;	
					$bean->sor_presc_recibida = 0;	
					$bean->sor_presc_contabilizada = 0;	
					$bean->tck_gan_volcados = '0';	
				}
        
				return true;
			}
	}
	
	function mostrar_msg($bean, $event, $arguments,$mensaje)
{	 		

		$_SESSION['myError']=$mensaje; 
		
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$recordId=$bean->id; 
		$action="&action=EditView"; //we need to have DetailView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['module'];      
		$offset=$_REQUEST['offset']; 
		if($offset=="") 
		{ 
		} else { 
			$offset="&offset=$offset"; 
		} 
     
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="")
		{ 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
         
		if($recordId=="") 
		{ 
			$returnAction="&return_action=EditView"; 
		} else { 
			$recordId=""; 
		} 
     
	
	
		$url="index.php?module=".$module.$action.$recordId; 

		header("Location: $url"); 

		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 

		exit;   //goto the location contained in header 
	}
	

	function updateTabla (&$bean, $event, $arguments) {
 	    include("parametros_app.php");

		$db = $GLOBALS['db'];
		
		$q = "UPDATE sor_pgmsorteo  SET tck_car = 0, apu_car = 0, rec_car = 0, pre_pre = coalesce($bean->pre_pre,0), apu_pais_car = 0,"; 
		$q.= "pre_net = coalesce($bean->pre_net,0), net_afe = 0, ret_afe = 0, pre_age = 0, net_age = 0, ret_age = 0, pre_pv0 = 0, net_pv0 = 0,";
		$q.= "ret_pv0 = 0, compv_afe = 0, comred_afe = 0, pre_ret = coalesce($bean->pre_ret,0), estado_control_contab = coalesce(estado_control_contab,0), ";
		$q.= "valor_en_cnt = coalesce(valor_en_cnt,0), sor_emision_cerrada = coalesce(sor_emision_cerrada,0), sor_presc_recibida = coalesce(sor_presc_recibida,0), ";
		$q.= "sor_presc_contabilizada = coalesce(sor_presc_contabilizada,0), tck_gan_volcados = coalesce(tck_gan_volcados,'0') ";
		$q.= "WHERE id = '$bean->id'";		

		$bean->db->query($q, true);
		
		// Si es bingo intengo agregarlo al periodo que le corresponde
		if ($bean->sor_producto_id_c == '17' or $bean->sor_producto_id_c == '18') {
			$parametros = $bean->id;
			$contMod = 0;
			try {
				$q = "CALL DIS_insert_sorteos_bin('$parametros', 1, @msgret)";
				$GLOBALS['log']->fatal("Sor_PgmSorteo - After Save - Inserta bingo en Periodo - sql ->$q<-");
					
				$mysqli2 = NEW mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm);
				$res2 = mysqli_query($mysqli2, $q); 				
						
				//$res = $mysqli2->QUERY('SELECT @msgret');
				while ($row2 = $res2->fetch_assoc()){
					
					$arrMod[$contMod][0] = $row2['msgret'];
					
					$GLOBALS['log']->fatal("Sor_PgmSorteo - After Save - Inserta bingo en Periodo -  cont: ->$contMod<-,  - row2[msgret] ->".$row2['msgret'],"<-");
					$contMod = $contMod + 1;
				}
				try {
					mysqli_free_result($res2);
				} catch (Exception $e) {}
				/*
				if ($arrMod[$contMod][0] != 'OK') {
					
				}*/
			} catch (Exception $e) {
				$GLOBALS['log']->fatal("Sor_PgmSorteo - After Save - Inserta bingo en Periodo - Excepción  ->".$e->getMessage()."<-");
				die();
			}		
		}
	}
}
?>