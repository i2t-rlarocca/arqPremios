<?php 

$hook_version = 1; 
$hook_array = Array(); 
// position, file, function 
$hook_array['before_save'] = Array(); 
$hook_array['before_save'][] = Array(1, 'mensaje', 'custom/modules/SOR_pgmsorteo/logic_hooks_impl.php', 'logic_hooks_impl', 'mensajes_list'); 
$hook_array['after_save'] = Array(); 
$hook_array['after_save'][] = Array(1, 'mensaje', 'custom/modules/SOR_pgmsorteo/logic_hooks_impl.php', 'logic_hooks_impl', 'updateTabla'); 

?>