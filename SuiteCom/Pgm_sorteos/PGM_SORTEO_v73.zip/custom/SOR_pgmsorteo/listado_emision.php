<?php
    include('parametros_app.php');

    $msgerr = $_SESSION['msgerr'];
    $offset = $_REQUEST['offset'];
    $stamp  = $_REQUEST['stamp'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <title>Emisiones</title> -->
    <!-- <style> 
        body {
            font-family: sans-serif, Arial;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
        }
        .emisiones {
            list-style-type: none;
            padding: 0;
        }
        .emision {
            margin-bottom: 10px;
        }
        .emision span {
            font-weight: bold;
        }
    </style> -->
    
    <style>
        body {
            /* font-family: sans-serif, Arial;   */
            font-family: sans-serif;      
        }        
    </style>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- <div class="container"> -->
    <div class="container mt-5 bg-light">
        <!-- <h2>Resumen de Emisiones</h2> -->
        <!-- <h2 class="mb-4 ms-4 text-danger">Emisiones que no pueden ser procesadas</h2> -->
        <h2 class="mb-4 ms-4 text-danger">Resultado del proceso</h2>
        <?php        
            // Dividir la cadena en líneas
            $lineas = explode("\n", $msgerr);
            
            // Imprimir cada línea como un elemento de lista HTML
            // echo "<ul class='emisiones'>";
            echo "<ul class='list-group'>";
            foreach ($lineas as $linea) {

                // Extraer el valor del estado                
                // preg_match("/ESTADO:\s*(\S(?:.*\S)?)\s*$/", $linea, $matches);
                preg_match("/ESTADO:\s*([^-\n]+)/", $linea, $matches); //  buscará la palabra "ESTADO:" seguida de cualquier cantidad de espacios, seguida del valor del estado
                
                $estado = isset($matches[1]) ? $matches[1] : '';               
                // $GLOBALS['log']->fatal("Valor del estado: " . $estado);

                // Resaltar el valor del estado en rojo
                if ($estado) {
                    $linea = str_replace($estado, "<span class='text-danger fw-bold text-uppercase'>$estado</span>", $linea);
                }

                // echo "<li class='emision'>$linea</li>";
                echo "<li class='list-group-item fw-bold fs-6'>$linea</li>";
            }
            echo "</ul>";
        ?>

        <input name="offset" type="hidden" id="offset" value="<?php echo $offset; ?>">	
        <input name="stamp" type="hidden" id="stamp" value="<?php echo $stamp; ?>">	      
        <input name="cancelar" type="button" id="btn_cancelar"  class="btn btn-outline-primary ms-4 mt-4 mb-2 fs-6" value="Volver" onclick="volver('<?php echo $url_crm;?>');"/>	
    </div>

    <script type="text/javascript">
		function volver(url_crm){
			window.location ="http://"+url_crm+"/index.php?module=SOR_pgmsorteo";			
		}
	</script>
    <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>

</body>
</body>
</html>