<?php

require_once('include/MassUpdate.php');

class CustomSOR_pgmsorteoController extends SugarController
{
	public function action_cerrar_premios() {
		$GLOBALS['log']->fatal("CIERRE EMISION PREMIOS - ENTRO");
		include('parametros_app.php');
		$recordIds=array();
		
		$param_idjuego=99;
		//$param_sor = "3".date("m").date("Y")."04";
		$param_sor = date("y").date("m").date("d").date("H").date("i");
		$operador = '1';
		file_put_contents("log_cierre_prescripcion.txt","param_sor:" . $param_sor . "\n",FILE_APPEND);

		//Obtiene ID de prn_proceso
		$conexion=mysqli_connect($servidor_crm,$usuario_crm ,$password_crm,$bd_crm) or	die("Problemas con la conexión");
		$datos_de_conexion=$servidor_crm.'|'.$usuario_crm.'|'.$password_crm.'|'.$bd_crm;
		$GLOBALS['log']->fatal("CIERRE EMISION PREMIOS - INICIO - datos_de_conexion ->".$datos_de_conexion."<-");
		
		/********* 		obtiene idProceso		***********/
		$query="SELECT getNuevoProcesoAuditoria() AS idProceso;";
		$result = mysqli_query($conexion, $query); 
		
		while ($fila = mysqli_fetch_array($result)) {
			$idProceso = $fila['idProceso'];
		}
		mysqli_free_result($result);
		//file_put_contents("log_cierre_prescripcion.txt","idProceso:" . $idProceso . "\n",FILE_APPEND);
		$GLOBALS['log']->fatal("CIERRE EMISION PREMIOS - ID PROCESO ->".$idProceso."<-");

		$id_ordenpago = 'NA';
		$opc = 4;	
		// RECUPERO LOS IDs DE SORTEOS SELECCIONADOS
		if ( !empty($_REQUEST['uid']) ) {
			$recordIds = explode(',',$_REQUEST['uid']);//IDS DE LOS RESULTADOS
			$db = $GLOBALS['db'];
			
			$mensajeVista = 0;
		}
		
		$GLOBALS['log']->fatal("CIERRE EMISION PREMIOS - LISTA SORTEOS ->".$recordIds."<-");

		/*********************************/
		// proceso que realiza el cierre
		/*********************************/
		$x = 0;
		$al_menos_uno = 0;
		foreach ($recordIds as $idResultado) {
			$mysqli = NEW mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm);

			// Obtener datos del sorteo 
			$sql0="SELECT pgm.NAME AS nombre, pgm.idjuego AS juego, pgm.nrosorteo AS sorteo FROM sor_pgmsorteo pgm WHERE pgm.deleted = 0 and pgm.id='".$idResultado."';";
			// $GLOBALS['log']->fatal("sql0->".$sql0);
			$res0 = $mysqli->query($sql0);
			$results0 = $res0->fetch_assoc();
			$juego = $results0['juego'];
			$sorteo = $results0['sorteo'];
			
			$GLOBALS['log']->fatal("CIERRE EMISION PREMIOS - GET DATOS DEL SORTEO ->".$idResultado."<- - SQL ->".$sql0."<- - JUEGO-SORTEO ->".$juego."-".$sorteo);
				
			// Auditoria
			// Audito ev 80 Inicio Cierre y Prescripcion de Emision 
			$mysqli0 = NEW mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm);
			$sqlaudit='CALL sor_inserta_auditoria('.$idProceso.','.$juego.','.$sorteo.',80,"'.$operador.'",80,81,"Cierre de Premios - INICIO - sorteo: '.$sorteo.', producto: '.$juego.'")';
			$resultaudit = mysqli_query($mysqli0, $sqlaudit); 
			mysqli_free_result($sqlaudit);

			// Audito ev 81 Validación de sorteo
			$mysqli2 = NEW mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm);
			$sqlaudit='CALL sor_inserta_auditoria('.$idProceso.','.$juego.','.$sorteo.',81,"'.$operador.'",80,82,"Cierre de Premios - VALIDACION - sorteo: '.$sorteo.', producto: '.$juego.'");';
			$resultaudit = mysqli_query($mysqli2, $sqlaudit); 
			mysqli_free_result($sqlaudit);
				
			/************ llamado a SP PREMIOS_CIERRE_presc_emision params: idsorteo y opcion 4		************/
			
			$mysqli3 = NEW mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm);
			$sql="CALL PREMIOS_CIERRE_presc_emision('".$idResultado."','".$id_ordenpago."','".$idProceso."','".$opc."', @msgerr);";
			$GLOBALS['log']->fatal("CIERRE EMISION PREMIOS - Ejecuta el cierre opc 4 - sql->".$sql."<-");
			$result2 = mysqli_query($mysqli3, $sql); 
				
			$res = $mysqli3->QUERY('SELECT @msgerr');
			$result2 = $res->fetch_assoc();
			$out_finProcesoCierre = $result2['@msgerr'];
			mysqli_free_result($result2);
			mysqli_free_result($res);
				
			if ($out_finProcesoCierre == 'OK') {
				// Audito ev 83 Fin Cierre Premios OK
				$mysqli5=mysqli_connect($servidor_crm,$usuario_crm ,$password_crm,$bd_crm) or	die("Problemas con la conexión");
				$sqlaudit='CALL sor_inserta_auditoria('.$idProceso.','.$juego.','.$sorteo.',83,"'.$operador.'",82,84,"Cierre de Premios - FIN CORRECTO - sorteo: '.$sorteo.', producto: '.$juego.'");';
				$resultaudit = mysqli_query($mysqli5, $sqlaudit); 
				mysqli_free_result($sqlaudit);
			}else{
				// Audito ev 88 Fin Cierre Y Prescripción de Emisión con ERROR
				$mysqli9=mysqli_connect($servidor_crm,$usuario_crm ,$password_crm,$bd_crm) or	die("Problemas con la conexión");
				$sqlaudit='CALL sor_inserta_auditoria('.$idProceso.','.$juego.','.$sorteo.',88,"'.$operador.'",82,0,"Cierre de Premios - FIN ERRONEO ('.$out_finProcesoCierre.') - sorteo: '.$sorteo.', producto: '.$juego.'");';
				$resultaudit = mysqli_query($mysqli9, $sqlaudit); 
				//$GLOBALS['log']->fatal("sql->".$sqlaudit);
				mysqli_free_result($sqlaudit);
			}
			mysqli_free_result($results0);
			$al_menos_uno = $al_menos_uno + 1;
		} // fin de foreach

		if ($al_menos_uno > 0){
			echo "Inicio Proceso Cierre...";

			// se genera grilla para la siguiente pantalla CUMPLEN
			$noCumplen=Array(); 
			$Cumplen=Array(); 
			//$urlReporte = 'http://devcas.i2tsa.com.ar/suitecrm_dev';
			$urlReporte = $protocolo.$servidor_jasper."/Ejecutar_Reportes2.php?ruta_reporte=/Reports/CAS/Premios/Resumen_emision/inf_resumen_emision&formato=PDF&param_modo=C&param_idpgm=";
			$db = $GLOBALS['db'];
			$db2 = $GLOBALS['db'];
			$query = "SELECT  
				idproceso,COALESCE(aud.id,'') AS idauditoria,
				p.name AS producto,
				id_sorteo, 
				nro_sorteo,
				juego,
				cod_estado,
				estadoproc,
				MAX(t.date_modified) AS ultima_modificacion
			FROM tmp_estado_proc_cierre_emis_presc t
			LEFT JOIN sor_aud_consolidacion aud ON aud.id_pro_consolidacion = t.idproceso
			INNER JOIN sor_pgmsorteo ps ON ps.id = t.id_sorteo
			INNER JOIN sor_producto p ON p.id = ps.sor_producto_id_c
			WHERE cod_estado != '0' AND idproceso = '".$idProceso."' 
			GROUP BY idproceso, p.name, id_sorteo, nro_sorteo, juego, cod_estado, estadoproc  
			ORDER BY p.name, nro_sorteo, MAX(t.date_modified) DESC;"
			;
			$query2 = "SELECT  
					idproceso,COALESCE(aud.id,'') AS idauditoria,
					p.name AS producto,
					id_sorteo, 
					nro_sorteo,
					juego,
					cod_estado,
					estadoproc,
					MAX(t.date_modified) AS ultima_modificacion
				FROM tmp_estado_proc_cierre_emis_presc t
				LEFT JOIN sor_aud_consolidacion aud ON aud.id_pro_consolidacion = t.idproceso
				INNER JOIN sor_pgmsorteo ps ON ps.id = t.id_sorteo
				INNER JOIN sor_producto p ON p.id = ps.sor_producto_id_c
				WHERE cod_estado = '0' AND idproceso = '".$idProceso."' 
				GROUP BY idproceso, p.name, id_sorteo, nro_sorteo, juego, cod_estado, estadoproc  
				ORDER BY p.name, nro_sorteo, MAX(t.date_modified) DESC;"
			;
			//$GLOBALS['log']->fatal("CIERRE EMISION PREMIOS - while Cumplen  dato2->".$query2."<-");
			$result = $db->query($query);
			$result2 = $db2->query($query2);
				
			//file_put_contents("log_cierre_prescripcion.txt",$datos." datos",FILE_APPEND);
			while (  $dato=$db->fetchByAssoc($result) ) {
				$noCumplen[] = $dato;
			}
			mysqli_free_result($query);
			
			while (  $dato2=$db2->fetchByAssoc($result2) ) {
				$Cumplen[] = $dato2;
			}
			mysqli_free_result($query2);
			
			$_SESSION['noCumplen']=$noCumplen;
			$_SESSION['Cumplen']=$Cumplen;
			$_SESSION['urlReporte']=$urlReporte;

			$url = "index.php?module=SOR_pgmsorteo&action=sorteos_no_cumplen&offset=".$_REQUEST['offset']."&stamp=".$_REQUEST['stamp'];//."&return_module=gar_Poliza&action=index";
			header("Location:".$url);
			/*$urlAuditoria=$url_crm."/index.php?module=SOR_aud_consolidacion&return_module=SOR_aud_consolidacion&action=DetailView&record=";

			foreach($Cumplen as $e2){
			  //echo "<tr><td>".$e2['idauditoria']." - ".$e2['idproceso']."</td><td>".$e2['producto']."</td><td>".$e2['nro_sorteo']."</td><td>".$e2['estadoproc']."</td><td><div><a href=".$urlReporte.$e2['id_sorteo']." target='_blanck'>Reporte Resumen de Emisiones</a></div></td></tr>";
			  echo "<tr><td><div><a href=".$urlAuditoria.$e2['idauditoria']." target='_blanck'>".$e2['idproceso']."</a></div></td><td>".$e2['producto']."</td><td>".$e2['nro_sorteo']."</td><td>".$e2['estadoproc']."</td><td><div><a href=".$urlReporte.$e2['id_sorteo']." target='_blanck'>Reporte Resumen de Emisiones</a></div></td></tr>";
			}
			*/
			exit;
			
		}else{
			echo "Error Inicio Proceso Cierre.";
		}
	}
	
	// PROCESAR PRESCRIPCION en Ctas Ctes Pcias 
	public function action_cerrar_ctasctes_pcias(){
		include("parametros_app.php");
		$GLOBALS['log']->fatal("action_cerrar_ctasctes_pcias - ENTRO");
		if (!empty($_REQUEST['uid'])) {
			$recordIds=array();
			if ($_REQUEST['select_entire_list']) {
                $GLOBALS['log']->fatal("action_cerrar_ctasctes_pcias - if");
				$mass = new MassUpdate();
				
				$bean = $GLOBALS['app']->controller->bean;
				$mass->setSugarBean($bean);    
				$module=$bean->module_dir;
				$mass->generateSearchWhere($module, $_REQUEST['current_query_by_page']);
				
				$op=$bean->get_full_list('',$mass->where_clauses);
				foreach ($op  as $record ) {
					$recordIds[]=$record->id;
				}
			}else{
                $GLOBALS['log']->fatal("action_cerrar_ctasctes_pcias - else");
				if (!empty($_REQUEST['uid'])) {
						$recordIds = explode(',',$_REQUEST['uid']);//IDS DE LOS RESULTADOS
				}
			}	
		}
        $GLOBALS['log']->fatal("action_cerrar_ctasctes_pcias - recordIds: ".$recordIds);

        // Llamar al metodo generarNCPcias
        $this->generarNCPcia($recordIds);        
      
	}
    public function generarNCPcia($recordIds){
        $GLOBALS['log']->fatal("generarNCPcia - inicio". print_r($recordIds,true));
        
        include("parametros_app.php");
        
		// Recorrer cada elemento en $recordIds y agregar comillas
		$lstIDsPgmSorteos = array();				
		foreach ($recordIds as $recordId) {
			$lstIDsPgmSorteos[] = "'" . $recordId . "'";
		}
		
        // Crear la conexi&oacute;n a la base de datos
        $mysqli = $this->connectToDatabase($servidor_crm, $usuario_crm, $password_crm, $bd_crm);

        if ($mysqli) {			
			//********* 		obtiene idProceso		***********
			$query="SELECT getNuevoProcesoAuditoria() AS idProceso;";
			$result = mysqli_query($mysqli, $query); 
		
			while ($fila = mysqli_fetch_array($result)) {
				$idProceso = $fila['idProceso'];
			}
			mysqli_free_result($result);
			
			$GLOBALS['log']->fatal("generarNCPcia - ID PROCESO ->".$idProceso."<-");
			/*
			// OBTENER ID PROCESO
			$param_idjuego = 99;		
			$param_sor     = date("y").date("m").date("d").date("H").date("i");	
						
			$query1="SELECT getNuevoProcesoAuditoria() AS idProceso";

			// Preparar la consulta
			$stmt = $mysqli->prepare($query1);
			
			// Verificar si hubo errores en la preparación
			if (!$stmt) {
				die("Error de preparación de la consulta: " . $mysqli->error);
			}

			// Vincular los parámetros
			$stmt->bind_param("ii", $param_idjuego, $param_sor);
			
			// Ejecutar la consulta
			$stmt->execute();

			// Obtener el idProceso
			$resultado1 = $stmt->get_result();

			// Verificar si hay filas en el resultado1
			if ($resultado1->num_rows > 0) {
				// Obtener la fila como un array asociativo
				$fila = $resultado1->fetch_assoc();

				// Obtener el valor de idProceso
				$param_id_proceso = $fila['idProceso'];

				// Mostrar el resultado1
				// echo "ID Proceso: " . $idProceso;
				$GLOBALS['log']->fatal("generarNCPcia - param_id_proceso: ", $param_id_proceso);
			} else {
				// echo "No se encontraron resultados";
				$GLOBALS['log']->fatal("generarNCPcia - no se encontro param_id_proceso: ", $param_id_proceso);
			}            
			*/
			
			// CALL PREMIOS_CIERRE_presc_emision_NC
			if($idProceso){
				/*
				// Preparo call 
				$call = $mysqli->prepare('CALL PREMIOS_CIERRE_presc_emision_NC(?, ?, ?, ?, @msgerr);');
           
				if (!$call) {
					$GLOBALS['log']->fatal("generarNCPcia - Error en la preparación de la consulta: " . $mysqli->error);
					echo "Error: No se pudo preparar la consulta.";
					return;
				} */
				// Parametros para CALL
				$param_lst_str_ids = '"'.implode(',', $lstIDsPgmSorteos).'"' ;
				$param_id_proceso = $idProceso;
				$param_opc = 5;
				$param_idUsuario = '1';
				$param_idUsuario = $GLOBALS['current_user']->id;
				$GLOBALS['log']->fatal("generarNCPcia - param_lst_str_ids: " .print_r($param_lst_str_ids,true). " param_id_proceso: " .$param_id_proceso. " param_opc: ".$param_opc. " param_idUsuario: ".$param_idUsuario);
				
				//$call->bind_param('sii', $param_lst_str_ids, $param_id_proceso, $param_opc, $param_idUsuario);
				//$GLOBALS['log']->fatal("generarNCPcia - call.queryString: ".$call->queryString);
				//$call->execute();

			$mysqli3 = NEW mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm);
			$sql="CALL PREMIOS_CIERRE_presc_emision_NC(".$param_lst_str_ids.", ".$param_id_proceso.", ".$param_opc.", '".$param_idUsuario."', @msgerr);";
			$GLOBALS['log']->fatal("generarNCPcia - Ejecuta SP  - sql->".$sql."<-");
			$result2 = mysqli_query($mysqli3, $sql); 


			// Obtener el resultado de la llamada al procedimiento almacenado
			$res = $mysqli3->QUERY('SELECT @msgerr');
			$result2 = $res->fetch_assoc();
			$msgerr = $result2['@msgerr'];
			/*
				// Obtener el resultado de la llamada al procedimiento almacenado
				$query2     = $mysqli->query('SELECT @msgerr');				
				
				$resultado2 = $query2->fetch_assoc();
	
				// Acceder a los resultados obtenidos
				$msgerr = $resultado2['@msgerr'];	
			*/
				$GLOBALS['log']->fatal("generarNCPcia - msgerr ->".$msgerr."<-");
				$mysqli->close();
				//$msgerr = "FIN OK";
				
				// Envio el mensaje por variable de sesion a listado_emision
				$_SESSION['msgerr']=$msgerr;
				$noCumplen=Array(); 
				$Cumplen=Array(); 
				$urlReporte = ""; // $protocolo.$servidor_jasper."/Ejecutar_Reportes2.php?ruta_reporte=/Reports/CAS/Premios/Resumen_emision/inf_resumen_emision&formato=PDF&param_modo=C&param_idpgm=";
				//$url_listado = "index.php?module=SOR_pgmsorteo&action=listado_emision&offset=".$_REQUEST['offset']."&stamp=".$_REQUEST['stamp'];
				//header("Location:".$url_listado);
				//exit;
				if (substr($msgerr,0,2) == "OK"){
					$db = $GLOBALS['db'];
					$db2 = $GLOBALS['db'];

					$query2 = "SELECT  
						idproceso,COALESCE(aud.id,'') AS idauditoria,
						p.name AS producto,
						id_sorteo, 
						nro_sorteo,
						juego,
						cod_estado,
						estadoproc,
						MAX(t.date_modified) AS ultima_modificacion
					FROM tmp_estado_proc_cierre_emis_presc t
					LEFT JOIN sor_aud_consolidacion aud ON aud.id_pro_consolidacion = t.idproceso
					INNER JOIN sor_pgmsorteo ps ON ps.id = t.id_sorteo
					INNER JOIN sor_producto p ON p.id = ps.sor_producto_id_c
					WHERE cod_estado = '0' AND idproceso = '".$param_id_proceso."' 
					GROUP BY idproceso, p.name, id_sorteo, nro_sorteo, juego, cod_estado, estadoproc  
					ORDER BY p.name, nro_sorteo, MAX(t.date_modified) DESC;"
					;
					//$GLOBALS['log']->fatal("CIERRE EMISION PREMIOS - while Cumplen  dato2->".$query2."<-");
					//$result = $db->query($query);
					$result2 = $db2->query($query2);
					while (  $dato2=$db2->fetchByAssoc($result2) ) {
						$Cumplen[] = $dato2;
					}
					mysqli_free_result($query2);
				}
				$_SESSION['noCumplen']=$noCumplen;
				$_SESSION['Cumplen']=$Cumplen;
				$_SESSION['urlReporte']=$urlReporte;

				$url = "index.php?module=SOR_pgmsorteo&action=ctasctes_pcias_resul_prescripcion&offset=".$_REQUEST['offset']."&stamp=".$_REQUEST['stamp'];//."&return_module=gar_Poliza&action=index";
				header("Location:".$url);
				exit;
			}			           
        }      
        //$GLOBALS['log']->fatal("generarNCPcia - fin");
        // Cerrar las consulta y la conexion a la base de datos
		//$stmt->close();
		//$call->close();
		//$mysqli->close();
    }

	public function action_seguimiento() {
		
		include('parametros_app.php');
		
		$recordIds=array();
		
		// RECUPERO LOS IDE DE SORTEOS	SELECCIONADOS
		if ( !empty($_REQUEST['uid']) ) {
			$recordIds = explode(',',$_REQUEST['uid']);//IDS DE LOS RESULTADOS
		}

		$cant_array=count($recordIds);

		if($cant_array == 1){
			foreach ($recordIds as $idResultado) {
				$url = $protocolo.$servidor_jasper."/Ejecutar_Reportes2.php?ruta_reporte=/Reports/CAS/Premios/Resumen_emision/inf_resumen_emision&formato=PDF&param_idpgm=".$idResultado."&param_modo=C";
				echo "<script language=\"javascript\">window.open(\"$url\",\"_blank\");</script>";
				$url2 = "Refresh: 0; url=".$protocolo.$url_crm."/index.php?module=SOR_pgmsorteo";
				header($url2, true, 303);
			}
		}else{
			echo "Seleccione solo un sorteo para visualizar el reporte.";
			$url2 = "Refresh: 0; url=".$protocolo.$url_crm."/index.php?module=SOR_pgmsorteo"; // .$_REQUEST['modulo_act']
			header($url2, true, 303);
			exit; 
		}
			/*
			$reporte=$_REQUEST['id_reporte'];
			$url = "http://$servidor_jasper/cas/pgm_sorteos/informeAcciones.php?id_reporte=".$reporte;
			echo "<script language=\"javascript\">window.open(\"$url\",\"_blank\");</script>";

			$url2 = "Refresh: 0; url= http://$url_crm/index.php?module=".$_REQUEST['modulo_act'];
			header($url2, true, 303);

			exit; 
			*/
	}
	
	public function action_republicarExtracto() {
	//Asignación de lotes a cuotas.
	require_once('data/BeanFactory.php');
	require_once('premios_funciones.php');
	include('parametros_app.php');
	
	
	$recordIds=array();
	
	if ( !empty($_REQUEST['uid']) ) {
		$recordIds = explode(',',$_REQUEST['uid']);//IDS DE LOS RESULTADOS
	}
	echo "<h5>Proceso de Republicar Extracto JAVAREST.</h5>";
	foreach ($recordIds as $idResultado) {
		//$bCuota = BeanFactory::getBean("PRE_Premios_Cuotas", $idResultado);
		//SELECT NAME AS juego_sorteo FROM sor_pgmsorteo WHERE id = 'd46df804-ccac-11e8-8c7a-000c29c52daa';
	$mysqli3 = NEW mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm);
	$sql = "SELECT NAME AS juego_sorteo FROM sor_pgmsorteo WHERE id = '$idResultado';";
	$res0 = $mysqli3->query($sql);
	$row = $res0->fetch_assoc();
	$juegoSorteo = $row['juego_sorteo'];
	mysqli_free_result($res0);

		$ctx = stream_context_create(array('http'=>
		array(
			'timeout' => 600,  //10 Minutos
			)
		));
		
		file_put_contents('RepublicarExtracto.log', '***COMIENZA EJECUCION**** \n', FILE_APPEND);
		$baseURL=$url_webservice_premios_rest.$idResultado;
		file_put_contents('RepublicarExtracto.log', '***LLamado**** \n'.$baseURL, FILE_APPEND);
	
		$jsonResponse =file_get_contents($baseURL,false,$ctx);
		$response = json_decode($jsonResponse);
		
		file_put_contents('RepublicarExtracto.log',"Sorteo ".$juegoSorteo." - ".$response->msg, FILE_APPEND);
		echo("<h5>Sorteo ".$juegoSorteo." procesado. Mensaje: ".$response->msg."</h5>");
	}	
		 echo "<h5>Se ejecutó el proceso Republicar Extracto en forma Correcta</h5>";
		 file_put_contents('RepublicarExtracto.log', '***TERMINO EJECUCION**** \n', FILE_APPEND);

	//echo "<h5><a href=\"".$url_app."index.php?module=PRE_Premios_Cuotas&action=index\">Volver a Consulta de Premios Cuotas</a></h5>";
	echo "<h5><a href=\"index.php?module=SOR_pgmsorteo&action=index\">Volver a Programa Sorteo</a></h5>";
	// echo "<h3><a href=\"".$url_crm."/index.php?module=PRE_Premios_Cuotas&action=index\">Volver a Consulta de Premios Cuotas</a></h3>";
	// header("Refresh:10; URL=index.php?module=PRE_Premios_Cuotas&action=index");

	exit;
}
		/*
		public function action_prescribirSorteo() {
				
			include('parametros_app.php'); 
			$recordIds=array();
			$recordIds50=array();
			
						$param_idjuego=99; // no refleja el juego lotería (50) usamos 99 para generar el id para auditoría
						$param_sor = date("y").date("m").date("d").date("H").date("i");
						$operador = '1';
						file_put_contents("log_prescribirSorteo.txt","param_sor:" . $param_sor . "\n",FILE_APPEND);

						//Obtiene ID de prn_proceso
						$conexion=mysqli_connect($servidor_crm,$usuario_crm ,$password_crm,$bd_crm) or	die("Problemas con la conexión");
						$datos_de_conexion=$servidor_crm.'|'.$usuario_crm.'|'.$password_crm.'|'.$bd_crm;

						
						$query="SELECT getProcesoAuditoriaCtaCte(".$param_idjuego.",".$param_sor.") AS idProceso;";
						$result = mysqli_query($conexion, $query); 
						
						while ($fila = mysqli_fetch_array($result)) {
							$idProceso = $fila['idProceso'];
						}
						mysqli_free_result($result);
						
						file_put_contents("log_prescribirSorteo.txt","idProceso:" . $idProceso . "\n",FILE_APPEND);

						// concurencia
						
						$conexion=mysqli_connect($servidor_crm,$usuario_crm ,$password_crm,$bd_crm_adm) or	die("Problemas con la conexión");
						$datos_de_conexion=$servidor_crm.'|'.$usuario_crm.'|'.$password_crm.'|'.$bd_crm;

						
						$query="SELECT getProcesoAuditoriaCtaCte(".$param_idjuego.",".$param_sor.") AS idProceso;";
						$result = mysqli_query($conexion, $query); 
						
						while ($fila = mysqli_fetch_array($result)) {
							$idProceso = $fila['idProceso'];
						}
						mysqli_free_result($result);
						
						file_put_contents("log_prescribirSorteo.txt","idProceso:" . $idProceso . "\n",FILE_APPEND);
						// aqui 
			
						$user='1';
						$tabla='users';
						$mysqli3 = NEW mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm_adm);
						$sql="CALL SP_ET_ConcurrenciaGET('".$user."','".$user."','".$tabla."','".$opc."', @msgerr);";
						
						file_put_contents("log_prescribirSorteo.txt","sql:" . $sql . "\n",FILE_APPEND);
						
						$result2 = mysqli_query($mysqli3, $sql); 
						$GLOBALS['log']->fatal("sql->".$sql);
							
						$res = $mysqli3->QUERY('SELECT @msgerr');
						$result2 = $res->fetch_assoc();
						$out_finProcesoCierre = $result2['@msgerr'];
						mysqli_free_result($result2);
						mysqli_free_result($res);
							
						if ($out_finProcesoCierre == 'OK') {
					
					
					
					
					
					// RECUPERO LOS IDE DE SORTEOS	SELECCIONADOS 50
					if ( !empty($_REQUEST['uid']) ) {
						$recordIds = explode(',',$_REQUEST['uid']);//IDS DE LOS RESULTADOS
						$db = $GLOBALS['db'];
						
						$mensajeVista = 0;
						$id_ordenpago = 'NA';
						$opc = 4;
					}

					file_put_contents("log_prescribirSorteo.txt","recordIds:" . $recordIds . "\n",FILE_APPEND);

					$x = 0;
					foreach ($recordIds as $idResultado) {

						file_put_contents("log_prescribirSorteo.txt","idResultado: ".$idResultado."\n",FILE_APPEND);
						$mysqli = NEW mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm);
							
								// esto funciona
							
							//		$sql="UPDATE sor_pgmsorteo SET sor_emision_cerrada=5 where id='".$idResultado."' and sor_emision_cerrada=0";
							//		$GLOBALS['log']->fatal("sql->".$sql);
							//  	$results = $db->query($sql, true);
								

				file_put_contents("log_prescribirSorteo.txt","idResultado:" . $idResultado . "\n",FILE_APPEND);
						

				$sql0="SELECT pgm.NAME AS nombre, pgm.idjuego AS juego, pgm.nrosorteo AS sorteo FROM sor_pgmsorteo pgm WHERE pgm.deleted = 0 and pgm.id='".$idResultado."';";
				$GLOBALS['log']->fatal("sql0->".$sql0);
				$res0 = $mysqli->query($sql0);
				$results0 = $res0->fetch_assoc();
				$juego = $results0['juego'];
				$sorteo = $results0['sorteo'];
				
				if($juego == '50'){
					
					 array_push($recordIds50, $idResultado);
					
						file_put_contents("log_prescribirSorteo.txt","juego: " . $juego . " sorteo: " . $sorteo . " id:". $idResultado ."\n",FILE_APPEND);
					
				}
				
			

			
			}
	}
	}
	*/

  // Establece la conexion con la base de datos
    public function connectToDatabase($servidor_crm, $usuario_crm, $password_crm, $bd_crm) {
        $mysqlii = new mysqli($servidor_crm, $usuario_crm, $password_crm, $bd_crm);
    
        if ($mysqlii->connect_errno) {
            $GLOBALS['log']->fatal("Error al conectar a BD Codigo -> " . $mysqlii->errno . " <- Msg -> " . $mysqlii->error . " <-");
            echo "Ha ocurrido una excepci&oacute;n al intentar conectar a la base de datos. Intente mas tarde o consulte a Soporte.";
            return null;
        }
    
        return $mysqlii;
    }
}
?>