<?php
include('parametros_app.php');

$noCumplen=$_SESSION['noCumplen'];
$Cumplen=$_SESSION['Cumplen'];
$urlReporte=$_SESSION['urlReporte'];
$urlAuditoria=$url_crm."/index.php?module=SOR_aud_consolidacion&return_module=SOR_aud_consolidacion&action=DetailView&record=";

$GLOBALS['log']->fatal("CIERRE EMISION PREMIOS - while Cumplen  urlAuditoria->".$urlAuditoria."<-");

$offset=$_REQUEST['offset'];
$stamp=$_REQUEST['stamp'];

?>
<html>
    <head>
	       <title></title>
		 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	</head>
	<script type="text/javascript">
		function volver(url_crm){
			window.location ="http://"+url_crm+"/index.php?module=SOR_pgmsorteo";			
		}
	</script>
	<body >
		<div id="LBL_DETAILVIEW_PANEL1" class="detail view">
	
			<div id="detailviews" class="dell"> 
			
				<form class="clase_baja"  name="baja" action="http://<?php echo $url_crm; ?>/index.php?module=SOR_pgmsorteo&action=" method="POST" id="baja">
					
						<?php if(!empty($Cumplen)){ ?>
							<table>
							<tr><div><h4 style="color:green"><B>CIERRES DE PREMIOS CORRECTOS:</B></h4></div>
							<div id="div_select_baja">
								<?php 
									echo "<table border=1><tr><td><strong>Proceso</strong></td><td><strong>Producto</strong></td></td><td><strong>Sorteo</strong></td><td><strong>Estado</strong></td><td><strong>Reporte Seguimiento</strong></td></tr>";
									foreach($Cumplen as $e){
									  echo "<tr><td><div><a href=https://".$urlAuditoria.$e['idauditoria']." target='_blanck'>".$e['idproceso']."</a></div></td><td>".$e['producto']."</td><td>".$e['nro_sorteo']."</td><td>".$e['estadoproc']."</td><td><div><a href=".$urlReporte.$e['id_sorteo']." target='_blanck'>Reporte Resumen de Emisiones</a></div></td></tr>";
									}
								?>
							</div>	
							</tr>
							</table>
						<?php }?>
						
						<?php if(!empty($noCumplen)){ ?>
							<table>
							<tr><div><h4 style="color:red"><B>CIERRES DE PREMIOS FALLIDOS:</B></h4></div>
							<div id="div_select_baja">
								<?php 
									echo "<table border=1><tr><td><strong>Proceso</strong></td><td><strong>Producto</strong></td></td><td><strong>Sorteo</strong></td><td><strong>Estado</strong></td><td><strong>Reporte Seguimiento</strong></td></tr>";
									foreach($Cumplen as $e2){
									  echo "<tr><td><div><a href=https://".$urlAuditoria.$e2['idauditoria']." target='_blanck'>".$e2['idproceso']."</a></div></td><td>".$e2['producto']."</td><td>".$e2['nro_sorteo']."</td><td>".$e2['estadoproc']."</td><td><div><a href=".$urlReporte.$e2['id_sorteo']." target='_blanck'>Reporte Resumen de Emisiones</a></div></td></tr>";
									}
								?>
							</div>	
							</tr>
							</table>
						<?php }?>
						
						<?php if(empty($Cumplen) && empty($noCumplen)){ ?>
							<table>
							<tr><div><h4 style="color:blue"><B>No hay detalles para mostrar.</B></h4></div>
							</tr>
							</table>
						<?php }?>
						
						<?php /*if(!empty($urlReporte)){ ?>	
						
						<table>
							<tr><div><h4>Reporte de sorteos cerrados:</h4></div>
							<div id="div_select_no_baja">
								<?php 
							//	echo "<div><a href=".$urlReporte.">Listado de Resumen de Emisiones Cerradas</a></div>";
								//echo "<table border=1><tr><td><strong>Nº Póliza</strong></td></tr>";
								//foreach($noCambiaEstadoProcesado as $e){
								//  echo "<tr><td>".$e."</td><tr>";
								//}
								?>
							</div>	
							</tr>
						</table>
						<?php }
						*/
						?>
						
						<input name="offset" type="hidden" id="offset" value="<?php echo $offset; ?>">	
						<input name="stamp" type="hidden" id="stamp" value="<?php echo $stamp; ?>">										
						<!-- <input  type="submit" value="Aceptar"/> -->
						<input name="cancelar" type="button" id="btn_cancelar" value="Volver" onclick="volver('<?php echo $url_crm;?>');"/>					
					
				</form>
			</div>			
		</div>
		
		<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
				
    </body>
	
</html>
