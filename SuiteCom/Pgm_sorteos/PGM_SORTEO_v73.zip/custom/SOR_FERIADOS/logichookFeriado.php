<?php
class logichookFeriado{
function asigna_orden ($bean, $event, $arguments)
{
	 $dia= date("w", strtotime($bean->fecha));
	
	$bean->codigo=$dia+1;
	
	
}

}
?>