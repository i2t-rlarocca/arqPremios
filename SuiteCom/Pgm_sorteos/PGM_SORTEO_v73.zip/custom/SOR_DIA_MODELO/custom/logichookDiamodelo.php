<?php
class logichookDiamodelo{
function elimina_diamodelo ($bean, $event, $arguments)
{
	$this->actualiza_version_meses($bean,"Elimina");
}
function asigna_nombre ($bean, $event, $arguments)
{
   
	if ($bean->id!= $bean->fetched_row['id'])
	{
	// es un ingreso
		$resultado=$this->realiza_controles($bean,$mensaje);
		if(!($resultado)){
			$this->mostrar_msg($bean, $event, $arguments,$mensaje);
		}
		$this->actualiza_version_meses($bean,"Alta");
		
	}else{// si cambio algun parametro
		if(($bean->sor_dias_id_c!= $bean->fetched_row['sor_dias_id_c']) ||($bean->sor_producto_id_c!= $bean->fetched_row['sor_producto_id_c'])||($bean->sor_loterias_id_c!= $bean->fetched_row['sor_loterias_id_c'])||($bean->hora_sorteo!= $bean->fetched_row['hora_sorteo']) ||($bean->minuto_sorteo!= $bean->fetched_row['minuto_sorteo']))
		{
			$resultado=$this->realiza_controles($bean,$mensaje);
			if(!($resultado)){
				$this->mostrar_msg($bean, $event, $arguments,$mensaje);
			}
			$this->actualiza_version_meses($bean,"Modificacion");
		}
	}
	// asigna el combre concatenando juego-dia-hora-loteria
	$bean->name=$bean->producto." ".$bean->producto." ".$bean->dia." ".$bean->hora_sorteo.":".$bean->minuto_sorteo." ".$bean->loteria;
	
}
function realiza_controles($bean,&$msj)	{
	
		$db = $GLOBALS['db'];
		$where="";
		//controla repetidos
		$dia=$bean->sor_dias_id_c;
		$producto=$bean->sor_producto_id_c;
		$loteria=$bean->sor_loterias_id_c;
		$where=" sor_dias_id_c=$dia and sor_producto_id_c='$producto' and sor_loterias_id_c='$loteria'";
		if (trim($bean->hora_sorteo)!=""){
			$hora_sorteo=$bean->hora_sorteo;
			if (trim($bean->minuto_sorteo)!=""){
				$minuto_sorteo=$bean->minuto_sorteo; 
			}else{
				$minuto_sorteo=0;
			}
			$where.=" and hora_sorteo=$hora_sorteo and minuto_sorteo=$minuto_sorteo";
		}
		
        
        $sql="select count(*) as cantidad from sor_dia_modelo where ".$where;
	
	
		$results = $db->query($sql, true);
		$row = $db->fetchByAssoc($results);
		if ($row['cantidad'] >0)
            {
				$msj="Ya existe un Dia Modelo con los datos ingresado";
				return false;
            }
			// controla que si eligio un juego padre,ya exista el dia modelo para santa fe
			/*
			if (trim($bean->producto_vinculado)!=""){
				$where=" sor_dias_id_c=$dia and sor_producto_id_c='$bean->sor_producto_id1_c' and sor_loterias_id_c='3'";
				if (trim($bean->hora_sorteo)!=""){
					$hora_sorteo=$bean->hora_sorteo;
					$minuto_sorteo=$bean->minuto_sorteo; 
					$where.=" and hora_sorteo=$hora_sorteo and minuto_sorteo=$minuto_sorteo";
				}
				$sql="select count(*) as cantidad from sor_dia_modelo where ".$where;
			
			
				$results = $db->query($sql, true);
				$row = $db->fetchByAssoc($results);
				if ($row['cantidad'] ==0)
					{
						$msj="El d&iacute;a modelo del extracto:".strtoupper($bean->producto_vinculado)."  no existe";
						return false;
					}
			}
			*/
        return true;
	}
	
	function mostrar_msg($bean, $event, $arguments,$mensaje)
	{	 
		 $_SESSION['myError']=$mensaje; 
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$action="&action=EditView"; //we need to have EditView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['return_module']; 
		 
		$offset=$_REQUEST['offset']; 
		if($offset=="") { 
		} else { 
			$offset="&offset=$offset"; 
		} 
		 
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="") { 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
			 
		if($recordId=="") { 
			$returnAction="&return_action=detailView"; 
		} else { 
			$recordId="&record=".$recordId; 
		} 
		 
		$url="index.php?module=".$module.$offset.$stamp.$action.$returnModule.$returnAction.$recordId; 
		header("Location: $url"); 
		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 
		exit;   //goto the location contained in header 
	}
	
	function actualiza_version_meses($bean,$accion)	{
	global $current_user;
		$db = $GLOBALS['db'];
		$id1="";
		$id_version1="";
		$id_nuevaversion1=
		$id2="";
		$id_version2="";
		$id_nuevaversion2="";
		$desconfirma=false;
		$desconfirma2=false;
		$i=1;
		
	// aumenta la version de sor_anuncios para los meses confirmados comprendidos entre el mes actual y el mes proximo
		$sql="select coalesce(id,0) id,id_version,confirmado from  sor_anuncios ";
		$sql.=" WHERE confirmado=1 AND (anio*100+mes) BETWEEN (YEAR(NOW())*100+MONTH(NOW())) AND (YEAR(DATE_ADD(NOW(),INTERVAL 1 MONTH))*100+MONTH(DATE_ADD(NOW(),INTERVAL 1 MONTH)))";
		$result = $db->query($sql, true);
		
		while ($row = $db->fetchByAssoc($result)){
				if ($i==1){
					$id1=$row['id'];
					$id_version1=$row['id_version'];
					if ($row['confirmado']=1) {
						$desconfirma=true;				
					}
				}else{
					$id2=$row['id'];
					$id_version2=$row['id_version'];
					if ($row['confirmado']=1) {
						$desconfirma2=true;				
					}
				}
				$i=$i+1;
			}
			//marca el mes actual y el siguiente como no confirmado
			if (trim($id1!="")){
				$id_nuevaversion1=$id_version1+1;				
				//$sql="UPDATE  sor_anuncios SET confirmado=0, id_version=$id_nuevaversion1, fecha_hora_confirmacion='1900/01/01'";
				$sql="UPDATE  sor_anuncios SET confirmado=0,  fecha_hora_confirmacion='1900/01/01'";
				$sql.=" WHERE  id= '".$id1."'";
				if ($desconfirma){
					// ingresa auditoria de cambio de estado
					$db->query($sql, true);
					$msj=" PROVISORIO ".strtoupper($accion)." DIA MODELO,dia:".$bean->dia." Producto:".$bean->producto." Loteria:".$bean->loteria." Hora:".$bean->hora_sorteo." Minutos:".$bean->minuto_sorteo;
					$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id1',now(),'text','CONFIRMADO','$msj','Estado',$current_user->id)	";
					//$GLOBALS['log']->fatal("insert estado id1->".$sql);
					$db->query($sql, true);
				}	
			//ingresa auditoria de cambios  si la version es mayor a cero, es decir,que ya fue confirmado al menos una vez
				if ($id_version1>0){
					
					$msj=$id_version1." ".strtoupper($accion)." DIA MODELO,dia:".$bean->dia." Producto:".$bean->producto." Loteria:".$bean->loteria." Hora:".$bean->hora_sorteo." Minutos:".$bean->minuto_sorteo;
					$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id1',now(),'text','$id_version1','$msj','Cambios',$current_user->id)	";
					//$GLOBALS['log']->fatal("insert cambio id1->".$sql);
					$db->query($sql, true);
				}
		}
		
		if (trim($id2!="")){
				$id_nuevaversion2=$id_version2+1;
				
				// $sql="UPDATE  sor_anuncios SET	confirmado=0,id_version=$id_nuevaversion2, fecha_hora_confirmacion='1900/01/01'";
				$sql="UPDATE  sor_anuncios SET	confirmado=0, fecha_hora_confirmacion='1900/01/01'";
				$sql.=" WHERE  id= '".$id2."'";
				//$GLOBALS['log']->fatal("UPDATE id2->".$sql);
				$db->query($sql, true);
				
				if ($desconfirma2){
					// ingresa auditoria de cambio de estado
					
					$msj=" PROVISORIO ".strtoupper($accion)." DIA MODELO,dia:".$bean->dia." Producto:".$bean->producto." Loteria:".$bean->loteria." Hora:".$bean->hora_sorteo." Minutos:".$bean->minuto_sorteo;
					$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id2',now(),'text','CONFIRMADO','$msj','Estado',$current_user->id)	";
					//$GLOBALS['log']->fatal("insert estado  id2->".$sql);
					$db->query($sql, true);
				}	
				
				//ingresa auditoria de cambios  si la version es mayor a cero, es decir,que ya fue confirmado al menos una vez
				if ($id_version2>0){
					
					$msj=$id_version2." ".strtoupper($accion)." DIA MODELO,dia:".$bean->dia." Producto:".$bean->producto." Loteria:".$bean->loteria." Hora:".$bean->hora_sorteo." Minutos:".$bean->minuto_sorteo;
					$sql="insert into sor_anuncios_audit (id,parent_id,date_created,data_type,before_value_string,after_value_string,field_name,created_by) values  (uuid(),'$id2',now(),'text','$id_version2','$msj','Cambios',$current_user->id)	";
					//$GLOBALS['log']->fatal("insert cambio  id2->".$sql);
					$db->query($sql, true);
				}
		}			
		
		
	}
}
?>