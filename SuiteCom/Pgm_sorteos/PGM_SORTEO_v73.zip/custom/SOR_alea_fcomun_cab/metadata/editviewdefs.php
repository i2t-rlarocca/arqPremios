<?php
$module_name = 'SOR_alea_fcomun_cab';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'sorteo',
            'studio' => 'visible',
            'label' => 'LBL_SORTEO',
			'displayParams' => array(
              'initial_filter' => '&producto_advanced=Quini 6',
            ),
          ),
          1 => '',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'aporte_premios',
            'label' => 'LBL_APORTE_PREMIOS',
          ),
          1 => 
          array (
            'name' => 'fondo_comun',
            'label' => 'LBL_FONDO_COMUN',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'premios',
            'label' => 'LBL_PREMIOS',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
?>
