<?php
include('parametros_app.php');
global $current_user;
$idusuario=$current_user->id;
$module_name = 'SOR_alea_fcomun_cab';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
		  4 => 
			array (
				'customCode' => '<input class="button"  onclick="window.open(\'http://'.$url_crm.'/index.php?action=ajaxui#ajaxUILoc=index.php?action=procesaCtaCte&module=SOR_alea_fcomun_cab&record='.$_REQUEST['record'].'&rnd='.time().'\',\'_self\');this.form.action.value=\'procesaCtaCte\';"  name="button"  value="Generar Cuenta Corriente"  type="submit">'
          ),
		   5 => 
          array (
            'customCode' => '<input class="button"  onclick="window.open(\'http://'.$servidor_jasper.'/Ejecutar_Reportes2.php?ruta_reporte=/'.$carpeta_reports.'/CAS/Cuentas_Corrientes/Cuenta_Corriente_ALEA/reporte_ctacte_pcia_alea&formato=PDF&param_id_cab_alea='.$_REQUEST['record'].'\');this.form.action.value=\'DetailView\';"  name="button"  value="Reporte Control ALEA"  type="submit">',
          ),
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => '',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'aporte_premios',
            'label' => 'LBL_APORTE_PREMIOS',
          ),
          1 => 
          array (
            'name' => 'fondo_comun',
            'label' => 'LBL_FONDO_COMUN',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'premios',
            'label' => 'LBL_PREMIOS',
          ),
          1 => 
          array (
            'name' => 'procesado',
            'label' => 'LBL_PROCESADO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'modified_by_name',
            'label' => 'LBL_MODIFIED_NAME',
          ),
          1 => 'date_modified',
        ),
      ),
    ),
  ),
);
?>
