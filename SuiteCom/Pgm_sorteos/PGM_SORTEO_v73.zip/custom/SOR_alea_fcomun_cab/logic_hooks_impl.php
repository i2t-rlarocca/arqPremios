<?php
require_once('modules/SOR_alea_fcomun_cab/SOR_alea_fcomun_cab.php');
// include('parametros_app.php');

class logic_hooks_impl {
	
	
	function generar_registros (&$bean, $event, $arguments) {
				include('parametros_app.php');
				// set nombre
					$bean->name = $bean->sorteo;
	 
					$GLOBALS['log']->fatal("LogikHooks_iml-Funcion: generar_registros - sorteo : ".$bean->sorteo); 
					$GLOBALS['log']->fatal("LogikHooks_iml-Funcion: generar_registros - id : ".$bean->id); 
				
				// Crear conexión
						
						$conn = new mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm);
							
						// Verificar la conexión
						if ($conn->connect_error) {
							die("Error de conexión: " . $conn->connect_error);
						}

						// Consulta SQL para verificar la cantidad de resultados
						$sql = "SELECT COUNT(*) AS cantidad 
								FROM sor_alea_fcomun_cab a
								INNER JOIN sor_alea_fcomun_det_sor_alea_fcomun_cab_c b ON b.sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_cab_ida = a.id
									AND b.deleted = 0
								INNER JOIN sor_alea_fcomun_det c ON c.id = b.sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_det_idb AND c.deleted = 0
								WHERE a.id = '" . $bean->id . "'";

						// Ejecutar la consulta
						$result = $conn->query($sql);

						// Obtener la cantidad de resultados
						if ($result->num_rows > 0) {
							$row = $result->fetch_assoc();
							$cantidad = $row['cantidad'];
							
							$GLOBALS['log']->fatal("LogikHooks_iml-Funcion: generar_registros - cantidad : ".$cantidad); 
							
							// Verificar la condición para ejecutar el procedimiento almacenado
							if ($cantidad == '0') {
								$GLOBALS['log']->fatal("LogikHooks_iml-Funcion: generar_registros - ok "); 
								/*
								// Llamada al procedimiento almacenado
								// $idPersona = 1; // Cambia esto al valor del ID de la persona
								$resultado = "";

								// Preparar la llamada al procedimiento almacenado
								$stmt = $conn->prepare("CALL sor_insertar_alea_detalle(?, @resultado)");
								$stmt->bind_param("s", $bean->id);

								// Ejecutar la llamada al procedimiento almacenado
								$stmt->execute();

								// Obtener el resultado del parámetro de salida
								$select = $conn->query("SELECT @resultado AS resultado");
								$row = $select->fetch_assoc();
								$output = $row['resultado'];
								
								$GLOBALS['log']->fatal("LogikHooks_iml-Funcion: generar_registros - output : ".$output); 
								// Verificar el resultado del parámetro de salida
								if ($output == "OK") {
									echo "La llamada al procedimiento almacenado fue exitosa.";
								} else {
									echo "La llamada al procedimiento almacenado no fue exitosa.";
								}
								*/
							} else {
								echo "La cantidad de resultados no cumple la condición para ejecutar el procedimiento almacenado.";
							}
						} else {
							echo "No se encontraron resultados en la consulta.";
						}

						// Cerrar la conexión
						$conn->close();
					
	}



	function updateTabla (&$bean, $event, $arguments) {
 	    include("parametros_app.php");
		$conn = new mysqli($servidor_crm,$usuario_crm ,$password_crm,$bd_crm);
							
						// Verificar la conexión
						if ($conn->connect_error) {
							die("Error de conexión: " . $conn->connect_error);
						}

						// Consulta SQL para verificar la cantidad de resultados
						$sql = "SELECT COUNT(*) AS cantidad 
								FROM sor_alea_fcomun_cab a
								INNER JOIN sor_alea_fcomun_det_sor_alea_fcomun_cab_c b ON b.sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_cab_ida = a.id
									AND b.deleted = 0
								INNER JOIN sor_alea_fcomun_det c ON c.id = b.sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_det_idb AND c.deleted = 0
								WHERE a.id = '" . $bean->id . "'";

						// Ejecutar la consulta
						$result = $conn->query($sql);

						// Obtener la cantidad de resultados
						if ($result->num_rows > 0) {
							$row = $result->fetch_assoc();
							$cantidad = $row['cantidad'];
							
							$GLOBALS['log']->fatal("LogikHooks_iml-Funcion: updateTabla - cantidad : ".$cantidad); 
							
							// Verificar la condición para ejecutar el procedimiento almacenado
							if ($cantidad == '0') {
								// Llamada al procedimiento almacenado
								// $idPersona = 1; // Cambia esto al valor del ID de la persona
								$resultado = "";

								// Preparar la llamada al procedimiento almacenado
								$stmt = $conn->prepare("CALL sor_insertar_alea_detalle(?, @resultado)");
								$stmt->bind_param("s", $bean->id);

								// Ejecutar la llamada al procedimiento almacenado
								$stmt->execute();

								// Obtener el resultado del parámetro de salida
								$select = $conn->query("SELECT @resultado AS resultado");
								$row = $select->fetch_assoc();
								$output = $row['resultado'];
								
								$GLOBALS['log']->fatal("LogikHooks_iml-Funcion: updateTabla - output : ".$output); 
								// Verificar el resultado del parámetro de salida
								if ($output == "OK") {
									echo "La llamada al procedimiento almacenado fue exitosa.";
								} else {
									echo "La llamada al procedimiento almacenado no fue exitosa.";
								}
							} else {
								echo "La cantidad de resultados no cumple la condición para ejecutar el procedimiento almacenado.";
							}
						} else {
							echo "No se encontraron resultados en la consulta.";
						}

						// Cerrar la conexión
						$conn->close();
		}
	
	
	function mostrar_msg($bean, $event, $arguments,$mensaje)
	{	 		

		$_SESSION['myError']=$mensaje; 
		
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$recordId=$bean->id; 
		$action="&action=DetailView"; // EditView"; //we need to have DetailView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['module'];      
		$offset=$_REQUEST['offset']; 
		if($offset=="") 
		{ 
		} else { 
			$offset="&offset=$offset"; 
		} 
     
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="")
		{ 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
         
		if($recordId==""){ 
			$returnAction="&return_action=DetailView"; 
		} else { 
			$recordId=""; 
		} 
     
	
	
		$url="index.php?module=".$module.$action.$recordId; 

		header("Location: $url"); 

		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 

		exit;   //goto the location contained in header 
	}
	
	
}
?>