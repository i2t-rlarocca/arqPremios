<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2023-01-19 11:12:55
$layout_defs["SOR_alea_fcomun_cab"]["subpanel_setup"]['sor_alea_fcomun_det_sor_alea_fcomun_cab'] = array (
  'order' => 100,
  'module' => 'SOR_alea_fcomun_det',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SOR_ALEA_FCOMUN_DET_SOR_ALEA_FCOMUN_CAB_FROM_SOR_ALEA_FCOMUN_DET_TITLE',
  'get_subpanel_data' => 'sor_alea_fcomun_det_sor_alea_fcomun_cab',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);

?>