<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_SOR_ALEA_FCOMUN_DET_SOR_ALEA_FCOMUN_CAB_FROM_SOR_ALEA_FCOMUN_DET_TITLE'] = 'ALEA - Fondo Comun - Detalle';

?>