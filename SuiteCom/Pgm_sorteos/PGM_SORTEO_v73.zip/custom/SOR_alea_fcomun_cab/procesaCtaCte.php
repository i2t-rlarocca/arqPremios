<?php
	require_once('include/MVC/SugarApplication.php');
	require_once('data/BeanFactory.php');  

	include('parametros_app.php');

	$msg = "";
	$grupo = "";

	$id		= $_REQUEST['record'];
	$offset	= $_REQUEST['offset'];
//	$stamp	= $_REQUEST['stamp'];
	$url	= "/index.php?module=SOR_alea_fcomun_cab&rnd=".time()."&action=DetailView&record=".$id;

	// $GLOBALS['log']->debug("validacion-cas02_cc_cntpoc_grp - url: $url");
	$GLOBALS['log']->fatal("Inicio funcion: procesaCtaCte"); 
	
	$bean = BeanFactory::getBean('SOR_alea_fcomun_cab', $id);	

	$identprc = $bean->id;
	$sor_pgmsorteo_id_c = $bean->sor_pgmsorteo_id_c;
	$GLOBALS['log']->fatal("validacion-SOR_alea_fcomun_cab -  idenprc: $identprc - servidor: $servidor_crm - usuario: $usuario_crm - db: $bd_crm");
	
	// Si el grupo es de tipo 'cc_p' - cuenta corriente provincia, tengo que validar secuencia y fecha de ultima contabilizacion
	// if ($grupo == 'cc_p') {
		$conexion2 = mysqli_connect($servidor_crm, $usuario_crm, $password_crm, $bd_crm) or die("Problemas con la conexion");
		$q2 = "SELECT  a.premios AS premios_cab, a.fondo_comun AS fondo_comun_cab, a.aporte_premios AS aporte_premios_cab,
					SUM(c.premios) AS premios_det, SUM(c.fondo_comun) AS fondo_comun_det, SUM(c.aporte_premios) AS aporte_premios_det, sor_pgmsorteo_id_c
				FROM sor_alea_fcomun_cab a
				INNER JOIN sor_alea_fcomun_det_sor_alea_fcomun_cab_c b ON b.sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_cab_ida = a.id
					AND b.deleted = 0
				INNER JOIN sor_alea_fcomun_det c ON c.id = b.sor_alea_fcomun_det_sor_alea_fcomun_cabsor_alea_fcomun_det_idb AND c.deleted = 0
			WHERE a.id = '$id'
					;";
		
		// $GLOBALS['log']->debug("validacion-cas02_cc_cntpoc_grp - SQL: $q2");
		
		$res2=mysqli_query($conexion2, $q2);
		$row2 = mysqli_fetch_array($res2);

		$premios_cab = $row2['premios_cab'];
		$fondo_comun_cab = $row2['fondo_comun_cab'];
		$aporte_premios_cab = $row2['aporte_premios_cab'];
		$premios_det = $row2['premios_det'];
		$fondo_comun_det = $row2['fondo_comun_det'];
		$aporte_premios_det = $row2['aporte_premios_det'];
		$sor_pgmsorteo_id_c = $row2['sor_pgmsorteo_id_c'];
		
		mysqli_close($conexion2);
	
		// $GLOBALS['log']->fatal("validacion-cas02_cc_cntpoc_grp - hoy: $hoy - fecha_contabilizacion: '$fecha_contabilizacion' - val_fechacon: '$val_fechacon'");
		if($premios_cab != $premios_det){
			$GLOBALS['log']->fatal("SOR_alea_fcomun_cab - procesaCtaCte - validacion - premios");
			$msg = "EL total de Premios de cabecera y detalles no coincide";
		}
		if($fondo_comun_cab != $fondo_comun_det){
			$GLOBALS['log']->fatal("SOR_alea_fcomun_cab - procesaCtaCte - validacion - fondo comun");
			$msg = "El total de fondo comun de cabecera y detalles no coincide";
		}
			$GLOBALS['log']->fatal("SOR_alea_fcomun_cab - procesaCtaCte -  validacion - aporte premios". $aporte_premios_cab);
			$GLOBALS['log']->fatal("SOR_alea_fcomun_cab - procesaCtaCte -  validacion - aporte_premios_det". $aporte_premios_det);
		if($aporte_premios_cab != $aporte_premios_det ){
			$GLOBALS['log']->fatal("SOR_alea_fcomun_cab - procesaCtaCte -  validacion - aporte premios");
			$msg = "El total de aportes de premios de cabecera y detalles no coincide";
		}


	$UserId=0;
	$UserId=$GLOBALS['current_user']->id;
	
	
		$mysqli = NEW mysqli($servidor_crm, $usuario_crm, $password_crm, $bd_crm);
		// verificar conexion 
		if (mysqli_connect_errno()) {
			$msg = "Falla en la conexion: " . mysqli_connect_error();
		}

		if ($msg == "") {
			$stmt = $mysqli->stmt_init();
			// sor_procesa_ctascte_pcia_ALEA(IN par_juego INT,IN par_sorteo INT,IN id_proceso INT ,IN usuario VARCHAR(1204),OUT msgret VARCHAR(2048))
			$GLOBALS['log']->fatal("SOR_alea_fcomun_cab - antes de sor_procesa_ctascte_pcia_ALEA -  parametros - sor_pgmsorteo_id_c ". $sor_pgmsorteo_id_c," UserId: ",$UserId);
			$stmt->prepare("CALL sor_procesa_ctascte_pcia_ALEA('$sor_pgmsorteo_id_c', '$UserId', @msgret)");
			$stmt->execute();
				
			$resultado = $mysqli->query('SELECT @msgret as msgret');
			$fila = $resultado->fetch_assoc();
			$msgret = $fila['msgret'];
			// $RTxt = $fila['RTxt'];

			$GLOBALS['log']->fatal("validacion-SOR_alea_fcomun_cab - despues de ejecutar sor_procesa_ctascte_pcia_ALEA - msgret: : " . print_r($msgret, true));
			
			mysqli_free_result($resultado);
			mysqli_stmt_close($stmt);		

			// if($Rcode != 1){
			if($msgret !='OK'){
				// mysqli_close($conexion);
				$msg = "Ocurrio un problema al procesar la cuenta corriente ALEA";
			}
			if($msgret =='OK'){
				// Si ok, actualizar en la cabecera procesado = 1 y el usuario y fecha de modificación.
					$db = $GLOBALS['db'];
		
					$q = "UPDATE sor_alea_fcomun_cab  SET procesado = 1, date_modified = now(), modified_user_id = '".$UserId."'";
					$q.= " WHERE id ='".$bean->id."'";		

					$bean->db->query($q, true);
			}
		}
	
	
	$GLOBALS['log']->fatal("ProcesaCtaCte - validacion - SOR_alea_fcomun_cab - fin - mensaje: $msg");
	
	if ($msg != "") {
		SugarApplication::appendErrorMessage($msg);
		$params = array(
				'module'=> 'SOR_alea_fcomun_cab',
				'action'=>'DetailView', 
				'record' => $id,
				);
		//$_SESSION['MyBean']=$bean;
		SugarApplication::redirect('index.php?' . http_build_query($params));
		return false;		
	} else {
		echo ("<h2> Procesando... </h2>");
		sleep(5);

		$urlReload = $protocolo.$url_crm.$url;
		$GLOBALS['log']->fatal("Fin ProcesaCtaCte - SOR_alea_fcomun_cab -  urlReload ->".$urlReload);
		header("Refresh:4; URL=".$urlReload);		
		exit;
	}

	
?>


