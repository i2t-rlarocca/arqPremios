function RecorrerForm()
{
	var sAux="";
	var frm = document.getElementById("EditView");
	$('#fecha_alta_trigger').hide();
	for (i=0;i<frm.elements.length;i++)
	{
		if (frm.elements[i].name=="duplicateSave"){
			sAux = "duplicateSave";
		}
	}

	if (sAux==""){
		for (i=0;i<frm.elements.length;i++)
		{
			
			if (frm.elements[i].value=="Cancelar"){
				
			}else{
			frm.elements[i].disabled=true
			
			}
		}
	}else{
		for (i=0;i<frm.elements.length;i++)
		{
			
			if (frm.elements[i].name=="name" && frm.elements[i].id=="name"){
				//frm.elements[i].style.display = "none";
				frm.elements[i].value="Medio-Proveedor-Espacio-Vigencia"
				frm.elements[i].disabled=true
			}
		}
	}	
	//alert("Mensaje " + sAux);
}
$(document).ready( function () {
	RecorrerForm();	
			
});