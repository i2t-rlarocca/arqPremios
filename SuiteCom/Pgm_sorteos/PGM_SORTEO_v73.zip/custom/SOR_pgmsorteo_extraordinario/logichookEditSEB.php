<?php
class logichookEditSEB{
	
function customizar($event, $arguments) {

    if ($_REQUEST['action'] == 'EditView') {
	 

		// require_once 'verifica_funcion.php';

		$UserId=0;
		$UserId=$GLOBALS['current_user']->id;

		// $idPauta = 0;

		//die('Paso por aca!!!');
		$idPauta = $_REQUEST['record'];
		$idPautaDet = '';
		$NoEdita = 0;
		//Si el tarifario está en uso en alguna OP, deshabilita la edición. Se debe crear una nueva vigencia a través de Nuevo o Duplicar
		// $NoEdita = verifica_pauta_en_uso($idPauta, $idPautaDet);
		if ($NoEdita!=0)
            {
				echo "<script src=custom/modules/prn_pauta/Edicion_Limitada.js></script>";
            }ELSE{
				// echo "<script src=custom/modules/prn_pauta/Edicion_Limitada.js></script>";
				// echo "<script>alert('Mensaje propio 5');</script>";
			}
    }
  }
}
?>