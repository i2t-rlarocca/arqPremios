function RecorrerForm()
{
	
	//$('#name').attr('readonly', 'readonly');
	
	var sAux="";
	var frm = document.getElementById("EditView");
	//$('#fecha_alta_trigger').hide();
	for (i=0;i<frm.elements.length;i++)
	{
		
		if (frm.elements[i].name=="producto" || frm.elements[i].name=="btn_producto" || frm.elements[i].name=="btn_clr_producto" 
			|| frm.elements[i].name=="proveedor" || frm.elements[i].name=="btn_clr_proveedor" || frm.elements[i].name=="btn_clr_proveedor"
			 || frm.elements[i].name=="name" || frm.elements[i].name=="importe_neto" || frm.elements[i].name=="importe_total" || frm.elements[i].name=="importe_iva"){
				frm.elements[i].disabled=true;
		}
	}

/*	$('#email').removeAttr('disabled');
	$('#codigo_proveedor_estado').removeAttr('disabled');
	$('#SAVE_FOOTER').removeAttr('disabled');
	$('#SAVE_HEADER').removeAttr('disabled');
	$('#CANCEL_FOOTER').removeAttr('disabled');
	$('#CANCEL_HEADER').removeAttr('disabled');
*/
	}

$(document).ready( function () {
	RecorrerForm();	
			
});
 