<?php
class logichookSaveSEB{

function controlar ($bean, $event, $arguments)
{
	require_once('data/BeanFactory.php');    

	$mensaje="";
	$result = false;
	$result=$this->realiza_controles($bean,$mensaje);

	if ($result==false){
		$this->mostrar_msg($bean, $event, $arguments,$mensaje);
	}
}

function relaciones ($bean, $event, $arguments)
{
	require_once('data/BeanFactory.php');    

	$mensaje="";
	$result = false;

    $db=$GLOBALS['db'];
	// Armo las relaciones con SOR_pgmsorteo
	$q="DELETE FROM `sor_pgmsorteo_sor_pgmsorteo_extraordinario_c`	WHERE `sor_pgmsord895dinario_idb` = '$bean->id';";
	
	$result = $db->query($q, true);
	if ($result==true) {
		$q="INSERT INTO `sor_pgmsorteo_sor_pgmsorteo_extraordinario_c` VALUES(UUID(), NOW(), 0, '$bean->sor_pgmsorteo_id_c', '$bean->id');";
		$result = $db->query($q, true);
		if ($result!=true) {
			$mensaje = "Fallo el insert de la relacion con programa de sorteo '$bean->sor_pgmsorteo_id_c'" ;
		}
	} else {
		$mensaje = "Fallo el delete de la relacion con programa de sorteo '$bean->sor_pgmsorteo_id_c'" ;
	}
	// Armo las relaciones con SOR_producto
	$q="DELETE FROM `sor_producto_sor_pgmsorteo_extraordinario_c`	WHERE `sor_produc2491dinario_idb` = '$bean->id';";
	$result = $db->query($q, true);
	if ($result==true) {
		$q="INSERT INTO `sor_producto_sor_pgmsorteo_extraordinario_c` VALUES(UUID(), NOW(), 0, '$bean->sor_producto_id_c', '$bean->id');";
		$result = $db->query($q, true);
		if ($result!=true) {
			$mensaje = "Fallo el insert de la relacion con producto '$bean->sor_producto_id_c'" ;
		}
	} else {
		$mensaje = "Fallo el delete de la relacion con producto '$bean->sor_producto_id_c'" ;
	}

	// Armo las relaciones con SOR_modalidades
	$q="DELETE FROM `sor_modalidades_sor_pgmsorteo_extraordinario_c`	WHERE `sor_modali47dcdinario_idb` = '$bean->id';";
	$result = $db->query($q, true);
	if ($result==true) {
		$q="INSERT INTO `sor_modalidades_sor_pgmsorteo_extraordinario_c` VALUES(UUID(), NOW(), 0, '$bean->sor_modalidades_id_c', '$bean->id');";
		$result = $db->query($q, true);
		if ($result!=true) {
			$mensaje = "Fallo el insert de la relacion con modalidades '$bean->sor_modalidades_id_c'" ;
		}
	} else {
		$mensaje = "Fallo el delete de la relacion con modalidades '$bean->sor_modalidades_id_c'" ;
	}

	if ($mensaje!=""){
		$this->mostrar_msg($bean, $event, $arguments, $mensaje);
	}
}



function realiza_controles($bean, &$msj) {

	require_once 'verifica_funcion.php';
	
	$msj="";
	
	$UserId=0;
	$UserId=$GLOBALS['current_user']->id;

	// Busco el sorteo para encontrar PRODUCTO/MODALIDAD
	$bSORTEO = BeanFactory::getBean("SOR_pgmsorteo", $bean->sor_pgmsorteo_id_c);
	if ($bSORTEO->sor_producto_id_c == NULL )
    {
	 		$msj="Debe indicar un sorteo existente";
	 		return false;
    }
	// Veo que no exista una extencion para este sorteo con distinto ID!!!
	$resultado = split(";", verificar_sorteo_extraordinario($bean->sor_pgmsorteo_id_c, $bean->id));	
	if ($resultado[0] == "ERROR") {
	 		$msj=$resultado[1];
	 		return false;
	}

	// Busca la modalidad, devuelve un string con 2 valores separados por ;, el primer valor es el resultado (OK o ERROR)
	$resultado = split(";", obtener_modalidad($bSORTEO->sor_producto_id_c));	

	if ($resultado[0] == "ERROR") {
	 		$msj=$resultado[1];
	 		return false;
	}
	// Valores mayores a cero
	if ($bean->seb_valor_apuesta == 0 )
    {
	 		$msj="Debe indicar un valor para la apuesta";
	 		return false;
    }
	// if ($bean->seb_importe_premio_menor == 0 )
    // {
	 		// $msj="Debe indicar un valor para el importe de premios menores.";
	 		// return false;
    // }

	// Cargo el resto de los datos!
	$bean->sor_producto_id_c = $bSORTEO->sor_producto_id_c;
	$bean->sor_modalidades_id_c = $resultado[1];
	$bean->name = $bSORTEO->name;

	return true;
}

	function mostrar_msg($bean, $event, $arguments,$mensaje)
	{	 
		 $_SESSION['myError']=$mensaje; 
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$action="&action=EditView"; //we need to have EditView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['return_module']; 
		 
		$offset=$_REQUEST['offset']; 
		if($offset=="") { 
		} else { 
			$offset="&offset=$offset"; 
		} 
		 
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="") { 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
			 
		if($recordId=="") { 
			$returnAction="&return_action=detailView"; 
		} else { 
			$recordId="&record=".$recordId; 
		} 
		 
		$url="index.php?module=".$module.$offset.$stamp.$action.$returnModule.$returnAction.$recordId; 
		header("Location: $url"); 
		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 
		exit;   //goto the location contained in header 
	}    
}
?>