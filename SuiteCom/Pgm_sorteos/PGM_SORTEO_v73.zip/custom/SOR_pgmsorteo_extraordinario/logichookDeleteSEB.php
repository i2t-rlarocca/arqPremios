<?php
class logichookDeletePauta{

function controlar ($bean, $event, $arguments)
{
		require_once('data/BeanFactory.php');    
		
		$mensaje="";
		$result=$this->realiza_controles($bean,$mensaje);
		if ($result){
			
		}else{
			echo $mensaje;
			header("Refresh:3; URL=index.php?module=prn_pauta&action=index");
		    exit;
		}


}

function realiza_controles($bean, &$msj) {

	require_once 'verifica_funcion.php';
	
	$msj="";

	$UserId=0;
	$UserId=$GLOBALS['current_user']->id;

	$idPauta = "";

	//die('Paso por aca!!!');
	// $idPauta = $bean->id;

	$enUso = 0;
	
	//Si la pauta generó alguna OP, no permite eliminación.
	// $enUso = verifica_pauta_en_uso($idPauta, '');
	
	//var_dump($enUso);
	//die('Pasó por aquí');
	
	if ($enUso>0)
        {
			$msj="No puede eliminarse una extension cuando el sorteo fue...";
			return false;
        }else{
			$msj="";
			return true;
		}
    }

	function mostrar_msg($bean, $event, $arguments,$mensaje)
	{	 
		 $_SESSION['myError']=$mensaje; 
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$action="&action=EditView"; //we need to have EditView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['return_module']; 
		 
		$offset=$_REQUEST['offset']; 
		if($offset=="") { 
		} else { 
			$offset="&offset=$offset"; 
		} 
		 
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="") { 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
			 
		if($recordId=="") { 
			$returnAction="&return_action=detailView"; 
		} else { 
			$recordId="&record=".$recordId; 
		} 
		 
		$url="index.php?module=".$module.$offset.$stamp.$action.$returnModule.$returnAction.$recordId; 
		header("Location: $url"); 
		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 
		exit;   //goto the location contained in header 
	}    
}
?>