<?php
// Do not store anything in this file that is not part of the array or the hook version.  This file will	
// be automatically rebuilt in the future. 
$hook_version = 1; 
$hook_array = Array(); 
// $hook_array['after_ui_frame'] = Array(); 
// $hook_array['after_ui_frame'][] = Array(1, 'Customizar', 'custom/modules/SOR_pgmsorteo_extraordinario/logichookEditSEB.php', 'logichookEditSEB', 'customizar'); 
$hook_array['before_save'] = Array(); 
$hook_array['before_save'][] = Array(1, 'Controlar', 'custom/modules/SOR_pgmsorteo_extraordinario/logichookSaveSEB.php', 'logichookSaveSEB', 'controlar'); 
$hook_array['after_save'] = Array(); 
$hook_array['after_save'][] = Array(1, 'Controlar', 'custom/modules/SOR_pgmsorteo_extraordinario/logichookSaveSEB.php', 'logichookSaveSEB', 'relaciones'); 
// $hook_array['before_delete'] = Array(); 
// $hook_array['before_delete'][] = Array(1, 'Controlar', 'custom/modules/SOR_pgmsorteo_extraordinario/logichookDeleteSEB.php', 'logichookDeleteSEB', 'controlar'); 
?>

