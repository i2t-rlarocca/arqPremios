function RecorrerForm()
{
	var sAux="";
	var frm = document.getElementById("EditView");
	$('#fecha_alta_trigger').hide();
	for (i=0;i<frm.elements.length;i++)
	{
		
		if (frm.elements[i].value=="Cancelar"){
			
		}else{
		frm.elements[i].disabled=true
		
		}
	}
	
	//alert("Mensaje " + sAux);
}
$(document).ready( function () {
	RecorrerForm();	
			
});