<?php
class logichookCargos{
function controla ($bean, $event, $arguments)
{
	$resultado=$this->realiza_controles($bean,$mensaje);
	if(!($resultado)){
		$this->mostrar_msg($bean, $event, $arguments,$mensaje);
	}
	
}
function grab_dump($var)
		{
			ob_start();
			var_dump($var);
			return ob_get_clean();
		}
function realiza_controles($bean,&$msj)	{

/* no va mas!	   
		$bProd = BeanFactory::getBean("SOR_PRODUCTO", $bean->sor_producto_id_c);
		$GLOBALS['log']->fatal("[Guardar Cargo] toma producto - bProd: $bProd->prefijo - fin_operacion: $bProd->fin_operacion");
		if($bProd->fin_operacion != ""){
			$GLOBALS['log']->fatal("Está en blanco");
			$msj="El producto no está activo desde $bProd->fin_operacion";
			return false;
		}
*/

		$GLOBALS['log']->fatal("[Guardar Cargo] toma cargo - beanCargo: $bean->car_cargo");
		$bAuto = BeanFactory::getBean("SOR_Autoridades", $bean->sor_autoridades_id_c);
		$GLOBALS['log']->fatal("[Guardar Cargo] toma nombre de autoridad - bAutoNombre: $bAuto->name)");

		$db = $GLOBALS['db'];
		
		$sql="SELECT COUNT(*) AS cantidad";
		$sql.=" FROM sor_cargos a  ";
		$sql.=" WHERE a.deleted=0 and a.car_orden=$bean->car_orden AND a.id<>'$bean->id' AND a.sor_autoridades_id_c='$bAuto->id'";
		$results = $db->query($sql, true);
		$row = $db->fetchByAssoc($results);
		if ($row['cantidad'] >0)
			{
				$msj="Ya existe la combinación AUTORIDAD-CARGO: ".trim($bean->car_cargo).'-'.trim($bAuto->name);
				return false;
			}
		


		$bean->name = trim($bean->car_cargo).'-'.trim($bAuto->name);
		$bean->assigned_user_id=$bAuto->assigned_user_id;
		$GLOBALS['log']->fatal("[Guardar Cargo] nombre completo de cargo - bean: $bean->name");
	
		return true;
	}

	
	function mostrar_msg($bean, $event, $arguments,$mensaje)
	{	 
		 $_SESSION['myError']=$mensaje; 
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$action="&action=EditView"; //we need to have EditView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['return_module']; 
		 
		$offset=$_REQUEST['offset']; 
		if($offset=="") { 
		} else { 
			$offset="&offset=$offset"; 
		} 
		 
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="") { 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
			 
		if($recordId=="") { 
			$returnAction="&return_action=detailView"; 
		} else { 
			$recordId="&record=".$recordId; 
		} 
		 
		$url="index.php?module=".$module.$offset.$stamp.$action.$returnModule.$returnAction.$recordId; 
		header("Location: $url"); 
		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 
		exit;   //goto the location contained in header 
	}
}
?>