<?php
$module_name = 'SOR_MODALIDADES_EXT';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'producto',
            'studio' => 'visible',
            'label' => 'LBL_PRODUCTO',
/*
// Deberian ser Q6, BR y PF, ver por donde conviene seleccionar
			'displayParams' => array(
                'initial_filter' => '&id_categoria_advanced="QUINI SEIS"',				
			),
*/
			),
          1 => 
          array (
            'name' => 'modalidad',
            'studio' => 'visible',
            'label' => 'LBL_MODALIDAD',
			'displayParams' => array(
                // 'initial_filter' => '&producto_advanced="+encodeURIComponent(document.getElementById("producto").value)+"',				
                'initial_filter' => '&producto_advanced="+encodeURIComponent(document.getElementById("producto").value)+"&activa_advanced=1',				

				/* borrar, es ejemplo				
            'displayParams' => array(
                'initial_filter' => '&tipo_cmp_advanced="+encodeURIComponent(document.getElementById("filtroTipocomp").value)+"&tipo_sujeto_advanced="+encodeURIComponent(document.getElementById("tipoSujetoParam").value)+"&estado_advanced="+encodeURIComponent(document.getElementById("estadoParam").value)+"',
                ),
*/				
			),
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'nrosorteo',
            'label' => 'LBL_NROSORTEO',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'valor_apuesta',
            'label' => 'LBL_VALOR_APUESTA',
          ),
          1 => 
          array (
            'name' => 'asegurado_minimo',
            'label' => 'LBL_ASEGURADO_MINIMO',
          ),
        ),
      ),
    ),
  ),
);
?>
