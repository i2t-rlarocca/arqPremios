<?php
class logichookModalidadExt{
	
	function controla (&$bean, $event, $arguments){
		$GLOBALS['log']->fatal("Sor_Modalidades_Ext - controla - inicio - event->".$event);
		
		$resultado=$this->realiza_controles($bean, $mensaje);

		$GLOBALS['log']->fatal("Sor_Modalidades_Ext - controla - fin controles - ajusta_estado->".$ajusta_estado);

		if(!($resultado)){
			$this->mostrar_msg($bean, $event, $arguments,$mensaje);			
		}
		// Rehago el NAME
	 	$bean->name = $bean->producto . " - " . $bean->modalidad . " sorteo " . $bean->nrosorteo;
	}
/*
	function grab_dump(&$var){
		ob_start();
		var_dump($var);
		return ob_get_clean();
	}

	function ajusto_estado_sor_anuncios()	{
		// Ajusto el estado del mes en curso
		$db = $GLOBALS['db'];
		
		$sql="UPDATE sor_anuncios SET confirmado = false, fecha_hora_confirmacion='1900/01/01' WHERE anio = YEAR(CURDATE()) AND mes = MONTH(CURDATE())";
		$GLOBALS['log']->fatal("Sor_Modalidades - el periodo actual ha sido pasado a provisorio ->".$sql);
		$db->query($sql, true);
		
	}
*/	
	function realiza_controles(&$bean, &$msj)	{
		$db = $GLOBALS['db'];

		$GLOBALS['log']->fatal("Sor_Modalidades_EXT - controles - producto->" . $bean->producto );
		$GLOBALS['log']->fatal("Sor_Modalidades_EXT - controles - id de producto->" . $bean->sor_producto_id_c );
		$GLOBALS['log']->fatal("Sor_Modalidades_EXT - controles - modalidad->" . $bean->modalidad );
		$GLOBALS['log']->fatal("Sor_Modalidades_EXT - controles - id modalidad->" . $bean->sor_modalidades_id_c );

		require_once('data/BeanFactory.php');    

		//el proudcto es obligatorio

		if(trim($bean->producto)=="" || trim($bean->sor_producto_id_c) =="" ){
			$msj="Ingrese PRODUCTO";
			return false;
		}
		//el modalidad es obligatorio
		if(trim($bean->modalidad)=="" || trim($bean->sor_modalidades_id_c) == "" ){
			$msj="Ingrese MODALIDAD";
			return false;
		}
		//el sorteo es obligatorio
		if($bean->nrosorteo == 0){
			$msj="Ingrese el número de sorteo";
			return false;
		}
		
		/* Controles:
						Producto: Q6, BR, PF
						Codigo de Modalidad: 1 o para Q6 3/7 (activa)
						Sorteo: No debe estar en sor_pgmsorteo
						Valor Apuesta / Pozo Mínimo Asegurado > 0 los 2
		*/

		// Recupero ID de modalidad
		$producto = BeanFactory::getBean("SOR_PRODUCTO", $bean->sor_producto_id_c);
		$GLOBALS['log']->fatal("Sor_Modalidades_EXT - localiza el prefijo del producto ->" . $producto->prefijo );
		if(!($producto->prefijo == "Q6" || $producto->prefijo == "BR" || $producto->prefijo == "PF" )){
			$msj="El producto seleccionado no es válido. Son válidos Quini 6, Brinco y Poc.Federal.";
			return false;
		}
		
		// Recupero ID de modalidad
		$modalidad = BeanFactory::getBean("SOR_MODALIDADES", $bean->sor_modalidades_id_c);
		$GLOBALS['log']->fatal("Sor_Modalidades_EXT - localiza el codigo de modalidad ->" . $modalidad->codigo_modalidad );

		// El codigo de modalidad es 1 o 3/7 solo para quini 6...
		if (!($modalidad->codigo_modalidad == 1 
				|| ($producto->prefijo == "Q6" && ($modalidad->codigo_modalidad == 3 || $modalidad->codigo_modalidad == 7)))){
			switch ($producto->prefijo){
				case "Q6":
					$msj="La modalidad seleccionada no es válida. Son válidas las modalidades 1, 3 y 7.";
					break;
				case "BR":
				case "PF":
					$msj="La modalidad seleccionada no es válida. Solo es válida la modalidad 1.";
					break;
			}
			return false;
		}

		// El valor de apuesta es menor que el actual para la modalidad...
		if ($bean->valor_apuesta < $modalidad->valor_apuesta) {
				$msj="El valor apuesta ingresado es menor al actual. Valor actual $modalidad->valor_apuesta";
				return false;
		}

		// El pozo asegurado es menor que el actual para la modalidad...
		if ($bean->asegurado_minimo < $modalidad->asegurado_minimo) {
				$msj="El pozo mínimo asegurado ingresado es menor al actual. Valor actual $modalidad->asegurado_minimo";
				return false;
		}

		// No debe haber sorteos el en sor_pgmsorteo igual o mayor al ingresado
		$cant = $this->verifico_sorteo($bean->sor_producto_id_c, $bean->nrosorteo);
		if ($cant > 0){
				$msj="El sorteo ya ha sido procesado";
				return false;
		}
		
		return true;
	}
	
	function verifico_sorteo($sor_producto_id_c, $nrosorteo){
		$cantidad=0;
		$db = $GLOBALS['db'];
		$sql="SELECT COUNT(*) AS cnt FROM sor_pgmsorteo WHERE sor_producto_id_c = $sor_producto_id_c AND nrosorteo >= $nrosorteo";			
		$results = $db->query($sql, true);
		$GLOBALS['log']->fatal("Sor_Modalidades_EXT - verifico_sorteo - sql->" . $sql ); 
		$row = $db->fetchByAssoc($results);
		$cantidad=$row['cnt'];
		$GLOBALS['log']->fatal("Sor_Modalidades_EXT - verifico_sorteo - sorteos->" . $cantidad);
		return  $cantidad;
	}
/*
	function controla_repetidos(&$bean){
		$db = $GLOBALS['db'];
		if (($bean->codigo_modalidad!= $bean->fetched_row['codigo_modalidad']) || ($bean->inicio_operaciones!= $bean->fetched_row['inicio_operaciones']) ){
			$sql="SELECT COUNT(*) AS cantidad,COALESCE(a.id,-1) AS idmodalidad ";
			$sql.=" FROM sor_modalidades  a  ";
			$sql.=" INNER JOIN sor_modalidades_sor_producto_c b ON a.id=b.sor_modalidades_sor_productosor_modalidades_idb  AND  b.deleted=0 ";
			$sql.=" INNER JOIN sor_producto c ON c.id=b.sor_modalidades_sor_productosor_producto_ida  AND  c.deleted=0 ";
			$sql.=" WHERE a.deleted=0 and a.codigo_modalidad=$bean->codigo_modalidad and c.id='$bean->sor_producto_id_c' and a.inicio_operaciones='$bean->inicio_operaciones'";

			$results = $db->query($sql, true);
			$row = $db->fetchByAssoc($results);
			if ($row['cantidad'] >0){
				return true;
			}
		}		
		return false;
	}
*/	
	function mostrar_msg(&$bean, $event, $arguments,$mensaje){	 
		 $_SESSION['myError']=$mensaje; 
		//build the URL to return to 
		$module=$_REQUEST['module']; 
		$action="&action=EditView"; //we need to have EditView b/c that is the action we are taking 
		$returnModule="&return_module=".$_REQUEST['return_module']; 
		 
		$offset=$_REQUEST['offset']; 
		if($offset=="") { 
		} else { 
			$offset="&offset=$offset"; 
		} 
		 
		$stamp=$_REQUEST['stamp']; 
		if($stamp=="") { 
		} else { 
			$stamp="&stamp=$stamp"; 
		} 
			 
		if($recordId=="") { 
			$returnAction="&return_action=detailView"; 
		} else { 
			$recordId="&record=".$recordId; 
		} 
		 
		$url="index.php?module=".$module.$offset.$stamp.$action.$returnModule.$returnAction.$recordId; 
		header("Location: $url"); 
		$_SESSION['MyBean']=$bean;  //store the bean in session so we can retrieve the values later 
		exit;   //goto the location contained in header 
	}
}
?>